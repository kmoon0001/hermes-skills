---
name: copilot-studio-blank-agent-build
description: "Zero-to-perfect Copilot Studio agent build: create a blank agent, then systematically populate every component using proven patterns and lessons from 100+ eval runs across therapy compliance agents. Covers instructions, topics, KBs, settings, system topics, test sets, and eval-driven validation.

**For the full end-to-end pipeline (intake → spec → YAML generation → QA gate → deploy → eval loop), use agent-builder-orchestrator.** This skill remains the authoritative step-by-step guide for manual blank-agent creation."
version: 1.0.0
author: Therapy AI Agents Pipeline
platforms: [windows]
---

# Copilot Studio Blank Agent Build

Build a perfect Copilot Studio agent from scratch. Proven workflow: create a blank agent in the UI, then populate every component using Dataverse PATCH, tools, and tested patterns — no UI editing needed.

## The Core Insight

Building a "perfect agent" is NOT about guessing what works. It's about:

1. **Starting blank** — a fresh agent with zero custom components
2. **Applying proven patterns** — every component type (instructions, topics, KBs, settings) has a known working shape validated across multiple agents
3. **Adding only what the agent needs** — no bloat, no unused topics, no conflicts
4. **Eval-validating** — every change is measured against SR and Conv scores

## Phase 0: Environment & Auth Setup

Before touching any agent, establish your auth pipeline. You'll need different tokens for different operations — using the wrong one silently fails.

### Auth Token Cheat Sheet

| Token | How to Get | Used For | Expiry | Scope |
|-------|-----------|----------|--------|-------|
| **Azure CLI token** | `az account get-access-token --resource https://{org}.crm.dynamics.com/` | Dataverse PATCH/POST (topics, instructions, KBs) | ~1 hr | Org-specific CRM |
| **MSAL PPAPI token** | `node refresh_tda_eval_token.cjs` (reads manage-agent.cache.json) | Gateway eval API (list testsets, start runs, poll) | ~15 min | Power Virtual Agents app |
| **PAC auth** | `pac auth create --environment https://{org}.crm.dynamics.com/` | `pac copilot` commands (list, publish) | Varies | Power Platform |
| **CDP-captured token** | Chrome DevTools / Playwright from browser eval page | Fallback when MSAL cache is empty | ~15 min | PPAPI user token |

**CRITICAL: Never overwrite one token with another.** The `az token` for Dataverse (resource ending in `.dynamics.com/`) is DIFFERENT from the MSAL eval token (scope `api://96ff4394-.../.default`). Writing the Dataverse token to `test-agent-token.txt` will 403 the Gateway.

### PAC Auth Setup
```bash
# List available environments
pac env list

# Create auth session
pac auth create --environment https://{org}.crm.dynamics.com/

# Verify
pac auth list
```

### MSAL Cache for Eval Tokens
The `manage-agent.cache.json` at `~/.copilot-studio-cli/` is populated by `pac auth` and VS Code extension. Use it to mint eval tokens without browser sign-in:
```bash
cd "D:/my agents copilot studio/pipeline"
node scripts/refresh_tda_eval_token.cjs
# Writes to ~/.copilot-studio-cli/test-agent-token.txt
```

### DevOps Credential File Inventory
| File | Location | Purpose |
|------|----------|---------|
| `manage-agent.cache.json` | `~/.copilot-studio-cli/` | MSAL cache for silent token refresh |
| `test-agent-token.txt` | `~/.copilot-studio-cli/` | PPAPI eval token (Gateway API) |
| `dataverse-token.txt` | `~/.copilot-studio-cli/` | Azure CLI Dataverse token (PATCH/POST) |
| `ppapi-token.txt` | `~/.copilot-studio-cli/` | Legacy PPAPI token (deprecated) |
| `conn.json` | `<workspace>/.mcs/conn.json` | Workspace connection config for push/pull |

## Phase 0.5: Environment Selection & Bot Discovery

### Find Your Environment
```bash
# List all environments
pac env list

# Sample output:
#   Index  Display Name            Environment ID                       Type
#   1      Therapy AI Agents Dev   a944fdf0-0d2e-e14d-8a73-0f5ffae23315  Trial
#   2      Therapy AI Agents Prod  6951ccc2-3791-ecf4-987f-3dab97bdc716  Production
```

### Find Your Bot
```bash
# List all bots in current env
pac copilot list

# Sample output:
#   Name                          Copilot ID                             Status
#   Medicare Part B Compliance    b0346795-4876-f111-ab0e-70a8a5b1b8cc   Provisioned

# Or query Dataverse directly
python3 << 'PY'
import json, urllib.request, subprocess
az = r'C:\Program Files\Microsoft SDKs\Azure\CLI2\wbin\az.cmd'
result = subprocess.run([az, 'account', 'get-access-token', '--resource', 'https://{org}.crm.dynamics.com/'],
                       capture_output=True, text=True, timeout=15)
TOKEN = json.loads(result.stdout)['accessToken']
H = {'Authorization': f'Bearer {TOKEN}', 'Accept': 'application/json'}
url = "https://{org}.crm.dynamics.com/api/data/v9.2/bots?$select=name,botid,schemaname"
req = urllib.request.Request(url, headers=H)
with urllib.request.urlopen(req, timeout=30) as resp:
    for b in json.loads(resp.read()).get('value', []):
        print(f"{b['name']:40s} {b['botid']}")
PY
```

### Workspace Directory Structure
Standard workspace layout for an agent:
```
<agent-dir>/
├── agent.mcs.yml              # Agent metadata + settings
├── topics/                    # Topic YAML files (*.mcs.yml)
├── .mcs/
│   └── conn.json              # Auth connection config
├── knowledge-sources/         # KB files
├── feedback_b_*.json          # Eval reports
├── I_*.yml                    # Instructions snapshot
├── T_*.yml                    # Topic snapshot
└── _index.json               # Component inventory
```

### Create Blank Agent

Proven pathways ranked by reliability.

### Pathway 1: Dataverse API PATCH (✅ Most Reliable — Use First)

**What it does:** Directly modifies the `data` YAML field of any botcomponent via REST API.
**Works for:** Custom topics (type 9), custom instructions (type 15), KB descriptions/names (types 14, 16)
**Does NOT work for:** System topic data (breaks publish), the `content` field (UI-only)

**Authentication — Azure CLI token (refreshes ~1hr):**
```python
import subprocess, json
az = r'C:\Program Files\Microsoft SDKs\Azure\CLI2\wbin\az.cmd'
result = subprocess.run([az, 'account', 'get-access-token', '--resource', 'https://{org}.crm.dynamics.com/'],
                       capture_output=True, text=True, timeout=15)
TOKEN = json.loads(result.stdout)['accessToken']
```

**Read current data:**
```python
import urllib.request
url = f"https://{org}.crm.dynamics.com/api/data/v9.2/botcomponents({componentId})?%24select=data"
req = urllib.request.Request(url, headers={'Authorization': f'Bearer {TOKEN}', 'Accept': 'application/json'})
with urllib.request.urlopen(req, timeout=30) as resp:
    current = json.loads(resp.read())['data']
```

**PATCH the data field:**
```python
new_data = current.replace('kind: AdaptiveDialog', 'kind: AdaptiveDialog\nmodelDescription: <new description>', 1)
patch_url = f"https://{org}.crm.dynamics.com/api/data/v9.2/botcomponents({componentId})"
patch_body = json.dumps({"data": new_data}).encode('utf-8')
patch_headers = {'Authorization': f'Bearer {TOKEN}', 'Content-Type': 'application/json', 'Accept': 'application/json'}
patch_req = urllib.request.Request(patch_url, data=patch_body, method='PATCH', headers=patch_headers)
with urllib.request.urlopen(patch_req, timeout=30) as resp:
    print(f"PATCH {resp.status}")  # 204 = success
```

**Update display name (not data — the component's name field):**
```python
# The display name is the botcomponent's `name` property, NOT in the YAML data
name_url = f"https://{org}.crm.dynamics.com/api/data/v9.2/botcomponents({componentId})"
name_body = json.dumps({"name": "New Display Name"}).encode('utf-8')
# Same PATCH call as above but with name field instead of data
```

**Failure mode diagnostics:**
| Error | Meaning | Fix |
|-------|---------|-----|
| HTTP 400 `Could not find a property named 'X'` | The column doesn't exist on the entity | Check field name — `data` and `name` are valid; `content`, `displayname` are NOT |
| HTTP 400 `Invalid filter` | The `$filter` value contains spaces or special chars | URL-encode the filter value with `urllib.parse.quote()` |
| HTTP 401/403 | Token expired or wrong resource | Refresh token — ensure resource ends with trailing `/` |
| HTTP 404 | Component ID wrong or belongs to different org | Verify component ID and org URL |
| HTTP 204 but publish fails | `data` YAML has semantic error (IncorrectTypeError, ExpressionError) | Read publish diagnostics from `synchronizationstatus` on the bot entity |

**CRITICAL: System topic data PATCH breaks publish.** PATCHing the `data` field of system topics (OnEscalate, OnError, OnSystemRedirect, OnConversationStart) returns HTTP 204 success but `pac copilot publish` then fails with `SynchronizationSystemError`. Recovery: revert the system topic data to its original content, re-publish. System topics must be edited through the Copilot Studio UI code editor only.

**CRITICAL: `data` vs `content` field.** `data` stores the YAML (patchable via API). `content` stores a different representation (not patchable via API — UI-only). PATCHing `content` returns HTTP 400.

### Pathway 2: manage-agent.bundle.js Push/Pull (✅ Reliable with Workspace)

**What it does:** Uses the LSP binary to push/pull topic YAMLs between a local workspace and Dataverse.
**Works for:** Full workspace sync — push all topics at once, pull all topics to disk
**Requires:** A workspace with `conn.json` (authentication config)

**Pull live agent to local workspace:**
```bash
node "D:/my agents copilot studio/pipeline/scripts/manage-agent.bundle.js" pull --workspace <path> --agent-id <botId> --tenant-id <tenantId> --environment-id <envId>
```

**Push local workspace to live agent:**
```bash
node "D:/my agents copilot studio/pipeline/scripts/manage-agent.bundle.js" push --workspace <path>
```

**Clone an agent (create local workspace from cloud agent):**
```bash
node "D:/my agents copilot studio/pipeline/scripts/manage-agent.bundle.js" clone --workspace <path> --agent-id <botId> --tenant-id <tenantId> --environment-id <envId>
```

**Validate workspace YAMLs:**
```bash
node "D:/my agents copilot studio/pipeline/scripts/manage-agent.bundle.js" validate --workspace <path>
```

**Publish after push:**
```bash
node "D:/my agents copilot studio/pipeline/scripts/manage-agent.bundle.js" publish --workspace <path>
```

**Limitations:**
- Requires `.mcs/conn.json` in the workspace (populated by `pac auth` or VS Code extension)
- Push/pull syncs ALL topics — cannot push a single topic
- May overwrite UI-side changes if pulling from stale workspace
- `conn.json` may point at a different agent than intended — verify `botId` matches

### Pathway 3: Dataverse API POST — Create New Topic (✅ Works, GUID From Response Header)

**What it does:** Creates a brand new topic botcomponent in Dataverse that doesn't exist yet.
**Works for:** Adding custom topics to an agent that was created blank.

```python
import urllib.request, json, uuid

url = f"https://{org}.crm.dynamics.com/api/data/v9.2/botcomponents"
headers = {
    'Authorization': f'Bearer {TOKEN}',
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'OData-MaxVersion': '4.0',
    'OData-Version': '4.0',
}

body = {
    "name": "Evaluation and Plan of Care Review",           # Display name
    "schemaname": f"auto_agent_XRF5I.EvaluationAndPlanOfCareReview",  # Unique schema name with customization prefix
    "componenttype": 9,                                       # 9 = topic
    "_parentbotid_value@odata.bind": f"/bots({botId})",       # Link to parent bot
    "data": "kind: AdaptiveDialog\n..."                       # Full YAML content
}

req = urllib.request.Request(url, data=json.dumps(body).encode(), headers=headers, method='POST')
try:
    with urllib.request.urlopen(req, timeout=30) as resp:
        new_id = resp.headers.get('OData-EntityId', '').split('(')[1].split(')')[0] if 'OData-EntityId' in resp.headers else '?'
        print(f"Created: {resp.status} — ID: {new_id}")
except urllib.error.HTTPError as e:
    err = e.read().decode()[:500]
    print(f"POST error {e.code}: {err}")
```

**CRITICAL — POST fails with 0x80060888 if parentbotid format is wrong:**
```python
# ✅ CORRECT — uses @odata.bind syntax
"_parentbotid_value@odata.bind": f"/bots({botId})"

# ❌ WRONG — setting _parentbotid_value directly as a GUID
"_parentbotid_value": botId  # Returns 0x80060888
```

**CRITICAL — schemaname needs a valid customization prefix:**
```python
# ✅ CORRECT — uses auto_agent_ prefix (varies by environment)
"schemaname": "auto_agent_XRF5I.EvaluationAndPlanOfCareReview"

# ❌ WRONG — no prefix or wrong prefix
"schemaname": "EvaluationAndPlanOfCareReview"  # Returns 0x800608ad

# Find the correct prefix:
# 1. GET a known existing topic's schemaname from the same bot
# 2. Copy the prefix (everything before the last '.')
# 3. Use it for new topics
```

### Pathway 4: pac CLI Push/Pull (⚠️ Reliable but Slow)

**What it does:** Uses the Power Platform CLI to push/pull agent content.
**Requires:** `pac auth` session, managed workspace.

```bash
# Create auth session
pac auth create --environment https://{org}.crm.dynamics.com/

# List agents
pac copilot list

# Pull agent
pac copilot extract-template --bot-id <botId> --output-directory <path>

# Publish
pac copilot publish --bot <botId>
```

**Publish cache quirk:** `pac copilot publish` may show "Failed [timestamp]" even on success — that's the LAST publish result, not the current one. Check `bot.publishedon` in Dataverse for the real timestamp.

### Pathway 5: Copilot Studio UI Code Editor (⚠️ Manual, Only Path for System Topics)

**When to use:** ONLY when PATCHing system topics (Conversation Start, OnError, OnEscalate, etc.) — the Dataverse API breaks publish for these.

**Steps:**
1. Open Copilot Studio → Topics → find the system topic
2. Click "Open code editor" (three dots menu)
3. Replace the YAML content
4. Save → Publish

**What NOT to do (proven broken):**
- **CDP Monaco injection**: `monaco` global is behind an iframe, `model.setValue` does NOT persist — Save button enables but commits original content
- **Playwright textarea injection**: Writes to accessibility textarea, not the editor model
- **CompositionEvent injection**: Shows false Save enable, commits original content

### Pathway 6: Gateway API (For Evals Only — NOT for Patching)

The PowerVA Gateway API (`powervamg.us-il107.gateway.prod.island.powerapps.com`) handles eval operations:
- `POST/GET .../makerevaluations` — start/list/query evals
- `GET .../makerevaluations/{id}/details` — per-case results  
- `POST .../publish` — **returns 404** (publish via Gateway does NOT work — use pac CLI or UI)

**DO NOT use the Gateway for topics/settings/KBs** — it has no write endpoints for agent configuration.

### Pathway Comparison

| Pathway | Speed | Reliability | Topics | KBs | Settings | System Topics | Auth Needed |
|---------|-------|-------------|--------|-----|----------|--------------|-------------|
| Dataverse API PATCH | ⚡ Fast | ✅ Reliable | ✅ | ✅ names/desc | ❌ | ❌ breaks publish | Azure CLI token |
| Dataverse API POST | ⚡ Fast | ✅ Works | ✅ New topics | ❌ | ❌ | ❌ | Azure CLI token |
| manage-agent.bundle.js | 🐢 Medium | ✅ Reliable | ✅ Batch | ✅ | ✅ | ❌ | MSAL cache |
| pac CLI | 🐢 Slow | ⚠️ Cache quirks | ✅ Extract | ✅ | ✅ | ❌ | pac auth |
| Copilot Studio UI | 🐢 Manual | ✅ Only path | ❌ | ❌ | ❌ | ✅ System topics | Browser session |
| Gateway API | ⚡ Fast | ✅ Evals only | ❌ | ❌ | ❌ | ❌ | PPAPI eval token |

## Phase 1: Create Blank Agent

### Option A: Copilot Studio UI
1. Go to Copilot Studio → Agents → + New agent
2. Give it a name (e.g. "Therapy Documentation Assistant")
3. Choose "Skip to create blank" — DO NOT use a template
4. Save — you now have a blank agent with only system topics

### Option B: Verify Blank State
After creation, confirm the agent has:
- Only system topics (Conversational boosting, Conversation Start, Greeting, Fallback, On Error, Escalate, etc.)
- No custom topics, no custom KBs, no custom actions
- Default settings (authentication, generative AI defaults)

Query from Dataverse:
```python
# After creating, check component count = 0 for ctype in (9, 14, 15, 16) with your bot's _parentbotid_value
# Should show only system components (managed, shared across bots)
```

## Phase 2: Instructions (componenttype 15)

### The Foundation
The instructions file is the single highest-leverage component. It defines:
- Agent role and scope
- Routing rules (Route A/B/C/D)
- Output contracts per route
- Guardrails
- Eval-specific directives

### Proven Template (therapy compliance agents)
```yaml
kind: GptComponentMetadata
displayName: <Agent Name>
instructions: |-
  # ROLE
  You are an AI-based <type> Compliance Auditor. You audit <document types> against <standards>.
  [Precise, one-paragraph mission statement]

  # SCOPE
  [What the agent DOES and DOES NOT do. Explicitly: "This is a REVIEW/ANALYSIS tool — NOT a documentation writer."]

  # APPROVED KNOWLEDGE SOURCES (priority order)
  1. <primary standard>
  2. <secondary standard>
  If sources conflict, follow the higher-ranked source.

  # ROUTING RULES
  - Route A — Document Review: A therapy note is provided.
  - Route B — General Compliance Question: No document; user asks conceptual/standards question.
  - Route C — Missing-Document Review Request: User asks for audit but no note.
  - Route D — Procedural/Workflow Question: User asks how to use the agent.

  # ROUTE B OUTPUT CONTRACT
  Answer directly from approved sources. Plain text, max 3 bullets or 4 sentences.

  # ROUTE D OUTPUT CONTRACT  
  Answer the workflow question directly. 2-4 sentences. Do NOT trigger document intake.

  # PROCEDURAL ROUTE EXPANSION — "how do I get" patterns (Route D)
  - Questions starting with "how do I get" are procedural Route D.
  - Questions about "what are the five sections" — Route B, list directly.
  - "Can you review my documentation for compliance with X" — Route B.

  # EVALUATION CONTEXT — DIRECT ANSWER REQUIRED
  ## DATA-SPARSE PROMPTS
  When the prompt asks without providing clinical text: answer directly. Do NOT use "framework", "based on available knowledge", or "the sources do not address". Do NOT refuse.
  ## DATA-RICH PROMPTS
  When user provides detailed clinical data: follow normal workflow, complete structured analysis.

  # GUARDRAILS
  G1. Source Grounding: Use only approved sources.
  G2. Review Scope: Only content in current conversation.
  G3. No Hallucination: Report only what is present/missing/required.
  G4. Citation Requirement: Every finding includes Issue, Standard, and inline citation.
  ...
responseInstructions: Respond concisely. Use formatting when it improves clarity.
aISettings:
  model:
    modelNameHint: <correct model for env>
```

### Key Rules from Failure Analysis
| Rule | Why | Evidence |
|------|-----|----------|
| 2000-6000 chars max | >8000 chars causes eval slowdown | Verified across 10+ agents |
| No contradictory caps | "under 800 chars" + "prioritize completeness" conflict | Conv dropped 20pp |
| No "No headers or markdown" | Blocks structured formatting for audits | +10-15 pts SR after removing |
| Conditional RESPONSE FORMAT | Structured for audits, plain for general | +10 pts SR verified |
| EVALUATION CONTEXT block | Prevents abstention on sparse queries | +5-15 pts verified |
| Route D expansion for "how do I get" | Prevents "paste the text" non-answers | Targets 4 SR failures |
| Agent mission clarity | "review" vs "draft" — test sets expect different output | +15 pts potential |
| No model safety override fights | Model's safety training can override instructions | Accept 80-85% ceiling on some topics |

### Pitfalls
- **Don't put Route D rules deep in the document** — buried rules don't reach the generative catch-all path. Put Route D and EVALUATION CONTEXT at the TOP of instructions.
- **Don't use "under 4 sentences" unconditionally** — use conditional format: structured for document reviews, plain for general Q&A
- **The responseInstructions box (Settings → Generative AI → Responses) OVERRIDES instructions** — make sure it doesn't contradict the main instructions
- **MS Learn citation requirements**: Microsoft's evaluation framework requires inline citations for groundedness. Do NOT tell the agent to suppress them.

## Phase 3: Settings

### authentication
```yaml
authenticationMode: None          # Was: Integrated — prevents connector gate from blocking general Qs
authenticationTrigger: AsNeeded   # Was: Always
```

**CRITICAL**: authenticationMode: None makes general questions answerable without sign-in. Connector/auth gate is the #1 SR failure driver when present (40-67% of failures).

### generative AI settings
```yaml
webBrowsing: false                # OFF for PHI-handling agents
codeInterpreter: false
applyModelKnowledgeSetting: true  # Let the model use its training for general knowledge
generateAnswers: true             # Use generative answers for topics
```

### Pre-Flight Settings Check
- [ ] authMode=None avoids connector gate blocking general questions
- [ ] webBrowsing=false for PHI/compliance
- [ ] responseInstructions has NO "No headers or markdown"
- [ ] responseInstructions has NO "under N sentences" unconditional length cap
- [ ] Model matches environment (GPT55Chat, Sonnet46, etc.)

## Phase 4: System Topics

### What Stays, What Goes

| Topic | Action | Why |
|-------|--------|-----|
| **Conversational boosting** | KEEP — add `additionalInstructions` | Catch-all for unmatched queries |
| **Conversation Start** | DEACTIVATE or make minimal | Fires on EVERY conversation — kills SR eval |
| **Greeting** | ADD specific trigger phrases only | Keep it active but narrow — generic greeting steals Conv turns |
| **Fallback** | REWRITE — helpful reprompt, not "I am not sure" | "I am not sure" causes abstention fails |
| **On Error** | KEEP default (or add minimal logging) | Graceful error handling |
| **Escalate** | KEEP default | Transfers to human when needed |
| **Sign in** | DEACTIVATE when authMode=None | Not needed |

### Conversational Boosting — additionalInstructions
```yaml
additionalInstructions: |-
  Provide specific requirements with inline citations. Never fabricate.
```

**Without this**, the catch-all produces generic answers that fail Groundedness checks.

### Conversation Start — Minimal
```yaml
kind: AdaptiveDialog
beginDialog:
  kind: OnConversationStart
  actions:
    - kind: SendActivity
      id: send_greeting
      activity: "Hello, I'm the <Agent Name>. How can I help?"
```

**OR** deactivate it (statecode=1) if the greeting causes eval failures.

### Fallback — Helpful Reprompt
```yaml
kind: AdaptiveDialog
beginDialog:
  kind: OnUnknownIntent
  actions:
    - kind: SearchAndSummarizeContent
      id: search
      userInput: =System.Activity.Text
      additionalInstructions: ...
      allowLatencyMessage: false
    - kind: ConditionGroup
      conditions:
        - condition: =Not(IsBlank(Topic.Answer))
          actions:
            - kind: SendActivity
              activity: =Topic.Answer
            - kind: EndDialog
      elseActions:
        - kind: SendActivity
          activity: |-
            I can help with: [list agent capabilities]. 
            Describe what you need or paste a document.
        - kind: EndDialog
```

## Phase 5: Custom Topics

### Topic Names — MS Learn Optimized
Every topic display name must follow these rules:

| Rule | Example ✅ | Anti-Example ❌ |
|------|-----------|-----------------|
| Descriptive — says what the topic DOES | `Evaluation and Plan of Care Review` | `Topic1` or `DocReview` |
| Consistent naming convention | `Progress Report Review`, `Discharge Summary Review` | `eval_Review`, `DischargeSummaryProgCheck` |
| No periods in the name | `Episode of Care` | `Episode.of.Care` |
| No trailing spaces | `Treatment Encounter Note Review` | `Treatment Encounter Note Review ` |
| Under 50 chars (truncated in UI if longer) | `Large Document OCR Extraction` | `The Comprehensive Multi-Discipline Therapy Documentation Compliance Audit and Analysis Topic` |
| Document type is the first meaningful word | `Progress Report Review` | `Review of Progress Reports by Type` |
| Parallel structure across similar topics | `Evaluation and Plan of Care Review` matches `Progress Report Review` | Mix of `X Review`, `Reviewing X`, `X Audit` |

**How to apply via Dataverse PATCH:**
The topic's display name is stored in the botcomponent `name` field. Change it with:
```http
PATCH https://{org}.crm.dynamics.com/api/data/v9.2/botcomponents({componentId})
Content-Type: application/json

{"name": "Progress Report Review"}
```
The `schemaname` field (immutable) stays the same — only the display `name` changes.

### Topic Descriptions (modelDescription)
Every topic MUST have a `modelDescription` that describes WHAT the topic handles, NOT how it works.

| Rule | Example ✅ | Anti-Example ❌ |
|------|-----------|-----------------|
| Describes what the topic does (not implementation) | `Reviews therapy progress notes for Medicare Part B compliance — goal progress, medical necessity, skilled intervention, outcomes, and discharge readiness.` | `Contains SearchAndSummarizeContent node with additionalInstructions and EndDialog.` |
| Unique across all topics | Only one topic has this exact description | Two topics say "Handles user document questions" |
| Matches the trigger phrases | If triggers mention "progress report", description should say "progress report" | Generic: "Handles user questions about documents" |
| Helps AI routing select the correct topic | `Routes treatment encounter notes to compliance review — assesses skilled service justification, clinical reasoning, and denial risk per Chapter 15.` | `For treatment encounter notes.` |
| 1-3 sentences | Coverage, purpose, outcome | One word or an entire paragraph |
| No implementation details | Don't mention SearchAndSummarizeContent, BeginDialog, EndDialog, or variable names | `Uses SearchAndSummarizeContent to find answers and then sends via SendActivity` |

**How to add modelDescription via Dataverse PATCH:**
Insert `modelDescription: <text>` after the `kind:` line in the topic's YAML data:
```yaml
kind: AdaptiveDialog
modelDescription: Reviews therapy progress notes for Medicare Part B compliance — evaluates goal progress, medical necessity, skilled intervention, outcomes, and discharge readiness.
beginDialog:
  ...
```

**Proven descriptions for common therapy topics:**
| Topic | modelDescription |
|-------|-----------------|
| Evaluation and Plan of Care Review | Reviews therapy evaluation and plan of care documentation for Medicare Part B compliance — assesses medical necessity, goal appropriateness, skilled service justification, and denial risk per CMS Chapter 15. |
| Treatment Encounter Note Review | Reviews treatment encounter notes for Medicare Part B compliance — evaluates skilled intervention documentation, clinical reasoning, progress toward goals, and response to treatment. |
| Progress Report Review | Reviews therapy progress notes for Medicare Part B compliance — assesses goal progress, medical necessity for continued therapy, skilled service justification, and discharge readiness planning. |
| Discharge Summary Review | Reviews therapy discharge summaries for Medicare Part B compliance — evaluates discharge planning, care continuity, functional outcomes, follow-up recommendations, and goal achievement. |
| Recertification or UPOC Review | Reviews recertification and updated plans of care for Medicare Part B compliance — assesses continued skilled need, goal updates, plan revisions, and certification timing requirements. |
| Episode of Care | Provides longitudinal compliance audit across all therapy documentation for a full episode of care — evaluates consistency, medical necessity progression, and cumulative denial risk across evaluations, progress notes, recertifications, and discharge summaries. |
| Large Document OCR Extraction | Handles scanned or image-based therapy documents requiring OCR text extraction before compliance review can be performed. Manages asynchronous job submission, status checking, and result retrieval. |
| Document Upload Intake | Routes users to the correct therapy documentation review topic based on the document type they want to submit (evaluation, treatment note, progress report, recertification, discharge summary, or episode of care). |
| Conversation Start | Answers the user's first therapy documentation or Medicare compliance request directly using the configured knowledge sources and agent instructions. Provides a brief introduction and invites the user to describe their documentation needs. |
| Greeting | Welcomes returning users and briefly explains agent capabilities — lists supported document types for compliance review and invites the user to describe what they need. |

### Topic Template (for each document type)
```yaml
kind: AdaptiveDialog
modelDescription: <unique description of what this topic handles — helps AI routing>
beginDialog:
  kind: OnRecognizedIntent
  intent:
    displayName: <Topic Name>
    triggerQueries:
      - <5-10 natural language phrases>
  actions:
    - kind: SearchAndSummarizeContent
      id: search_document_review
      userInput: =System.Activity.Text
      additionalInstructions: |-
        <2-4 bullet points specific to this topic>
      allowLatencyMessage: false
      applyModelKnowledgeSetting: true
      responseCaptureType: FullResponse   # **CRITICAL** — missing this causes incomplete eval responses
    - kind: SendActivity
      id: send_answer
      activity: =Topic.Answer
    - kind: EndDialog
      id: end_topic
      clearTopicQueue: true
```

### Document Upload Intake — Pre-Check Pattern
For agents that accept document uploads, add a pre-check ConditionGroup BEFORE the Question node:
```yaml
    - kind: ConditionGroup
      id: precheck_doc_type
      conditions:
        - id: check_eval_pre
          condition: ="evaluation" in Lower(System.Activity.Text) || "plan of care" in Lower(System.Activity.Text)
          actions:
            - kind: SetVariable
              id: setvar_eval_pre
              variable: Topic.DocumentTypeSelection
              value: ='<schema>.topic.DocumentUploadIntake.main.question_document_type'.'Evaluation and Plan of Care'
            - kind: GotoAction
              id: goto_route
              actionId: conditionGroup_route
        # ... additional conditions for each doc type
    - kind: Question
      id: question_document_type
      # ... fall through to Question if no type detected
```

### Critical Topic Rules
| Rule | Why |
|------|-----|
| EndDialog + clearTopicQueue: true on EVERY topic | Prevents context bleed between topics |
| No Question nodes in audit/answer topics | Kills SR eval — grader sees question, not answer |
| SearchAndSummarizeContent with userInput: =System.Activity.Text | Ensures user's question is used for search |
| responseCaptureType: FullResponse on EVERY SSC node | Missing = incomplete eval responses |
| allowLatencyMessage: false | Prevents the "searching..." message from being counted as answer |
| Model descriptions present + unique | Helps AI routing select correct topic |
| 5-10 trigger phrases per topic, natural language | No robot phrases, no overlaps with other topics |

## Phase 6: Knowledge Sources

### KB Requirements
| Attribute | Requirement | Dataverse Implementation |
|-----------|-------------|--------------------------|
| displayName | Descriptive, unique — "CMS MDS 3.0 RAI Manual v1.18" NOT "doc.pdf" | Add `displayName:` to the component's `data` YAML field |
| description | 1-2 sentences on what the source covers — critical for AI routing | Add `description:` to the component's `data` YAML field |
| Official designation | Mark as "Official" for compliance sources — this tells the AI to prioritize this source over general knowledge | Set `isOfficialDataSource: true` in the component's `data` YAML |
| File uploads | Under 5MB per MS Learn | Upload via Copilot Studio UI → Knowledge → Add knowledge → Upload files |
| No duplicates | Same content in multiple KBs = double retrieval issues | Check for duplicate schemanames |

### Marking Knowledge Sources as Official

"Official" designation tells Copilot Studio's AI that this KB is an authoritative source and should be prioritized over the model's general training data. This is critical for compliance agents where CMS regulations, clinical guidelines, and legal standards must take precedence.

**Dataverse structure for an Official KB (type 14 — File):**
```yaml
kind: FileAttachmentComponentMetadata
displayName: CMS Medicare Benefit Policy Manual Chapter 15
description: Official CMS Medicare Benefit Policy Manual Chapter 15 covering coverage of therapy services in SNFs — skilled necessity, documentation requirements, and payment rules for PT, OT, and SLP.
isOfficialDataSource: true
```

**Dataverse structure for an Official KB (type 16 — Web/URL):**
```yaml
kind: KnowledgeSourceConfiguration
displayName: APTA Clinical Practice Guidelines — Therapy Documentation
description: Official American Physical Therapy Association clinical practice guidelines for evidence-based physical therapy documentation, covering examination procedures, intervention documentation standards, and outcome measurement.
isOfficialDataSource: true
source:
  kind: PublicSiteSearchSource
  site: https://www.apta.org/patient-care
```

**How to set Official via Dataverse PATCH:**
```python
# Read current data, add isOfficialDataSource: true, PATCH back
current_data = comp.get('data', '')
# Insert displayName, description, isOfficialDataSource after the kind line
new_data = current_data.replace(
    'kind: FileAttachmentComponentMetadata',
    'kind: FileAttachmentComponentMetadata\ndisplayName: <descriptive name>\ndescription: <1-2 sentence description>\nisOfficialDataSource: true'
)
# PATCH
urllib.request.Request(url, data=json.dumps({"data": new_data}).encode(), method='PATCH', headers=headers)
```

**How to set Official via Copilot Studio UI:**
1. Go to agent → Knowledge tab
2. Select the knowledge source
3. In the details panel, toggle "Official" ON
4. Save

**Which KBs should be Official:**
| Type | Mark Official? | Reason |
|------|---------------|--------|
| CMS manuals and regulations | ✅ YES | These are primary compliance standards |
| Clinical practice guidelines (APTA, AOTA, ASHA) | ✅ YES | Evidence-based clinical standards |
| CMS FAQ documents (Jimmo, etc.) | ✅ YES | Official CMS clarifications |
| Internal company policies | ⚠️ Only if compliance-relevant | May conflict with CMS if not aligned |
| Public website knowledge sources | ✅ YES | Grounds the agent in authoritative web content |
| General reference materials | ❌ NO | Let the model use its training for these |

### MS Learn-Optimized displayName and description Examples

| Source Type | displayName | description |
|-------------|-------------|-------------|
| CMS PDF | CMS Medicare Benefit Policy Manual Chapter 15 — Therapy Coverage | Official CMS manual covering skilled therapy coverage in SNFs, including Part B documentation requirements, certification/recertification rules, and payment policies. |
| APTA Guidelines | APTA Clinical Practice Guidelines — PT Documentation | Official American Physical Therapy Association evidence-based clinical practice guidelines for physical therapy documentation standards and examination procedures. |
| Jimmo Settlement | Jimmo v. Sebelius CMS Settlement FAQ | Official CMS frequently asked questions regarding the Jimmo v. Sebelius settlement clarifying that the improvement standard does not apply to Medicare coverage. |
| Internal Guide | Therapy Documentation Assistant Configuration Guide | Configuration guide for setup instructions, supported document types (evaluations, treatment notes, progress reports, recertifications, discharge summaries, episodes of care), and workflow guidance for compliance review. |
| Web Source | Ensign 7 Habits Documentation Framework | Ensign 7 Habits clinical documentation framework for skilled therapy justification, covering clinical reasoning, individualized care planning, and defensible documentation practices. |

### KB Verification Checklist
- [ ] Every KB has a non-empty `displayName`
- [ ] Every KB has a unique, descriptive `description` (1-2 sentences)
- [ ] Compliance/regulatory KBs are marked `isOfficialDataSource: true`
- [ ] No two KBs have the same or overlapping descriptions
- [ ] No KB uses a generic filename as its display name (no "doc1.pdf" or "untitled.txt")
- [ ] KB descriptions match what the source actually covers (no misleading descriptions)
- [ ] File uploads are under 5MB
- [ ] Public website URLs are valid and accessible

### KB Gap Analysis
After first eval run:
1. Classify groundedness=No failures by missing content type
2. Search authoritative sources (CMS.gov, APTA, AOTA, ASHA, AHRQ)
3. Download/upload with proper naming/description
4. Re-run eval

## Phase 7: Test Sets

### Create Test Sets
Use Copilot Studio UI → Evaluate → New evaluation:
- **SR set**: 100 cases — single-turn questions covering every topic + general compliance
- **Conv set**: 20 cases — multi-turn conversations testing follow-up context

### Test Set Requirements
| Attribute | SR | Conv |
|-----------|-----|------|
| Cases | 100 | 20 |
| Expected answer provided | YES — critical for grading | YES — per turn |
| At least 3 turns per case | N/A | YES |
| Document text embedded | For review-type cases | For document upload scenarios |
| Edge cases included | Out-of-scope, malformed queries | Interruptions, corrections |

### Golden Rule
Test cases must match the agent's ACTUAL scope. If the agent reviews documentation, don't ask it to draft documentation — or fix the test set, not the agent.

## Phase 8: Eval-Driven Validation

### The Loop
```
Apply fix → Start Conv eval → Poll → Analyze → Apply fix → Start SR eval → Poll → Analyze
```
Run Conv first (20 cases, ~15 min) then SR (100 cases, ~45 min).

### Run Limits
- Max 20 runs per agent per 24 hours
- 1 active run at a time per agent
- Cancel blocked runs via Gateway API PATCH

### Failure Classification
```python
classifications = {
    "abstention": "Agent refused — guardrails or model safety",
    "incomplete": "Answer truncated or missed elements",
    "groundedness": "Not supported by knowledge sources",
    "relevance": "Wrong topic matched",
    "format": "Wrong output format",
}
```

### Fix Priority Order
| Order | Fix | Impact |
|-------|-----|--------|
| 1 | Agent instructions (EVAL CONTEXT, Route D expansion) | +5-15 pts SR |
| 2 | Conversational boosting additionalInstructions | +5-10 pts |
| 3 | Remove unconditional length caps from responseInstructions | +10-15 pts Conv |
| 4 | Document Upload Intake pre-check | targets Conv routing fails |
| 5 | KB gap fill for groundedness=No failures | +5-10 pts SR |
| 6 | Fallback reprompt (not "I am not sure") | +3-5 pts |
| 7 | authenticationMode: None | +40-67 pts if connector gate active |

### Score Targets
| Metric | Target | Blocking |
|--------|--------|----------|
| SR (Single Response) | ≥ 95% | < 80% |
| Conv (Conversational) | ≥ 95% | < 80% |
| Up to 5% variance between runs is normal | | |

## Phase 15: Post-Deployment Monitoring

### Analytics Dashboard
Copilot Studio provides built-in analytics:
- **Sessions** — total conversations, active users, engagement rate
- **Topics** — which topics fire most, drop-off rates, escalation rates
- **Customer satisfaction** — CSAT scores per session
- **Billing** — token consumption, session count (for M365 Copilot)

### Key Metrics to Watch
| Metric | What It Means | Action If Low |
|--------|---------------|---------------|
| Resolution rate | % of conversations ending without escalation | Check Fallback/Escalate routing |
| Abandon rate | User leaves before resolution | Check Conversation Start — may be confusing |
| Topic match rate | % of queries that hit a custom topic (not Fallback) | Add trigger phrases or model descriptions |
| CSAT | User satisfaction score | Review recent failure conversations |
| Escalation rate | % transferred to human | Too high = agent can't handle key scenarios |

### Eval Score Tracking Over Time
```python
# Track eval scores per agent as a CSV for trend analysis
# Fields: date, agent, run_type, score, passes, total, notes
# Re-run SR + Conv after each major change and log the result
```

### Telemetry Event Logging
Add `LogCustomTelemetryEvent` to OnError topic for debugging:
```yaml
- kind: LogCustomTelemetryEvent
  id: logError
  eventName: OnErrorLog
  properties: "={ErrorMessage: System.Error.Message, ErrorCode: System.Error.Code, TimeUTC: Topic.CurrentTime}"
```

## Quick Reference Card

### Agent Recipe (Therapy Compliance Agent)
```
INSTRUCTIONS: 2000-6000 chars, EVAL CONTEXT + Route D + Route B
SETTINGS:      authMode=None, webBrowsing=false, codeInterpreter=false
SYSTEM TOPICS: Boosting (add additionalInstructions), Fallback (helpful reprompt),
               Conv Start (deactivate), Greeting (narrow triggers)
CUSTOM TOPICS: EndDialog + clearTopicQueue, SSC with responseCaptureType,
               no Question nodes in answer topics, modelDescription on every topic
KB:            displayName + description + isOfficialDataSource on every source
UPLOAD:        Document Upload Intake with pre-check ConditionGroup
EVALS:         Conv 20 (first) → SR 100 (second), max 20 runs/day
PUBLISH:       pac copilot publish --bot <id> (verify publishedon in Dataverse)
SNAPSHOT:      Full component dump before every change
AUTH:          Azure CLI for Dataverse, MSAL for Gateway, never mix tokens
```

### Error → Fix Quick Reference
| Symptom | Root Cause | Fix |
|---------|------------|-----|
| "I could not find an answer" | No topic matched, Fallback firing | Add trigger phrases or improve Boosting additionalInstructions |
| "What type of therapy document" | Document Upload Intake Question node firing | Add pre-check ConditionGroup |
| "Let's get you connected first" | authMode=Integrated blocking general Qs | Set authMode=None + authTrigger=AsNeeded |
| "Please wait... Paste the text" | Destination topic's first SendActivity is generic | Replace with direct answer about what the agent will produce |
| "I am not sure how to help with that" | Fallback default message | Replace with helpful reprompt listing capabilities |
| Publish fails with SynchronizationSystemError | System topic data PATCHed via API | Revert system topic data, publish, use UI code editor for system topics |
| Publish fails with IncorrectTypeError | Condition in topic returns wrong type | Ensure condition returns Boolean, not EmbeddedOptionSet or string |
| Eval stuck InProgress for >1hr | Platform flake — cancel not available | Wait it out; it will complete eventually |
| Eval shows 0/0 scored | Still InProgress — scores populate at end | Continue polling; check list endpoint for aggregated results |
| 401 on Gateway API | Eval token expired | Refresh with node refresh_tda_eval_token.cjs |
| 403 on Gateway API | Wrong token file — not a clean JWT | Re-run refresh script without stdout redirect; verify file starts with eyJ |

### Supported Channels
| Channel | Auth Required | Use For | MS Learn Notes |
|---------|--------------|---------|----------------|
| **Copilot Studio demo web** | None (default) | Testing, internal demos | Chat widget on copilotstudio.microsoft.com |
| **Microsoft Teams** | Microsoft Entra ID | Internal staff use | Requires Teams admin approval; uses bot registration |
| **Microsoft 365 Copilot** | Microsoft Entra ID | Enterprise-wide deployment | Requires M365 Copilot license; agent appears in Copilot sidebar |
| **Custom website** | Depends on config | Patient/provider portals | Embed via DirectLine API |
| **Power Apps / Power Pages** | Depends on app | Embedded in business apps | Add Copilot control to canvas |

### Configuring for Teams
1. Go to agent → Settings → Channels → Microsoft Teams
2. Turn ON "Teams"
3. Note the `botChannelRegistrationAppId` from `applicationmanifestinformation` in Dataverse
4. In Teams admin center, allow the bot registration
5. Publish the agent
6. The agent appears in Teams App Catalog → "Copilot Studio" section

### Configuring for M365 Copilot
1. Go to agent → Settings → Channels → Microsoft 365 Copilot
2. Turn ON
3. Set permissions (who can see it)
4. Publish
5. Users with M365 Copilot license see it in the Copilot sidebar under "Agents"

### webBrowsing & codeInterpreter
```yaml
webBrowsing: false     # OFF for PHI/compliance agents — prevents the model from searching the live web
codeInterpreter: false # OFF unless agent needs to run Python for analysis
```

**Why webBrowsing must be OFF for compliance agents:**
- If ON, the agent can search the internet for answers instead of using approved KBs
- This bypasses CMS regulatory content with general web search results
- Eval test cases expect KB-grounded answers, not web search results
- Verified: webBrowsing=true caused multiple Groundedness=No failures

## Phase 10: Content Moderation & Safety

### Moderation Levels
| Level | Use Case | Effect |
|-------|----------|--------|
| **Low** | General-purpose, no PHI | Minimal filtering |
| **Medium** | Internal business tools | Blocks profanity, hate speech |
| **High** | **Compliance/PHI agents — RECOMMENDED** | Blocks clinical content that could be misused, PII patterns |

**Set in:** Settings → Security → Content moderation

### Custom Moderation Categories
For therapy compliance agents, add custom categories:
- Protected health information (PHI) patterns
- Clinical decision-making disclaimers (FDA CDS criteria)
- Fraud, waste, and abuse language

### Guardrail Configuration
The `Guardrails` section in agent instructions serves as content moderation:
```yaml
  G1. Source Grounding: Use only approved knowledge sources
  G2. Review Scope: Only content provided in the current conversation
  G7. Advisory Use Only: Outputs are educational; require independent clinical review
  G8. AI Transparency: Disclose AI-generated status in every output
  G9. PHI Handling: Ignore and never repeat patient identifiers
```

### HIPAA Compliance Notes (for therapy compliance agents)
- Azure OpenAI HIPAA compliance requires: no PHI in prompts, no data retention, no human review
- Copilot Studio with Dataverse: PHI stays in your tenant if KBs and Dataverse are in the same region
- Use `High` content moderation
- Mark all KBs as `Official` to control what the agent uses
- Never use `webBrowsing: true`
- Add `G9. PHI Handling` to instructions

## Phase 11: Multi-Agent Orchestration

### When to Use Multiple Agents
| Scenario | Approach | Pattern |
|----------|----------|---------|
| Different specialties (PT, OT, SLP) | One parent agent with child agents per discipline | Parent handles routing, children handle domain-specific reviews |
| Different document types | Single agent with topic routing (simpler) | Better for < 7-8 topics |
| Compliance + analytics + reporting | Separate agents for each function | Each agent has focused KBs and instructions |

### Parent → Child Agent (AgentDialog)
```yaml
# Parent topic routes to child agent
kind: AdaptiveDialog
beginDialog:
  kind: OnRecognizedIntent
  actions:
    - kind: AgentDialog
      id: route_to_pt_agent
      agent:
        kind: AgentReference
        schemaName: auto_agent_xxx.PTSpecialist
      input: =System.Activity.Text
    - kind: EndDialog
```

### Connected Agent (TaskDialog)
```yaml
# Connected agent topic
kind: TaskDialog
beginDialog:
  kind: OnInvokeConnectedAgent
  id: main
  actions:
    - kind: InvokeConnectedAgentTaskAction
      id: invoke_pt_agent
      botSchemaName: auto_agent_xxx.PTSpecialist
      input: =System.Activity.Text
```

### State Verification
```python
# Check that connected agents are ACTIVE (statecode=0)
for comp in botcomponents:
    if comp['componenttype'] == 9 and 'InvokeConnectedAgent' in comp.get('data',''):
        if comp['statecode'] != 0:
            print(f"⚠️ DEACTIVATED connected agent: {comp['name']}")
```

### Critical Rules
- **Child agents must have `statecode=0`** — deactivated connected agents silently fail routing
- **AgentDialog has NO `beginDialog.actions`** — child agents use generative orchestration only
- **Connected agent topic must NOT have EndDialog** — TaskDialog with InvokeConnectedAgent has no EndDialog by design
- **Parent agent needs authenticationMode set correctly** — if parent has `None` but child needs auth, connection fails

## Phase 12: Disaster Recovery & Version Control

### Git Workflow
```bash
# Standard commit pattern after agent changes
cd "D:/my agents copilot studio"
git add -A
git commit -m "fix(agent-name): description of what changed — Conv X%, SR Y%"
git push
```

### Snapshot Before Any Change
Before every PATCH, save the current live state:
```python
snap_dir = f"agents/{agent_name}/snapshot-{datetime.date.today()}-{change_description}"
os.makedirs(snap_dir, exist_ok=True)
# Save all botcomponents for this agent
for comp in botcomponents:
    with open(f"{snap_dir}/T_{comp['name']}.yml", 'w') as f:
        f.write(comp['data'])
```

### Recovery from Corruption
If an agent is corrupted:
1. **Full snapshot was taken** → restore each component by PATCHing the saved data
2. **No snapshot** → use `pac copilot extract-template` to get current state, then manually fix
3. **UI corruption** → restore instructions and topics via Copilot Studio UI code editor
4. **Publish broken** → check `synchronizationstatus.lastFinishedPublishOperation.diagnosticDetails` for exact errors

### Component Backup Inventory
Keep a JSON index of all components for each agent:
```json
[
  {"name": "Topic Name", "type": 9, "state": 0, "schema": "auto_agent_xxx.topicName", "cid": "guid"},
  {"name": "Instructions", "type": 15, "state": 0, "schema": "agent.gpt.default", "cid": "guid"}
]
```

### Rollback Strategy
| Scenario | Rollback Method | 
|----------|----------------|
| Instructions corrupted | PATCH saved I_*.yml data back to instructions component |
| Topic corrupted | PATCH saved T_*.yml data back to topic component |
| Multiple topics corrupted | Push from local workspace via manage-agent.bundle.js |
| Publish broken | Check diagnostics; revert system topic data if modified; revert InvokeFlowAction |
| Connector broke | Re-deploy Power Automate flow; update connection reference |

## Phase 13: Conversation Starters (Component Type 19)

### What They Are
Conversation starters are the suggested prompts shown when a user opens a new conversation. They're stored as **type 19 botcomponents** in Dataverse, NOT in the agent's settings.

### How to Add
```python
# Each starter is a separate type 19 component
starter_body = {
    "name": "Fresh-SR | How do I get a compliance review for my therapy note?",
    "schemaname": f"auto_agent_XRF5I.fresh_sr_{uuid.uuid4().hex[:12]}",
    "componenttype": 19,
    "_parentbotid_value@odata.bind": f"/bots({botId})",
    "data": ""  # Type 19 starters typically have empty data
}
```

### MS Learn Best Practices
- **5-10 conversation starters** per agent
- Each starter should reflect a **real user need** (not generic)
- Use natural language, not keyword lists
- Cover each major topic area
- Both SR-style (single question) and Conv-style (multi-turn scenario) starters
- Stored as type 19, NOT as settings.conversationStarters

### Starter Naming Convention
```
Fresh-SR | <single-turn question>
Fresh-CONV | <multi-turn scenario description>
```
The `Fresh-SR` prefix indicates single-response starters; `Fresh-CONV` indicates conversational starters.

### Checking Existing Starters
```python
# Query all type 19 components for your bot
url = f"{base}/botcomponents?$filter=_parentbotid_value eq '{botId}' and componenttype eq 19&$select=name"
```

## Phase 14: MCP Server Integration (Kiro Copilot Studio MCP)

The MCP server at `D:/my agents copilot studio/mcp-server-copilot-studio/` provides programmatic agent management through the Model Context Protocol. Built by Kiro, exposes 4 tools via stdio transport.

### Architecture

```
Kiro MCP Client  ←→  mcp-server-copilot-studio (index.js)  ←→  Azure CLI (auth)
                                          ↓
                                   Dataverse REST API
                                          ↓
                                   PAC CLI (publish only)
```

- **Auth:** `az account get-access-token --resource "https://{org}.crm.dynamics.com/"` — uses Azure CLI token, same as our manual Dataverse PATCH flow
- **Transport:** StdioServerTransport (MCP stdio protocol)
- **Env:** Hardcoded to Ensign Default (`org3353a370.crm.dynamics.com`, tenant `03cc92c3`)
- **PATCH:** Uses PowerShell Invoke-RestMethod workaround (writes temp `_patch_body.json` + `_patch_script.ps1`, cleans up after)

### Tools

#### 1. `connect_bot` — Connect to a bot
```json
{
  "botName": "Medicare Part B Compliance Agent"  // or bot GUID, omit to list all
}
```
- Finds bot by name (partial match with `contains()`) or GUID
- Creates local dir `bots/<sanitized-name>/` with `connection.json`
- Returns bot ID, schema name, state (Active/Inactive)

#### 2. `pull_bot` — Pull all components to local YAML
```json
{
  "includeInactive": false
}
```
- Queries ALL botcomponents for the connected bot
- Writes to `bots/<botname>/topics/*.yml`, `knowledge/*.yml`, `gpt-instructions.yml`
- Each file gets a metadata header: `# Component:`, `# ID:`, `# Type:`, `# Schema:`, `# State:`
- Writes `pull-manifest.json` with component count and summary
- Component type mapping: 9=topic, 14=file-kb, 15=gpt-instructions, 16=web-kb, 19=trigger-phrase

#### 3. `push_component` — Push a local YAML back to Dataverse
```json
{
  "filePath": "topics/Document_Upload_Intake.yml",
  "componentId": "optional-guid-override"
}
```
- Reads the YAML file from `bots/<botname>/<filePath>`
- Extracts component ID from `# ID: <guid>` metadata header (or use `componentId` override)
- Strips metadata header by splitting on `---` separator
- Runs **corruption checks** before PATCH:
  - Duplicated section headers ('RESPONSE LENGTH', 'MANDATORY AUDIT' appearing >1x)
  - Multiple `kind:` declarations (GptComponentMetadata, AdaptiveDialog)
  - BOM character detection
  - Mid-word splices (word fragments before capitalized identifiers like `PT_Specialist`)
  - Smashed-together words at section boundaries
  - Multiple `instructions:` blocks
- PATCH via `botcomponents({compId})` with the `data` field
- Blocks push with detailed error message if corruption detected

#### 4. `publish_bot` — Publish via PAC CLI with verification
```json
{
  "skipVerification": false
}
```
- Runs `pac copilot publish --bot <botId>`
- Waits 60s for propagation
- Reads `synchronizationstatus` from bot entity
- Reports success/failure with diagnostics if failed
- Appends reminder: "Check Work IQ = Disabled in Copilot Studio UI"

### Setup
```bash
cd "D:/my agents copilot studio/mcp-server-copilot-studio"
npm install
# Requires az login with access to org3353a370.crm.dynamics.com
# Configure in .mcp.json if using with VS Code MCP client
```

### Limitations vs Direct API
| Feature | MCP Server | Direct Dataverse API |
|---------|-----------|---------------------|
| PATCH single topic | ✅ push_component | ✅ PATCH botcomponents(id) |
| Pull all components | ✅ pull_bot | ✅ GET botcomponents with filter |
| Publish + verify | ✅ publish_bot | ❌ Gateway publish returns 404 |
| New topic creation | ❌ Not supported | ✅ POST new botcomponent |
| KB name/description update | ❌ Not a separate tool | ✅ PATCH KB component data |
| System topic editing | ❌ Not supported | ❌ Breaks publish (same limitation) |
| Eval operations | ❌ Not supported | ✅ Gateway /makerevaluations |
| Bulk push | ❌ One component at a time | ✅ manage-agent.bundle.js push |
| Auth model | Azure CLI only | Azure CLI + MSAL + PAC |

### Use Cases
- **From VS Code via MCP:** Connect to an agent, pull its topics, edit locally, push back — all within the editor
- **CI/CD pipelines:** Automate pull → validate → push → publish flow for managed agents
- **Pre-commit validation:** Run corruption checks before any PATCH lands
- **Cross-environment sync:** Pull from Prod, diff against Dev workspace

### Known Issues
- Hardcoded to Ensign Default environment — cannot switch orgs without editing the source
- PATCH uses PowerShell workaround (writes temp files) — may leave artifacts if interrupted
- Push corruption checks are specific to GPT instructions pattern — may not cover all topic corruption modes
- No error handling for concurrent edits (no `If-Match` / etag support)
- Publish verification sleep is a fixed 60s — may complete earlier or need longer

## Phase 16: Pre-Deploy Checklist & Publish
- [ ] All 8 phases above completed
- [ ] Instruction length 2000-6000 chars, no corruption
- [ ] All topics have EndDialog + clearTopicQueue: true
- [ ] No Question nodes in audit/answer topics
- [ ] Every SSC has responseCaptureType: FullResponse
- [ ] KBs named/described properly
- [ ] Trigger phrases 5-10 per topic, no duplicates
- [ ] Model descriptions unique and descriptive
- [ ] Connected agents active (statecode=0)
- [ ] authenticationMode: None (or correct for use case)
- [ ] webBrowsing: false for PHI agents
- [ ] EVAL CONTEXT block in instructions
- [ ] YAML validates clean (PyYAML safe_load)
- [ ] SR eval ≥ 95% in 2 consecutive runs
- [ ] Conv eval ≥ 95% in 2 consecutive runs

### Publish
```bash
pac copilot publish --bot <bot-id>
```
Or via Gateway API. Verify published timestamp in Dataverse.

## Tools Reference

### Skill Dependencies
| Skill | When to Use |
|-------|-------------|
| agent-builder-orchestrator | One-shot end-to-end build (intake → spec → YAML → QA → deploy → eval) |
| agent-architect | Elicit requirements and design topic architecture from a description |
| agent-crafter | Generate all topic YAML from a structured spec (5 pattern templates) |
| agent-qa-gate | Independent 12-gate verification before deploy |
| eval-optimization-loop | Run draft evals, analyze failures, iterate to 95% |
| agent-audit-protocol | Comprehensive 12-domain structural audit of an existing agent |
| copilot-studio-common-reference | Canonical auth patterns, generation rules, and pitfalls |
| copilot-studio-edit-agent | Edit instructions, settings, agent metadata |
| copilot-studio-author-topic | Create new topic YAML from template |
| copilot-studio-add-node | Add/modify topic nodes |
| copilot-studio-edit-triggers | Modify trigger phrases and model descriptions |
| copilot-studio-add-knowledge | Add KB sources |
| copilot-studio-add-generative-answers | Add SearchAndSummarizeContent |
| copilot-studio-live-sync-backup | Pull live agent state to disk |
| copilot-studio-validate | YAML schema validation |
| copilot-studio-pipeline | Universal scripts and publish helpers |

### Key Scripts (from D:/my agents copilot studio/pipeline/scripts/)
| Script | Purpose |
|--------|---------|
| refresh_tda_eval_token.cjs | Mint PPAPI eval token from MSAL cache |
| fix_all_topics.py | Bulk fix topic YAML issues |
| patch_all_doc_topics.py | PATCH all document review topics |
| publish_all.py | Publish all agents via pac CLI |
| verify_patch.py | Verify YAML patches landed correctly |
| list_testsets.sh | List eval test sets for an agent |

### Data Sources
| Source | Purpose |
|--------|---------|
| Dataverse botcomponents | Read/write topic data, instructions, KBs |
| Gateway API | Run evals, list test sets, poll results |
| Power Automate | Check flow deployments, connection references |
| Copilot Studio UI | Create blank agents, manage settings, review test pane |

## Pitfall Index

### Data Integrity
- **`data` vs `content` field**: Only `data` is patchable via API. `content` is UI-only.
- **Line endings**: Dataverse stores topics with `\r\n` or `\n` — use `replace()` not exact string matching
- **BOM characters**: `\uFEFF` at file start breaks js-yaml — strip before PATCH
- **System topics**: PATCHing system topic data breaks publish — use UI code editor only
- **_parentbotid_value**: Bot components may belong to a DIFFERENT parent bot (solution managed) — verify before PATCH

### Eval Quirks
- **Details endpoint 404**: Use `?$top=N` list endpoint + `aggregatedGraderResults` instead
- **Token expiry**: PPAPI eval token ~15 min — refresh mid-run
- **Conv takes 15-20 min, SR 45-75 min**: Set poll timeouts accordingly
- **Stuck runs**: Cannot cancel via API in some tenants — wait for timeout
- **0/0 shown while InProgress**: Normal — scores populate at end

### Topic Behavior
- **Question nodes kill SR**: The grader sees a question, not an answer
- **Missing EndDialog causes context bleed**: Always add clearTopicQueue: true
- **Pre-check conditions must return Boolean**: `If(<cond>, value, Blank())` returns value, not true/false — use raw condition expression
- **ConditionGroup empty actions block = silent exit**: No actions = conversation ends silently
