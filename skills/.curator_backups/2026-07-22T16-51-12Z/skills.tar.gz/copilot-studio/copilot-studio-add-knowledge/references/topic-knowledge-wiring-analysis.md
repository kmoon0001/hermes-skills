# Topic Knowledge Wiring Analysis

After uploading knowledge files to a Copilot Studio agent, verify that the agent's topics actually reference and use those files. A knowledge file can show **Ready** status but be disconnected from every topic.

## How Topics Reference Uploaded Files

When a topic uses SearchAndSummarizeContent (the standard Copilot Studio pattern for knowledge-grounding), the knowledge sources are wired via one of two approaches:

### Pattern A: SearchSpecificFiles (preferred — deterministic)

Each uploaded file is referenced by its schemaname in the `fileSearchDataSource` block:

```yaml
- kind: SearchAndSummarizeContent
  id: search-audit
  fileSearchDataSource:
    searchFilesMode:
      kind: SearchSpecificFiles
      files:
        - crbee_Agent.file.CMS-Ch15-Therapy.pdf_XqQ
        - crbee_Agent.file.Jimmo-v-Sebelius-FAQ.pdf_BNZ
```

**What to check:**
- The schemaname suffix (`_XqQ`, `_BNZ`) is auto-generated at upload. Re-uploading gets a **different** suffix, breaking all topic references.
- All files should use the same agent prefix (e.g., `crbee_Agent`).
- Verify the prefix matches the agent's customization prefix in Dataverse.

### Pattern B: SearchAllFiles / SearchAllKnowledgeSources (catch-all)

The topic doesn't specify which files — the model searches all available knowledge. Less precise but resilient to re-uploads.

## Attachment Handling Patterns

Two approaches for wiring uploaded attachments into the GPT:

### ForEach pattern (per-attachment — preferred):
```yaml
customDataSource:
  searchResults: |-
    =ForAll(System.Activity.Attachments, {
        Content: Text(ThisRecord.Content),
        Title: ThisRecord.Name,
        ContentLocation: ""
    })
```
Passes each attachment individually with its title. No truncation risk.

### Concat pattern (all text in one string):
```yaml
userInput: =Concat(System.Activity.Attachments, Content, ", ")
```
**Risk:** `Concat()` output is capped at ~2000 chars in Copilot Studio. Large docs silently truncate. Prefer ForAll() for multi-doc or large-doc scenarios.

## Dual userInput Strategy

Some topics use a **static prompt** as `userInput` (e.g., "Review the attached therapy documentation...") and rely on `customDataSource` to pipe attachment content separately. This is useful when:
- The semantic search should search knowledge files for context (not the attachment text)
- The attachment content is provided to the GPT independently via customDataSource
- The search query shouldn't change based on what the user attached

## Verification Workflow

1. Query Dataverse for the bot's components:
```bash
TOKEN=$(cat ~/Desktop/az_token.txt)
curl -s --get -H "Authorization: Bearer $TOKEN" -H "Accept: application/json" \
  --data-urlencode "\$filter=_parentbotid_value eq '<BOT_GUID>'" \
  --data-urlencode "\$select=botcomponentid,name,componenttype,schemaname,statecode" \
  --data-urlencode "\$top=200" \
  "https://<org>.crm.dynamics.com/api/data/v9.2/botcomponents"
```

2. Group by `componenttype`:
   - `type=9` = topics
   - `type=14` = uploaded knowledge files
   - `type=15` = instructions

3. For each custom topic (type=9), fetch `data` and check: does `fileSearchDataSource.searchFilesMode.files` reference any uploaded file schemanames?

4. Identify unmatched files — files in `type=14` that appear in NO topic's SearchSpecificFiles list. These files will never be retrieved.

5. Check for stale suffix tokens — if a file was re-uploaded, old topics still reference the old suffix (which no longer exists), causing silent search failures.
