# Live Dataverse public-source creation and SASC verification

Use this when adding official public website/PDF knowledge sources directly to a live Copilot Studio agent through Dataverse rather than by local YAML import.

## Safe live sequence

1. Read all bot components (`componenttype == 16` sources; `componenttype == 9` topics) and save a timestamped snapshot.
2. Inventory every active `SearchAndSummarizeContent` node, including system topics such as **Conversational boosting**. Do not assume only custom topics contain SASC.
3. Before adding sources, ensure every active SASC node has:
   ```yaml
   fileSearchDataSource:
     searchFilesMode:
       kind: SearchAllFiles
   knowledgeSources:
     kind: SearchAllKnowledgeSources
   ```
   If a node is unbound, patch and re-read it first. `SearchAllKnowledgeSources` makes each active new source eligible; no per-resource node checkbox is required.
4. Create a public source via `POST /api/data/v9.2/botcomponents` with `componenttype: 16`, `parentbotid@odata.bind: /bots(<bot-id>)`, and `data` containing `KnowledgeSourceConfiguration`.
5. **Do not send `If-Match` on POST.** Dataverse rejects it with: `The specified If-Match condition isn't valid for a POST request.` Use `If-Match: *` only for PATCH/DELETE.
6. Re-read components and verify each new source is active, has the exact intended URL, non-vague description, and `isOfficial: true`; also verify every SASC node uses `SearchAllKnowledgeSources`.
7. Publish with `pac copilot publish --environment <env> --bot <bot-id>` and verify `bots(<bot-id>).publishedon`.

## Description guardrails

Descriptions must say what the source covers, when to use it, and key limits. Examples of limits that prevent overclaiming:
- distinguish SNF Part A coverage from outpatient Part B billing;
- label historical OIG audits as nonbinding risk evidence;
- identify date-sensitive Medicare policies (telehealth); and
- limit home-health material to home-health cases.

## Proven 2026-07-17 Denial Defense V2 pattern

Five CMS/HHS OIG sources increased a live agent from 9 to 14 official public sources: CMS MBPM Ch. 8 SNF coverage, CMS Recovery Audit Program, CMS Home Health denial prevention, CMS Telehealth FAQ, and an HHS OIG outpatient-PT audit. All 6 active SASC nodes (five custom routes plus Conversational boosting) were verified as `SearchAllKnowledgeSources` after remediation.

Do not duplicate an existing authoritative source just to satisfy a gap name. First audit the existing source inventory and reuse its coverage where it is already specific enough (e.g., generic CMS FFS appeals source).