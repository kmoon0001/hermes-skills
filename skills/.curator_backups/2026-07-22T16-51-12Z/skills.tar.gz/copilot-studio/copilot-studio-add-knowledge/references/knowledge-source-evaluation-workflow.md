# Knowledge Source Evaluation Workflow

Before uploading a batch of PDFs as Copilot Studio knowledge, evaluate each one
for fit against the target agent. This prevents wasting upload slots on sources
that won't improve retrieval quality.

## Step 1: Read the Agent's Instructions

Load the agent's `agent.mcs.yml` — specifically the `instructions:` block.
Extract the agent's stated:

- **Knowledge sources / references** — listed in a dedicated section (e.g.,
  `## KNOWLEDGE SOURCES & GROUNDING`). These are the sources the agent
  *thinks* it has. If a PDF matches one of these but no uploaded source
  exists for it, that's a critical gap.
- **Core logic / clinical auditing flow** — what the agent claims to
  evaluate (e.g., Jimmo compliance, skilled terminology, SOAP structure).
  PDFs that support these evaluations are high-value.
- **Role & persona** — which setting (SNF, outpatient, home health) and
  which disciplines (PT, OT, SLP).

## Step 2: Audit Existing Knowledge Sources

List all files in the agent's `knowledge/` directory. Classify each by type:

| YAML `source.kind` | Meaning | Reliability |
|---|---|---|
| `PublicSiteSearchSource` | Bing web crawl of a domain | Non-deterministic, max depth 2 |
| `SharePointSearchSource` | SharePoint folder crawl | Semi-deterministic |
| `UploadedFileSearchSource` (not in YAML — UI-only) | Uploaded PDF/DOCX | Deterministic, always available |

**Key insight:** If ALL existing sources are `PublicSiteSearchSource`, the
agent has no reliable offline knowledge. Uploaded files will dramatically
improve retrieval consistency — reference: PT/OT agents using file-only
knowledge score 98-100%.

Identify which stated knowledge sources from Step 1 have NO matching
knowledge source file. Those are the highest-priority gaps to fill.

## Step 3: Evaluate Each Candidate PDF

For each PDF, produce a structured assessment:

### A. Relevance to Agent Mission
- Does the agent's instructions explicitly reference this topic? (e.g.,
  "Jimmo v. Sebelius Compliance" → Jimmo FAQ = direct hit)
- Does the agent's core logic require this information? (e.g., SNF therapy
  agent → 42 CFR Part 409 SNF covered services = bedrock)
- Is the PDF about a scenario the agent handles? (e.g., an outpatient-only
  LCD for an SNF agent = partial fit)

### B. Content Authority Level
| Level | Source | Examples |
|---|---|---|
| **Highest (statute/regulation)** | GovInfo, eCFR, Federal Register | 42 CFR Parts, CMS final rules |
| **High (official CMS guidance)** | CMS manual, MLN, FAQ, SOM | Chapter 15, Jimmo FAQ, Appendix PP |
| **Medium (MAC/local policy)** | LCD/LCA, MAC articles | CGS L34049, Noridian articles |
| **Medium (professional body)** | APTA, AOTA, ASHA | Practice portals, clinical guidelines |
| **Low (internal/derived)** | Internal forms, compiled guides | Ensign LCR form, 7 Habits framework |

An agent arguing for coverage defense needs regulation-level sources
first, then CMS guidance, then MAC/local. Internal docs supplement but
don't replace regulatory authority.

### C. Grounding Necessity (Current Gap)
- **Direct gap** — agent instructions name a source that has no
  corresponding knowledge file. (Highest priority.)
- **Implicit gap** — agent's tasks require this info but no source
  covers it. (High priority — the agent currently hallucinates this.)
- **Overlap** — existing knowledge already covers this area (check by
  comparing against existing YAMLs' `componentName` and `site` fields).
- **Downstream** — useful for next steps after the agent's primary
  function (e.g., appeals process after documentation). (Lower priority.)

### D. Priority Tiering
| Tier | Criteria | Action |
|---|---|---|
| **1 (Core)** | Direct gap + highest authority level + directly referenced in instructions | Upload immediately |
| **2 (Defense)** | Medium-high authority + implicit gap + supports audit/denial defense | Upload when Tier 1 is done |
| **3 (Supplementary)** | Downstream or partial fit + useful for completeness but not daily use | Upload last or skip |

## Step 4: Produce the Prioritized Upload Manifest

Write or update `UPLOAD-MANIFEST.md` in the knowledge folder with:

- **Priority order** — grouped by tier, sorted within tier
- **For each file:** File name, Display Name (for UI), Description (for
  UI), Official source flag (ON for authoritative docs)
- **Reasoning:** one-line why it's at this priority (e.g., "Core –
  directly named in agent instructions; no existing source")

## Example: PacCoast TheraDoc Agent

Worked example at `C:\Users\kevin\Desktop\PacCoast-Defense-KB\UPLOAD-MANIFEST.md`
— 14 PDFs evaluated against the TheraDoc agent's instructions (Jimmo,
Chapter 15, 42 CFR Part 409/483, SOM Appendix PP, MAC LCD, appeals
booklet, Part 422 MA rules) and tiered 1–3.

## Pitfall: Don't Skip Step 1

Uploading PDFs without reading the agent's instructions first risks
adding authoritative but irrelevant sources. The agent's retrieval finds
the right file but the model can't use it because it's outside its task
scope. Worse: an irrelevant authoritative file can confuse the model
into applying regulations that don't apply to the setting.
