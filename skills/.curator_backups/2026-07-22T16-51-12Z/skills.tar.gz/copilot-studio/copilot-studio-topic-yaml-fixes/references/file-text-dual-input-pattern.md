# File+Text Dual-Input Pattern for Document Review Topics

## CRITICAL PITFALLS — Read Before Applying

### 1. Every `IsBlank()` MUST have an argument
```
❌ =!IsBlank()          → silent fail, never fires
✅ =!IsBlank(First(System.Activity.Attachments))  → file check
✅ =!IsBlank(Trim(Topic.DocumentText))            → text check
```

### 2. Text condition must be `!IsBlank`, NOT `IsBlank`
```
❌ =IsBlank(Topic.DocumentText)        → runs SASC when text is EMPTY (inverted)
✅ =!IsBlank(Trim(Topic.DocumentText)) → runs SASC when text EXISTS
```

### 3. SendActivity Power Fx needs `=` prefix, not `{}` wrapper
```
❌ activity: "{If(CountRows(Attachments) > 1, \"x\", \"\")}"    → literal text
✅ activity: "=If(CountRows(Attachments) > 1, \"x\", \"\")"     → evaluates
```

### 4. SendActivity output must use `.Text.Content`
```
❌ activity: "{Topic.Answer}"           → leaks record metadata
✅ activity: "{Topic.Answer.Text.Content}" → clean text output
```

### 5. Multi-doc: use `=Concat` not `First` for AI Builder
```
❌ UserDocument: =First(System.Activity.Attachments).Content              → one doc
✅ UserDocument: =Concat(System.Activity.Attachments, Content, "\n\n---\n\n") → all docs
```

### 6. After API PATCH + publish, hard-reload browser (Ctrl+Shift+R)
The UI caches stale topic data. Without a hard reload, the editor overwrites your fixes.

## Problem
Question nodes using `entity: FilePrebuiltEntity` never complete when a user responds with text instead of a file. The Question keeps re-prompting because the file entity expects a binary attachment. This is the #1 cause of Conversational eval failures (20-35% scores).

## Pattern

### Entity: StringPrebuiltEntity (NOT FilePrebuiltEntity)
Accept any user input by switching to `StringPrebuiltEntity`. This lets users paste text OR upload files.

### File Detection
Use `=!IsBlank(First(System.Activity.Attachments))` instead of `=!IsBlank(Topic.var)` to check for file upload. `System.Activity.Attachments` holds uploaded files regardless of the Question's entity type.

### AI Builder Input Binding
When a file IS present, bind the AI Builder input to `=First(System.Activity.Attachments).Content` — NOT `=Topic.var` and NOT `=First(System.Activity.Attachments)`:

- `=Topic.var` → holds user's text (since entity is StringPrebuiltEntity), not the file blob
- `=First(System.Activity.Attachments)` → returns a Record type → causes `IncorrectTypeAssignment` error on publish
- `=First(System.Activity.Attachments).Content` → returns a File type → matches AI Builder's expected input

### Text-Input Branch
In the `elseActions` of the file check, add a nested ConditionGroup that checks `=!IsBlank(Trim(Topic.var))` for text. If text exists, pipe to SearchAndSummarizeContent → SendActivity → EndDialog.

### Fallback
If neither file nor text is present, GotoAction back to the Question.

### Critical: Do NOT Remove entity Entirely
A Question node requires an entity. Removing `entity:` causes `MissingRequiredProperty: Entity` on publish. Always change the type, never remove it.

## Full YAML Template

```yaml
    - kind: Question
      id: question_upload_doc
      interruptionPolicy:
        allowInterruption: true
      variable: init:Topic.DocumentText
      entity:
        kind: StringPrebuiltEntity
      prompt: Paste the text of or upload the document for audit.

    - kind: ConditionGroup
      id: conditionGroup_file_check
      conditions:
        - id: condition_file_uploaded
          condition: =!IsBlank(First(System.Activity.Attachments))
          actions:
            - kind: InvokeAIBuilderModelAction
              id: invokeAIBuilderModelAction
              input:
                binding:
                  InputField: =First(System.Activity.Attachments).Content
              output:
                binding:
                  predictionOutput: Topic.Results
              aIModelId: <model-guid>
            - kind: SendActivity
              id: sendActivity_file_audit
              activity: "{Topic.Results.text}"

      elseActions:
        - kind: ConditionGroup
          id: conditionGroup_text_check
          conditions:
            - id: condition_has_text
              condition: '=!IsBlank(Trim(Topic.DocumentText))'
              actions:
                - kind: SearchAndSummarizeContent
                  id: search_text_audit
                  variable: Topic.AuditResult
                  userInput: '=Concatenate("Audit this: ", Topic.DocumentText)'
                  applyModelKnowledgeSetting: true
                  responseCaptureType: FullResponse
                - kind: SendActivity
                  id: sendActivity_text_audit
                  activity: "{Topic.AuditResult.Text.Content}"
          elseActions:
            - kind: GotoAction
              id: goto_upload_retry
              actionId: question_upload_doc

    - kind: EndDialog
      id: endDialog_main
      clearTopicQueue: true
```

## Verification Checklist
- [ ] `FilePrebuiltEntity` NOT present — use `StringPrebuiltEntity`
- [ ] File condition uses `=!IsBlank(First(System.Activity.Attachments))` — NOT bare `=!IsBlank()` (silent fail)
- [ ] Text condition uses `=!IsBlank(Trim(Topic.Var))` — NOT `=IsBlank(...)` (inverted logic)
- [ ] AI Builder binding uses `.Content` suffix — `=First(System.Activity.Attachments).Content`
- [ ] For multi-doc: AI Builder uses `=Concat(All Attachments, Content, " separator ")` instead of `First`
- [ ] SendActivity Power Fx uses `=` prefix, NOT `{}` wrapper — `activity: "=If(...)"` NOT `activity: "{If(...)}"`
- [ ] SendActivity output uses `.Text.Content` — `{Topic.Var.Text.Content}` NOT `{Topic.Var}`
- [ ] Text-path has `SearchAndSummarizeContent` + `SendActivity` + `EndDialog`
- [ ] Fallback has `GotoAction` back to Question"
- [ ] YAML validates with `yaml.safe_load()`
