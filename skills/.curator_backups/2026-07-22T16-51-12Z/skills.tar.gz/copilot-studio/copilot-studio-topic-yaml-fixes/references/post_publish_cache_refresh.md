# Post-Publish Cache Refresh — Windows/Chrome Automation Reality

## The problem
After `pac copilot publish`, the Copilot Studio visual editor shows STALE topic data
(conditions render as "Select a variable", old node order, etc.) because the SPA caches
the last loaded topic. The fix in Dataverse is correct — the UI just hasn't re-fetched it.

## What does NOT work on this environment (Windows, default Chrome profile)
- `mcp__cua_driver__page execute_javascript` with `location.reload()` — requires either
  CDP (`--remote-debugging-port=N` + `CUA_DRIVER_CDP_PORT=N`) OR a bookmark named
  `cua-driver-eval` in the Bookmarks bar. BOTH fail here:
  - CDP: Chrome refuses `--remote-debugging-port` on the DEFAULT user-data-dir
    ("DevTools remote debugging requires a non-default data directory").
  - Bookmark bypass: creating the `cua-driver-eval` bookmark in Bookmarks JSON did not
    engage after cua-driver restart (driver may read a different profile path).
- Typed URLs in the Chrome address bar via cua-driver `type_text`/`set_value` — Chrome
  autocomplete hijacks them (lands on x.com, docs.x.ai, etc.). Unreliable for navigation.
- `mcp__cua_driver__hotkey ctrl+shift+r` in background mode — Chrome blocks bg hotkeys;
  needs `bring_to_front` + `delivery_mode:"foreground"`, which still isn't confirmed.

## What DOES work
1. **Manual Shift+Reload** by the user — always reliable, zero automation.
2. **PowerShell `wscript.shell` SendKeys** — `C:\Users\kevin\Desktop\refresh_paccoast.ps1`:
   - Activates the Chrome window by title substring (`AppActivate 'Copilot Studio'`)
   - Sends `^+r` (Ctrl+Shift+R = hard refresh)
   - PREREQUISITE: the PacCoast topic tab must be an OPEN Chrome window (not buried/
     dismissed). After a Chrome restart the "Restore pages?" dialog can drop the tab —
     reopen it first.
   - NOTE: `Shell.Application.Windows()` only enumerates Explorer/file windows, NOT Chrome
     tabs — do NOT use it to find the tab. Use `wscript.shell.AppActivate` by title.

## Permanent fix (not yet implemented)
Launch Chrome with a SEPARATE non-default profile + `--remote-debugging-port=9222`, log
into Copilot Studio once in that profile, then cua-driver `page execute_javascript` works
natively for `location.reload(true)`. This avoids the default-profile CDP block.

## Verification that the fix actually landed (do this instead of trusting the UI)
GET the botcomponent data and grep the condition/output fields:
```
TOKEN=$(cat /c/Users/kevin/Desktop/az_token.txt)
curl -s --get -H "Authorization: Bearer $TOKEN" -H "Accept: application/json" \
  --data-urlencode "\$select=data" \
  "https://pccapackage.crm.dynamics.com/api/data/v9.2/botcomponents(<TOPIC_GUID>)"
```
The Dataverse JSON is source of truth. The UI condition preview field is NOT — it cannot
render custom Power Fx formulas and shows a placeholder even when Dataverse is correct.
