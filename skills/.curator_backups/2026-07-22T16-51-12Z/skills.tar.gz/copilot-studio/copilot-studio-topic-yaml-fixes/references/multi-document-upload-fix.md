# Multi-Document Upload: FilePrebuiltEntity Conversion + Continuation Prompt

## Problem
When a user uploads multiple PDFs simultaneously to a Copilot Studio agent using `FilePrebuiltEntity`, only the LAST file is captured. The rest are silently dropped. The InvokeAIBuilderModelAction also only processes one file via its single-bind input.

## Root Cause
- `FilePrebuiltEntity` stores one blob value — overwritten on each upload
- `InvokeAIBuilderModelAction` has a single `UserDocument` input binding — one file at a time
- No mechanism exists to iterate across `System.Activity.Attachments` in the AI Builder path

## Fix: StringPrebuiltEntity + Attachment Detection

## CRITICAL — Must Use 3-Branch ConditionGroup
This fix converts FilePrebuiltEntity → StringPrebuiltEntity. You MUST add a nested text-check ConditionGroup + GotoAction loop (see `file-text-dual-input-pattern.md`). Without it, text inputs silently fall through and empty inputs produce garbage.

### Step 1 — Change the Question Entity
```diff
- entity: FilePrebuiltEntity
+ entity:
+   kind: StringPrebuiltEntity
```
The variable stores the user's text input. Attachment detection uses `System.Activity.Attachments`.

### Step 2 — Fix the File Check Condition
```diff
- condition: =!IsBlank(Topic.PatientRecord)
+ condition: =!IsBlank(First(System.Activity.Attachments))
```
**CRITICAL: Do NOT add `.Content` here.** `=!IsBlank(First(System.Activity.Attachments).Content)` passes a File blob to IsBlank — publish fails with `MissingRequiredProperty: Condition`. `.Content` is ONLY for AI Builder input bindings and Concatenate expressions.

### Step 3 — Fix AI Builder Input Binding  
```diff
- UserDocument: =Topic.PatientRecord
+ UserDocument: =First(System.Activity.Attachments).Content
```
The `.Content` suffix extracts the File blob from the attachment Record. Without it, you get `IncorrectTypeAssignment`.

**⚠️ CRITICAL: AI Builder `UserDocument` expects File type, NOT string.** Do NOT use `Concat(System.Activity.Attachments, Content, "...")` here. `Concat()` returns a string, but the AI Builder input binding expects a File blob. Binding a string causes the model to silently hang — starts processing, then stops, does nothing. If you need to analyze ALL attachments together (e.g. episode of care), use `SearchAndSummarizeContent` instead, which accepts string input natively:

```yaml
# For multi-doc combined analysis (SASC, not AI Builder):
userInput: '=Concatenate("Review these documents:\n\n", Concat(System.Activity.Attachments, Content, "\n\n---\n\n"))'
```

### Step 4 — Add Continuation Prompt for Multi-File
After the AI Builder path's SendActivity, add a conditional prompt:
```yaml
- kind: SendActivity
  id: sendActivity_multi_doc
  activity: "=If(CountRows(System.Activity.Attachments) > 1, \"I have reviewed the first document. To analyze another, please upload or paste it here.\", \"\")"
```

This returns an empty string when only one file was uploaded (no extra message), and prompts for the next document when multiple were detected.

## Limitations
- User must upload/attach one document per turn
- Only the FIRST attachment in `System.Activity.Attachments` is processed
- Multi-turn flow required for N documents (bot prompts between each)

## Verification Path
1. Upload 3 PDFs in test canvas
2. Verify first audit runs on first document
3. Verify continuation prompt appears: "I have reviewed the first document..."
4. Upload second PDF → second audit runs
5. Verify each audit is a complete, independent analysis

## References
- `copilot-studio-topic-yaml-fixes/references/yaml-structural-fixes-2026-07.md` — Pattern 8: FilePrebuiltEntity → StringPrebuiltEntity conversion
- `copilot-studio-yaml-reference` SKILL.md — Additive File + Text Pattern, Power Fx expressions

Applied: Pacific Coast Documentation Defense Agent Topic 1, July 2026.
