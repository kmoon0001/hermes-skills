# Conversational Boosting — Answer Computed But Never Displayed

**Validated:** 2026-07-15, Case History Reviewing Agent (f19e1c40)

## Symptom
Eval fails with abstention or incomplete even though the agent has relevant knowledge sources. The score lingers around 30-35% despite SASC being present.

## Root Cause
The `Conversational boosting` system topic (kind: OnUnknownIntent, priority: -1) runs `SearchAndSummarizeContent` → populates `Topic.Answer` → checks `!IsBlank(Topic.Answer)` → **but if there's NO `SendActivity` displaying the answer, the computed text is discarded and the dialog ends silently.** The grader sees abstention because the user-facing response is empty.

## Detection
Scan topic YAML for this pattern:
```yaml
- kind: SearchAndSummarizeContent
  ...
  variable: Topic.Answer
  ...

- kind: ConditionGroup
  conditions:
    - condition: =!IsBlank(Topic.Answer)
      actions:
        # NO SendActivity here = answer dropped
        - kind: EndDialog
```

If the `!IsBlank(Topic.Answer)` condition's actions block goes straight to `EndDialog` without a `SendActivity`, the answer is computed and discarded.

## Fix
Insert a `SendActivity` BEFORE the `EndDialog`:

```yaml
- kind: ConditionGroup
  id: has-answer-conditions
  conditions:
    - id: has-answer
      condition: =!IsBlank(Topic.Answer)
      actions:
        - kind: SendActivity          # ADD THIS
          id: send-answer
          activity: =Topic.Answer

        - kind: EndDialog
          id: end-topic
          clearTopicQueue: true
```

## API Safety
Unlike OnEscalate/OnError system topics, the Conversational boosting topic (OnUnknownIntent with priority=-1) CAN be patched via Dataverse API without blocking publish. Verified: PATCHed `botcomponents.data` → HTTP 204 → `pac copilot publish` → Succeeded.

## Impact
Case History Reviewing Agent: +3pp improvement (31% → 34%) after adding SendActivity to Conversational boosting and adding SASC to the Fallback topic.

## Related
- Also affected: **Fallback topic** (OnUnknownIntent) — same silent-discard pattern without SASC + SendActivity. See `copilot-studio-topic-yaml-fixes/references/yaml-structural-fixes-2026-07.md`.
