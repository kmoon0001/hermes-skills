# Condition Nodes with Power Fx Formulas Show Blank "Select a variable" (UI Display Bug)

## Symptom
In the Copilot Studio visual topic editor, a Condition node's variable slot renders
as an empty **"Select a variable"** placeholder — even though the condition is fully
configured and working. Users report it as "the variable is not there again / how do
I configure it," and it seems to "keep disappearing."

## Root Cause
When a Condition holds a raw **Power Fx formula** (not a simple
`[variable] [operator] [value]` picker expression), the visual condition editor's
simple variable-picker CANNOT represent the formula, so it displays a blank
"Select a variable" slot. The formula is still alive and correct in the backend
(Dataverse `botcomponent.data` YAML). The blank is purely cosmetic.

Formulas that trigger this include:
- `=!IsBlank(First(System.Activity.Attachments))`   (file-uploaded branch)
- `=!IsBlank(Trim(Topic.DocumentText))`             (pasted-text branch)

## CRITICAL PITFALL — Do NOT "fix" it by picking a variable
If you click the blank slot and select a plain variable, you **OVERWRITE the
`!IsBlank(...)` formula** and break the branch logic (e.g. the file-vs-text
3-branch dual-input pattern silently stops routing). This is the exact trap that
makes the config appear to "disappear again" — every touch of the node in simple
mode wants to replace the formula with an empty picker, and an autosave can wipe it.

## Diagnosis Steps (confirm before touching anything)
1. Do NOT trust the blank UI slot. Pull the LIVE topic YAML from Dataverse:
   ```bash
   TOKEN=$(az account get-access-token --resource https://<org>.crm.dynamics.com \
     --query accessToken -o tsv)
   ORG="https://<org>.crm.dynamics.com"
   curl -s -H "Authorization: Bearer $TOKEN" -H "Accept: application/json" \
     "$ORG/api/data/v9.2/botcomponents(<topic-guid>)?\$select=data" \
     | python -c "import sys,json; y=json.load(sys.stdin)['data']; \
       [print(f'L{i}: {l.strip()}') for i,l in enumerate(y.splitlines()) if 'condition:' in l or 'IsBlank' in l]"
   ```
2. If the `condition: =!IsBlank(...)` lines are present → config is INTACT, blank is cosmetic.
   Tell the user nothing is broken and to leave the node untouched.

## Resolution Options
- **Leave it (safest, recommended).** Verified-working live; blank display is cosmetic.
  Author/repair these conditions via Dataverse API PATCH, never the visual picker,
  and don't click into the condition nodes in the UI. (Matches the LIVE-UI-IS-TRUTH
  rule: Live UI can silently wipe custom Power Fx on save.)
- **Make it display correctly:** open the condition node → "⋯" More menu → the
  formula/code toggle ("Edit in formula bar" / `{x}` / `</>`) → switches that
  condition to formula view where `!IsBlank(...)` shows as text and won't be blanked.
- **Simple-picker-friendly rewrite (only if user wants pure UI editing):** add a
  SetVariable node computing a helper (e.g. `Topic.HasFile = !IsBlank(First(System.Activity.Attachments))`)
  then the condition becomes `Topic.HasFile is equal to true`, which the simple
  picker CAN display. Trade-off: an extra node; changes topic structure.

## Recovery if it WAS wiped
Re-PATCH the condition formula via Dataverse (additive edit to `botcomponent.data`),
then `pac copilot publish --environment <env> --bot <guid>`, then hard-refresh the
Copilot Studio browser tab (Ctrl+Shift+R) so the UI cache doesn't re-overwrite.
