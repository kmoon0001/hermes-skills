# Dataverse PATCH: Line Endings, Diagnostics, and YAML Restructuring

## \r\n Line Endings in Dataverse Data

The `data` field in Dataverse `botcomponents` stores YAML with **`\r\n` (CRLF) line endings**. This matters because:

1. **String matching fails silently** — Searching for `\n` patterns in the data won't match. Always normalize:
   ```python
   data_normalized = raw_data.replace("\r\n", "\n")
   # ... do replacements on data_normalized ...
   patched_data = data_normalized.replace("\n", "\r\n")
   ```

2. **Python `split('\n')` leaves trailing `\r`** — Each line after split has a trailing `\r`. Either strip it or normalize first.

3. **JSON encoding re-escapes nothing new** — The `json.dumps({"data": data})` wrapper handles the CRLF naturally since they're valid JSON chars.

## Condition Format: UI Editor vs Dataverse API

**These two environments use DIFFERENT condition formats and are NOT interchangeable.**

### Dataverse API PATCH — Single-quoted YAML (preferred)
```yaml
condition: '=!IsBlank(First(System.Activity.Attachments))'
```
The single quotes prevent the YAML parser from interpreting the Power Fx expression. Backslash escaping does not compound across JSON→YAML layers this way.

### Copilot Studio Code Editor — Bare inline (no quotes)
```yaml
condition: =!IsBlank(First(System.Activity.Attachments))
```
Quoting the condition value breaks the editor's parser — it strips content inside parentheses, leaving `=!IsBlank()` with a PowerFxError.

### Rule of thumb
- **API PATCH only** → single-quoted
- **Pasting into UI code editor** → bare inline, no quotes
- Never mix on the same topic — once you start with API PATCH, finish with API PATCH. The UI caches stale YAML and will overwrite your API changes on save.

## Reading Publish Diagnostics

When `pac copilot publish` fails, the exact errors are in the bot's `synchronizationstatus` field:

```bash
TOKEN=$(cat /path/to/token.txt)
curl -s -H "Authorization: Bearer $TOKEN" -H "Accept: application/json" \
  "https://<org>.crm.dynamics.com/api/data/v9.2/bots(<bot-guid>)?$select=synchronizationstatus" \
  | python3 -c "
import json,sys
d=json.load(sys.stdin)
ss = json.loads(d.get('synchronizationstatus','{}'))
lfp = ss.get('lastFinishedPublishOperation',{})
print('Status:', lfp.get('status'))
print('End:', lfp.get('operationEnd'))
for detail in lfp.get('diagnosticDetails',[]):
    comp = detail.get('componentId','?')[:10]
    act = detail.get('reference',{}).get('actionId','?')
    for dl in detail.get('diagnosticList',[]):
        print(f'  {comp}/{act}: {dl.get(\"errorMessage\")}')
```

Common errors from diagnostics:
- `MissingRequiredProperty: Id` on a ConditionGroup → the condition node has no `id:` field or the YAML structure is corrupted (often indentation)
- `MissingRequiredProperty: Condition` → same cause
- `MissingRequiredProperty: Title` on instructions → conversationStarters missing `title:+text:` format

**The `pac` CLI often shows a cached timestamp.** Always verify via the Dataverse API above. The `operationEnd` timestamp is the real indicator of whether a new publish ran.

## YAML Restructuring: AdditionalInstructions Indentation

When extracting `additionalInstructions` from one YAML context and re-inserting at a different nesting depth, the **entire block scalar content must be re-indented** to the new depth.

```yaml
# Original at 8-spaces indent:
      additionalInstructions: |-
        Line 1 text
        Line 2 text

# After moving to 14-spaces indent:
              additionalInstructions: |-
                Line 1 text    # was 8 spaces, now 16
                Line 2 text    # was 8 spaces, now 16
```

**If you don't re-indent**, the continuation lines (2nd, 3rd, etc.) break out of the block scalar and become top-level YAML nodes, corrupting the entire topic structure. The publish validator reports `MissingRequiredProperty` on the nearest ConditionGroup — but the root cause is the broken `additionalInstructions` content.

**Fix**: When extracting `additionalInstructions` content via regex, re-indent every continuation line to match the target context by prefixing the correct number of spaces:

```python
# Target indent = 16 spaces (under 14-spaced key)
lines = instruction_text.split("\n")
reindented = "\n".join(" " * 16 + line.strip() for line in lines if line.strip())
```

Or use a YAML-aware approach that tracks the block scalar indent automatically.

## Making Knowledge Sources Searchable with Descriptions

KB components (type 14) store data as YAML fields. Adding `description:` improves generative orchestration routing:

```yaml
kind: FileAttachmentComponentMetadata
description: CMS Medicare Benefit Policy Manual Chapter 15 — therapy coverage, medical necessity, POC, skilled services
triggerCondition: true
```

Patch via:
```python
new_data = base_lines[0] + "\ndescription: " + desc + "\n" + "\n".join(base_lines[1:])
```

The description helps the AI match user queries to the right knowledge source. Without it, routing is less accurate.

## 3-Branch ConditionGroup for File+Text Dual-Input

**This pattern MUST have 3 branches — never 2.** See `copilot-studio-yaml-reference` SKILL.md section "Additive File + Text Pattern" and `file-text-dual-input-pattern.md` for the full template.

1. File attached → processing
2. Text provided (no file) → SearchAndSummarizeContent with Concatenate
3. Neither → GotoAction back to Question

Skipping branch 2 or 3 causes silent failures (text inputs fall through, empty inputs produce generic garbage).
