# Publish Validation Checklist — Common Silent YAML Bugs

| Check | Symptom | Fix |
|-------|---------|-----|
| Conditions with empty `IsBlank()` — `=!IsBlank()` no argument | Publish fails MissingRequiredProperty 'Condition' | Add: `=!IsBlank(First(System.Activity.Attachments))` |
| Conditions with `.Content` in boolean — `=!IsBlank(First(...).Content)` | Publish fails MissingRequiredProperty 'Condition'+'Id' | Remove `.Content` — File blob not boolean-usable |
| Inverted text condition — `=IsBlank(Topic.Var)` missing `!` | Wrong branch runs silently (SASC fires when text IS blank) | Fix: `=!IsBlank(Trim(Topic.Var))` |
| SendActivity with `{}` wrapping Power Fx — `"{If(...)}"` | Formula literal rendered to user, never evaluated | Use `=` prefix: `"=If(...)"` |
| SendActivity outputs raw input `System.Activity.Text` | Shows user's question text, not the AI's analysis | Use `{Topic.Answer.Text.Content}` |
| AI instructions containing Power Fx (`Concatenate()`, `Char(10)`) | AI model receives code syntax instead of plain-text instructions | Write plain English only in `additionalInstructions: |-` block scalars |
| `FilePrebuiltEntity` on Question node | Only captures one file — rest silently dropped | Change to `StringPrebuiltEntity` + 3-branch ConditionGroup |
| UI caches stale YAML after API PATCH | Changes work in Dataverse but UI shows old version | Shift+Reload browser tab before editing |

## Publish Diagnostics via Dataverse

When `pac copilot publish` fails, the CLI output ("Failed [timestamp]") may show a cached/old timestamp. Get actual diagnostics:

```bash
TOKEN=$(cat /path/to/az_token.txt)
curl -s -H "Authorization: Bearer $TOKEN" -H "Accept: application/json" \
  "https://<org>.crm.dynamics.com/api/data/v9.2/bots(<bot-id>)?\$select=synchronizationstatus" \
  | python3 -c "
import json,sys; d=json.load(sys.stdin)
ss=d.get('synchronizationstatus','{}')
parsed=json.loads(ss) if isinstance(ss,str) else ss
lfp=parsed.get('lastFinishedPublishOperation',{})
print(f'Status: {lfp.get(\"status\")}')
for detail in lfp.get('diagnosticDetails',[]):
    comp=detail.get('componentId','?')[:12]
    act=detail.get('reference',{}).get('actionId','?')
    for dl in detail.get('diagnosticList',[]):
        print(f'  {comp}/{act}: {dl.get(\"errorMessage\")}')
"
```

The `operationEnd` timestamp updates on each publish attempt even if the CLI timestamp doesn't. Look for componentId + actionId + errorCode in diagnosticDetails.
