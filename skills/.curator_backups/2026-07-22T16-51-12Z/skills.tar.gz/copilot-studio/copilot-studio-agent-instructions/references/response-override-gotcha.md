# Response override: Generative AI — Responses box vs main instructions

The `Settings → Generative AI → Responses` text area (the `responseOverride` field in Dataverse) **overrides the main agent instructions component entirely**. This is the most common silent failure mode when modifying agent behavior.

## How it works

- The main instructions (componenttype 15) set the agent's primary behavior
- The responses override (stored in the bot entity's `responseOverride` or set via the Copilot Studio UI at Settings → Generative AI → Responses) takes **priority over** the main instructions
- Edits to the instructions component have **no visible effect** if the responses box contains conflicting directives
- This is because the generative AI platform concatenates the response override AFTER the main instructions, and the model follows the most recent/repeat directive

## Route-aware format strategy

The content of the responses override must be tailored to the agent's topic routing:

| Route Type | Format in override |
|---|---|
| Document audits / clinical output | Full markdown with tables, headers, numbered sections |
| General Q&A | Concise bullets |
| Missing-doc invites | Paste prompt with formatting instructions |

**Critical: Do NOT put "No headers or markdown" or "Use plain text only" in the response override if Route A (audit) needs markdown/tables.** That directive strips formatting from audit output and the grader penalizes completeness.

## Diagnosing override conflicts

If an instructions change doesn't take effect:

1. Check if `Settings → Generative AI → Responses` has content — any non-empty text there overrides
2. Compare the override text to the instructions — look for contradictory directives (format rules, scope definitions)
3. The override wins every time — either empty it, or fold its content into a unified strategy

## Verification

After editing instructions, send a test message that triggers the audit route and check whether formatting matches the instructions directive. If the model emits plain text despite instructions asking for tables, the response override is the cause.

## Character budgets

| Field | Hard max | Prefer |
|-------|----------|--------|
| Main instructions body | 7000 | ~6000 |
| Responses / `responseInstructions` | 500 | ≤495 |

Dense Responses one-liners must still allow markdown for clinical/audit routes (no "plain text only"). Put full structure in instructions; put format skeleton in Responses so the override reinforces rather than fights.

## Align section order with instructions

The Responses one-liner must list the **same report sections in the same order** as the instructions body. Example failure: instructions restore Timeline and Responses still omits it (or the reverse) → model follows Responses and ignores the rewrite.

**Rule:** any structure edit → re-author Responses in the same turn → PATCH both → one publish. Do not leave Responses stale.

## How `responseInstructions` is stored

Besides the UI Responses box / bot `responseOverride`, the same content often lives as `responseInstructions:` **inside** componenttype 15 `GptComponentMetadata` `data`. PATCHing that key on the instructions component is a validated inject path (Case History 2026-07-17). Bot entity response* columns may be empty even when the override is active via type-15.

## Related shared-graph entities

- `ResponseOverrideGotcha` (entityType: `gotcha`) in the shared MCP graph
- `LiveUITruthRule` (entityType: `convention`) — source-of-truth rules including response formatting
