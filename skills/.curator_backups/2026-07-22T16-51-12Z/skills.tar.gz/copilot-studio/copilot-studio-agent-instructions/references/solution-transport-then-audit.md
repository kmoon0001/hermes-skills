# Solution transport then instructions audit

When moving agents between envs with unmanaged solutions (see skill `copilot-studio-agent-solution-migration` — may be **pinned**; if patches are refused, put session detail under `agent-audit-protocol/references/`):

1. Create focused unmanaged solution (Dataverse POST `/solutions` if needed).
2. `pac solution add-solution-component --componentType bot --AddRequiredComponents`.
3. Export unmanaged → import target `--publish-changes --force-overwrite`.
4. **Re-fetch target botid by name** (new GUID).
5. Publish until Synchronized.
6. Immediately run agent-audit-protocol Domains 1–3 + instructions review:
   - `GPT55Chat` typos
   - empty `responseInstructions` (len ~1)
   - SASC missing FullResponse
   - Fallback without SASC
7. Char budgets if rewriting instructions: body ≤7000 prefer ~6000; Responses ≤500; align section order both fields; inject via type-15 PATCH.

Worked Doc Defense example IDs and P0 list: `agent-audit-protocol` → `references/post-migration-doc-defense-therapy-ai-dev.md`.
