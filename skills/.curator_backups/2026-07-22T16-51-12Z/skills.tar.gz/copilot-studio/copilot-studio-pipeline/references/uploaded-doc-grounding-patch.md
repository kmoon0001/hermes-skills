# Uploaded-Document Grounding Patch (validated Jul 17 2026)

Proven Python pattern for binding a `SearchAndSummarizeContent` (SASC) node so it reads
**user-uploaded PDFs** in the conversation, not just the agent-level knowledge bases. Built
and shipped live on Pacific Coast Documentation Defense Agent
(`2e08ac68-bdef-481e-9c04-6a349c79d6c0`, `crbee_…DocumentationDefenseAgent`) in
Therapy AI Agents Dev (`orgbd048f00`).

## Symptom
Agent has 14 regulatory KBs attached at agent level. User uploads a therapy note PDF in the
test pane and asks "audit this documentation." Agent replies:
"No information was found that could help answer this." → because the SASC node only had
`applyModelKnowledgeSetting: true` and no `fileSearchDataSource`/`knowledgeSources` binding,
so the uploaded note was never ingested.

## Root cause
A SASC node with ONLY `applyModelKnowledgeSetting: true` does not automatically consume the
uploaded file in the turn. You must explicitly tell the node to search files + knowledge.

## Fix — two YAML blocks on the SASC node
Insert after `responseCaptureType: FullResponse` and before `variable: Topic.Answer`:

```yaml
      fileSearchDataSource:
        searchFilesMode:
          kind: SearchAllFiles
      knowledgeSources:
        kind: SearchAllKnowledgeSources
```

- `SearchAllFiles` = node reads the user's uploaded doc this turn AND agent-attached files.
- `SearchAllKnowledgeSources` = node also searches the agent-level KBs.
- Do NOT use `SearchUploadedFiles` alone — excludes the KBs the defense argument needs.

## Working Python PATCH (line-ending sequence that actually works)

The trap: `Path.read_text()` strips `\r`, so matching on `\n` silently fails (HTTP 204, no change).
Pull via `urllib` (preserves `\r\n`), match on raw `\r\n`, then normalize CRLF for the PATCH payload.

```python
import json, urllib.request, urllib.parse, subprocess
from pathlib import Path

# 1) Auth (token to file first — terminal truncates long output)
subprocess.run(
    ["az", "account", "get-access-token",
     "--resource", "https://orgbd048f00.crm.dynamics.com",
     "--query", "accessToken", "-o", "tsv"],
    stdout=open(r"C:/Users/kevin/Desktop/az_token.txt", "w"),
)
tok = open(r"C:/Users/kevin/Desktop/az_token.txt").read().strip()
BASE = "https://orgbd048f00.crm.dynamics.com/api/data/v9.2"
H = {"Authorization": f"Bearer {tok}", "Content-Type": "application/json",
     "OData-MaxVersion": "4.0", "OData-Version": "4.0", "Accept": "application/json"}

CID = "ef6990c4-...."  # botcomponentid of the audit topic (crbee_docUploadAndAudit)

# 2) PULL via urllib (preserves \r\n)
req = urllib.request.Request(f"{BASE}/botcomponents({CID})?$select=data", headers=H)
d = json.loads(urllib.request.urlopen(req, timeout=90).read().decode())["data"]

# 3) BACKUP from raw pulled string (preserves \r\n for safe reversion)
Path(r"C:/Users/kevin/Desktop/docdef_audit_before_patch.yaml").write_text(d)

# 4) MATCH + REPLACE on raw \r\n anchor
anchor = '      responseCaptureType: FullResponse\r\n\r\n      variable: Topic.Answer'
assert anchor in d, "anchor missing (CRLF)"
inject = ('      responseCaptureType: FullResponse\r\n\r\n'
          '      fileSearchDataSource:\r\n        searchFilesMode:\r\n'
          '          kind: SearchAllFiles\r\n'
          '      knowledgeSources:\r\n        kind: SearchAllKnowledgeSources\r\n\r\n'
          '      variable: Topic.Answer')
d2 = d.replace(anchor, inject, 1)
assert 'fileSearchDataSource' in d2 and 'SearchAllFiles' in d2

# 5) PATCH payload: normalize to CRLF
d2c = d2.replace('\r\n', '\n').replace('\r', '\n').replace('\n', '\r\n')
req = urllib.request.Request(f"{BASE}/botcomponents({CID})",
                             data=json.dumps({"data": d2c}).encode(),
                             method="PATCH", headers=H)
with urllib.request.urlopen(req, timeout=120) as resp:
    print("PATCH", resp.status)  # expect 204

# 6) PUBLISH
subprocess.run(["pac", "copilot", "publish",
                "--environment", "https://orgbd048f00.crm.dynamics.com",
                "--bot", "2e08ac68-bdef-481e-9c04-6a349c79d6c0"],
               capture_output=True, text=True)

# 7) VERIFY — re-GET, assert substring exists (don't trust 204)
req = urllib.request.Request(f"{BASE}/botcomponents({CID})?$select=data", headers=H)
d_live = json.loads(urllib.request.urlopen(req, timeout=90).read().decode())["data"]
assert 'fileSearchDataSource' in d_live and 'SearchAllFiles' in d_live
print("VERIFIED: upload binding live")
```

## Verify in Studio
1. Shift+Reload the Copilot Studio tab (clear UI cache).
2. Open the agent → Test pane.
3. Upload the therapy note PDF.
4. Say: "audit this documentation for compliance risks and build defense."
5. Expect an Evidence→Standard→Reasoning→Risk audit citing the uploaded note + regulatory KBs.

## Note on the Question-node red herring
If the user edited the classic canvas to add a `Question` node + `Var1` + generative-answers
chain, that is the WRONG structure and typically does not touch the live modern SASC topic
(the canvas may show a classic representation). The real fix is the `fileSearchDataSource` /
`knowledgeSources` binding above — not a Var1 variable. Uploaded files ride along in the turn
automatically; they are never stored in a topic variable.
