# Adaptive Card Deep-Dive Grounding Pattern (validated Jul 17 2026)

Proven pattern for adding a POST-REPORT discipline/clinical deep-dive to a Copilot Studio
agent WITHOUT breaking Single-Response eval on short questions. Built and shipped live on
Pacific Coast Case History Reviewing Agent (`f19e1c40-…`, `cr917_…ReviewingAgent`) in
Therapy AI Agents Dev (`orgbd048f00`).

## Goal
After the agent produces a case-history / clinical report, let the clinician open a
deeper, knowledge-grounded interpretation (what findings mean, clinical significance,
eval implications, med→effect→precaution) for a specific discipline via a card or
trigger phrases — routed to a generative node, NOT free-form opinion.

## Architecture
1. **Dedicated topic** `Discipline Clinical Deep Dive` (componenttype 9):
   - `AdaptiveCardPrompt` with `Input.ChoiceSet` (PT / OT / SLP / ALL / SKIP),
     `isRequired: true`, `errorMessage` set, `Action.Submit` with `actionSubmitId`.
   - Output binding: `selectedDiscipline: Topic.SelectedDiscipline` (String).
   - `ConditionGroup`: if SKIP/blank → SendActivity hint + EndDialog. Else →
     `SearchAndSummarizeContent` (SASC) with `fileSearchDataSource.SearchSpecificFiles`
     (list the 16 real file GUIDs) + `knowledgeSources.SearchSpecificKnowledgeSources`
     (list the 2 topic KB GUIDs) + `applyModelKnowledgeSetting: true`.
   - SASC `userInput` = `Concatenate("…instructions…", Topic.SelectedDiscipline, "…",
     System.Activity.Text)`. DO NOT wrap String args in `Text()` (errors on String) and
     DO NOT reference a record-type global (errors). Use `System.Activity.Text` for the
     user's own clinical text; rely on conversation context for the prior report.
   - `SendActivity` the `Topic.DeepDiveAnswer` + EndDialog (`clearTopicQueue: true`).
2. **Wire into report topics** (Clinical Analysis, Multi-Discipline Summary, Fallback):
   - After the report `SendActivity`, add a `ConditionGroup`:
     - IF request looks like a full case-history/eval job (`Len(System.Activity.Text) > 180`
       or keywords: case history / eval / synthesize / hospital course / clinical document)
       → `BeginDialog` → the deep-dive topic (Adaptive Card shown).
     - ELSE → text-only hint (list the trigger phrases). Protects short-Q eval from the card.
   - **Fallback specifically**: do NOT auto-open the card (kills eval scores). After the
     report, show a TEXT prompt: "Say PT deep dive / OT deep dive / SLP deep dive / all
     three discipline deep dives / discipline clinical deep dive." Those phrases also
     trigger the topic directly as standalone next-turn intents.
3. **Shared report context (Global var)** — only the Fallback's `Global.Answer.Text`
   (genuinely a String) may `init:Global.LastCaseHistoryReport`. Report topics must NOT
   re-store the answer (assigning the SASC record to a String global fails publish).

## Why this shape (logic)
- **Card after report, not before**: the report is the unit of value; the drill-down is
  optional. Auto-card on every turn would force interactive content into SR eval → Abandonment.
- **Per-topic KB pinning** (not agent-level-only) makes "grounded in CMS/Beers/labs/APTA/AOTA/
  ASHA/IDDSI" actually true, not model-knowledge bluffing.
- **Discipline lens** turns a flat report into actionable clinical reasoning for the
  *evaluating* therapist (PT/OT/SLP each care about different findings, precautions, assessments).
- **DRAFT — CLINICAL REVIEW REQUIRED** footer on every deep dive (non-diagnostic, audit-safe).

## Trigger phrases that must route to the deep-dive topic
discipline clinical deep dive, PT/OT/SLP deep dive, more PT/OT/SLP clinical detail,
what does this mean for PT/OT/SLP evaluation, clinical interpretation for PT/OT/SLP,
explain findings for therapy eval, discipline-specific clinical significance,
meds labs precautions for PT/OT/SLP eval, all three discipline deep dives.

## Publish gotchas (see SKILL.md "Publish failure diagnostic loop")
- A non-atomic string replace on the topic YAML truncated `responseCaptureType: FullResponse`
  → `FullRespon…` → publish Failed. Rebuild full YAML; verify the literal survives.
- Storing SASC record into a String Global var → IncorrectTypeError. Only init from a true String.
- `Text()` on a String → ExpressionError. Don't wrap.
- `Global.Answer.Text.Content` → "." on Text error. Use `.Text` (String) or `.Answer` (record).

## Files (local artifacts from the build)
- `C:\Users\kevin\Desktop\pcr_DisciplineClinicalDeepDive.yaml` — the shipped topic
- `C:\Users\kevin\Desktop\pcr_backup_*_before_deepdive.yaml` — pre-change backups
- `C:\Users\kevin\Desktop\rebuild_pcr_deep_dive.py` — clean rebuild + publish script

## Contrast: Pacific Coast Documentation Defense Agent (`2e08ac68-bdef-481e-9c04-6a349c79d6c0`)
Different agent. 4 defense surfaces (Doc Audit+Defense, MAC Appeal/Survey, General Compliance
Q&A, Managed Care Contract Analysis) + healthy 3-tier Fallback. Its topics set
`applyModelKnowledgeSetting: true` but had NO per-topic `fileSearchDataSource`/`knowledgeSources`
pin — grounding depends on agent-level KB attachment. VERIFY the agent has the CMS/MBPM/Jimmo/
Beers/contract KBs attached before trusting its "regulation-grounded" defense arguments in a
real audit. (The memory note's older GUID suffix `…59d4e65` for this agent is STALE; live is
`…d6c0`.)
