# Text-Paste Additive Pattern for Doc Topics

## When to Use

When a Copilot Studio doc-review topic has `entity: FilePrebuiltEntity` on its upload Question node, but the agent also needs to accept pasted text input (e.g., for Conversational evals that cannot upload files).

## The Pattern

Keep the file upload path (AI Builder, SearchAndSummarizeContent, etc.) 100% intact. Add a text-input branch alongside it using a nested ConditionGroup in the `elseActions`.

## Recipe

### 1. Change Question Entity

```
BEFORE: entity: FilePrebuiltEntity
AFTER:  entity: StringPrebuiltEntity
```

Also update the prompt to mention both options: "Paste the text of or upload the X document."

Questions REQUIRE an entity — removing `entity:` entirely causes `MissingRequiredProperty: Entity` on publish.

### 2. Update File Check Condition

```
BEFORE: condition: =!IsBlank(Topic.<var>)
AFTER:  condition: =!IsBlank(First(System.Activity.Attachments))
```

### 3. Update AI Builder Binding (Use .Content, NOT SetVariable)

**CRITICAL:** Do NOT add a SetVariable to bridge the file attachment. The attachment is a Record type; the StringPrebuiltEntity variable is String type. Assigning a Record to a String variable causes `IncorrectTypeError` on publish.

Instead, update the AI Builder input binding to use `.Content` — this extracts the File-typed blob from the attachment Record:

```yaml
BEFORE: Evaluation_doc: =Topic.Evaluation_doc
AFTER:  Evaluation_doc: =First(System.Activity.Attachments).Content
```

**Why .Content is required:**
- `First(System.Activity.Attachments)` returns `Record(Content:File, ContentType:String, Name:String, Value:File)` — a Record type
- AI Builder model inputs expect `File` type, not `Record`
- `.Content` extracts the File-typed blob that matches what AI Builder expects
- Without `.Content`, publish fails with: `IncorrectTypeAssignment — Assigned: Record, expected: String`

No SetVariable needed. The AI Builder receives the file content natively.

### 4. Add Text-Input Branch in elseActions

Replace the existing `elseActions: GotoAction` with a nested ConditionGroup.

**IMPORTANT — Condition format depends on where you paste:**
- **UI Code Editor:** Use bare inline (NO quotes) — `condition: =!IsBlank(Trim(Topic.DocumentText))`
- **Dataverse API PATCH:** Use single-quoted — `condition: '=!IsBlank(Trim(Topic.DocumentText))'`

**PITFALL — Single-quoted conditions in the editor get stripped to empty `=!IsBlank()`.** This was verified across 6 topics on Jul 10-11 2026. The code editor's YAML parser consumes the content inside parentheses when the condition value is wrapped in single quotes. The fix is to paste bare inline conditions into the editor: `condition: =!IsBlank(First(System.Activity.Attachments))` (no surrounding quotes).

See the main skill's "Condition Format: Editor vs Dataverse API" section for the full explanation.

```yaml
      elseActions:
        - kind: ConditionGroup
          id: conditionGroup_text_check
          conditions:
            - id: condition_has_text
              # BARE INLINE format — for pasting into the UI code editor
              condition: =!IsBlank(Trim(Topic.DocumentText))
              actions:
                - kind: SearchAndSummarizeContent
                  id: search_text_audit
                  variable: Topic.AuditResult
                  userInput: '=Concatenate("Audit this documentation...", Topic.DocumentText)'
                  applyModelKnowledgeSetting: true
                  responseCaptureType: FullResponse
                - kind: SendActivity
                  id: sendActivity_text_audit
                  activity: "{Topic.AuditResult.Text.Content}"
                - kind: EndDialog
                  id: endDialog_text_audit
                  clearTopicQueue: true
          elseActions:
            - kind: GotoAction
              id: goto_upload_retry
              actionId: question_upload_doc
```

**Note:** Use `Topic.DocumentText` (the Question's variable) rather than `System.Activity.Text`. The Question node captures the user's response into its variable, which is more reliable than reading from `System.Activity.Text` directly.

### 5. Full Topic Structure

The resulting topic flow:

1. **Question** (StringPrebuiltEntity) → captures user text or file reference
2. **ConditionGroup** (file check): `!IsBlank(First(System.Activity.Attachments))`
   - Yes → AI Builder with `=First(System.Activity.Attachments).Content` binding → SendActivity → EndDialog
   - No → **nested ConditionGroup** (text check): `!IsBlank(Trim(System.Activity.Text))`
     - Yes → SearchAndSummarizeContent → SendActivity → EndDialog
     - No → GotoAction back to Question

### 6. Verify

Check the published topic via Dataverse GET:
- `StringPrebuiltEntity` present ✅
- `First(System.Activity.Attachments)` in file condition ✅
- `InvokeAIBuilderModelAction` still present ✅ (AI Builder path intact)
- AI Builder binding uses `=First(System.Activity.Attachments).Content` not `=Topic.<var>` ✅
- `search_text_audit` or `conditionGroup_text_check` present ✅ (text path)
- No `set_file_input_` SetVariable ✅
- `GotoAction` still present for fallback ✅
- YAML valid (`yaml.safe_load`) ✅

## Validation Changes

When changes are made via Dataverse PATCH, always re-read and verify YAML validity. The publish compiler checks YAML structure; valid PATCH responses (204) do NOT guarantee valid YAML. Always read back and verify before publishing.

## Validated

All 6 therapy doc topics on Medicare Part B Compliance Agent (b0346795), July 10-11 2026. The SetVariable bridge pattern caused `IncorrectTypeError` on publish. The `.Content` binding pattern (`=First(System.Activity.Attachments).Content`) validated successfully on all 6 topics.

**Condition format lesson (validated Jul 11):** Single-quoted conditions (`condition: '=!IsBlank(...)'`) get stripped to empty `=!IsBlank()` when pasted into the Copilot Studio code editor. Only bare inline conditions (`condition: =!IsBlank(...)`) survive the editor's YAML parser. However, the Dataverse API PATCH requires the single-quoted form to prevent backslash compounding. **The two environments have opposite requirements.**

**When to use which:**
- **User pastes code editor:** bare inline conditions, no surrounding quotes. Save to `.yaml` file, open in Notepad.
- **Agent PATCHes via API:** single-quoted conditions.
- **Never mix both** on the same topic in the same editing session — the UI cache overwrites API changes.
