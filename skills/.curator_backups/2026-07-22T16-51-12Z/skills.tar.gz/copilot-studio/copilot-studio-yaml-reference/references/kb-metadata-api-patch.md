# KB Metadata Patching via Dataverse API

After uploading files via the UI, you can add/update knowledge source descriptions
and metadata via Dataverse API PATCH on the botcomponent's `data` field.

## When to Use

- You uploaded PDFs via the Copilot Studio UI but need to add descriptions
- You need to batch-update descriptions across many KBs
- You want to ensure KB descriptions help generative orchestration route correctly

## KB Component Data Format

Uploaded files are stored as `FileAttachmentComponentMetadata` (componenttype=14):

```yaml
kind: FileAttachmentComponentMetadata
triggerCondition: true
```

## Adding a Description

PATCH the `data` field of the botcomponent. Insert a `description:` line between
the `kind:` line and any other fields:

```yaml
kind: FileAttachmentComponentMetadata
description: CMS Medicare Benefit Policy Manual Chapter 15 Sections 220-230. Covers therapy coverage requirements, medical necessity, Plan of Care, skilled services definition, and documentation standards for Part A and Part B.
triggerCondition: true
```

## Python Pattern

```python
# Fetch current data
req = urllib.request.Request(f"{org}/api/data/v9.2/botcomponents({kb_id})?$select=data", headers=H)
d = json.loads(urllib.request.urlopen(req).read())
current_data = d.get("data", "") or ""

# Add description after kind line
base = current_data.replace("\r\n", "\n").strip()
lines = base.split("\n")
new_data = lines[0] + "\ndescription: " + description_text + "\n" + "\n".join(lines[1:])
new_data_crlf = new_data.replace("\n", "\r\n")

# PATCH
body = json.dumps({"data": new_data_crlf}).encode("utf-8")
req2 = urllib.request.Request(f"{org}/api/data/v9.2/botcomponents({kb_id})", data=body, method="PATCH", headers=H)
urllib.request.urlopen(req2)
```

## Description Best Practices

Per MS Learn, descriptions help generative AI route to the right source. Write:

- **What it covers** — specific topics, sections, regulations
- **Why authoritative** — CMS, federal law, professional body
- **Use case** — what queries should hit this source

Example:
```
CMS Medicare Benefit Policy Manual Chapter 15 Sections 220-230. Covers therapy
coverage, medical necessity, Plan of Care, skilled services definition, and
documentation standards for Part A and Part B SNF therapy.
```

## Pitfalls

1. **"\r\n" line endings.** Dataverse stores YAML with \r\n. Always convert `\n` to `\r\n` before PATCH, and `\r\n` to `\n` for Python string matching.

2. **No duplicate description field.** If you PATCH with a second `description:` line, YAML silently uses the LAST one. Always check if `description:` already exists before adding.

3. **Must publish to take effect.** KB metadata changes require a publish (`pac copilot publish`) to be reflected in the runtime.
