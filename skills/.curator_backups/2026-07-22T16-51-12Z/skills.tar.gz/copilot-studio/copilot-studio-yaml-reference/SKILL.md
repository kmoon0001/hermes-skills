---
name: copilot-studio-yaml-reference
description: "Complete YAML reference for Copilot Studio authoring — file types, triggers, actions, entities, variables, Power Fx, MCP actions, connector patterns, and YAML-only features."
version: 1.0.0
author: Copilot Studio YAML Reference
license: MIT
platforms: [windows, linux, macos]
metadata:
  hermes:
    tags: [copilot-studio, yaml, reference, mcs-yaml, actions, triggers, variables, power-fx, mcp]
    homepage: https://learn.microsoft.com/microsoft-copilot-studio/
---

# Copilot Studio YAML Reference

## When to Use
- Reading, writing, or editing any .mcs.yml file in a Copilot Studio agent project
- Building topics, actions, knowledge sources, variables, or child agents from scratch
- Understanding the structure of exported Copilot Studio YAML
- Debugging YAML that fails validation or doesn't behave as expected
- Working with connector actions, MCP actions, or Power Fx expressions

## Prerequisites
- Copilot Studio environment access (or exported .mcs.yml files)
- Familiarity with YAML syntax
- Basic understanding of Copilot Studio concepts (topics, actions, variables)

---

# Core File Types

| File | Purpose | kind |
|------|---------|------|
| `agent.mcs.yml` | Agent metadata — name, description, display name | `GptComponentMetadata` |
| `settings.mcs.yml` | Agent settings and configuration (orchestration mode, language, etc.) | N/A |
| `connectionreferences.mcs.yml` | Connector references (SharePoint, Dataverse, etc.) | N/A |
| `topics/*.mcs.yml` | Conversation topics — triggers, nodes, actions | `AdaptiveDialog` |
| `actions/*.mcs.yml` | Connector-based actions (standalone reusable) | `TaskDialog` |
| `knowledge/*.mcs.yml` | Knowledge sources (URLs, files, SharePoint, etc.) | `KnowledgeSourceConfiguration` |
| `variables/*.mcs.yml` | Global variables (conversation-scoped) | `GlobalVariableComponent` |
| `agents/*.mcs.yml` | Child agents (agent-to-agent delegation) | `AgentDialog` |

## Minimal Topic File Structure

```yaml
kind: AdaptiveDialog
beginDialog:
  kind: OnConversationStart
  actions: []
```

## Minimal Action File Structure

```yaml
kind: TaskDialog
inputs: []
outputs: []
action:
  kind: InvokeConnectorTaskAction
  connectionReference: <connection-id>
  operationId: <operation>
```

---

# Creating a NEW Topic (Dataverse POST)

PATCH edits an *existing* topic. To **add** a topic you do not yet have an ID for, POST a new
`botcomponent` (`componenttype: 9`) and bind it to the bot. Full recipe + gotchas in
`references/create-topic-botcomponents-post.md`. The four traps that bite first-timers:

1. **Link via the navigation property, not the lookup field.** Body key `parentbotid@odata.bind`
   with value `'/bots(<BOTID>)'`. Setting `_parentbotid_value` directly fails `0x80060888`
   ("CRM do not support direct update of Entity Reference properties, Use Navigation properties").
2. **`schemaname` needs a customization prefix** (e.g. `auto_agent_XRF5I.<Name>`). Without it,
   `0x800608ad` "must start with a valid customization prefix". Find the prefix from any existing
   topic's `schemaname`.
3. **`componenttype` is an integer `9`**, not the string `"9"`.
4. **Success returns HTTP 204, not 201.** The new `botcomponentid` comes back in the
   `OData-EntityId` *response header*, not a JSON body.

A successful POST is additive (topic count +1) and live in DRAFT — no publish needed for a DRAFT
eval. Re-PATCH the same id later to upgrade the topic. See `copilot-studio-post-eval-fix` §3f2 for
the routing reason you'd add a catch-all topic this way (100% gptFallback on "extract X from
pasted text" queries).

---

# Trigger Types

Every topic needs exactly one trigger. The trigger determines when the topic activates.

| Trigger | Purpose | Key Properties |
|---------|---------|----------------|
| `OnRecognizedIntent` | Fires when NLU matches an intent | `intent`, `modelDescription` (generative), `triggerQueries` (classic) |
| `OnConversationStart` | Fires at conversation start | None (automatic) |
| `OnUnknownIntent` | Fallback when no intent matches | None (one per agent) |
| `OnEscalate` | Fires on system escalation event | None |
| `OnError` | Fires on system error | None |
| `OnSystemRedirect` | Fires on redirect from another topic | `redirectTopicId` |
| `OnSelectIntent` | Fires when user picks from intent disambiguation | `intents` list |
| `OnSignIn` | Fires after OAuth sign-in completes | `operationId` |
| `OnToolSelected` | Fires when generative orchestration selects this topic as a tool | None |
| `OnKnowledgeRequested` | Fires when knowledge retrieval is triggered | None |
| `OnGeneratedResponse` | Fires when generative orchestration produces a response | None |
| `OnOutgoingMessage` | **NON-FUNCTIONAL as of 2026-03-15** — does not fire | None |

### Intent Triggers: Generative vs Classic

```yaml
# Generative orchestration — modelDescription tells the LLM when to use this topic
kind: OnRecognizedIntent
intent:
  id: "MyIntent"
  modelDescription: "Use this when the user wants to reset their password"

# Classic orchestration — triggerQueries are keyword/phrases for NLU matching
kind: OnRecognizedIntent
intent:
  id: "MyIntent"
  triggerQueries:
    - "reset password"
    - "forgot my password"
    - "can't log in"
```

---

# Action Types

All actions go inside a `actions: []` array within a trigger, condition, or other action node.

| Action | Purpose | Key Properties |
|--------|---------|----------------|
| `SendActivity` | Send a message to the user | `activity` (supports Power Fx) |
| `Question` | Ask the user a question and capture response | `variable`, `prompt`, `entity`, `outputFormat` |
| `SetVariable` | Set a variable value | `variable`, `value` (Power Fx expression) |
| `SetTextVariable` | Set a text variable with interpolation | `variable`, `value` |
| `ConditionGroup` | Branching logic (if/else) | `conditions` array |
| `BeginDialog` | Launch another topic/action | `dialog` (topic ID) |
| `ReplaceDialog` | Replace current dialog with another | `dialog` (topic ID) |
| `EndDialog` | End the current topic | `outputVariables` |
| `CancelAllDialogs` | Cancel all active dialogs | None |
| `ClearAllVariables` | Reset all variables to defaults | None |
| `SearchAndSummarizeContent` | Search knowledge and summarize | `searchQuery`, `knowledgeSources` |
| `AnswerQuestionWithAI` | Use AI to answer from knowledge | `question`, `knowledgeSources` |
| `EditTable` | Manipulate table data | `table`, `operation`, `rows` |
| `CSATQuestion` | Customer satisfaction survey question | `variable`, `prompt` |
| `LogCustomTelemetryEvent` | Log custom analytics event | `eventName`, `properties` |
| `OAuthInput` | Prompt user for OAuth sign-in | `connection`, `operationId` |
| `SearchKnowledgeSources` | Search specific knowledge sources | `searchQuery`, `knowledgeSources` |
| `CreateSearchQuery` | Create a search query from context | `query`, `source` |
| `AdaptiveCardPrompt` | Show Adaptive Card and capture input | `card`, `variable` |

### Example: SendActivity with Power Fx

```yaml
- kind: SendActivity
  activity: "= \"Hello \" & Topic.UserName & \"! How can I help?\""
```

### Example: Question with Entity

```yaml
- kind: Question
  variable: Topic.UserEmail
  prompt:
    kind: SendActivity
    activity: "What is your email address?"
  entity:
    kind: EMailPrebuiltEntity
  outputFormat: String
```

### Example: ConditionGroup

```yaml
- kind: ConditionGroup
  conditions:
    - condition: "= Topic.UserAge >= 18"
      actions:
        - kind: SendActivity
          activity: "You are eligible."
    - else: true
      actions:
        - kind: SendActivity
          activity: "You must be 18 or older."
```

---

# Connector Actions (TaskDialog)

Connector actions invoke external services (SharePoint, Dataverse, custom connectors, etc.). They can be standalone files (`actions/*.mcs.yml`) or inline in topics.

## Standalone TaskDialog File Structure

```yaml
kind: TaskDialog
inputs:
  - kind: AutomaticTaskInput
    name: query
    type: String
    isRequired: true
    modelDisplayName: Search Query
    modelDescription: "The search query to find items"
  - kind: ManualTaskInput
    name: filter
    type: String
    modelDisplayName: Filter
    modelDescription: "OData filter expression"
outputs:
  - name: results
    type: Table
    modelDisplayName: Results
action:
  kind: InvokeConnectorTaskAction
  connectionReference: <connection-reference-id>
  connectionProperties:
    mode: Maker    # Maker = runs as bot maker, Invoker = runs as end user
  operationId: <operation-id>
  parameters:
    query: "= inputs.query"
    filter: "= inputs.filter"
  outputMode: Single    # Single or FirstOrDefault
```

### Input Types

| Input Kind | Purpose |
|------------|---------|
| `AutomaticTaskInput` | Discovered by generative orchestration; the LLM fills it automatically |
| `ManualTaskInput` | Must be explicitly set by the topic author in calling code |

### Connection Modes

| Mode | Behavior |
|------|----------|
| `Maker` | Action runs with the bot maker's credentials |
| `Invoker` | Action runs with the end user's credentials (requires auth) |

## $-Prefixed Property Names (SharePoint/OData)

SharePoint and OData connectors use `$`-prefixed property names. YAML parsers treat `$` specially, so wrap these in double+single quotes:

```yaml
parameters:
  "'$filter'": "= \"Status eq 'Active'\""
  "'$select'": "Title,Id,Status"
  "'$top'": "10"
  "'$orderby'": "Created desc"
```

## InvokeConnectorAction Inline in Topics

When a connector action is called inline within a topic (not as a standalone TaskDialog), parameters use a `parameters/` prefix:

```yaml
actions:
  - kind: InvokeConnectorAction
    connectionReference: <connection-id>
    operationId: <operation-id>
    parameters:
      parameters/query: "= Topic.SearchTerm"
      parameters/'$filter'": "= \"Title eq 'test'\""
```

---

# MCP Actions (Model Context Protocol)

MCP actions connect to external agent servers that implement the Model Context Protocol. Unlike standard connector actions, MCP does NOT use `AutomaticTaskInput` — the MCP server handles tool discovery dynamically.

## MCP Action Structure

```yaml
kind: TaskDialog
inputs: []
outputs:
  - name: result
    type: String
    modelDisplayName: Result
action:
  kind: InvokeExternalAgentTaskAction
  externalAgentMetadata:
    kind: ModelContextProtocolMetadata
    serverUrl: "https://your-mcp-server.example.com/mcp"
    toolName: "your_tool_name"
    # Optional: authentication configuration
    authentication:
      kind: OAuth2
      # ... auth config
  parameters:
    param1: "= Topic.SomeVariable"
  outputMode: Single
```

### Key Differences from Standard Connector Actions

| Aspect | Standard Connector | MCP Action |
|--------|-------------------|------------|
| `action.kind` | `InvokeConnectorTaskAction` | `InvokeExternalAgentTaskAction` |
| Metadata | `connectionReference` + `connectionProperties` | `externalAgentMetadata` with `ModelContextProtocolMetadata` |
| Inputs | `AutomaticTaskInput` / `ManualTaskInput` | Empty `inputs: []` (MCP discovers tools dynamically) |
| Discovery | Static — defined at design time | Dynamic — MCP server advertises available tools |

---

# System Variables

Built-in, read-only variables available in all topics. Access via `System.<name>`.

| Variable | Type | Description |
|----------|------|-------------|
| `System.Bot.Name` | String | Display name of the bot |
| `System.Activity.Text` | String | Raw text of the user's last message |
| `System.Conversation.Id` | String | Unique conversation identifier |
| `System.Conversation.InTestMode` | Boolean | `true` if running in test canvas |
| `System.FallbackCount` | Number | Number of consecutive fallback triggers |
| `System.Error.Message` | String | Error message (available in OnError) |
| `System.Error.Code` | String | Error code (available in OnError) |
| `System.SignInReason` | String | Reason for sign-in (available in OnSignIn) |
| `System.Recognizer.IntentOptions` | Table | Available intent options for disambiguation |
| `System.Recognizer.SelectedIntent` | String | Intent selected by user in disambiguation |
| `System.SearchQuery` | String | Current search query |
| `System.KeywordSearchQuery` | String | Keyword-based search query |
| `System.SearchResults` | Table | Search results from knowledge sources |
| `System.ContinueResponse` | Boolean | Whether to continue generating response |
| `System.Response.FormattedText` | String | Formatted version of the bot's response |

---

# Variable Scopes

## Scope Reference

| Scope | Prefix | Lifetime | Defined In |
|-------|--------|----------|------------|
| Topic | `Topic.<name>` | Current topic only | Topic YAML (implicit) |
| Global | `Global.<name>` | Entire conversation | `variables/<Name>.mcs.yml` |
| System | `System.<name>` | Built-in, read-only | N/A (provided by runtime) |

## Defining Global Variables

Create a file in `variables/` with the `GlobalVariableComponent` kind:

```yaml
# variables/UserContext.mcs.yml
kind: GlobalVariableComponent
schema:
  type: Object
  properties:
    UserName:
      type: String
    UserEmail:
      type: String
    UserAge:
      type: Number
aIVisibility: UseInAIContext
```

### AI Visibility Options

| Value | Effect |
|-------|--------|
| `UseInAIContext` | Variable is visible to generative orchestration (LLM can read/write) |
| `Hidden` | Variable is NOT visible to generative orchestration |

---

# Prebuilt Entities

Entities extract structured data from user input. Use these built-in entity types:

| Entity | Type | Extracts |
|--------|------|----------|
| `BooleanPrebuiltEntity` | Boolean | Yes/no, true/false values |
| `NumberPrebuiltEntity` | Number | Numeric values (integers, decimals) |
| `StringPrebuiltEntity` | String | Free-text strings |
| `DateTimePrebuiltEntity` | DateTime | Dates and times |
| `EMailPrebuiltEntity` | String | Email addresses |

### Entity Usage in Questions

```yaml
- kind: Question
  variable: Topic.UserEmail
  prompt:
    kind: SendActivity
    activity: "What is your email?"
  entity:
    kind: EMailPrebuiltEntity
  outputFormat: String
```

### Entity Usage in Trigger Recognition

```yaml
kind: OnRecognizedIntent
intent:
  id: BookFlight
  modelDescription: "User wants to book a flight"
  entities:
    - name: Destination
      kind: StringPrebuiltEntity
    - name: TravelDate
      kind: DateTimePrebuiltEntity
```

---

# Power Fx Expression Reference

Copilot Studio uses a subset of Power Fx for expressions in variables, conditions, and message interpolation.

## Syntax Basics

| Feature | Syntax | Example |
|---------|--------|---------|
| Expression prefix | `=` (must start with =) | `= 2 + 2` |
| String interpolation | `{expression}` inside strings | `"Hello {Topic.Name}!"` |
| Variable init (first assignment) | `init:` prefix | `init: "default value"` |
| Variable reference | `Topic.Var`, `Global.Var` | `= Topic.Count + 1` |
| String concatenation | `&` | `= "Hi " & Topic.Name` |

## Supported Functions

### Math
`Abs`, `Average`, `Count`, `CountA`, `CountIf`, `CountRows`, `Int`, `Max`, `Min`, `Mod`, `Rand`, `Round`, `Sum`, `SumIf`, `Sequence`

### Text
`Char`, `Concat`, `Concatenate`, `EndsWith`, `Exact`, `Find`, `First`, `FirstN`, `GUID`, `Hex`, `Index`, `IsBlank`, `IsEmpty`, `IsMatch`, `IsNumeric`, `Last`, `LastN`, `Left`, `Len`, `Lower`, `Mid`, `PlainText`, `Proper`, `Replace`, `Right`, `Split`, `StartsWith`, `Substitute`, `Text`, `Trim`, `TrimEnds`, `Upper`, `Value`

### Date/Time
`Date`, `DateAdd`, `DateDiff`, `DateTime`, `DateTimeValue`, `Day`, `Hour`, `Minute`, `Month`, `Now`, `Second`, `Time`, `TimeValue`, `Today`, `Weekday`, `Year`

### Logical
`And`, `Coalesce`, `Error`, `If`, `IfError`, `IsBlank`, `IsEmpty`, `IsError`, `IsMatch`, `IsNumeric`, `Not`, `Or`, `Switch`

### Table
`AddColumns`, `Column`, `Distinct`, `DropColumns`, `Filter`, `First`, `FirstN`, `ForAll`, `GroupBy`, `Index`, `Last`, `LastN`, `LookUp`, `Patch`, `RenameColumns`, `ReorderColumns`, `ShowColumns`, `Sort`, `SortByColumns`, `Table`, `UngroupBy`

### Aggregate
`Average`, `Count`, `CountA`, `CountIf`, `CountRows`, `Max`, `Min`, `Sum`, `SumIf`, `VarP`, `StdevP`

### Type Conversion
`AsType`, `Boolean`, `Char`, `Date`, `DateTime`, `DateTimeValue`, `DateValue`, `Decimal`, `Float`, `GUID`, `Hex`, `Int`, `Number`, `Text`, `Time`, `TimeValue`, `Value`

### Other
`Blank`, `Collect`, `DataSourceInfo`, `Defaults`, `EditForm`, `Field`, `IsType`, `Notify`, `Options`, `Parent`, `Remove`, `Reset`, `SubmitForm`, `ThisItem`, `User`

## Important Rules

- **Only use functions from the supported list above** — unsupported functions will cause runtime errors
- **All expressions must start with `=`** — without the prefix, it's treated as a literal string
- **String interpolation `{}` only works inside double-quoted strings**
- **`init:` prefix** — only on the first assignment of a variable in a topic; subsequent assignments drop the prefix
- **No semicolons** — use commas for function argument separation

## Common Patterns

```yaml
# Conditional message
activity: "= If(Topic.Score > 80, \"Great job!\", \"Keep trying!\")"

# String formatting
activity: "= Concatenate(\"Order #\", Topic.OrderId, \" is \", Topic.Status)"

# Date formatting
activity: "= \"Today is \" & Text(Today(), \"dddd, mmmm d, yyyy\")"

# Null-safe value
value: "= Coalesce(Topic.UserInput, \"No input provided\")"

# Filter a table
value: "= Filter(Global.Items, Status = \"Active\")"

# Count matching rows
value: "= CountIf(Global.Tickets, Priority = \"High\")"
```

---

# Available Templates

These templates can be used when creating new topics or actions in Copilot Studio:

| # | Template Name | Purpose |
|---|---------------|---------|
| 1 | `Blank` | Empty topic with no trigger or actions |
| 2 | `Call an Action` | Invoke a Power Automate flow or connector action |
| 3 | `Conversational` | Multi-turn conversation with question/answer flow |
| 4 | `Custom` | Custom topic with configurable trigger |
| 5 | `End of Conversation` | Standard conversation ending with survey |
| 6 | `Escalation` | Transfer to human agent |
| 7 | `Fallback` | Default response when no intent matches |
| 8 | `Greeting` | Welcome message and initial routing |
| 9 | `Message` | Simple one-shot message |
| 10 | `Multiple Choice Options` | Present options for user selection |
| 11 | `OAuth Connection` | Handle OAuth authentication flow |
| 12 | `Question` | Single question with entity extraction |
| 13 | `Redirect` | Redirect to another topic |
| 14 | `Survey` | Multi-question survey flow |
| 15 | `Topic with Generative AI` | AI-powered topic using knowledge sources |
| 16 | `Variable Management` | Set and manipulate variables |
| 17 | `Webhook` | Trigger external webhook and handle response |

---

# YAML-Only Features

These features work at runtime but are NOT visible in the Copilot Studio UI. They can only be configured by editing YAML directly.

## triggerCondition on Knowledge Sources

Add a `triggerCondition` to a knowledge source to control when it's queried. This works at runtime but is invisible in the UI:

```yaml
# knowledge/MySource.mcs.yml
kind: KnowledgeSourceConfiguration
displayName: Internal FAQ
triggerCondition: "= Topic.Category = \"Technical\""
sources:
  - kind: Url
    url: "https://contoso.com/faq"
```

The knowledge source will only be searched when the condition evaluates to `true`. The UI will show the knowledge source as always active, but the runtime respects the condition.

## Other YAML-Only Capabilities

- **Inline `InvokeConnectorAction`** with `parameters/` prefix — the UI shows these as regular actions but doesn't expose the prefix-based parameter syntax
- **`$`-prefixed parameters** in connector actions — the UI may not properly display these
- **Custom `modelDescription`** on intents — can be more detailed than what the UI allows
- **`aIVisibility: Hidden`** on global variables — UI shows the variable but not the AI visibility setting

---

### .Content Usage Quick Reference

| Context | Use `.Content`? | Correct Example |
|---------|----------------|-----------------|
| ConditionGroup check (IsBlank) | **NO** | `=!IsBlank(First(System.Activity.Attachments))` |
| AI Builder input binding | **YES — File blob** | `UserDocument: =First(System.Activity.Attachments).Content` — Do NOT use `Concat()` here. Concat returns a STRING; AI Builder expects FILE type. String→File binding silently hangs (starts, stops, nothing). |
| Concatenate in SASC userInput | **Use Concat()** | `Concatenate("text", Concat(System.Activity.Attachments, Content, "\\n---\\n"))` |
| SendActivity from SASC variable | **YES** | `"{Topic.Answer.Text.Content}"` |

`.Content` in a condition passes a File blob to IsBlank() causing `MissingRequiredProperty: Condition` on publish.

### Block scalar indentation breaks ConditionGroup

When `additionalInstructions: |-` content lines are at the wrong indent level, they break OUT of the instructions block and are parsed as sibling YAML nodes — displacing `id:` and `condition:` on the ConditionGroup that follows. Publish fails with `MissingRequiredProperty: 'Id'` and `MissingRequiredProperty: 'Condition'` on the ConditionGroup action.

**Root cause:** Copying instructions text from original topic YAML without re-indenting to the new nesting depth.

```yaml
# WRONG — instructions at indent 8 broke out to sibling level
      additionalInstructions: |-        # key at indent 14
        Identify whether this is...      # line 1 at indent 16 — correct
        For MAC appeals...               # line 2 at indent 8 — BROKEN OUT!
        For surveys...                   # line 3 at indent 8 — BROKEN OUT!
    - kind: ConditionGroup               # This is now a child of 'For surveys'
      id: conditionGroup...              # ConditionGroup id gets displaced

# CORRECT — all lines at indent 16
      additionalInstructions: |-
        Identify whether this is...      # indent 16
        For MAC appeals...               # indent 16
        For surveys...                   # indent 16
    - kind: ConditionGroup
      id: conditionGroup...
```

**Fix:** When extracting instructions from an original topic, re-indent ALL continuation lines to match the first line's depth (2 spaces more than the `additionalInstructions:` key). A Python re-indent routine:

```python
lines = data.split("\n")
fixed = []
for line in lines:
    stripped = line.rstrip()
    # Check if we're inside a ||- block scalar
    if in_block:
        content = stripped.strip()
        if content:
            fixed.append(" " * target_indent + content)
        else:
            fixed.append("")  # blank lines stay blank
        continue
    # ... rest of processing
```

## Power Fx on FilePrebuiltEntity Blobs

**PITFALL — FilePrebuiltEntity variables are BLOB values, not objects.** You cannot use `.Content` or `.Name` on a Topic variable declared with `entity: FilePrebuiltEntity`. The `.` operator on a Blob value produces `The '.' operator cannot be used on Blob values.`

**Correct patterns:**

| Intent | Wrong | Correct |
|--------|-------|---------|
| Pass file to AI Builder | `=Topic.TopicUploadedDoc.Content` | `=Topic.TopicUploadedDoc` (blob ref) |
| Check if file uploaded | `=!IsBlank(Topic.TopicUploadedDoc.Content)` | `=!IsBlank(Topic.TopicUploadedDoc)` |

AI Builder models that accept the file input handle the blob natively — they auto-decode and OCR the content. You do NOT need to pass `.Content` or `.Name`.

**PITFALL -- FilePrebuiltEntity Question never completes without a file (Validated Jul 10 2026).** A `Question` node with `entity: FilePrebuiltEntity` keeps re-prompting indefinitely when the user responds with text instead of a file. Any `ConditionGroup` or `elseActions` after the Question node **never execute**. This is the #1 cause of Conversational eval failures where test sets describe documents but cannot upload files. Detection: agent returns the EXACT question text for 2+ consecutive turns.

**CRITICAL — IsBlank() must have an argument. Never bare `=!IsBlank()`. Always `=!IsBlank(First(System.Activity.Attachments))` for files or `=!IsBlank(Trim(Topic.DocumentText))` for text.**

**IMPORTANT: This pattern MUST have 3 branches — file check, then nested text check, then GotoAction loop. Skipping the text-check ConditionGroup or the GotoAction causes silent failures. See the full 3-branch example below.**

**Fix -- Additive File + Text Pattern (3-branch):**

Change `FilePrebuiltEntity` to `StringPrebuiltEntity`. Branch with two nested ConditionGroups:

1. File attached → AI Builder with `=First(System.Activity.Attachments).Content` (unchanged flow)
2. Text provided → SearchAndSummarizeContent on user's pasted text → SendActivity → EndDialog
3. Neither → GotoAction back to Question

```yaml
- kind: Question
  id: question_upload_doc
  variable: init:Topic.DocumentText
  prompt: Paste the text of or upload the document...
  entity:
    kind: StringPrebuiltEntity

- kind: ConditionGroup
  id: conditionGroup_file_check
  conditions:
    - id: condition_file_uploaded
      condition: =!IsBlank(First(System.Activity.Attachments))
      actions:
        # AI BUILDER PATH (file uploaded)
        - kind: InvokeAIBuilderModelAction
          id: invokeAIBuilderModelAction
          input:
            binding:
              # MUST use .Content to extract File blob from attachment Record
              DocumentInput: =First(System.Activity.Attachments).Content
          output:
            binding:
              predictionOutput: Topic.Results
          aIModelId: <model-guid>

        - kind: SendActivity
          id: sendActivity_file_audit
          activity: "{Topic.Results.text}"

  elseActions:
    - kind: ConditionGroup
      id: conditionGroup_text_check
      conditions:
        - id: condition_has_text
          condition: =!IsBlank(Trim(Topic.DocumentText))
          actions:
            # TEXT PATH (no file, text was pasted)
            - kind: SearchAndSummarizeContent
              id: search_text_audit
              variable: Topic.AuditResult
              userInput: '=Concatenate("Audit this documentation:\n\n", Topic.DocumentText, "\n\nProvide assessment...")'
              applyModelKnowledgeSetting: true
              responseCaptureType: FullResponse

            - kind: SendActivity
              id: sendActivity_text_audit
              activity: "{Topic.AuditResult}"

      elseActions:
        # NOTHING PROVIDED — re-ask
        - kind: GotoAction
          id: goto_upload_retry
          actionId: question_upload_doc

- kind: EndDialog
  id: endDialog_main
  clearTopicQueue: true
```

**Key details:**
- File check changes from `!IsBlank(Topic.var)` to `=!IsBlank(First(System.Activity.Attachments))` — **bare format, NO quotes** for the editor
- **CRITICAL: Do NOT add `.Content` to the file check condition.** `=!IsBlank(First(System.Activity.Attachments).Content)` returns a File blob which is NOT usable in boolean context. The publish validator reports `MissingRequiredProperty 'Condition'` — the condition is treated as unreadable. `.Content` is ONLY correct in AI Builder input bindings and `Concatenate` expressions, NOT in ConditionGroup conditions.
- Text check: `=!IsBlank(Trim(Topic.DocumentText))` — also bare, no quotes
- AI Builder input binding MUST use `.Content`: `=First(System.Activity.Attachments).Content`
- This is the fixed format proven across 6 doc topics on Medicare Part B Compliance Agent, Jul 11 2026
- Questions REQUIRE an entity -- removing `entity:` entirely causes `MissingRequiredProperty: Entity` on publish

**PITFALL — Copilot Studio YAML editor rejects single-quoted condition wrappers.** When pasting YAML directly into the Copilot Studio code editor, conditions must use the bare inline format:

```yaml
# ✅ Works in the editor — bare inline value
condition: =Topic.DocumentTypeSelection = 'schema'.'Evaluation and Plan of Care'

# ❌ Fails in the editor — 'UnexpectedToken, token: 'selection.''
condition: '=Topic.DocumentTypeSelection = ''schema''.''Evaluation and Plan of Care'''
```

However, when writing to Dataverse via API PATCH, the single-quoted format is preferred to prevent backslash compounding. The two environments have opposite requirements for condition quoting.

## MS Learn Topic Description Guidelines

When writing `description` and `modelDescription` for generative AI topics:

1. **Active voice, present tense** — Start with a verb. "Audits..." not "This tool audits..."
2. **1-2 sentences** — Under 300 characters. Concise, specific to the topic's purpose.
3. **State what it DOES** — The specific note type, frameworks (CMS Chapter 15, Jimmo, Ensign 7 Habits), and output format.
4. **State what it DOES NOT do** — Negative scope prevents wrong LLM routing. "Does not review daily treatment notes."
5. **Descriptive componentName** — Unique, identifies the note type and function.
6. **Identical description and modelDescription** — Both fields should contain the same text to stay in sync.

## Document Upload Intake Router Pattern (ClosedListEntity + SendActivity)

The standard pattern for a router topic that asks "What type of document?" and routes without OCR/polling. **When pasting into the Copilot Studio YAML editor, conditions MUST use the bare inline format** (no wrapping quotes around the condition value).

```yaml
- kind: Question
  id: question_document_type
  variable: Topic.DocumentTypeSelection
  prompt: What type of therapy document did you want reviewed?
  entity:
    kind: EmbeddedEntity
    sensitivityLevel: None
    definition:
      kind: ClosedListEntity
      items:
        - id: Evaluation and Plan of Care
          displayName: Evaluation and Plan of Care
        - id: Progress Report
          displayName: Progress Report
        - id: Discharge Summary
          displayName: Discharge Summary
        - id: Recertification or UPOC
          displayName: Recertification or Updated Plan of Care
        - id: Treatment Encounter Note
          displayName: Treatment Encounter Note
        - id: Episode of Care
          displayName: Episode of Care

- kind: ConditionGroup
  id: conditionGroup_route
  conditions:
    - id: route_progress
      condition: =Topic.DocumentTypeSelection = '<schema-prefix>.topic.<TopicName>.main.<QuestionNodeId>'.'Progress Report'
      actions:
        - kind: SendActivity
          activity: I'll help you review a Progress Report. Share the document or describe what you need.
        - kind: EndDialog
    # ... repeat for each document type
```

**CRITICAL:** Do NOT wrap the `condition:` value in quotes when pasting into the editor. The bare inline format `condition: =Topic.Var = 'schema'.'item'` is required. Single-quoted YAML wrapping (`condition: '=...'`) causes `UnexpectedToken` errors in the editor. Use bare inline for the editor; use single-quoted YAML only for Dataverse PATCH (see `references/closed-list-entity-refs.md`).

## The OCR-Less Architecture

When the file-upload → OCR → poll → analyze pipeline is replaced with direct user-input analysis, the topic flow simplifies to:

1. User says document type → topic fires (trigger phrases or router)
2. Bot asks for upload or text input (Question with FilePrebuiltEntity or String)
3. User provides document (file upload or paste text)
4. SearchAndSummarizeContent generates audit report directly
5. Output via .Text.Content

No InvokeFlowAction, no InvokeAIBuilderModelAction, no polling retries. The SearchAndSummarizeContent node handles text extraction from user-provided content directly.

## Condition Format: Editor vs Dataverse API

**Copilot Studio has TWO different condition formats that are NOT interchangeable.** Choosing the wrong one causes silent data loss.

### Editor (UI Code Editor) — Bare Inline, NO quotes

When pasting YAML into the Copilot Studio code editor (`</>` button), conditions MUST use the bare inline format:

```yaml
# ✅ Works in the editor
condition: =!IsBlank(First(System.Activity.Attachments))
condition: =!IsBlank(Trim(Topic.DocumentText))

# ✅ Works in the editor — ClosedListEntity comparisons
condition: =Topic.DocumentTypeSelection = 'schema'.'Progress Report'

# ❌ FAILS in the editor — single quotes strip content to empty !IsBlank()
condition: '=!IsBlank(First(System.Activity.Attachments))'
```

**The single-quoted form causes the editor's YAML parser to strip the content inside parentheses**, resulting in `condition: =!IsBlank()` with a PowerFxError. This was verified across 6 topics on Jul 10-11 2026: every condition pasted with single quotes showed empty `()` in the visual editor.

**Validation path:** Treatment Encounter Note Review has working bare conditions (`=!IsBlank(First(System.Activity.Attachments))` and `=!IsBlank(Trim(System.Activity.Text))`) stored in the live Dataverse. These survive round-trips through the editor and render correctly in the visual canvas.

### Dataverse API PATCH — Single-Quoted (Preferred)

When patching topic YAML via `PATCH /botcomponents({id})`, the **single-quoted** form is preferred because backslash escaping compounds across JSON → YAML → Power Fx layers:

```yaml
# ✅ PREFERRED for API PATCH — single-quoted YAML
- kind: ConditionGroup
  conditions:
    - id: status_completed
      condition: '="Status: Completed" in Text(Topic.ocr_payload)'
```

### Reference Table

| Environment | Format | Example | Works? |
|-------------|--------|---------|--------|
| Code Editor | Bare inline | `condition: =!IsBlank(Topic.Var)` | ✅ |
| Code Editor | Single-quoted | `condition: '=!IsBlank(Topic.Var)'` | ❌ strips to `=!IsBlank()` |
| API PATCH | Single-quoted | `condition: '=!IsBlank(Topic.Var)'` | ✅ |
| API PATCH | Double-quoted | `condition: "=...\\"` | ❌ backslash compounding |

**Always wrap string variables in `Text()`** when using the `in` operator or any string comparison. This guarantees the type resolves as String at runtime, avoiding `Incompatible type` errors when the variable could be a Blob, Object, or untyped value.

Validated: 7 topics across Medicare Part B Compliance Agent, July 2026.

## Pitfalls

1. **ConditionGroup conditions MUST return a Boolean — `If()` returning a non-Boolean value silently causes publish failure.** A ConditionGroup `condition:` expression that returns a non-Boolean value (such as `If(condition, EmbeddedOptionSet, Blank())`) passes the publish validator's type check on some paths BUT fails with `IncorrectTypeError` (expected `Boolean`, got `EmbeddedOptionSet`) when the publish actually runs. The `If()` function returns the value of the matched branch — if that value is an EmbeddedOptionSet, the condition resolves to the option set instead of `true`/`false`.

   ```yaml
   # WRONG — If() returns the EmbeddedOptionSet value, not true/false
   condition: |-
     =If(
       "evaluation" in Lower(System.Activity.Text),
       'schema'.'Evaluation and Plan of Care',
       Blank()
     )

   # CORRECT — pure Boolean expression; assignment happens in actions block
   condition: ="evaluation" in Lower(System.Activity.Text) || "plan of care" in Lower(System.Activity.Text)

   # The SetVariable goes in the condition's actions block:
   # actions:
   #   - kind: SetVariable
   #     variable: Topic.DocumentTypeSelection
   #     value: ='schema'.'Evaluation and Plan of Care'
   ```

   **Detection:** Publish diagnostic shows `IncorrectTypeError` at the ConditionGroup's `actionId`. The error details show `expectedType: Boolean, assignedType: EmbeddedOptionSet`. This is distinct from the `ExpressionError` caused by malformed Power Fx.

   **Fix:** Replace the `If()` wrapper with a pure Boolean expression. Move any variable assignment into a `SetVariable` action inside the condition's `actions:` block. The `GotoAction` to the routing ConditionGroup then processes the pre-set variable.

   Verified: Medicare Part B Compliance Agent, July 14 2026. The first PATCH of the pre-check ConditionGroup used `If(..., EmbeddedOptionSet, Blank())` which caused `IncorrectTypeError` on publish. Switching to bare Boolean expressions resolved it.

1. **Dataverse PATCH double-escapes backslashes in YAML conditions (prevented by single-quoted form above).** When patching a `condition:` value via the Dataverse API using double-quoted YAML, backslash escaping compounds across JSON → YAML → Power Fx layers. Writing `\\\\\"` in Python (intending `\\\"` in YAML to produce a literal `\"` in Power Fx) can result in `\\\\\"` still being 2 backslashes in the stored string, which YAML interprets as `\\\\` (literal backslash) + `\\\"` (escaped quote), injecting a stray `\\` into the Power Fx expression.

2. **API↔UI Sync — Never mix API PATCH and UI edits on the same topic.** Copilot Studio's Single Page Application (SPA) caches topic YAML in browser memory. When you PATCH a topic via the Dataverse REST API, the UI still shows the STALE cached version. If you then open that topic in the visual editor and save (even without making changes), the UI overwrites the API changes with the cached version.

    **Symptoms:**
    - API PATCH returns 204 Success, but opening the topic in the UI shows the OLD content
    - Saving a topic after an API patch reverts your API changes
    - Topic can't be loaded in visual editor (YAML partially corrupted from the overwrite)
    - "Can't load variable set action" error in visual editor

    **Prevention:**
    - **Do ONE method per editing session** — either use API PATCH exclusively OR use the UI code editor
    - After an API PATCH, **Shift+Reload** the browser tab before opening any topic
    - Navigate directly via URL: `https://copilotstudio.microsoft.com/environments/{env}/bots/{bot}/adaptive/{topic-guid}` — this forces a fresh load
    - Or enable DevTools → Network → Disable cache while working

    **Best workflow:** Write YAML as local `.yaml` files, open in Notepad, paste into the UI code editor directly. No API patching, no cache issues. Verified Jul 10-11 2026: all 6 doc topics reverted to old state after UI save following API PATCH.

    **Symptoms:** `contentValidationError` at runtime with `UnexpectedCharacter` pointing at source `\\`. The error location is the condition node path. The bot publishes successfully but fails during conversation.

    **Root cause:** The Dataverse `data` field stores the YAML as a JSON-encoded string. When the data is read back via the REST API, JSON adds one layer of escaping. If your build script adds another, the stored value has `\\\\\"` or `\\\\\\\"` instead of `\\\"`. The YAML parser then sees extra backslashes as literal characters.

    **Verification:** Compare the condition line's raw hex bytes between a working topic and the failing topic rather than trusting repr output.

    **PITFALL — round-trip compounding.** Each PATCH round-trips through JSON encoding. Applying a fix to "add backslashes" then another to "remove them" can compound into `\\\\\\\"` (4 backslashes) instead of `\\\"` (1). Always write the correct format in one shot and fetch back to verify. **The single-quoted form above prevents this entirely.**

## SendActivity Power Fx: `=` prefix vs `{}` wrapper

**`{}` is for variable interpolation, `=` is for expression evaluation.** Using the wrong format produces silent output failure:

```yaml
# WRONG — {} treats If() as a variable name lookup, not an expression
activity: "{If(CountRows(System.Activity.Attachments) > 1, \"text\", \"\")}"

# CORRECT — = prefix evaluates the Power Fx expression
activity: "=If(CountRows(System.Activity.Attachments) > 1, \"text\", \"\")"
```

The interpolate format `{Topic.Var}` reads an existing variable. The evaluate format `=Expression()` runs the function. Mixing them — `"{Function()}"` — produces nothing because there's no variable named `Function()`.

**Rule of thumb:**
- `{Topic.Var}` — reading a variable value ✅
- `"=Function(...)"` — evaluating a Power Fx function ✅
- `"{Function(...)}"` — wrong format, silent output failure ❌

17. **AI Builder input binding with `=First(System.Activity.Attachments)` causes IncorrectTypeError.**

18. **YAML editing by line-removal from split list corrupts structure.** Python `data.split('\\n')` then removing lines by index produces malformed YAML because remaining lines lose parent-child indentation context. Always use targeted `data.replace(old, new)` on the complete YAML string. Never delete middle-structure lines by index. Verified Jul 10 2026.

19. **SetVariable with `First(System.Activity.Attachments)` to a String-typed variable causes IncorrectTypeError.** A StringPrebuiltEntity-typed variable cannot hold a Record value. Use `.Content` or bind the attachment directly in the consuming node's expression.

2. **ConditionGroup formula block scalars cause `Incompatible type` errors.** Using YAML `|-` (strip block scalar) syntax for `condition:` values can introduce invisible whitespace/newlines that break Power Fx parsing at runtime. Also prevented by the single-quoted inline form.

    ```yaml
    # WRONG — "Incompatible type" error at runtime
    - kind: ConditionGroup
      conditions:
        - id: status_completed
          condition: |-
            ="Status: Completed" in Topic.ocr_payload

    # CORRECT — single-quoted inline string with Text() wrapper
    - kind: ConditionGroup
      conditions:
        - id: status_completed
          condition: '="Status: Completed" in Text(Topic.ocr_payload)'
    ```

## Quick Reference: Full Minimal Topic

1. **`SearchAndSummarizeContent.userInput` with Concatenate** — when the Concatenate expression contains colons, braces, or other YAML-special characters, the entire value MUST be wrapped in double quotes with escaped inner quotes: `userInput: \\\"=Concatenate(\\\\\\\\\\\"text with colons: item\\\\\\\\\\\", Text(Topic.var), \\\\\\\\\\\"more\\\\\\\\\\\")\\\"`. Unquoted `userInput: =Concatenate(...)` breaks YAML parsing. The generated note is stored in `Topic.Answer`.

2. **`OnOutgoingMessage` trigger is non-functional** (as of 2026-03-15) — it exists in the schema but does NOT fire at runtime. Do not use it.

3. **`$`-prefixed property names** must use the double+single quote pattern: `\"'$filter'\"` — YAML treats `$` as a special character in some parsers.

4. **`init:` prefix** is only for the FIRST assignment of a variable in a topic. Using it again resets the variable.

5. **`AutomaticTaskInput` vs `ManualTaskInput`** — AutomaticTaskInput is discovered by the LLM in generative orchestration. ManualTaskInput must be explicitly set by the author.

6. **MCP actions use empty `inputs: []`** — do NOT add AutomaticTaskInput/ManualTaskInput to MCP actions; the MCP server handles tool schema discovery.

7. **Power Fx expressions MUST start with `=`** — without it, the value is treated as a literal string, not an expression.

8. **`triggerCondition` on knowledge sources** works at runtime but is invisible in the UI — if someone edits the knowledge source in the UI, the condition may be lost.

10. **Connection mode `Invoker`** requires end-user authentication — if no auth is configured, the action will fail.

11. **`outputMode: Single`** returns one row; `outputMode: FirstOrDefault` returns the first row or null. Choose based on whether you expect one result or potentially zero.

12. **Only use supported Power Fx functions** — unsupported functions cause silent failures or runtime errors.

13. **Duplicate YAML properties are silently accepted — LAST occurrence wins.** YAML parsers (both PyYAML and js-yaml) accept duplicate keys and use the LAST value. Detect with: `grep -n applyModelKnowledgeSetting topics/*.mcs.yml | cut -d: -f1 | sort | uniq -d`

14. **`SendActivity.activity` accepts string or block scalar, NOT a dict with `value`/`text`.** The nested dict form parses without error but produces no visible output at runtime. The correct form is a flat string or block scalar.

15. **`InvokeFlowAction` output binding type mismatch.** When using the OCR Text Extraction flow (or any flow that returns integer-typed fields), binding an integer output to a topic variable can cause a `FlowActionBadRequest` at runtime. For the OCR Text Extraction flow (`c71672f2`), only bind `extracted_text`, `processing_status`, and `error_message` — never `char_count`.

16. **`SearchAndSummarizeContent` / `AnswerQuestionWithAI` output is a RECORD type, not a string.** When you interpolate the variable in a `SendActivity` with `{Topic.Var}`, the runtime renders the full record structure — AI metadata, citation payloads, internal sub-records — not just the answer text. This is the #1 cause of "leaking raw AI output" bugs.

    **The fix:** always use `.Text.Content` (for text channel) or `.Speech.Content` (for voice channel) on the variable:

    ```yaml
    # WRONG — leaks full record (metadata, citations, speech/text sub-records)
    - kind: SendActivity
      activity: "{Topic.ProgressReportAuditReport}"

    # CORRECT — outputs only the clean answer text
    - kind: SendActivity
      activity: "{Topic.ProgressReportAuditReport.Text.Content}"
    ```

    The `SearchAndSummarizeContent` record has two parallel sub-properties:
    - `.Text.Content` (string) — the answer text for the text channel
    - `.Speech.Content` (string) — the answer text for the voice channel

    For `AnswerQuestionWithAI`, the same `.Text.Content` / `.Speech.Content` pattern applies to the variable named in the node's `variable:` property.

    **PITFALL (2026-07-16) — `inputType: file[]` / `property: turn.uploadedFiles` BREAKS the authoring canvas.** A `Question` node authored with:
    ```yaml
    - kind: Question
      id: question_file_upload
      variable: init:Topic.UploadedDocs
      prompt: Upload your PDF(s)...
      inputType: file[]
      property: turn.uploadedFiles
    ```
    will PUBLISH successfully (the agent runs fine in the test pane) and the runtime accepts attachments — BUT the Copilot Studio authoring canvas renders BLANK and the code editor ("</>" button) fails to open for that topic. The editor's YAML deserializer can't render the `file[]`/`turn.uploadedFiles` schema, so the whole topic canvas shows no nodes ("total frozen / code editor won't load" symptom).
    **Root cause vs. other blank-canvas causes:** distinguish from (a) a stuck "Publishing..." modal overlay (click its Close — canvas re-renders) and (b) CRLF/data corruption. This one is schema-specific: the `data` field parses at publish but not in the editor.
    **Detection:** `pac org fetch` the topic `data` and grep for `inputType: file[]` / `property: turn.uploadedFiles`. If present and the canvas is blank, this is the cause.
    **Fix:** Do NOT ship `inputType: file[]` on a Question node. Use the proven editor-safe pattern instead — `entity: FilePrebuiltEntity` (renders in the editor) OR the 3-branch File+Text pattern (see `copilot-studio-yaml-reference` §Additive File+Text Pattern). If you already shipped `file[]` and the canvas is blank: restore the topic `data` to the last editor-safe backup via Dataverse PATCH, then re-implement the upload using a schema the editor CAN render. The runtime file-upload capability does NOT require `inputType: file[]` — `System.Activity.Attachments` is available on any Question node regardless.


## Reference Files

- `references/closed-list-entity-refs.md` — ClosedListEntity entity reference format, finding schema prefix, and comparison patterns.
- `references/document-upload-intake-precheck.md` — Document Upload Intake pre-check pattern: detect document type from `System.Activity.Text` before the Question node to skip re-asking when the user already specified it. Resolves Conv eval "What type?" loop failures.
- `references/ocr-polling-loop-pattern.md` — OCR polling loop with retry_count_num sentinel.
- `references/mem0-oss-setup-windows.md` — Mem0 OSS self-hosted memory on Windows with Qdrant + OpenRouter.
- `references/dataverse-patch-workflow.md` — Dataverse PATCH workflow for updating topic YAML.
- `references/create-topic-botcomponents-post.md` — CREATE a new topic via botcomponents POST (navigation-property binding, customization-prefix schemaname, 204/OData-EntityId).
- `references/kb-metadata-api-patch.md` — Add/update KB descriptions via Dataverse API PATCH on FileAttachmentComponentMetadata components.\n- `references/text-paste-additive-pattern.md` — Additive text-input branch alongside file upload for doc review topics.

## Quick Reference: Full Minimal Topic

```yaml
# topics/Greeting.mcs.yml
kind: AdaptiveDialog
beginDialog:
  kind: OnConversationStart
  actions:
    - kind: SendActivity
      activity: "Welcome! How can I help you today?"
```

## Quick Reference: Connector Action Call from Topic

```yaml
# topics/SearchItems.mcs.yml
kind: AdaptiveDialog
beginDialog:
  kind: OnRecognizedIntent
  intent:
    id: SearchItems
    modelDescription: "User wants to search for items"
  actions:
    - kind: Question
      variable: Topic.SearchTerm
      prompt:
        kind: SendActivity
        activity: "What are you looking for?"
      entity:
        kind: StringPrebuiltEntity
    - kind: BeginDialog
      dialog: actions/SharePointSearch
      input:
        query: "= Topic.SearchTerm"
```

## Quick Reference: Global Variable File

```yaml
# variables/UserSession.mcs.yml
kind: GlobalVariableComponent
schema:
  type: Object
  properties:
    IsAuthenticated:
      type: Boolean
      default: false
    CartItems:
      type: Table
      default: "[]"
aIVisibility: UseInAIContext
```

## Quick Reference: MCP Action

```yaml
# actions/ExternalTool.mcs.yml
kind: TaskDialog
inputs: []
outputs:
  - name: response
    type: String
    modelDisplayName: Tool Response
action:
  kind: InvokeExternalAgentTaskAction
  externalAgentMetadata:
    kind: ModelContextProtocolMetadata
    serverUrl: "https://mcp.example.com/sse"
    toolName: "get_data"
  parameters:
    query: "= Topic.UserQuery"
  outputMode: Single
```
