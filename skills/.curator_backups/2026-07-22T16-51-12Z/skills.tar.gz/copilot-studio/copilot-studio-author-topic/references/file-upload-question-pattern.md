# File-Upload Question Pattern (inputType: file[])

Capture user-uploaded files into a topic variable the runtime condition can
actually detect. Use this for any "upload PDF(s) for audit/review" topic.

## The bug this fixes (root cause, verified live 2026-07-16)

A text-only Question (`variable: init:Topic.DocumentText`, `entity:
MultipleLine.String`) does NOT populate `System.Activity.Attachments` on the
test-pane / chat upload path. The upload event arrives, but the bound text
variable stays blank. Any condition testing `!IsBlank(First(System.Activity.Attachments))`
or `!IsBlank(Topic.DocumentText)` is then FALSE → the agent falls through to
the "I did not receive any documentation" fallback even though the user attached
5 PDFs. This is a REAL runtime defect, not a cosmetic UI glitch. The upload and
the text variable are DECOUPLED.

## Correct pattern: file[] Question -> turn.uploadedFiles

```yaml
    - kind: Question
      id: question_file_upload
      prompt: Upload one or more PDF therapy documents for a combined compliance audit.
      inputType: file[]
      property: turn.uploadedFiles
      interruptible: false
      allowMultipleFiles: true

    - kind: ConditionGroup
      id: condition_file_uploaded
      conditions:
        - id: condition_file_not_blank
          condition: '=!IsBlank(turn.uploadedFiles)'
          actions:
            - kind: SearchAndSummarizeContent
              id: sasc_audit_files
              connectionName: ''
              includeHistory: false
              includeMetadata: false
              responseSemanticFormat: ''
              userInput: |-
                =Concatenate(
                  "Review the following therapy documentation for compliance risks ... ",
                  Concat(turn.uploadedFiles, Content, "---NEXT DOCUMENT IN EPISODE---")
                )
            - kind: SendActivity
              id: send_activity_file_results
              activity: '{Topic.Answer}'
      elseActions:
        # text-branch or fallback
```

Key points:
- `inputType: file[]` (NOT `entity: MultipleLine.String` / `allowMultipleFiles` hack).
- `property: turn.uploadedFiles` (the collection lives on `turn.`, not `Topic.`;
  `turn.uploadedFiles` is the documented variable the `file[]` response type
  populates). Reference it in conditions as `turn.uploadedFiles` (no `Text()`).
- Condition on `!IsBlank(turn.uploadedFiles)` — this fires reliably on upload.
- For SASC ingestion, feed the file content. The proven path (from the Topic 1
  multi-doc merge) is `Concat(turn.uploadedFiles, Content, "---NEXT DOCUMENT---")`
  so multiple files merge into one episode audit. SASC natively reads the file
  content via the `file[]` variable.

## Schema correctness — DO NOT use these (they fail or silently break)

| Wrong | Why |
|---|---|
| `entity: MultipleLine.String` + `allowMultipleFiles: true` | Not a valid file-collection schema; upload decouples from the variable, condition never fires |
| `variable: init:Topic.UploadedFiles` with no `inputType` | No `file[]` type declared; upload path doesn't populate it |
| Condition on `First(System.Activity.Attachments)` for an upload Question | Attachments empty at condition time for a `file[]` Question bound to `turn.uploadedFiles` |

## Reference: verified Topic 1 fix (Pacific Coast, 2026-07-16)

Topic 1 "Therapy Documentation Compliance Audit and Defense" (bot 9e7b871d).
Before: text-only Question -> `Topic.DocumentText`, condition on
`First(System.Activity.Attachments)` -> always fell through.
After (Option A, additive): added `file[]` Question -> `turn.uploadedFiles`
+ condition `!IsBlank(turn.uploadedFiles)`, kept text branch, kept fallback +
GotoAction loop. PATCHed to Dataverse botcomponent `data` field, published,
confirmed in live `data` (version 4188200). Live upload click-test then routes
to SASC instead of the fallback.

## Deployment notes

- PATCH the whole `data` field (complete YAML, not regex) via Dataverse REST,
  verify by re-querying `data`, then `pac copilot publish --bot <guid> --environment <orgUrl>`.
- The authoring CANVAS may show the OLD structure (stale UI cache) after PATCH.
  That is cosmetic — the runtime uses the published `data` field. Ctrl+Shift+R
  the Copilot Studio tab to resync the canvas.
- To actually prove the upload end-to-end via the test pane, the native Windows
  "Open" file dialog is fragile to drive via UIA (see copilot-studio-chat-test
  pitfall). Hand the final click-test to the user at the machine, or use a
  single-call set_value on the File-name box + Open.
