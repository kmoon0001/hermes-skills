---
name: copilot-studio-author-topic
description: Create new Copilot Studio topic YAML files from templates or scratch.
category: copilot-studio
---

# Create New Topic

Generate Copilot Studio topic YAML files based on user requirements.

## Workflow

1. Auto-discover agent directory: Glob **/agent.mcs.yml. NEVER hardcode agent name.

2. Check templates in the pipeline templates/topics/ directory first:
- greeting.topic.mcs.yml — OnConversationStart greeting
- fallback.topic.mcs.yml — OnUnknownIntent fallback with escalation
- arithmeticsum.topic.mcs.yml — Topic with inputs/outputs and computation
- question-topic.topic.mcs.yml — Question with branching logic
- search-topic.topic.mcs.yml — Generative answers from knowledge
- auth-topic.topic.mcs.yml — Authentication flow
- error-handler.topic.mcs.yml — Error handling
- disambiguation.topic.mcs.yml — Multiple topics matched
- conversation-init.topic.mcs.yml — JIT glossary/context on conversation start
- custom-knowledge-source.topic.mcs.yml — OnKnowledgeRequested custom API
- remove-citations.topic.mcs.yml — OnGeneratedResponse citation stripping

3. MANDATORY: Verify ALL kind values against schema before writing:
```bash
node "D:/my agents copilot studio/pipeline/scripts/schema-lookup.bundle.js" kinds
node "D:/my agents copilot studio/pipeline/scripts/schema-lookup.bundle.js" resolve <TriggerType>
node "D:/my agents copilot studio/pipeline/scripts/schema-lookup.bundle.js" search <ActionKind>
```
NEVER write a kind value you haven't verified exists. #1 hallucination source.

4. Determine trigger type:
- OnRecognizedIntent — user phrases (most common)
- OnConversationStart — welcome/greeting
- OnUnknownIntent — fallback
- OnEscalate — escalation to human
- OnError — error handling

5. Generate YAML with:
- # Name: comment at top
- kind: AdaptiveDialog
- Appropriate beginDialog with correct trigger
- Unique IDs for ALL nodes (format: <nodeType>_<6-8 random alphanumeric>)
- Replace ALL _REPLACE placeholders if using templates

6. Check settings.mcs.yml for GenerativeActionsEnabled

7. Save to agent's topics/<topic-name>.topic.mcs.yml

8. MANDATORY: Validate after saving:
```bash
node "D:/my agents copilot studio/pipeline/scripts/schema-lookup.bundle.js" validate <saved-file.yml>
```

9. **CRITICAL: Push to live agent and verify.** Local file edits do NOT update the running agent. You must:
   - Push the YAML to Dataverse `botcomponents` table via `manage-agent.bundle.js push` OR direct Dataverse REST PATCH/POST (see `copilot-studio-manage-agent` skill)
   - **Re-query Dataverse** to confirm the `data` field contains your changes
   - Publish the agent (via gateway API, pac CLI, or UI)
   
   **PITFALL:** Files sitting in the topics/ directory are NOT visible to users until pushed AND published. "It validated clean" is NOT the same as "it's working in the live agent."

## Generative Orchestration Guidelines
When GenerativeActionsEnabled: true:
- Use Topic Inputs (AutomaticTaskInput) instead of Question nodes
- Place inputs at AdaptiveDialog root level (NOT inside beginDialog)
- Use Topic Outputs instead of SendActivity for final results
- Include inputType/outputType schemas at root level

## Topic-Action Chaining
- Self-contained topic: output confirmation/status message
- Data-gathering topic for action: output the DATA itself, not confirmation
- Ask: does this topic complete the task, or prepare data for an action?

## Power Fx Quick Reference
- Expressions start with = in YAML
- String interpolation uses {}
- Common: Text(), Now(), IsBlank(), !IsBlank()
- Variable init: variable: init:Topic.MyVar
- Type coercion: use SetTextVariable for non-text types

## Power Fx In YAML vs The UI Formula Editor

**Critical difference — the `=` prefix:**
- In YAML, conditions MUST start with `=`: `condition: '=Topic.RetryCount < 10'`
- In the Copilot Studio UI formula editor, the `=` is **implied** — the editor shows formulas WITHOUT it: `Topic.RetryCount < 10`
- This mismatch can cause confusion when reading a YAML export vs what you see in the UI. Both are correct for their context.

**Block scalar pitfall:** A `|-` block scalar introduces trailing whitespace or newlines that Power Fx cannot parse, causing "Incompatible type" errors. Always use a quoted scalar for condition formulas:

```yaml
# WRONG — block scalar introduces whitespace
          condition: |-
            ="Status: Completed" in Topic.ocr_payload

# CORRECT — quoted scalar keeps formula clean
          condition: '="Status: Completed" in Text(Topic.ocr_payload)'
```

**`Text()` wrapper:** Variables typed as `string` in the topic variables panel may still fail with the `in` operator. Always wrap the variable in `Text()` when using `in`:
- `'="term" in Text(Topic.var)'` ✅
- `'"term" in Topic.var'` ❌ — "Incompatible type"

**Rule for `in` operator conditions:** quoted scalar + `Text()` wrapper = always works.

## Card-Based Topic Pattern (Post-Session Documentation)

For topics that collect structured data via AdaptiveCard and generate notes:

```yaml
mcs.metadata:
  componentName: DISCIPLINE Note Type Card
kind: AdaptiveDialog
beginDialog:
  kind: OnRecognizedIntent
  id: main
  intent: {}
  actions:
    - kind: AdaptiveCardPrompt
      id: card_main
      card: |-
        { "type": "AdaptiveCard", ... }
      output:
        binding:
          fieldId: Topic.fieldName
      outputType:
        properties:
          fieldName: String

    - kind: SearchAndSummarizeContent
      id: gen_note
      userInput: "=Concatenate(\\\\\"Generate a skilled DISCIPLINE NOTE_TYPE. SECTIONS - 1. Header 2. Diagnosis 3. Subjective 4. Objective 5. Assessment 6. Plan 7. Signature. Data: VAR \\\\\", Text(Topic.var), \\\\\".\\\\\")\"

    - kind: SendActivity
      id: draft_note
      activity: |-
        DRAFT - CLINICAL REVIEW REQUIRED

        {Topic.Answer}

    - kind: EndDialog
      id: end_note
      clearTopicQueue: true

inputType: {}
outputType: {}
```

## Standardised modeldescription/description Metadata

Every card-based topic in the **TheraDoc** agent must have BOTH `modeldescription` and `description` set. The uniform template:

```yaml
mcs.metadata:
  componentName: PT Daily Note Card
  description: |-
    Elite clinical intelligence module specialized in [PTDailyNoteCard]. Executes high-precision data analysis grounded in CMS Chapter 15 and Pacific Coast Services Ironclad Standards. Optimized for Dynamic Chaining.
kind: AdaptiveDialog
modeldescription: |-
  Elite clinical intelligence module specialized in [PTDailyNoteCard]. Executes high-precision data analysis grounded in CMS Chapter 15 and Pacific Coast Services Ironclad Standards. Optimized for Dynamic Chaining.
```

Replace `[ComponentName]` with the topic's componentName (e.g., `[PTRecertCard]`, `[SLPEvaluationCard]`). This metadata drives Copilot Studio's generative AI topic matching — topics without it may not be selected correctly by the agent.

**PITFALL: modeldescription is a root-level key** (sibling of `kind:`), NOT inside `mcs.metadata`. The `description` IS inside `mcs.metadata`. They share identical text value.

## Batch Metadata Update Workflow

When applying the standardised modeldescription/description to many existing topic files:

1. Read each topic file to find its `componentName` (drives which `[BracketName]` to use)
2. Use `patch` to insert both fields right after the `componentName:` line
3. Validate all changed files with the schema validator (`schema-lookup.bundle.js validate <file>`)
4. The text is always identical across all topics except the bracketed component name

## Full End-to-End: File Edit → Live Agent (Dataverse REST)

Local YAML file edits do NOT update the running Copilot Studio agent. Getting them live requires three stages:

### Stage 1: Local YAML Changes
- Edit the `.mcs.yml` files in the agent's `topics/` directory
- Run `schema-lookup.bundle.js validate <file>` — ALL files must pass before proceeding
- Especially check: unique node IDs, no `_REPLACE` placeholders, correct Power Fx quoting

### Stage 2: Push to Dataverse
If `manage-agent.bundle.js push` fails (e.g., `Cannot find module 'vscode-jsonrpc/node'`), use direct Dataverse REST:

**PATCH existing topics** (metadata updates, content fixes):
```python
import json, urllib.request, urllib.parse, subprocess

BOT_ID = "e09954e1-..."
ORG = "https://org....crm.dynamics.com"

# Get token via az
result = subprocess.run(
    ["powershell", "-Command", "az account get-access-token --resource 'https://<org>.crm.dynamics.com' --query accessToken -o tsv"],
    capture_output=True, text=True, timeout=30
)
token = result.stdout.strip()

# Query for the component ID
url = f"{ORG}/api/data/v9.2/botcomponents?\$filter=_parentbotid_value eq '{BOT_ID}' and componenttype eq 9 and schemaname eq 'pcca_...topic.XXX'"
req = urllib.request.Request(url)
req.add_header("Authorization", f"Bearer {token}")

# PATCH the data field with full YAML content
patch_url = f"{ORG}/api/data/v9.2/botcomponents(<comp_id>)"
payload = {"data": yaml_content}
req = urllib.request.Request(patch_url, data=json.dumps(payload).encode(), method="PATCH")
# → HTTP 204 = success
```

**CREATE new topics** (brand new card topics):
```python
payload = {
    "schemaname": "pcca_...topic.NewTopicName",   # MUST start with a valid customization prefix (see PITFALL below)
    "name": "Display Name",
    "componenttype": 9,
    "parentbotid@odata.bind": f"/bots({BOT_ID})",  # entity-reference syntax, NOT _parentbotid_value
    "data": full_yaml_content,
}
req = urllib.request.Request(url, data=json.dumps(payload).encode(), method="POST")
# → HTTP 204 = created in THIS tenant; the new botcomponentid is in the OData-EntityId RESPONSE HEADER, not a 201 body
```
**PITFALLS for POST create (validated PCCH 2026-07-12):**
- Do NOT use `_parentbotid_value` (GUID string) — OData rejects it with `0x80060888 "CRM do not support direct update of Entity Reference properties. Use Navigation properties instead."` Use `parentbotid@odata.bind: "/bots(<GUID>)"`.
- `schemaname` MUST start with a valid customization prefix (e.g. `auto_agent_XRF5I.` — reuse the prefix from a sibling topic's schemaname). A bare name 400s with `0x800608ad "must start with a valid customization prefix."`
- Do NOT include `displayname` (not a valid OData property on botcomponents) or `iscustomizable`/`overwritetime` (can 400).
- The new topic id is in the `OData-EntityId` response header (status **204**, not 201, in this tenant). Re-query by `schemaname` to verify it landed under the right bot, AND confirm `_parentbotid_value` matches the target bot (the botcomponents collection spans the whole Dynamics org).
- Reusable script: `copilot-studio-manage-agent` ships `scripts/create_topic_botcomponent.py` (handles prefix + bind + token-from-file).

**Key API rules:**
- `componenttype: 9` for topics (type 15 = GPT metadata, type 11 = entity, type 14 = file, type 19 = knowledge)
- Use `parentbotid@odata.bind` NOT `_parentbotid_value` for creation
- Use raw GUID `_parentbotid_value` is read-only from Dataverse
- `componenttype` is a primitive int, NOT `componenttype@odata.bind`
- Always include `"statecode": 0, "statuscode": 1` if creating from scratch (defaults may differ)

### Stage 3: Verify Before Publishing
**ALWAYS re-query** Dataverse to confirm the PATCH/POST stuck:
```python
filt = f"_parentbotid_value eq '{BOT_ID}' and componenttype eq 9 and schemaname eq 'pcca_...topic.XXX'"
url = f"{ORG}/api/data/v9.2/botcomponents?\$filter={urllib.parse.quote(filt)}&\$select=data"
```

Check for: `modeldescription:` present in `data` field, YAML structure intact, no truncation.

### Stage 4: Publish

**Preferred: Copilot Studio UI** — open agent → click Publish. Shows validation errors with actionable messages.

**Gateway API** (when UI not available):
```python
GATEWAY = "https://powervamg.us-XXX.gateway.prod.island.powerapps.com"
publish_url = f"{GATEWAY}/api/botmanagement/v1/environments/{ENV_ID}/bots/{BOT_ID}/publishv2-operations"

# POST to trigger a new publish operation (returns operationId)
status, body = rest("POST", publish_url, {})

# GET to poll for completion
status, body = rest("GET", publish_url)
```
Look for `isInFinalState: true` and `state: "Finished"`.

**PAC CLI fallback:** `pac copilot publish --environment <orgUrl> --bot <botId>`
- Cached failures (date-stamped like "Failed [6/28/2026 9:42:08 AM]") persist. Clear by PATCHing `synchronizationstatus` on the bot entity to reset state to Idle.
- `PvaPublish` bound action via API: `POST /bots({BOT_ID})/Microsoft.Dynamics.CRM.PvaPublish` — returns `PublishedBotContentId: ""` on silent failure
- PublishedBotContentId empty = verification needed via UI

**Common publish failures:**
- `ValidationFailedException` — check for: stale knowledge references, blank conversation starters in GPT metadata, BeginDialog referencing deleted topics
- `StorageUnitNotAssigned` on publishv2-operations GET — means no operation exists yet, POST first then GET
- PAC `System.ArgumentException` crash — may need to restore sync status via PATCH

## AI Builder / InvokeFlowAction Audit Topic Pattern

For compliance audit topics that use an AI Builder model to analyze uploaded documents:

```yaml
kind: AdaptiveDialog
mcs.metadata:
  componentName: TDFA Evaluation Documentation Audit
  description: |-
    Medicare Part B Therapy Documentation Compliance Auditor topic specialized in [ComponentName].
    Evaluates submitted therapy documentation for denial risk using CMS standards.
modeldescription: |-
  Medicare Part B Therapy Documentation Compliance Auditor topic specialized in [ComponentName].
  Evaluates submitted therapy documentation for denial risk using CMS standards.
beginDialog:
  kind: OnRecognizedIntent
  id: main
  intent:
    displayName: Descriptive Name
    triggerQueries:
      - audit evaluation
      - analyze documentation
      - compliance check

  actions:
    - kind: Question
      id: ask_for_document
      interruptionPolicy:
        allowInterruption: true
      variable: init:Topic.TopicUploadedDoc
      prompt: Please upload the document for review.
      entity: FilePrebuiltEntity
      valueType:
        kind: FileType

    - kind: ConditionGroup
      id: check_file_uploaded
      conditions:
        - id: file_is_valid
          condition: =!IsBlank(Topic.TopicUploadedDoc)
          actions:
            - kind: InvokeAIBuilderModelAction
              id: invokeAIBuilderModelAction
              input:
                binding:
                  Document_20input: =Topic.TopicUploadedDoc
              output:
                binding:
                  predictionOutput: Global.GlobalAuditResultstext
              aIModelId: <guid>

            # CRITICAL: output MUST be sent to user before EndDialog
            - kind: SendActivity
              id: send_audit_results
              activity: "=Global.GlobalAuditResultstext"

      elseActions:
        - kind: SendActivity
          id: send_error_message
          activity: It looks like you didn't upload a valid file. Please ensure the document is attached and try again.

    - kind: EndDialog
      id: end-topic
      clearTopicQueue: true
```

### CRITICAL: The "Silent Topic" Anti-Pattern

Every audit topic MUST have a `SendActivity` in the **success path** (inside the condition actions, after the AI Builder/Flow call) to display the results to the user. The most common bug in Feedback B topics:

```yaml
→ Question (upload doc)
→ ConditionGroup
  → InvokeAIBuilderModelAction → output to Global variable  ✓ runs AI
  → ✗ MISSING SendActivity to show results                 ← BUG
  elseActions:
    → SendActivity (error only)
→ EndDialog → user sees nothing, topic silently ends        ← BUG
```

**Checklist for every AI Builder/Flow-based topic:**
1. Is there a `SendActivity` **after** the AI Builder/Flow call but **before** the `EndDialog`?
2. Does the `SendActivity` reference the correct output variable (`Global.GlobalAuditResultstext`, not `Global.GlobalAuditResultstext.text`)?
3. Are the results shown in the success path AND is an error message in the else path?
4. Does the `InvokeFlowAction` binding exclude `char_count`? (See `references/ocr-flow-audit-topic-pattern.md` for the type-mismatch pitfall.)
5. If a file is uploaded, does the topic pass `=Topic.extracted_text` (OCR output) to the AI Builder, not the raw `=Topic.TopicUploadedDoc`? Scanned images need OCR extraction first.

## InvokeFlowAction — CRITICAL: Exclude `char_count` from Output Binding

When using the OCR Text Extraction flow (flowId `c71672f2`) in an `InvokeFlowAction`, the flow returns `char_count` as an integer-typed field. If you bind it to a variable in the output block, Copilot Studio creates a `StringDataType` mapping, causing:

```
Error Code: FlowActionBadRequest
The parameter with name 'char_count' evaluated to type 'StringDataType',
expected type 'UnspecifiedDataType'
```

**Fix:** Only bind the fields you actually use:
```yaml
      output:
        binding:
          # char_count: Topic.char_count   ← DO NOT BIND THIS
          error_message: Topic.error_message
          extracted_text: Topic.extracted_text
          processing_status: Topic.processing_status
```

`char_count` is not consumed by any topic — removing it has no functional impact.

## Async OCR Job Status Polling Pattern (GotoAction + Retry Counter)

When an async OCR flow submits a job and returns a `job_id`, the topic must poll for completion. A bare GotoAction without a retry limit creates an infinite loop, hitting Copilot Studio's 500-execution ceiling and crashing the topic.

**The Pattern:** Add a `Topic.RetryCount` (Number) variable initialized at the start of the polling loop. In the "not complete" branch, check the count, increment, and either loop back or give up gracefully.

### YAML Template

```yaml
kind: AdaptiveDialog
...
beginDialog:
  kind: OnRecognizedIntent
  id: main
  intent:
    displayName: Document OCR Audit
    triggerQueries:
      - process this document
  actions:
    # --- Submit job ---
    - kind: InvokeFlowAction
      id: invokeFlow_submit_async_ocr
      flowId: c71672f2-113b-f111-88b4-0022480b6bd9
      input:
        binding:
          file: ={ contentBytes: First(System.Activity.Attachments).Content, name: First(System.Activity.Attachments).Name }
          document_type: "..."
          requesting_agent: "..."
          extraction_goal: "Asynchronous OCR and structured compliance audit"
      output:
        binding:
          job_id: "Topic.async_job_id"
          processing_status: "Topic.async_processing_status"
          message: "Topic.async_message"

    # --- Send initial confirmation ---
    - kind: SendActivity
      id: sendActivity_job_submitted
      activity: |-
        Document submitted for OCR processing.
        Job ID: {Topic.async_job_id}

    # --- Initialize retry counter ---
    - kind: SetVariable
      id: init_retry_count
      variable: Topic.RetryCount
      value: 0

    # --- POLLING LOOP START ---

    # Step A: Check OCR status via flow (this label is the GotoAction target)
    - kind: InvokeFlowAction
      id: invokeFlow_check_ocr_status
      flowId: c71672f2-113b-f111-88b4-0022480b6bd9
      input:
        binding:
          job_id: =Topic.async_job_id
      output:
        binding:
          job_json: "Topic.job_json"

    # Step B: Examine status
    - kind: SetVariable
      id: set_ocr_payload
      variable: Topic.ocr_payload
      value: =Topic.job_json

    - kind: ConditionGroup
      id: check_ocr_status
      conditions:
        - id: condition_completed
          condition: ='Status: Completed' in Topic.ocr_payload
          actions:
            # Generate and show results
            - kind: SearchAndSummarizeContent
              id: generate_report
              userInput: "=Concatenate(...)"
            - kind: SendActivity
              id: show_report
              activity: "{Topic.Answer}"
      elseActions:
        # --- RETRY LOGIC ---
        - kind: ConditionGroup
          id: check_retry_count
          conditions:
            - id: condition_retry_remaining
              condition: =Topic.RetryCount < 10
              actions:
                - kind: SetVariable
                  id: increment_retry
                  variable: Topic.RetryCount
                  value: =Topic.RetryCount + 1
                - kind: SendActivity
                  id: send_waiting
                  activity: |-
                    OCR processing in progress (attempt {Topic.RetryCount} of 10).
                    Please wait...
                # Loop back to the status check
                - kind: GotoAction
                  id: goto_retry
                  actionId: invokeFlow_check_ocr_status
          elseActions:
            # Max retries exhausted
            - kind: SendActivity
              id: send_timeout
              activity: |-
                The OCR job is taking longer than expected.
                Please check back later with Job ID: {Topic.async_job_id}

    - kind: EndDialog
      id: endDialog_done
      clearTopicQueue: true
```

### Key Rules
1. **ALWAYS initialize `Topic.RetryCount` to 0** before the polling loop starts (use `SetVariable`, not Topic defaults)
2. **Set a loop limit** — 10 retries is a reasonable default for OCR jobs that take 30-60 seconds
3. **Increment the counter** in the retry branch BEFORE the GotoAction — otherwise the count never changes
4. **Use `GotoAction` with `actionId`** pointing to the InvokeFlowAction that checks status — NOT the submit flow
5. **Show a progress message** on each retry so the user knows the topic is still working
6. **After max retries, end gracefully** — don't leave the user hanging with no response

### Pitfall: Infinite Loop Crash
Copilot Studio enforces a 500-execution limit per conversation turn. A bare GotoAction (no retry counter) that loops every ~5 seconds hits this in ~40 minutes and the topic crashes with "dialog was executed more than 500 times." Always pair GotoAction with a retry count check.

### Pitfall: Polling Too Fast
InvokeFlowAction calls consume API capacity. Without a delay mechanism between retries, the topic polls as fast as the runtime allows. Copilot Studio topics don't have a native "wait/delay" node, so the retry gap is whatever the round-trip takes. Keep retry counts reasonable (5-15, not 100+) to avoid rate-limiting or capacity issues.

## Document Audit Architecture — OCR Pipeline vs SASC

For compliance audit topics that analyze **uploaded documents**, the choice between SASC (SearchAndSummarizeContent/KB-based generative answers) and the full OCR → AI Builder pipeline depends on document type and goal:

| Document Type | SASC Works? | Need OCR Flow? | Recommended Route |
|---|---|---|---|
| Native PDF (text layer, typed) — quick Q&A | Yes | No | SASC/generative answers |
| Native PDF, 100+ pages — full audit | **No** (too large for retrieval) | **Yes** | OCR flow → AI Builder |
| Scanned PDF (image layers, no text) | **No** — can't OCR images | **Yes** | OCR flow → AI Builder |
| Image file (JPG, PNG of a document) | **No** — unsupported format | **Yes** | OCR flow → AI Builder |
| Word doc, TXT, CSV — quick Q&A | Yes | No | SASC/generative answers |
| Any document — full structured audit with citations | **No** (SASC is retrieval/Q&A, not structured analysis) | **Yes** | OCR flow → AI Builder |

**MS Learn verification (Jul 2026):**
- Copilot Studio does NOT auto-extract text from user-uploaded files — the file variable stores binary, not parsed text. (Microsoft Q&A)
- Generative answers supports only text-based formats (PDF, DOCX, TXT, MD, etc.). Image, audio, video, executable are NOT supported. (learn.microsoft.com/en-us/microsoft-copilot-studio/nlu-documents)
- The documented approach for document compliance audits: file upload → Power Automate flow (OCR/extraction) → AI Builder model → SendActivity. (learn.microsoft.com/en-us/microsoft-copilot-studio/guidance/pass-files-to-connectors)

**Decision rule:** "full audit" on ANY document = ALWAYS the OCR → AI Builder pipeline. SASC is for "answer a question about this." Full structured audits need complete text extraction first.

## File-Upload Question (inputType: file[]) — ⚠️ DEPRECATED — BREAKS EDITOR

**WARNING: `inputType: file[]` / `property: turn.uploadedFiles` is valid for PUBLISH but the Copilot Studio authoring canvas renders BLANK and the code editor won't load for that topic.** The editor's YAML deserializer cannot render this schema. Confirmed 2026-07-16: the Therapy Documentation Compliance Audit topic froze entirely with "code editor won't load up" after deploying this pattern.

**Use the editor-safe File+Text Dual-Input pattern instead:** copilot-studio-common-reference §File+Text Dual-Input Pattern (3-branch ConditionGroup with StringPrebuiltEntity). This pattern works for file uploads AND text input AND renders in the editor.

Only use `inputType: file[]` if you accept that the authoring canvas will be blank and the topic can only be edited via Dataverse API PATCH (no UI). For all new topics, use the safe pattern.

---

The original `file[]` pattern (kept for reference, NOT recommended):

When a topic needs the USER to attach file(s) and you want to branch on "did they upload?", use a `file[]` Question bound to `turn.uploadedFiles`. Do NOT use a text Question and test `System.Activity.Attachments`.

**PITFALL — text Question does NOT bridge uploads into the condition (verified live 2026-07-16).** A `kind: Question` with `variable: init:Topic.DocumentText` + `entity: MultipleLine.String` does NOT populate `System.Activity.Attachments` on the test-pane/chat upload path. The agent receives the file but the bound text variable stays blank, so any condition on `!IsBlank(First(System.Activity.Attachments))` or `!IsBlank(Topic.DocumentText)` is FALSE and the topic falls through to a "I did not receive any documentation" fallback even after the user attached 5 PDFs. This is a real runtime defect, not a cosmetic UI glitch.

**Correct schema:**
```yaml
    - kind: Question
      id: question_file_upload
      prompt: Upload one or more PDF documents for a combined audit.
      inputType: file[]
      property: turn.uploadedFiles
      interruptible: false
      allowMultipleFiles: true

    - kind: ConditionGroup
      id: condition_file_uploaded
      conditions:
        - id: condition_file_not_blank
          condition: '=!IsBlank(turn.uploadedFiles)'
          actions:
            - kind: SearchAndSummarizeContent
              id: sasc_audit_files
              userInput: |-
                =Concatenate(
                  "Review the following documentation for compliance risks ... ",
                  Concat(turn.uploadedFiles, Content, "---NEXT DOCUMENT IN EPISODE---")
                )
            - kind: SendActivity
              id: send_activity_file_results
              activity: '{Topic.Answer}'
      elseActions:
        # text-branch or fallback
```
- `inputType: file[]` (NOT `entity: MultipleLine.String` + `allowMultipleFiles`).
- `property: turn.uploadedFiles` — the `file[]` response type populates `turn.uploadedFiles`; reference it directly (no `Text()`).
- Condition `=!IsBlank(turn.uploadedFiles)` fires reliably on upload.
- Multi-file merge: `Concat(turn.uploadedFiles, Content, "---NEXT DOCUMENT IN EPISODE---")` feeds SASC all files as one episode.

Full pattern + verified Pacific Coast Topic 1 fix: `references/file-upload-question-pattern.md`.

## SendActivity Format — YAML Pitfall

**WRONG** (nested `activity:` with `value:` + `text:` — this silently fails):
```yaml
- kind: SendActivity
  id: sendActivity_bLueL2
  activity:
    value: =Global.GlobalAuditResultstext.text
    text:
      - "{Global.GlobalAuditResultstext.text}"
```

**CORRECT** (flat `activity:` string — this shows output to user):
```yaml
- kind: SendActivity
  id: send_audit_results
  activity: "=Global.GlobalAuditResultstext"
```

Per Microsoft Learn, `SendActivity.activity` accepts a string (with Power Fx interpolation via `=`) or a multiline block scalar (`|-`). It does NOT accept a dict with `value`/`text` sub-keys. The nested format looks valid in YAML but the runtime ignores it — the result is a silent topic that runs but shows nothing.

A **Treatment Encounter Note** is a single-session treatment documentation card, distinct from Daily Notes and Progress Notes. It captures detailed encounter-level data (pre/post pain, vitals, specific intervention parameters) vs. Daily Notes which are more summary-level.

```yaml
mcs.metadata:
  componentName: PT Treatment Encounter Card
  description: |-
    Elite clinical intelligence module specialized in [PTTreatmentEncounterCard]. Executes high-precision data analysis grounded in CMS Chapter 15 and Pacific Coast Services Ironclad Standards. Optimized for Dynamic Chaining.
kind: AdaptiveDialog
modeldescription: |-
  Elite clinical intelligence module specialized in [PTTreatmentEncounterCard]. Executes high-precision data analysis grounded in CMS Chapter 15 and Pacific Coast Services Ironclad Standards. Optimized for Dynamic Chaining.
beginDialog:
  kind: OnRecognizedIntent
  id: main
  intent: {}
  actions:
    - kind: AdaptiveCardPrompt
      id: card_pt_tx_encounter
      card: |-
        {
          "type": "AdaptiveCard",
          "$schema": "https://adaptivecards.io/schemas/adaptive-card.json",
          "version": "1.5",
          "body": [
            {"type": "TextBlock", "text": "PT Treatment Encounter Note", "weight": "Bolder", "size": "Large", "wrap": true},
            ...encounter-specific fields...
            {"type": "Input.Text", "id": "therapistName", "label": "Therapist Name & Credentials", "placeholder": "Jane Smith, PT, DPT", "isRequired": true}
          ],
          "actions": [{"type": "Action.Submit", "title": "Generate PT Treatment Encounter Note"}]
        }

    - kind: SearchAndSummarizeContent
      id: gen_pt_tx_encounter
      userInput: "=Concatenate(\"Generate a skilled PT Treatment Encounter Note. SECTIONS - ...\", Text(Topic.var), \"...\")"

    - kind: SendActivity
      id: draft_pt_tx_encounter
      activity: |-
        DRAFT - CLINICAL REVIEW REQUIRED
        {Topic.Answer}
        Review before EHR entry. Say audit for compliance check.

    - kind: BeginDialog
      id: audit_pt_tx_encounter
      input:
        binding:
          incomingDiscipline: ="PT"
          incomingDocumentType: ="Treatment Encounter Note"
      dialog: pcca_theradocworkbench.topic.AuditExistingNote

    - kind: EndDialog
      id: end_pt_tx_encounter
      clearTopicQueue: true
```

**Key differences from Daily Note:**
- Pre/post pain scores (baseline + post-treatment) rather than single pain level
- Vital signs (HR/SpO2/BP at rest and exertion)
- Verbal/tactile cueing percentage as a discrete field
- Specific intervention parameters (sets, reps, rest, distance)
- Clean SOAP structuring in the SearchAndSummarize prompt (Subjective/Objective/Assessment/Plan)

**Variable naming convention:** Use discipline-specific prefixes and encounter-specific suffixes:
- `Topic.walkingDistanceEncounter` (not `Topic.distance`)
- `Topic.verbalCueThreshold` (not `Topic.cueing`)
- `Topic.painBaseline` / `Topic.painPostTreatment` (not `Topic.pain`)
- `Topic.vitalSignsEncounter` (not `Topic.vitals`)

When creating Treatment Encounter Note topics for the TheraDoc agent, also update `NoteIntakeRouter.mcs.yml`:
- Add `- id: TreatmentEncounter` to the ClosedListEntity note type items
- Add 3 routing conditions (one per discipline) pointing to the new card topics

**Key rules:**
- `intent: {}` — Card topics are only reachable via BeginDialog from a router
- SearchAndSummarizeContent userInput MUST be double-quoted (see YAML Quoting pitfall in common-pitfalls.md)
- Always EndDialog with clearTopicQueue: true
- Add AuditExistingNote BeginDialog before EndDialog for compliance review

See `therapy-fleet-agent-audit` skill `references/theradoc-workbench-card-generation-pattern.md` for full template with verified examples.

## Template Location
Templates are at: D:/my agents copilot studio/pipeline/templates/
Reference templates for each topic type when creating new topics.

## Skill Templates and References
This skill includes additional templates and references in its own directory:
- `templates/document-audit-topic.topic.mcs.yml` — Document compliance audit topic (Question → AnswerQuestionWithAI → SendActivity → EndDialog). Customize triggerQueries and additionalInstructions for your domain.
- `templates/inline_extraction_topic.mcs.yml` — Catch-all INLINE-TEXT EXTRACTION topic (verbatim extraction from pasted/user-provided text via SearchAndSummarizeContent with applyModelKnowledgeSetting:false). Proven fix for the 100%-gptFallback "extract X from these records" failure class. GENERALIZE the triggerQueries/modelDescription/extract prompt to the agent's domain before use.
- `references/dataverse-botcomponent-api.md` — Dataverse API for creating/updating botcomponents programmatically via CDP/Playwright. Includes required fields (`schemaname`, `parentbotid@odata.bind`), error codes, and test set API limitations.
- `references/feedback-b-audit-topic-pattern.md` — Documentation audit topic pattern for the Topic Therapy Documentation Feedback agent (bot `b0346795`). Covers AI Builder + OCR flow, SendActivity pitfall, and the 5 most common bugs in compliance audit topics.
- `references/power-automate-dataverse-documentbody-sanitize.md` — Power Automate fix for Invalid Character errors. 29-nested-replace to strip control chars from documentbody.
- `references/ocr-flow-audit-topic-pattern.md` — OCR async flow: auto-polling retry loop, Dataverse invalid-char fix, binding pitfalls, YAML duplication trap.
- `references/file-upload-question-pattern.md` — Modern `inputType: file[]` + `property: turn.uploadedFiles` upload Question. Fixes the text-Question/`System.Activity.Attachments` decoupling bug where uploads never populate the condition.
