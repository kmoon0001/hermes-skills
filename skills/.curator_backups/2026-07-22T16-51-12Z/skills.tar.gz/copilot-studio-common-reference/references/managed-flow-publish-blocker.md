# Managed Power Automate Flow Publish Blocker

## Symptoms
- `pac copilot publish` fails repeatedly
- Diagnostics show: "Output binding 'fieldName' is not found, refresh this flow to get the latest bindings"
- Flow count in errors = number of fields the managed flow expects
- Error count doesn't change after removing topic-level output properties
- Copilot Studio UI publish shows: **"InfiniteLoopInBotContent"** with a Reference ID — the managed flow creates a circular dependency with the topic's output bindings (flow reads topic → topic outputs to flow → flow reads again)
- Both the Output binding errors AND InfiniteLoopInBotContent resolve together when the flow is removed

## Root Cause
A **managed Power Automate flow** (ismanaged=True) is connected to the bot.
Managed flows are part of a solution — they cannot be deleted via Dataverse API (405 Method Not Allowed).
Even Draft-state managed flows block publish if the bot references them.

## Detection
```python
# Query the workflows table for managed flows
filter_str = "_primaryentityid_value eq {botId}"
# OR just search for flow names containing key terms
filter_str = "contains(name,'Compliance') or contains(name,'AuditLog')"
url = f'{BASE}/workflows?$filter={urllib.parse.quote(filter_str)}&$select=workflowid,name,statecode,ismanaged'
```
Look for `ismanaged=True` entries.

## Fix

**Two approaches depending on flow type:**

### Non-managed flow: Copilot Studio UI
1. Open the agent in Copilot Studio browser
2. Click **Flows** tab in the left sidebar
3. Find the flow → click **... → Remove**
4. Click **Publish**

### Managed flow (in a solution): Power Platform admin
When the flow's detail page says "The process is part of a managed solution and cannot be individually deleted":

1. Find the parent solution:
   - Query `solutions` table: `SELECT uniquename,friendlyname FROM solutions WHERE ...`
   - Common candidates: "TheraDocTransport", "TheraDocSource", or any solution containing "Compliance"
   - On this machine: `TheraDoc Transport` (TheraDocTransport), `TheraDocSource` (TheraDocSource)
2. Go to `https://make.powerapps.com` → **Solutions**
3. Open the managed solution (e.g. "TheraDoc Transport")
4. Find the flow inside → click **... → Remove**
5. Back in Copilot Studio → **Flows** tab → **... → Remove** the now-liberated flow
6. **Publish**

**Verification:** After remove, the Output binding errors AND InfiniteLoopInBotContent both disappear.
**Risk:** Removing a flow component from a managed solution does NOT delete the solution or other components. Only the flow is affected. Agents/topics are untouched.

## Prevention
Add G14 (Orphan Flow Detection) to the QA gate. Run BEFORE every publish.
The detection script finds all flowId references and verifies each exists with statecode=0.
Managed flows are flagged with a warning so the user knows they need UI removal.

## Why Managed Flows Exist
These are often auto-created by Copilot Studio when:
- A Power Automate flow was connected to a topic via the "Call an action" UI
- A solution was imported that included a flow connected to the bot
- The agent was exported from another environment with the flow still linked

## Sync Status Cache Reset (Stale Failure Workaround)

When `pac copilot publish` reports `Failed []` (empty diagnostics), the sync status is CACHED from a previous failed attempt. The actual publish may have passed but the cached failure overrides. To force a fresh validation:

```python
# Reset sync status to Succeeded
body = json.dumps({'synchronizationstatus': json.dumps({
    'lastFinishedPublishOperation': {'status': 'Succeeded', 'diagnosticDetails': []}
})}).encode()
url = f'{BASE}/bots({botId})'
req = urllib.request.Request(url, data=body, headers=H_PATCH, method='PATCH')
```

After reset, run `pac copilot publish` again for a fresh result. Does NOT change bot content — only the cached diagnostic state. Use when you've verified the topics are correct and need to force re-validation.

## pac-log.txt Analysis

When `pac copilot publish` crashes with `"Sorry, the app encountered a non-recoverable error"`, the real error is in:
```
C:\Users\<user>\.dotnet\tools\.store\microsoft.powerapps.cli.tool\2.7.4\...\tools\net10.0\any\logs\pac-log.txt
```

Look for:
- `Exception Type:` — outer wrapper
- `Inner Exception Level 1:` — the actual error
- `Message:` containing `statuscode:409` + `ExternalServiceException` → a service the publish depends on is down (e.g. deleted AI Prompt model in a managed flow)
- `BotPublish` + `InvalidPluginExecutionException` → the publish plugin rejected the operation

## InfiniteLoopInBotContent

Appears in Copilot Studio UI (not `pac` CLI). Causes:
1. **Most common:** A managed flow with stale output bindings creates a circular validation dependency — the flow reads from a topic's output schema, but the schema changed (e.g. adding 52 outputType properties), creating a self-referencing cycle
2. GotoAction targeting itself (rare)
3. BeginDialog calling a parent topic (very rare)

**Fix for #1:** Remove the managed flow OR revert the outputType properties that triggered the cycle, then reset sync status cache and re-publish.

## When Solution Won't Delete

If the managed solution can't be deleted (permissions):
1. **Ask a Power Platform Admin** to remove the flow from the solution or uninstall it
2. **Reset sync status** and try publishing anyway — works if flow references are stale and no topic calls it
3. The flow must already be removed from all topics (InvokeFlowAction blocks deleted) for the publish to bypass it

## Proof: Output Binding Errors are Flow-Side Only (proven 2026-07-16)

On TheraDoc Workbench:
1. 52 output binding errors present ("Output binding 'therapistName' is not found")
2. Added all 52 field names as `outputType.properties` to Master Patient Context
3. **ZERO change** — identical errors, identical counts
4. This proves binding errors are stored in the Power Automate flow's registered schema, NOT in topic YAML

**Rule:** Never patch topic outputType for binding errors. Fix the flow only.

## Verification After Fix
# Publish again and check sync status
url = f'{BASE}/bots({botId})?$select=synchronizationstatus,publishedon'
req = urllib.request.Request(url, headers=H)
with urllib.request.urlopen(req, timeout=15) as r:
    d = json.loads(r.read())
ss = d.get('synchronizationstatus','{}')
lfp = ss.get('lastFinishedPublishOperation', {})
status = lfp.get('status')
if status == 'Succeeded':
    print("PUBLISH PASSED — managed flow was the blocker")
elif status == 'Failed':
    # Check if output binding errors are gone
    errors = set()
    for detail in lfp.get('diagnosticDetails', []):
        for dl in detail.get('diagnosticList', []):
            errors.add(dl.get('errorMessage','')[:80])
    if not any("Output binding" in e for e in errors):
        print("Flow bindings resolved. Remaining errors:")
        for e in errors:
            print(f"  {e}")
```
