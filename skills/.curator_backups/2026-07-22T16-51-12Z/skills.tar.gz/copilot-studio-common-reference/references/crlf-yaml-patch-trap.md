# Dataverse YAML Line-Ending Trap

When PATCHing YAML data to the `botcomponent.data` field via the Dataverse API:

## The Problem

Dataverse stores YAML data with **`\r\n` (CRLF)** line endings. Python `re.sub()` and `str.replace()` operate on **`\n`** by default. A regex like:

```python
data.replace("responseCaptureType: FullResponse\n", "responseCaptureType: FullResponse\n      variable: Topic.Answer\n")
```

**WILL NOT MATCH** because `\r\n` is in the data, not `\n`. The regex silently fails — no replacement occurs, and you have no error to debug.

## The Fix

Always use `\r?\n` in regex patterns when working with Dataverse YAML data:

```python
# CORRECT:
data = re.sub(
    r"(responseCaptureType: FullResponse)\r?\n\s*(userInput:)",
    r"\1\r\n      variable: Topic.Answer\r\n      \2",
    data
)

# Or normalize first:
data_n = data.replace("\r\n", "\n")
# ... do replacements with \n ...
data = data_n.replace("\n", "\r\n")
```

## Multiple Fixes in One Topic

When applying multiple PATCHes to the same topic, apply ALL changes to a copy of the data before PATCHing. Sequential PATCH calls each overwrite the component:

```python
orig = data  # backup
# Apply ALL fixes
data = fix_1(data)
data = fix_2(data)
data = fix_3(data)
if data != orig:
    do_patch(cid, data)  # ONE PATCH call
```

This prevents the `\r\n` issues AND reduces API calls.
