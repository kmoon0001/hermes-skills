# Documentation Defense Agent — Live Audit Notes (2026-07-17)

Agent: Pacific Coast Documentation Defense Agent
Bot ID: `2e08ac68-bdef-481e-9c04-6a349c79d6c0`
Schema: `crbee_PacCoastDocumentationDefenseAgent`
Env: Therapy AI Dev (`orgbd048f00`)
Published: 2026-07-17 ~11:06 PM Pacific

## Architecture (21 topics, 50 components)
4 working defense surfaces (all SASC + `applyModelKnowledgeSetting: true`, `responseCaptureType: FullResponse`):
1. `crbee_docUploadAndAudit` — upload note → Evidence/Standard/Reasoning/Risk + auto defense arg. Trigger: "upload and audit this therapy note", "review this documentation for compliance risks", etc.
2. `crbee_appealSurveyDefense` — MAC/ADR appeal vs CMS/state survey (SOM App PP, 42 CFR 483, F-tags, plan of correction). Trigger: "i have a MAC appeal", "prepare a survey defense", "i received a 2567".
3. `crbee_generalComplianceV2` — Ch.15/Jimmo/Part B Q&A, capped <900 chars, 2-3 bullets w/ inline citations.
4. `crbee_contractAnalysisV2` — managed-care contract vs Ch.15 coverage criteria.

Fallback (`crbee_PacCoastDocumentationDefenseAgent.topic.Fallback`): SASC catch-all (CMS MBPM Ch.15, Jimmo, 42 CFR 409/483/422, Program Integrity Ch.3, PDPM, LCR) + 3-tier (answer → rephrase guidance → final redirect). Ends "AI draft — clinician review required."

## Grounding verification (componenttype 14 = 14 files)
CMS Ch.15 Therapy Services; Jimmo v. Sebelius FAQ; SOM Appendix PP; 42 CFR 422/483/409; MAC LCD CGS L34049; Program Integrity Manual Ch.3; 2026 Part B LCR Form+Grid; Claims Processing Ch.5; Medicare Appeals MLN; PDPM Fact Sheet + Tech Report; APTA/AOTA/ASHA standards.

componenttype 19 = 11 eval prompts + 1 "Evaluate Pacific Coast Documentation Defense Agent" asset → eval set is wired.

## Key lessons captured this session
- Topics use `applyModelKnowledgeSetting: true` + SASC but do NOT pin sources per-topic. Grounding depends on these 14 agent-level KBs being attached — verified present. Attachment ≠ retrieval; spot-check citations on a real question.
- `instructions` is NOT a column on `bots` — it lives on botcomponent type 15.
- Classic canvas view (Question→Var1→Generative Answers) is a DIFFERENT representation from the live SASC topic; editing it didn't change the published component (modifiedon unchanged). Don't trust canvas = live.
- "No information was found" after PDF upload = settings issue (allow-upload off / node not reading conversation uploads), not topic-logic. PDFs ride in System.Activity.Attachments, never into a variable.

## User's live question this session
"I edited it thinking it was right" — edited classic canvas Question node (set Identify=User's entire response → Var1, wired generative-answers). Live topic untouched. Resolved by explaining the canvas/live mismatch + that file upload is a settings flip, not a topic rebuild.
