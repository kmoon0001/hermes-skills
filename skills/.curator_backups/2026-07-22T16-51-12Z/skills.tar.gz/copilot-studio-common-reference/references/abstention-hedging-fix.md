# Abstention Hedging Fix Pattern

When an agent's Conv eval is dominated by abstention=Yes failures despite having an EVALUATION CONTEXT block with "Do NOT say you cannot answer," the agent is likely **soft-abstaining** — producing a response that hedges rather than answering directly.

## Detection

From Conv failure details (Gateway `GET /makerevaluations/{runId}/details`):

```
abs=Yes rel=NA comp=None gnd=None
answer: "To generate the QM severity classification for your facility's recent cases,
        I'll need to work from current quality measure data..."
```

The answer starts with "To do X, I need Y" — a proviso that the grader treats as abstention=Yes even though the agent didn't say "I cannot answer."

Common hedging phrases to grep for in failing answers:
- "I need data" / "I'll need to work from"
- "To do this I would need" / "To [verb] I need"
- "This requires your facility data"
- "This action needs to be done to ensure" (generic non-answer)
- "Here's a framework/structure/outline for" (framework-only trap)

## Root Cause

Two interdependent issues in the agent's instructions:

1. **DATA-SPARSE section allows proviso language.** "Answer directly" is too weak — the agent can interpret it as "give a direct answer about what you WOULD need" rather than "answer the question now."

2. **BEHAVIORAL GUIDELINES gives permission to hedge.** The common anti-pattern:
   ```
   # BEHAVIORAL GUIDELINES
   - Prioritize actionable, specific interventions over broad theory.
   - When data is insufficient for a facility-specific claim, state what is missing rather than inventing rates.
   ```
   The second line explicitly tells the agent to say "I'm missing X" — which is exactly what causes abstention failures. This clause overrides any "never abstain" directive placed elsewhere.

## Fix

Apply both changes via Dataverse PATCH on the instructions component (type 15).

### 1. Strengthen DATA-SPARSE with banned phrases

Replace the DATA-SPARSE PROMPTS section:

```yaml
  ## DATA-SPARSE PROMPTS
  When the prompt asks without providing clinical/facility text:
  - Answer directly with CMS standards-based information and coaching steps
  - Do NOT use "framework", "framework only", "based on available knowledge", or "the sources do not address"
  - Do NOT say "I need data" or "to do this I would need" or "this requires" or "I need to work from"
  - Do NOT hedge or explain what you would do IF you had data -- just answer the question
  - Do NOT say you cannot answer
```

### 2. Restructure BEHAVIORAL GUIDELINES to lead with NEVER ABSTAIN

Replace the entire BEHAVIORAL GUIDELINES section:

```yaml
  # BEHAVIORAL GUIDELINES
  - NEVER ABSTAIN on in-scope QM coaching questions. This is the single most important rule.
  - Answer directly and substantively. Do NOT say you need data first.
  - Prioritize actionable, specific interventions over broad theory.
  - Ground recommendations in CMS-published measure specifications and uploaded QM SOP files when available.
```

Key changes:
- "NEVER ABSTAIN" is now the **first** line, not buried
- "Answer directly and substantively. Do NOT say you need data first." replaces the "state what is missing" clause
- The "state what is missing rather than inventing" permission is **removed entirely**

## Publish

After PATCHing the instructions, publish (PvaPublish or `pac copilot publish`).

## Verification

1. Re-run Conv on the same test set. The same 3-5 abstention failures should convert to passes or at least change to a different failure category (completeness/gnd).
2. If abstention persists, check for a separate `responseInstructions` field that may contain its own hedging language.
3. Also check the Fallback topic's `additionalInstructions` for hedging language — Fallback handles unmatched queries and may be the source of abstention for questions that don't reach a custom topic.

## Pitfalls

- **`# ` prefix matching:** The BEHAVIORAL GUIDELINES header may not have `# ` prefix (CRLF data from Dataverse). Always `repr()` the exact string before building your `.replace()` anchor. The header may be bare `BEHAVIORAL GUIDELINES\r\n` not `# BEHAVIORAL GUIDELINES\r\n`.
- **CRLF vs LF:** Dataverse stores `\r\n`. A Python `.replace()` that worked in an earlier session may silently no-op if the whitespace or line-ending differs. Always `repr()` the exact live data before PATCHing.
- **Response time:** The fix takes effect immediately after publish. No need to wait for model retraining.
