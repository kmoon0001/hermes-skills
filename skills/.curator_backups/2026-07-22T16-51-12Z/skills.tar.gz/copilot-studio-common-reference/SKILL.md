---
name: copilot-studio-common-reference
description: Single source of truth for shared Copilot Studio standards — auth patterns, generation rules, the File+Text dual-input pattern, editor-render gate, publish diagnostics, and common pitfalls. All other skills cross-reference this instead of duplicating content. Update ONE file when a rule changes.
version: 1.0.0
tags: [copilot-studio, reference, standards, patterns]
---

# Copilot Studio Common Reference

## Auth Patterns (Canonical)

**Shared Memory Bridge (Hermes ↔ Kiro):** Both read/write the same knowledge graph at `C:/Users/kevin/.kiro/memory/memory.jsonl` via MCP. Kiro fires commit-memory-sync hook after git commits. Write cross-tool facts (bot IDs, failure patterns, auth recipes) there once. Do NOT duplicate into separate stores.

### Path 1: pac (primary — no MFA, cached identity)
```bash
pac auth create --environment https://<org>.crm.dynamics.com/
pac org who   # verify connection
```
Works on this machine where `az` returns 401 (CA/MFA on pccapackage). However, the CA/MFA block on pccapackage is **intermittent** — observed both 401 and successful 200 in the same session. Always try `az` first; verify with WhoAmI HTTP 200 before falling back to `pac`.
`az` at the shell level IS available and works for Therapy AI Dev (`orgbd048f00`), Ensign Default (`org3353a370`), AND intermittently for pccapackage (`https://pccapackage.crm.dynamics.com`).

### Path 2: MSAL Cache (eval tokens — no browser)
```bash
# The refresh script lives at ~/skills-for-copilot-studio/scripts/ on THIS machine,
# NOT in the pipeline dir. Find it:
cd "$(find ~ -name refresh_eval_token.cjs -printf '%h' -quit 2>/dev/null)"
node refresh_eval_token.cjs    # writes to ~/.copilot-studio-cli/test-agent-token.txt
```
**Rules:** Run WITHOUT stdout redirect (captures status into token). Verify file starts with `eyJ`. Token expires ~15min.

### Path 3: CDP Capture (fallback eval token — needs browser)
```bash
curl -s http://127.0.0.1:9223/json/version   # verify CDP
node cdp_capture_token.cjs    # finds eval tab by URL pattern
```

### Path 4: az Dataverse Token (for PATCHing botcomponent.data, NOT for evals)

**CRITICAL: `az` is a bash script on Windows, not a standalone .exe.** It lives at `/c/Program Files/Microsoft SDKs/Azure/CLI2/wbin/az` and requires MSYS2/git-bash to run. System Python's `subprocess.run(['az', ...])` raises `FileNotFoundError` because git-bash's PATH is invisible to Windows-native Python. Always run `az` from the terminal tool (which runs in git-bash), and save the token to a file for Python to read:

```bash
az account get-access-token --resource "https://<org>.crm.dynamics.com" --query accessToken -o tsv > az_token.txt
# Always verify before use:
curl -s -w "%{http_code}" -H "Authorization: Bearer $(tr -d '\\r\\n' < az_token.txt)" \
  -H "Accept: application/json" "https://<org>.crm.dynamics.com/api/data/v9.2/WhoAmI"
```
**WhoAmI must return 200.** Trailing slash on `--resource` has flipped on this tenant (with slash 401 / without slash 200 observed 2026-07-17; reverse has also been true). Do **not** hardcode one slash rule — try the other form (and optional `--tenant`) if WhoAmI 401s.
**CRITICAL:** Never overwrite `test-agent-token.txt` with an `az` token — Gateway 403s on CRM-scoped tokens.

### Gateway API Headers (for eval endpoints)
```python
H = {
  'Authorization': f'Bearer {TOKEN}',
  'X-CCI-ApplicationSource': 'Web',
  'X-CCI-BapEnvironmentId': ENV_ID,
  'X-CCI-BotId': BOT_ID,
  'X-CCI-CdsBotId': BOT_ID,
  'X-CCI-TenantId': '03cc92c3-986c-4cf4-ae27-1478cf99d17f',
  'X-CCI-OrganizationId': ENV_ID,
}
```
**Host:** `https://powervamg.us-il106.gateway.prod.island.powerapps.com/api/botmanagement/v2`
**Direct PPAPI host `api.powerplatform.com` returns 401 on this tenant — do not use.**

---

## The 12 Generation Rules (Canonical — all skills must follow these)

1. **Every topic file MUST start with `# {topic_name}` comment line.** Required by Dataverse for type-9 component data.
2. **Every SASC MUST have:** `userInput`, `additionalInstructions`, `responseCaptureType: FullResponse`, `allowLatencyMessage: false`, **AND `variable: Topic.Answer`** (or `Global.Answer`). Without `variable:`, the next action's `{Topic.Answer}` reference fails with `Identifier not recognized in expression`. The `variable:` must be at the SAME indent level as `responseCaptureType` and `userInput` — a deeper indent makes it a child property, causing `Missing required property 'UserInput'` on publish. Required by the eval grader.
3. **Every custom topic MUST have:** `EndDialog` with `clearTopicQueue: true` as the last action, preceded by `SendActivity(activity: =Topic.Answer)`.
4. **Never generate `entity: FilePrebuiltEntity`.** Always use `StringPrebuiltEntity` with a 3-branch ConditionGroup.
5. **Never generate `inputType: file[]` or `property: turn.uploadedFiles`.** These break the editor (blank canvas freeze, confirmed 2026-07-16).
6. **Never generate `SearchSpecificFiles` or `SearchSpecificKnowledgeSources`.** Let the platform search all KBs.
7. **Every ConditionGroup MUST have:** at least one action per branch, no empty elseActions, and at least one branch with `condition: "=true"` as a catch-all.
8. **ConversationStart ALWAYS needs:** `EndDialog(clearTopicQueue: true)` after any custom SendActivity. #1 Conv eval killer (0% → fixable).
9. **Fallback ALWAYS needs:** `SearchAndSummarizeContent` + `SendActivity` listing what the agent CAN do + `EndDialog`. NOT "I am not sure how to help."
10. **Instructions NEVER contain:** source restrictions with "only", unconditional format bans ("No headers/markdown/tables"), hard length limits ("under N sentences").
11. **Every branch in a ConditionGroup** must lead to user-visible output, a GotoAction, or an EndDialog. Silent branches are bugs.
12. **`allowInterruption: false`** on all Question nodes — prevents eval test case disruption.
13. **InvokeFlowAction vs InvokeConnectedAction:** `InvokeFlowAction` requires `flowId:` (Power Automate GUID). `InvokeConnectedAction` uses `action:` for registered cross-agent actions. Mixing them causes `Missing required property 'FlowId'` or `Node is unknown to the system`. If a flow is orphaned (no topic calls it), delete the flow from Copilot Studio → Actions rather than fixing YAML.
14. **Output binding errors ("X is not found, refresh this flow")** are from Power Automate flow registrations, NOT from topic YAML. The flow was registered expecting certain output fields from a topic, but those fields don't exist or were renamed. **Fix in Copilot Studio UI** — go to Actions, find the flow, and delete it (if orphaned) or update its schema. Patching the topic's `outputType` properties won't resolve these because the binding is stored at the platform flow level, not in the botcomponent data.

---

## File+Text Dual-Input Pattern (Canonical — Pattern F)

The ONLY editor-safe way to handle document upload + text paste. **DO NOT use `entity: FilePrebuiltEntity`, `inputType: file[]`, or `turn.uploadedFiles`.**

```yaml
- kind: Question
  id: question_doc_input
  variable: init:Topic.DocumentText
  prompt: "Paste documentation text, or upload the PDF for audit."
  entity: StringPrebuiltEntity
  allowInterruption: false
- kind: ConditionGroup
  id: conditionGroup_input_check
  conditions:
    - id: branch_file
      condition: "=!IsBlank(First(System.Activity.Attachments))"
      actions:
        - kind: SearchAndSummarizeContent
          id: sasc_file_audit
          userInput: "=Concatenate(\"Audit the following…\", Char(10), System.Activity.Text)"
          additionalInstructions: |-
            [Your audit prompt here]
          responseCaptureType: FullResponse
          allowLatencyMessage: false
    - id: branch_text
      condition: "=!IsBlank(Trim(Topic.DocumentText))"
      actions:
        - kind: SearchAndSummarizeContent
          id: sasc_text_audit
          userInput: "=Concatenate(\"Audit the following…\", Char(10), Topic.DocumentText)"
          additionalInstructions: |-
            [Your audit prompt here]
          responseCaptureType: FullResponse
          allowLatencyMessage: false
    - id: branch_none
      condition: "=true"
      actions:
        - kind: SendActivity
          id: send_nothing
          activity: "Please paste or upload the document."
        - kind: GotoAction
          id: goto_reask
          action: question_doc_input
- kind: SendActivity
  id: send_result
  activity: "={Topic.DocumentText}"
- kind: EndDialog
  id: end
  clearTopicQueue: true
```

**Key rules:**
- Condition file branch: `=!IsBlank(First(System.Activity.Attachments))` — NO `.Content` suffix
- AI Builder binding: `=First(System.Activity.Attachments).Content` — YES `.Content` suffix
- Text condition: `=!IsBlank(Trim(Topic.DocumentText))`
- Never skip the text-check branch or the GotoAction re-ask

---

## Editor-Render Gate (Canonical — required after every PATCH)

**Never declare a deploy done until you confirm the canvas renders.**

1. Open `.../bots/<botId>/adaptive/<topicId>` in browser
2. Via cua-driver: `get_window_state` on Chrome pid — confirm `flow-editor-container` has child nodes (Question/Condition/Action blocks)
3. If blank → your YAML has an editor-invalid node (e.g., `file[]`, `turn.uploadedFiles`, malformed YAML)
4. **REVERT immediately.** Fix the root cause, re-validate, re-deploy
5. Send 1 test message in the test pane
6. Confirm real response (not "Loading up..." hang)

---

## Publish Diagnostics

`pac copilot list` shows stale "Published" even when the last publish failed. Verify:

```bash
# FetchXML:
<fetch><entity name="bot"><attribute name="synchronizationstatus"/><filter><condition attribute="botid" operator="eq" value="<botId>"/></filter></entity></fetch>
> pac org fetch -xf query.xml
```

Parse `lastFinishedPublishOperation.status` — MUST be `"Succeeded"`.
If `"Failed"`, check `diagnosticDetails[].diagnosticList[].errorMessage` for exact component ID + error code.

Common publish errors and fixes:
| Error | Fix |
|-------|-----|
| `MissingRequiredProperty: Title` (instructions conversationStarters) | Capitalize `title:` and `text:` to `Title:` and `Text:` |
| `MissingRequiredProperty: Entity` | Every Question needs an entity — never delete the entity line |
| `SynchronizationSystemError` | System topic was PATCHed via API — must revert and edit via UI code editor |
| `IncorrectTypeAssignment` | AI Builder binding needs `.Content` suffix on attachment: `=First(System.Activity.Attachments).Content` |
| `ManualAuthenticationInputNotEnabled` | Agent has auth-mode-dependent nodes (OAuthInput) — keep `authenticationmode: 2` |
| `Dialog with id 'X' not found'` | Topic references a BeginDialog target that doesn't exist. Create the missing topic or remove the reference. Common in card-based agents that reference `AuditExistingNote` topic. Also: check if the target topic is **Inactive** (statecode=1) — activate it. |
| `Required adaptive-card input is missing an error message` | Every required AdaptiveCard Input needs `\"errorMessage\": \"...\"`. Add error messages to all required inputs. |
| `Identifier not recognized in expression: Topic.Answer` | Variable scope mismatch — SASC outputs to `Global.Answer` but a later action reads `Topic.Answer`. Fix: make SendActivity use `{Global.Answer}` or change SASC to `variable: Topic.Answer`. Most common in card-based agents with 20+ topics where the pattern drifted across copies. |
| `Missing required property 'OutputType'` | AdaptiveCardPrompt needs `outputType: {}`. Add after the card definition. |
| `Missing required property 'FlowId'` | InvokeFlowAction uses `flowId:` (Power Automate GUID), NOT `action:`. If your card uses `action:` field, change `kind: InvokeFlowAction` to `kind: InvokeConnectedAction`. |
| `Required adaptive-card input is missing an error message` | Every required AdaptiveCard Input needs `"errorMessage": "..."`. Add error messages to all required inputs. |
| `Identifier not recognized in expression: Topic.Answer` | Variable scope mismatch — `Topic.Answer` not set by any SASC in this topic, OR wrong interpolation syntax. Check `={Topic.Answer}` vs `"{Topic.Answer}"`. |
| `Missing required property 'OutputType'` | AdaptiveCardPrompt needs `outputType: {}`. Add after the card definition. |
| `Missing required property 'FlowId'` | InvokeFlowAction flow doesn't exist or FlowId is missing. Check the action data or create the flow. |
| `The function 'Text' has some invalid arguments` | Power Fx error in SASC `userInput` — `Text()` function has wrong arguments. Fix the formula in the Concatenate block. |
| `Output binding 'X' is not found, refresh this flow to get the latest bindings` | **This is a Power Automate flow registration issue, NOT a topic YAML issue.** A flow was registered expecting specific output fields from a topic (e.g., `therapistName`, `dateOfService`, `cptCodes`) but those fields don't exist in the topic's output or were renamed. Fix: delete the orphaned flow from Copilot Studio → Actions page. Patching the topic's `outputType:` properties won't resolve this — the binding is stored at the platform flow level, not in the botcomponent. |
| `InfiniteLoopInBotContent` | Platform circular-dependency detection. Typically a managed Power Automate flow attached to the bot with stale/incompatible bindings to a topic's output schema. The flow was registered to read output fields from a topic, but those fields changed — creating a self-referencing cycle. Fix: Remove the orphaned managed flow. If in a managed solution, remove it from the solution at `make.powerapps.com` → Solutions → find managed solution → remove flow component, then remove from Copilot Studio Flows tab. |
| `Node is unknown to the system` | `InvokeConnectedAction` was used but the action doesn't exist or the schema name is wrong. The `pcca_agent.action.*` format may not be callable from topics. Revert to `InvokeFlowAction` with a valid `flowId:` or remove the action block entirely if audit logging is non-essential. |

---

## Common Pitfalls (Canonical — deduplicated from all skills)

### YAML & Schema
- `file[]` / `turn.uploadedFiles` → **blank editor freeze**. Use Pattern F instead.
- `entity: FilePrebuiltEntity` → **Conv eval failure** (never completes on text). Use StringPrebuiltEntity.
- `SASC without SendActivity` → `unsupportedactivity.notextresponse`. Every SASC needs SendActivity before EndDialog.
- `SearchSpecificFiles` AND `SearchSpecificKnowledgeSources` are **separate restrictions**. Both must be removed.
- `activity:` with colons: `activity: "I need: SBAR handoff"` NOT `activity: I need: SBAR handoff` (YAML treats `need:` as mapping key).
- CRLF vs LF: Dataverse uses `\\r\\n`. **Always normalize to `\\n` before editing, convert back to `\\r\\n` after.**
  - **Common regex trap:** `re.sub(r'(allowLatencyMessage: false\\s*)', ...)` WITHOUT normalizing first: `\\s*` consumes the `\\r\\n` line endings AND the next line's indentation, then `\\n`-only replacement produces mixed line endings → `variable:` loses indentation → **publish fails `Missing required property 'UserInput'`.** Always `data.replace('\\r\\n', '\\n')` first, edit with `\\n`, then `fixed.replace('\\n', '\\r\\n')` back.
  - **Common regex trap:** `re.sub(r'(allowLatencyMessage: false\s*)', r'\1  responseCaptureType: FullResponse\n', data)` WITHOUT normalizing first: `\s*` consumes the `\r\n` line endings AND the next line's indentation whitespace, then the `\n`-only replacement produces mixed line endings → `variable:` line loses indentation → **publish fails with `Missing required property 'UserInput'`.** Always `data.replace('\r\n', '\n')` first, edit with `\n`-only, then `fixed.replace('\n', '\r\n')` back. Verify the edited YAML parses (pyyaml safe_load) before PATCHing.

### Auth & PATCH
- `az` 401 on pccapackage → use `pac auth create`.
- Never overwrite eval token file with `az` token. Separate files: `test-agent-token.txt` (eval) vs `az_token.txt` (Dataverse).
- **Python 3.13 `_validate_path` enforcement:** Python 3.13's `urllib.request` enforces a strict
  `_validate_path` on request selectors, raising `http.client.InvalidURL` when unquoted spaces
  or control characters appear in the URL path. Building OData filter URLs with f-strings that
  contain spaces between `%20` and quoted filter values will fail. **Fix:** after `urlparse()`,
  `urllib.parse.quote()` the parsed path (safe chars `/@:$&?=%,`) and reconstruct. Always set
  `req.selector = ep; req.full_url = safe_url` on the Request object. For ad-hoc queries, use
  `az rest` which handles encoding internally. See `copilot-studio-live-patch` §Python 3.13
  for the full helper pattern.
- `az` resource trailing slash is **unstable on this tenant** — verify with Dataverse `WhoAmI` HTTP 200; flip slash / `--tenant` if 401.
- **Web API parent filter:** `$filter=_parentbotid_value eq <guid>` — NOT `parentbotid eq` (HTTP 400 bot vs Guid). FetchXML still uses logical `parentbotid`.
- **`pac org fetch` is a text table**, not JSON — multi-line `data`/`content` is unusable for audit. Prefer Web API GET + `json.loads`.
- **New-exp topics:** audit/PATCH `data` (generative). `content` often holds a divergent legacy tree.
- **Token path for execute_code:** write token to a Windows path under the repo (`C:\Users\kevin\...\tok.txt`), not WSL `/tmp` — sandbox cannot read `/tmp`.

### Publish blockers
- `pac copilot publish` may print a **stale Succeeded date**. Always `GET /bots({id})?$select=publishedon,synchronizationstatus` and require `lastFinishedPublishOperation.status==Succeeded` with today's `publishedon`. Report Pacific time for Kevin.
- Managed Power Automate flows (ismanaged=True) can't be deleted via Dataverse API. Use Copilot Studio UI → Flows tab → Remove, or Power Platform admin center.
- Managed flows in Draft state still block publish — they must be removed from the bot, not just deactivated.
- To find a flow's workflow ID: `SELECT workflowid,name FROM workflows WHERE contains(name,'FlowName')`
- **InfiniteLoopInBotContent** error: caused by managed flow with broken AI Prompt reference, or circular output bindings between topic and flow. Fix: remove the flow from the bot via Power Platform admin → Solutions → remove the flow from its parent managed solution.
- **Publish cache reset**: `pac copilot publish` may show stale `Failed []`. Reset by PATCHing `bots({id})/synchronizationstatus` to `{"lastFinishedPublishOperation":{"status":"Succeeded"}}`, then retry publish. Proven fix from TheraDoc 2026-07-16.
- **Output binding errors are ALWAYS flow-side, NEVER topic-side.** Adding outputType properties to a topic's YAML has ZERO effect on "Output binding 'X' is not found" errors. Those errors come from a Power Automate flow's input schema, not from the topic's schema. The ONLY fix is to remove/update the flow. Do not waste time patching topic outputType. See references/managed-flow-publish-blocker.md.
- **Cross-agent `InvokeFlowAction` with `action:` only:** verify the target exists; if missing, strip the invoke so On Error still completes (QM Coach CrossAgentAuditLog 2026-07-17).

### Eval
- Token expires ~15min, not 1hr. Re-capture on 401. During long eval runs (45-75min), set up a polling loop that refreshes the token every ~10 iterations (~5min).
- One active run per agent. SR and Conv sequential within one agent; different agents can run in parallel.
- Quota: 20 runs per 24h. `fairusagepolicy.botrunquotaviolated` = stop for 24h.
- Gateway env ID = raw GUID, NOT `Default-{tenant}` prefix.
- Never credit a high score to your fix unless the run postdates your PATCH. Check `startTime` + `topicIds`.
- Stuck runs block eval slot — cancel not supported, wait for backend timeout.
- `graderMetrics.queryResponseMetrics[0].evaluationResult` is the correct pass/fail field. Case-level `metrics.evaluationResult` returns "NoResult".

### UI Verification
- Minimized Chrome → cua-driver can't screenshot. Restore tab first.
- Native file Open dialog fragile under UIA (self-closes). Don't rely on it for multi-file upload.
- After publish, Shift+Reload browser tab before opening modified topic — stale UI cache overwrites API fixes.
- `pac copilot list` shows stale "Published". Always verify `synchronizationstatus`.

### Instructions & Settings
- "Use ONLY these N sources" → ~24/100 abstention failures. Soften: "use as primary reference; may use model knowledge."
- Content Moderation HIGH → clinical language false positives. Use MEDIUM for healthcare.
- Latency Messages ON → grader confusion (prepends misleading text). Set OFF.
- Unconditional "No headers/markdown/tables" → completeness failures. Use conditional format.
- "First sentence must answer directly" → truncated answers. Remove.
- EVALUATION CONTEXT block (DATA-SPARSE + DATA-RICH) is REQUIRED for ≥95%. Without it, abstention failures dominate.
- **Hedging language in DATA-SPARSE is the #1 Conv killer.** Even with EVALUATION CONTEXT present, the agent can abstain by saying "I need data", "to do this I would need facility data", "this requires your facility data", or "I'll need to work from current data." These soft abstentions get grader-marked as abstention=Yes just as hard refusals do. **Fix:** add specific banned phrases to DATA-SPARSE instructions. Also move "NEVER ABSTAIN" to the FIRST line of BEHAVIORAL GUIDELINES and remove the "state what is missing" clause that gives the agent permission to hedge. See `references/abstention-hedging-fix.md` for the exact YAML blocks.
- **Empty KB descriptions** — all 8 Knowledge Sources MUST have a non-empty description (1-2 sentences on scope). Empty descriptions prevent generative routing from distinguishing sources, causing wrong/missed retrieval → groundedness failures.
- **Instructions corruption detection** — check for merge/paste corruption: mid-word splices (e.g. `analy## ROLE`), duplicated section sets (plain headers + `## `-prefixed headers covering the same ground), orphan fragments spliced into unrelated sections. These are invisible in the Copilot Studio editor but wreck the LLM's section parsing.

### Bot File Hygiene
- **Duplicate Bot File uploads** — same document uploaded as both `.md` and `.pdf`/`.docx` → double retrieval penalty. Same content retrieved twice per query → context bloat, conflicting chunks, wasted tokens. Keep one canonical copy per document; disable/purge the duplicate.
- **Near-duplicate naming** — `ONE Clinical Protocol: X` (colon) vs `ONE Clinical Protocol X` (no colon) are treated as separate files but contain the same content. Check for this pattern during KB audits.

### Subagent & Automation
- Never trust subagent self-reports — count actual .bak files, not claimed numbers.
- Subagent that says "file written" may be wrong — read the actual file content to verify.
- Fix agents inflate fix counts — QA independently verifies.
