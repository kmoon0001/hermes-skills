---
name: copilot-studio-edit-agent
description: Edit Copilot Studio agent metadata (agent.mcs.yml) or configuration (settings.mcs.yml) — display name, instructions, conversation starters, AI model, authentication, capabilities.
category: copilot-studio
---

# Edit Agent Settings/Instructions

Modify agent metadata (agent.mcs.yml) or configuration (settings.mcs.yml).

## Instructions

1. Auto-discover agent directory: Glob **/agent.mcs.yml. NEVER hardcode.

2. Identify what to change:
- Instructions, display name, conversation starters, AI settings -> agent.mcs.yml
- GenerativeActionsEnabled, authentication, recognizer, capabilities -> settings.mcs.yml

3. For AI model changes, run schema lookup first:
```bash
node "D:/my agents copilot studio/pipeline/scripts/schema-lookup.bundle.js" models
```
CRITICAL: Do NOT include kind in the model block — uses CurrentModelsNoKind.

4. Read current file before making changes.

## Editable Fields in agent.mcs.yml
| Field | Description | Example |
| displayName | Agent display name | displayName: My Agent |
| instructions | System prompt / personality | Multi-line YAML with | |
| conversationStarters | Suggested starters | Array of {title, text} |
| aISettings.model.modelNameHint | Model hint | Sonnet46, GPT5Chat |
| aISettings.model.provider | Model provider (non-OpenAI) | Anthropic |

## Editable Fields in settings.mcs.yml
| Field | Description | Example |
| GenerativeActionsEnabled | Enable generative orchestration | true/false |
| authenticationMode | Auth mode | Integrated, None |
| authenticationTrigger | When to auth | Always, AsNeeded |
| accessControlPolicy | Access control | ChatbotReaders |
| configuration.aISettings.* | AI capabilities | Various booleans |
| configuration.settings.*.content.capabilities.webBrowsing | Web browsing | true/false |

## Fields to NEVER Modify
- schemaName — internal Power Platform identifier
- publishedOn — managed by platform
- template — managed by platform
- language — changing can corrupt the agent

## Writing Effective Instructions
- Be specific about agent personality and scope
- Include grounding directives
- Define citation control behavior
- Set scope enforcement rules
