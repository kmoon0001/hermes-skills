// cdp-capture-token.cjs — Capture PPAPI Bearer token from browser via Chrome DevTools Protocol
//
// PREREQUISITE: Browser must be running with --remote-debugging-port=9223
//   msedge.exe --remote-debugging-port=9223
//   chrome.exe --remote-debugging-port=9223
//
// This script:
//  1. Finds the Copilot Studio tab via CDP HTTP endpoint
//  2. Connects to its WebSocket debugger
//  3. Enables Fetch domain to intercept ALL requests
//  4. Reloads the Copilot Studio Evaluation page
//  5. Captures the Authorization: Bearer header from PPAPI requests
//  6. Saves the raw token to %USERPROFILE%\.copilot-studio-cli\test-agent-token.txt
//
// The saved token can then be used for direct PPAPI calls:
//   curl -H "Authorization: Bearer <token>" "https://api.powerplatform.com/copilotstudio/..."
//
// USAGE: node cdp-capture-token.cjs
//
// VALIDATED: Jul 1, 2026 — Therapy Documentation Feedback Agent (Prod)
//   Connected to Chrome 149, found eval tab, captured 4487-char token from PPAPI request.

const WebSocket = require('ws');
const fs = require('fs');
const path = require('path');
const http = require('http');

const TOKEN_FILE = path.join(process.env.USERPROFILE, '.copilot-studio-cli', 'test-agent-token.txt');

(async () => {
  // Get all open tabs from CDP
  const pages = await new Promise((resolve, reject) => {
    http.get('http://127.0.0.1:9223/json/list', res => {
      let d = ''; res.on('data', c => d += c); res.on('end', () => resolve(JSON.parse(d)));
    }).on('error', reject);
  });
  
  const target = pages.find(p => p.url.includes('copilotstudio.microsoft.com'));
  if (!target) { console.log('Copilot Studio tab not found'); process.exit(1); }
  console.log('Found tab:', target.title.slice(0, 80));

  const ws = new WebSocket(target.webSocketDebuggerUrl);
  let token = null;
  const startTime = Date.now();

  // ONE handler — never replaced
  ws.on('message', (raw) => {
    const msg = JSON.parse(raw.toString());
    
    // Capture token from intercepted requests
    if (msg.method === 'Fetch.requestPaused' && !token) {
      const req = msg.params.request;
      const auth = req.headers['Authorization'] || req.headers['authorization'];
      const url = req.url;
      
      if (url.includes('powerplatform.com') || url.includes('makerevaluation')) {
        console.log('REQ:', url.slice(0, 120));
        if (auth) {
          token = auth.replace(/^Bearer\s+/i, '');
          console.log('TOKEN CAPTURED!');
        }
      }
      ws.send(JSON.stringify({ id: 9999, method: 'Fetch.continueRequest', params: { requestId: msg.params.requestId } }));
      return;
    }
    
    // Timeout after 45 seconds
    if (Date.now() - startTime > 45000 && !token) {
      console.log('Timeout — no token found');
      ws.close();
      process.exit(1);
    }
  });

  ws.on('open', () => {
    console.log('Connected');
    // Enable Fetch interception for all URLs
    ws.send(JSON.stringify({ id: 1, method: 'Fetch.enable', params: { patterns: [{ urlPattern: '*' }] } }));
    // Reload page to trigger fresh API calls
    ws.send(JSON.stringify({ id: 2, method: 'Page.reload' }));
    console.log('Reloading...');
  });

  // Check every second if we have token
  const check = setInterval(() => {
    if (token) {
      clearInterval(check);
      fs.mkdirSync(path.dirname(TOKEN_FILE), { recursive: true });
      fs.writeFileSync(TOKEN_FILE, token);
      console.log('OK: Token saved (' + token.length + ' chars)');
      ws.close();
      process.exit(0);
    }
  }, 1000);

  ws.on('close', () => {
    clearInterval(check);
    if (!token) process.exit(1);
  });
  
  ws.on('error', (e) => { console.error('WS error:', e.message); process.exit(1); });
})().catch(e => { console.error(e.message); process.exit(1); });
