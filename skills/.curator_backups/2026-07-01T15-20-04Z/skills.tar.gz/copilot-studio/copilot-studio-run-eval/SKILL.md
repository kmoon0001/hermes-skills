---
name: copilot-studio-run-eval
description: "Run evaluations against Copilot Studio agent's DRAFT via PPAPI — no publish needed. List test sets, start runs, poll, fetch results, propose fixes."
version: 1.0.0
author: Copilot Studio Pipeline
license: MIT
platforms: [windows, linux, macos]
metadata:
  hermes:
    tags: [copilot-studio, evaluation, ppapi, draft-eval]
    homepage: https://learn.microsoft.com/microsoft-copilot-studio/
---

# Run Evaluation (PPAPI)

Run evaluations against Copilot Studio agent's DRAFT — no publish needed.
Requires --client-id and --workspace. If no client ID, tell caller to run test-auth first.
All eval-api commands normally run in foreground. If a command prints `No cached token — starting interactive login`, use a PTY-backed interactive run so the local redirect listener stays alive while the user signs in directly in the browser. Do not ask the user to paste credentials or MFA codes in chat. If backgrounding is required to keep working while auth waits, use `pty=true` and poll the process; non-PTY background auth can fail with `stdin is not a tty`.

### Auth fallback: device-code cache seeding
If localhost redirect/browser auth gives Microsoft sign-in errors, query parameters get dropped, or the user reports trouble signing in, do not keep looping the same URL. Seed the same MSAL cache with device-code auth, then rerun `eval-api.bundle.js` normally.

**PITFALL — redirect URI mismatch (AADSTS50011):** The interactive localhost redirect can fail with `AADSTS50011: The redirect URI 'http://localhost:<port>' specified in the request does not match the redirect URIs configured for the application`. MSAL Node's LoopbackClient chooses a random port, but the Azure app registration may only have specific ports or no localhost URIs. If you see this, the interactive flow is dead for that client — do not retry with different ports (they all fail the same way).

**PITFALL — tenant Conditional Access blocks device-code flow:** If `https://login.microsoft.com/device` returns "you don't have access", the tenant policy blocks device-code authentication. The device-code helper will sit at `device_code` status forever — kill it. Do not retry device code after a tenant-access denial.

**PITFALL — both localhost redirect AND device-code blocked:** When both interactive redirect (AADSTS50011) and device-code (Conditional Access) fail, all automated OAuth paths for the PPAPI client are exhausted. Fall back to manual token capture (see below). Do not loop retrying either flow.

### Automated CDP WebSocket token capture (preferred over manual)

When both `eval-api.bundle.js` interactive login AND device-code seeding are blocked, use the CDP WebSocket script to capture the token automatically from the user's already-signed-in browser:

```bash
node scripts/cdp-capture-token.cjs
```

**PREREQUISITE**: The user's browser must be running with `--remote-debugging-port=9223`. If not, ask the user to restart their browser with the flag:
```
msedge.exe --remote-debugging-port=9223
```
or
```
chrome.exe --remote-debugging-port=9223
```

The script:
1. Discovers the Copilot Studio tab via `http://127.0.0.1:9223/json/list`
2. Connects to the tab's WebSocket debugger
3. Enables Fetch domain interception for all URLs
4. Reloads the page → PPAPI requests fire with the Bearer token
5. Captures the Authorization header and saves to `%USERPROFILE%\.copilot-studio-cli\test-agent-token.txt`

With the token, call PPAPI endpoints directly via `curl` or Python `urllib`. Do NOT attempt to write into the DPAPI-encrypted MSAL cache file. Token expires after ~1 hour.

**Verified**: Jul 1, 2026 — Chrome 149, 4487-char token, Therapy Documentation Feedback Agent (Prod).

### Manual browser DevTools token capture (fallback)

If CDP isn't available, ask the user to extract the Bearer token manually:

1. Have the user open the Copilot Studio Evaluation page in their signed-in browser:
   `https://copilotstudio.microsoft.com/environments/<envId>/bots/<botId>/evaluation`
2. Press F12 → Network tab
3. Refresh the page (F5)
4. Filter by `makerevaluation`
5. Click any request, go to Headers → Request Headers
6. Copy the full `Authorization: Bearer eyJ...` header value
7. Paste the token back to the agent

With the raw token, call PPAPI endpoints directly:
```bash
curl -H "Authorization: Bearer <token>" \
  "https://api.powerplatform.com/copilotstudio/environments/<envId>/bots/<botId>/api/makerevaluation/testsets?api-version=2024-10-01"
```
### Auth fallback: device-code cache seeding
If localhost redirect/browser auth gives Microsoft sign-in errors, query parameters get dropped, or the user reports trouble signing in, do not keep looping the same URL. Seed the same MSAL cache with device-code auth, then rerun `eval-api.bundle.js` normally.

Use the bundled helper in this skill as a template/copy target:
`scripts/device-code-auth.cjs`

When running the device-code helper through Hermes/background process tooling, use a PTY (`pty=true`). Without a TTY the helper can exit immediately with `stdin is not a tty`. Prefer a tracked background process with `notify_on_complete=true`, then poll for the JSON payload containing `verificationUri` and `userCode`.

Important cache details:
- `eval-api.bundle.js` with explicit `--client-id` uses cache slot `test-agent`.
- Cache path is `%USERPROFILE%\\.copilot-studio-cli\\test-agent.cache.json`.
- Scope for PPAPI evals is `https://api.powerplatform.com/.default`
- If the helper is copied to `%TEMP%`, normal `require()` may not resolve the pipeline's `node_modules`; use the script's optional final argument pointing at the pipeline `package.json` (or use `createRequire('D:/.../pipeline/package.json')`).
- Device codes expire quickly, usually in 15 minutes. If the process exits with `device_code_expired`, do not troubleshoot the old code; immediately restart the helper and give the user the fresh `verificationUri` + `userCode`.

### Auth fallback: CDP WebSocket token capture (when ALL MSAL flows are blocked)

If ALL MSAL-based flows fail — interactive redirect gives `AADSTS50011` (redirect URI mismatch on app `96ff4394-9197-43aa-b393-6a41652e21f8`), device-code shows "You don't have access" (tenant Conditional Access), and VS Code/Azure CLI tokens return 403 `InsufficientDelegatedPermissions` — use CDP WebSocket capture to extract the token directly from the user's signed-in browser.

**The evaluation-rest-api skill has the full recipe** (`skill_view('evaluation-rest-api')`, Method B section) and the working script at `scripts/cdp_ws_capture.cjs`. Summary:

1. Verify CDP is available: `curl -s http://127.0.0.1:9223/json/version`
2. Find the Copilot Studio eval tab: `curl -s http://127.0.0.1:9223/json/list | python -c "..."` 
3. Run the capture script via PowerShell: `powershell.exe -NoProfile -Command "node <skill-dir>/scripts/cdp_ws_capture.cjs"`
4. Token lands at `%USERPROFILE%\\.copilot-studio-cli\\test-agent-token.txt`
5. Use the token directly with PPAPI: `Authorization: Bearer <token>` against `https://api.powerplatform.com/copilotstudio/environments/<env>/bots/<agent>/api/makerevaluation/...`

Do NOT keep retrying `eval-api.bundle.js` or device-code when these specific error codes appear. Go directly to CDP capture.
- If the helper is copied to `%TEMP%`, normal `require()` may not resolve the pipeline's `node_modules`; use the script's optional final argument pointing at the pipeline `package.json` (or use `createRequire('D:/.../pipeline/package.json')`).
- Device codes expire quickly, usually in 15 minutes. If the process exits with `device_code_expired`, do not troubleshoot the old code; immediately restart the helper and give the user the fresh `verificationUri` + `userCode`.

Example from the pipeline checkout:
```bash
cd "D:/my agents copilot studio/pipeline"
node "C:/Users/kevin/AppData/Local/hermes/profiles/coding-profile/skills/copilot-studio/copilot-studio-run-eval/scripts/device-code-auth.cjs" \
  <tenant-id> \
  96ff4394-9197-43aa-b393-6a41652e21f8 \
  https://api.powerplatform.com/.default \
  test-agent \
  "D:/my agents copilot studio/pipeline/package.json"
```
Give the user only `verificationUri` and `userCode`; never ask for passwords or MFA codes in chat. When the helper prints `status: ok`, rerun `list-testsets` or `start-run`; it should use the cached token.

## Step 1: List test sets

**PITFALL — missing IDs when no `.mcs/conn.json`:** `eval-api.bundle.js` needs `--agent-id`, `--tenant-id`, and `--environment-id` if the workspace lacks `.mcs/conn.json`. Without them it fails sequentially with "Cannot determine agent/tenant/environment ID". Provide all three explicitly. Find the environment GUID with `pac env list` (look for the org name in the "Display Name" column). Find the agent Copilot ID with `pac copilot list`.

Verification pitfall: after eval/push-related YAML edits, if there is no canonical test suite, create and run a temporary `hermes-verify-*.py` verifier under the user's temp directory, validate changed YAML plus the active workspace, clean it up, and report it as ad-hoc verification rather than suite green. See `references/live-auth-url-and-verification.md`.

Active-agent/connection pitfall: before push/eval, verify the live active/provisioned agent rather than trusting `.mcs/conn.json`; local connection files may point at a managed/inactive/deprovisioned legacy agent or fail due to BOM JSON parsing. See `references/stale-conn-active-agent-eval-push.md`.

### Interactive auth URL handling pitfall
When opening the Microsoft auth URL from tool/browser automation, preserve the full query string. If the browser opens a Microsoft error such as `AADSTS900144: The request body must contain the following parameter: 'scope'`, the URL was truncated or `&scope=...` was dropped. Retry by assigning the full URL through page JavaScript (`window.location.href = '<full URL>'`) or by opening it in the user's local default browser (`os.startfile(url)` on Windows) while the PTY auth listener remains running. Do not ask the user to paste credentials; have them complete sign-in/MFA directly in the browser, then poll the eval process for completion.

## Step 1: List test sets
```bash
node "D:/my agents copilot studio/pipeline/scripts/eval-api.bundle.js" list-testsets --workspace <path> --client-id <id>
```
- No test sets: tell user to create one in Copilot Studio (Evaluate tab > New evaluation). Stop.
- One test set: tell user which one and proceed.
- Multiple: show all and ask user to pick.

## Step 2: Ask about authenticated execution — MANDATORY
Ask user: Does your agent use authenticated knowledge sources or connector actions?
If so, they need a connection ID from https://make.powerautomate.com -> Connections -> Microsoft Copilot Studio connection -> copy connection ID from URL.
Without connection ID, eval runs anonymously and tools/knowledge will NOT be used.
Do NOT proceed until user responds.

## Step 3: Start the run
```bash
node "D:/my agents copilot studio/pipeline/scripts/eval-api.bundle.js" start-run --workspace <path> --client-id <id> --testset-id <id> --run-name "Draft eval <date>"
```
Add --connection-id <id> if user provided one. Add --published only if user explicitly asked.

## Step 4: Poll until complete
```bash
node "D:/my agents copilot studio/pipeline/scripts/eval-api.bundle.js" get-run --workspace <path> --client-id <id> --run-id <runId>
```
Poll every 15-30 seconds. Report progress. Stop when state is Completed, Failed, Abandoned, or Cancelled.

## Live UI/gateway fallback

If the bundled PPAPI path is not enough, or if you are already operating from the live Copilot Studio Evaluation UI, use the PowerVA gateway API pattern documented in `evaluation-driven-agent-optimization/references/live-evaluation-gateway-api.md` and the local notes in `references/live-gateway-details-quota-and-guardrails.md`:
- Capture the live Evaluation page's `authorization` and `x-cci-*` headers.
- `GET /makerevaluations?count=10` lists runs.
- `POST /makerevaluations` starts a run by `testSetId`.
- `GET /makerevaluations/{runId}/details` fetches full case details and is the preferred source for progress/result analysis. If a custom poller gets `405 Method Not Allowed`, switch to `/details` rather than continuing to retry the failing endpoint.
- In `/details`, score General Quality from `details.testCases[].graderMetrics.queryResponseMetrics[]`: pass only when relevance=Yes, completeness=Yes, abstention=No, and groundedness is absent or Yes.
- `PATCH /makerevaluations/{runId}/cancel` cancels an active run. Body: `{ "evaluationRunId": "<runId>" }`.

Important quota nuances:
- Active-run limit is per agent. SR and Conv for the same agent must be sequential, but different agents can have active runs at the same time.
- Active-run block error: `fairusagepolicy.botactiverunquotaviolated`.
- Daily quota block error: `fairusagepolicy.botrunquotaviolated` with message similar to `The agent has been evaluated more than 20 times in the last 24 hours. Please wait before trying again.` Stop launching and record handoff when this appears; do not burn time retrying until the 24-hour window resets.

Guardrail-patch validation:
- When inserting static `ConditionGroup` / `SendActivity` guardrails or replacing `additionalInstructions`, validate generated `.after.yml` backups before running another eval. A common regression is malformed indentation under `additionalInstructions: |-`, causing YAML `ScannerError` and potentially invalid topic data. See `references/live-gateway-details-quota-and-guardrails.md`.

## Step 5: Fetch and analyze results
```bash
node "D:/my agents copilot studio/pipeline/scripts/eval-api.bundle.js" get-results --workspace <path> --client-id <id> --run-id <runId>
```
Present summary table (total, passed, failed, errors). For failures:
| Metric | What to check |
| GeneralQuality Fail | Which of relevance/completeness/groundedness/abstention failed |
| ExactMatch Fail | Score 0.0-1.0 |
| CapabilityUse Fail | missingInvocationSteps |
| Error status | errorReason — often test set config issue |

## Step 6: Propose fixes
For YAML authoring failures: find relevant topic, read it, propose specific edits. Wait for user approval.
After applying: offer to push and re-run (go back to Step 3).
