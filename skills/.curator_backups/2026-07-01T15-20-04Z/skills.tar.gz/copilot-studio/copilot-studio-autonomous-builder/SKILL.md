---
name: copilot-studio-autonomous-builder
description: End-to-end autonomous workflow for building, editing, validating, and publishing Copilot Studio agents.
category: copilot-studio
---

# Autonomous Copilot Studio Builder

End-to-end autonomous workflow for building, editing, validating, and publishing Copilot Studio agents.

## The Loop

```
Edit YAML -> Validate -> Push -> Publish -> Test -> Analyze -> Fix -> Repeat
```

## Phase 1: Clone or Initialize
1. If agent exists in cloud: use copilot-studio-manage-agent clone
2. If new agent: create local YAML structure
   ```
   <agent-dir>/
   ├── agent.mcs.yml      # Agent metadata
   ├── settings.mcs.yml   # Settings (GenerativeActionsEnabled, auth, etc.)
   ├── topics/             # Conversation topics
   ├── actions/            # Connector actions
   ├── knowledge/          # Knowledge sources
   ├── variables/          # Global variables
   └── agents/             # Child agents
   ```

## Phase 2: Author
For each requested feature:
1. Load appropriate skill:
   - New topic -> copilot-studio-author-topic
   - Add node -> copilot-studio-add-node
   - Edit instructions -> copilot-studio-edit-agent
   - Edit triggers -> copilot-studio-edit-triggers
   - Knowledge source -> copilot-studio-add-knowledge
   - Connector action -> copilot-studio-add-action
   - Adaptive card -> copilot-studio-add-adaptive-card
   - Global variable -> copilot-studio-add-global-variable
   - Child agent -> copilot-studio-add-other-agents
   - Generative answers -> copilot-studio-add-generative-answers
2. ALWAYS verify kind values against schema before writing
3. ALWAYS validate after writing

## Phase 3: Validate
Two-layer validation:
1. Schema validation (local, fast):
   ```bash
   node "D:/my agents copilot studio/pipeline/scripts/schema-lookup.bundle.js" validate <file.yml>
   ```
2. LSP validation (needs conn.json, comprehensive):
   ```bash
   node "D:/my agents copilot studio/pipeline/scripts/manage-agent.bundle.js" validate --workspace <path> ...
   ```
Fix ALL errors before proceeding. Fix warnings where applicable.

## Phase 4: Push
```bash
node "D:/my agents copilot studio/pipeline/scripts/manage-agent.bundle.js" pull --workspace <path> ...
node "D:/my agents copilot studio/pipeline/scripts/manage-agent.bundle.js" push --workspace <path> ...
```
ALWAYS pull before push (avoids ConcurrencyVersionMismatch).

## Phase 5: Publish
```bash
node "D:/my agents copilot studio/pipeline/scripts/manage-agent.bundle.js" publish --workspace <path> ...
```
Confirm with user before publishing (makes agent live for all shared users).
Timeout: 300000ms.

## Phase 6: Test
Option A — Point test (single message):
1. Detect auth mode with chat-with-agent.bundle.js --detect-only
2. Send test message via directline-chat.bundle.js or chat-with-agent.bundle.js

Option B — Eval (draft testing, no publish needed!):
1. Use copilot-studio-run-eval skill
2. This can test DRAFT agents — huge for iteration speed

Option C — Batch test suite:
Use eval-api.bundle.js with pre-defined test sets

## Phase 7: Analyze and Fix
If test fails:
1. Analyze failure (which metric failed, what was expected vs actual)
2. Find relevant topic/action YAML
3. Propose specific fix
4. Apply fix
5. Go back to Phase 3 (Validate)

## Decision Rules
- NEVER write a kind value without verifying it exists in schema
- ALWAYS pull before push
- ALWAYS validate before push
- ALWAYS confirm before publish
- Use schema-lookup for ANY YAML question
- Use templates as starting points, not from scratch
- Generate unique IDs: <nodeType>_<6-8 random alphanumeric>
- When GenerativeActionsEnabled: true, prefer inputs/outputs over Question/SendActivity

## Pitfalls

- **Playwright tests need storageState for auth.** Headless browsers can't complete Microsoft OAuth. Capture auth cookies once with `npx playwright codegen --save-storage=tests/auth.json https://copilotstudio.microsoft.com` then reuse in headless runs. See `copilot-studio-pipeline` references/playwright-auth-pattern.md.
- **eval-api tests DRAFT — use it for fast iteration.** Don't publish until eval passes on draft. This saves minutes per iteration cycle.
- **Schema validation is LOCAL — no auth needed.** Run `schema-lookup.bundle.js validate <file>` before every push. It catches structural errors instantly.
- **AgentDialog must NOT have beginDialog.actions.** Child agents use generative orchestration only.
- **System topics are off-limits.** Modifying them breaks pac copilot publish.
- **data field ≠ content field.** Only data is patchable via API. content is UI-only.

## Key Scripts
| Script | Purpose |
| schema-lookup.bundle.js | Schema queries + YAML validation (local) |
| manage-agent.bundle.js | Push/pull/clone/publish/validate (needs auth) |
| chat-with-agent.bundle.js | Detect auth mode + M365 chat |
| directline-chat.bundle.js | DirectLine v3 chat (no auth) |
| connector-lookup.bundle.js | Connector operations lookup |
| eval-api.bundle.js | PP Evaluation API (draft testing) |

All scripts at: D:/my agents copilot studio/pipeline/scripts/
Templates at: D:/my agents copilot studio/pipeline/templates/
Patterns at: D:/my agents copilot studio/pipeline/patterns/
