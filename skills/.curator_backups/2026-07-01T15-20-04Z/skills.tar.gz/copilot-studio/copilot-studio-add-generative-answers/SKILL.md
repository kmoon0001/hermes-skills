---
name: copilot-studio-add-generative-answers
description: Add SearchAndSummarizeContent or AnswerQuestionWithAI nodes to Copilot Studio topics.
category: copilot-studio
---

# Add Generative Answers

Add SearchAndSummarizeContent or AnswerQuestionWithAI nodes to Copilot Studio topics.

## Important: Do You Even Need a Topic?
When knowledge sources are added, AI can directly search them without any topic for QnA-style queries. Dedicated topic with SearchAndSummarizeContent is useful when:
- Restrict search to subset of knowledge sources
- Control flow around answer (follow-up, formatting, adaptive cards)
- Process response before showing
- Use specific input other than user's last message

## SearchAndSummarizeContent vs AnswerQuestionWithAI vs SearchKnowledgeSources
| Node | Use When | Data Source | Output |
| SearchAndSummarizeContent | Grounded in knowledge sources | Agent's knowledge | AI-summarized |
| SearchKnowledgeSources | Verbatim/exact content (insurance, legal, HR) | Agent's knowledge | Raw results, no AI |
| AnswerQuestionWithAI | Conversation history + general model knowledge only | No external data | AI-generated |

## Key Rules
1. ALWAYS precede SearchAndSummarizeContent with CreateSearchQuery to preserve conversational context
2. NEVER pass =System.Activity.Text directly to SearchAndSummarizeContent
3. Access result via Topic.<ResultVar>.SearchQuery
4. ALWAYS add a SendActivity after SearchAndSummarizeContent that sends the result variable. Default examples often use `activity: =Topic.Answer`, but if live/eval output shows the literal string `=Topic.Answer`, switch that topic to interpolation form `activity: "{Topic.Answer}"` and verify with a fresh eval. Without an explicit SendActivity, the eval framework reports `unsupportedactivity.notextresponse` because it can't capture Topic.Answer as a text response. The SendActivity should be the last action before EndDialog.
5. For knowledge-grounded Q&A topics, do not pass `=System.Activity.Text` directly to SearchAndSummarizeContent. Use `CreateSearchQuery` first (`userInput: =System.Activity.Text`, `result: Topic.SearchQuery`), then set SearchAndSummarizeContent `userInput: =Topic.SearchQuery.SearchQuery`.
6. Do NOT add `autoSend: false` to SearchAndSummarizeContent unless the schema has been validated for that exact agent/runtime. In OT_Specialist (Jul 1 2026), adding `autoSend: false` produced topic errors because the node schema rejected the property. If SearchAndSummarizeContent auto-sends verbose/cited text in addition to SendActivity, first try supported patterns (tight additionalInstructions, topic-level direct-answer rule, normal SendActivity + EndDialog) and validate/publish one topic before batch patching.

## Knowledge Source References
When using knowledgeSources to restrict search:
- Knowledge source must already exist (add with add-knowledge first)
- Find filename in knowledge/ directory
- Reference WITHOUT .mcs.yml extension
```yaml
knowledgeSources:
  kind: SearchSpecificKnowledgeSources
  knowledgeSources:
    - cre3c_agent.topic.MyDocs_abc123
```

## Patterns
For full YAML examples see the templates at:
- D:/my agents copilot studio/pipeline/templates/topics/search-topic.topic.mcs.yml

Additional field notes:
- `references/ot-specialist-eval-runtime-pitfalls-2026-07.md` — eval/runtime fixes for literal `=Topic.Answer`, CreateSearchQuery wiring, `autoSend: false`, and citation/markdown leakage.

## Structured Data → Note Generation Pattern

When SearchAndSummarizeContent is used to generate clinical notes from structured data (not knowledge search), CreateSearchQuery is NOT needed. Pass structured data directly via Concatenate():

```yaml
    - kind: SearchAndSummarizeContent
      id: gen_note
      userInput: "=Concatenate(\\"Generate a skilled NOTE_TYPE. Use only provided data. VAR1 \\", Text(Topic.var1), \\" VAR2 \\", Text(Topic.var2), \\".\\")"
```

**When to skip CreateSearchQuery:**
- Generating notes from AdaptiveCard-collected data
- Processing user-pasted document content
- Any flow where the input is structured clinical data, not a knowledge search query

**When to use CreateSearchQuery:**
- Knowledge-grounded Q&A (searching agent's knowledge sources)
- When you need to restrict search to specific knowledge sources
- Conversational context preservation for multi-turn knowledge queries

**YAML Quoting:** userInput with Concatenate() MUST be double-quoted with escaped inner quotes. Unquoted form breaks on colons/braces.

Verified: TheraDoc Workbench Card topics (Jun 30 2026) — 17 Card topics generate clinical notes from AdaptiveCard data without CreateSearchQuery.

## Generative Orchestration
When GenerativeActionsEnabled: true:
- Prefer Pattern 2 (Orchestrator): use topic inputs/outputs
- When false: use Pattern 1 (Direct Response) with autoSend: false + manual SendActivity
- Verbatim content needed: Pattern 4 (Precision Search) with SearchKnowledgeSources + CreateSearchQuery
