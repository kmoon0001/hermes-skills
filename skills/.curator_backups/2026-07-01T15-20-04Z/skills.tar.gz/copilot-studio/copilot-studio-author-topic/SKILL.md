---
name: copilot-studio-author-topic
description: Create new Copilot Studio topic YAML files from templates or scratch.
category: copilot-studio
---

# Create New Topic

Generate Copilot Studio topic YAML files based on user requirements.

## Workflow

1. Auto-discover agent directory: Glob **/agent.mcs.yml. NEVER hardcode agent name.

2. Check templates in the pipeline templates/topics/ directory first:
- greeting.topic.mcs.yml — OnConversationStart greeting
- fallback.topic.mcs.yml — OnUnknownIntent fallback with escalation
- arithmeticsum.topic.mcs.yml — Topic with inputs/outputs and computation
- question-topic.topic.mcs.yml — Question with branching logic
- search-topic.topic.mcs.yml — Generative answers from knowledge
- auth-topic.topic.mcs.yml — Authentication flow
- error-handler.topic.mcs.yml — Error handling
- disambiguation.topic.mcs.yml — Multiple topics matched
- conversation-init.topic.mcs.yml — JIT glossary/context on conversation start
- custom-knowledge-source.topic.mcs.yml — OnKnowledgeRequested custom API
- remove-citations.topic.mcs.yml — OnGeneratedResponse citation stripping

3. MANDATORY: Verify ALL kind values against schema before writing:
```bash
node "D:/my agents copilot studio/pipeline/scripts/schema-lookup.bundle.js" kinds
node "D:/my agents copilot studio/pipeline/scripts/schema-lookup.bundle.js" resolve <TriggerType>
node "D:/my agents copilot studio/pipeline/scripts/schema-lookup.bundle.js" search <ActionKind>
```
NEVER write a kind value you haven't verified exists. #1 hallucination source.

4. Determine trigger type:
- OnRecognizedIntent — user phrases (most common)
- OnConversationStart — welcome/greeting
- OnUnknownIntent — fallback
- OnEscalate — escalation to human
- OnError — error handling

5. Generate YAML with:
- # Name: comment at top
- kind: AdaptiveDialog
- Appropriate beginDialog with correct trigger
- Unique IDs for ALL nodes (format: <nodeType>_<6-8 random alphanumeric>)
- Replace ALL _REPLACE placeholders if using templates

6. Check settings.mcs.yml for GenerativeActionsEnabled

7. Save to agent's topics/<topic-name>.topic.mcs.yml

8. MANDATORY: Validate after saving:
```bash
node "D:/my agents copilot studio/pipeline/scripts/schema-lookup.bundle.js" validate <saved-file.yml>
```

## Generative Orchestration Guidelines
When GenerativeActionsEnabled: true:
- Use Topic Inputs (AutomaticTaskInput) instead of Question nodes
- Place inputs at AdaptiveDialog root level (NOT inside beginDialog)
- Use Topic Outputs instead of SendActivity for final results
- Include inputType/outputType schemas at root level

## Topic-Action Chaining
- Self-contained topic: output confirmation/status message
- Data-gathering topic for action: output the DATA itself, not confirmation
- Ask: does this topic complete the task, or prepare data for an action?

## Power Fx Quick Reference
- Expressions start with =
- String interpolation uses {}
- Common: Text(), Now(), IsBlank(), !IsBlank()
- Variable init: variable: init:Topic.MyVar
- Type coercion: use SetTextVariable for non-text types

## Card-Based Topic Pattern (Post-Session Documentation)

For topics that collect structured data via AdaptiveCard and generate notes:

```yaml
mcs.metadata:
  componentName: DISCIPLINE Note Type Card
kind: AdaptiveDialog
beginDialog:
  kind: OnRecognizedIntent
  id: main
  intent: {}
  actions:
    - kind: AdaptiveCardPrompt
      id: card_main
      card: |-
        { "type": "AdaptiveCard", ... }
      output:
        binding:
          fieldId: Topic.fieldName
      outputType:
        properties:
          fieldName: String

    - kind: SearchAndSummarizeContent
      id: gen_note
      userInput: "=Concatenate(\\"Generate a skilled DISCIPLINE NOTE_TYPE. SECTIONS - 1. Header 2. Diagnosis 3. Subjective 4. Objective 5. Assessment 6. Plan 7. Signature. Data: VAR \\", Text(Topic.var), \\".\\")"

    - kind: SendActivity
      id: draft_note
      activity: |-
        DRAFT - CLINICAL REVIEW REQUIRED

        {Topic.Answer}

    - kind: EndDialog
      id: end_note
      clearTopicQueue: true

inputType: {}
outputType: {}
```

**Key rules:**
- `intent: {}` — Card topics are only reachable via BeginDialog from a router
- SearchAndSummarizeContent userInput MUST be double-quoted (see YAML Quoting pitfall in common-pitfalls.md)
- Always EndDialog with clearTopicQueue: true
- Add AuditExistingNote BeginDialog before EndDialog for compliance review

See `therapy-fleet-agent-audit` skill `references/theradoc-workbench-card-generation-pattern.md` for full template with verified examples.

## Template Location
Templates are at: D:/my agents copilot studio/pipeline/templates/
Reference templates for each topic type when creating new topics.

## Skill Templates and References
This skill includes additional templates and references in its own directory:
- `templates/document-audit-topic.topic.mcs.yml` — Document compliance audit topic (Question → AnswerQuestionWithAI → SendActivity → EndDialog). Customize triggerQueries and additionalInstructions for your domain.
- `references/dataverse-botcomponent-api.md` — Dataverse API for creating/updating botcomponents programmatically via CDP/Playwright. Includes required fields (`schemaname`, `parentbotid@odata.bind`), error codes, and test set API limitations.
