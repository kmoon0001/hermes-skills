---
name: therapy-fleet-agent-audit
description: Full Copilot Studio Therapy AI Agents Dev audit and remediation workflow, adapted from Kiro .kiro/skills/full-agent-audit.md with hard environment guardrails, Microsoft Learn best practices, and sequential one-agent-at-a-time execution.
tags: [copilot-studio, therapy-ai-dev, audit, remediation, microsoft-learn, healthcare]
---

# Therapy Fleet Agent Audit

Reference for focused documentation-assistant audits: `references/theradoc-workbench-focused-documentation-audit.md` captures the TheraDoc Workbench lesson: verify the active agent vs legacy/deprovisioned names, frame PT/OT/SLP documentation assistants as click-button post-session note generators, audit entry points for old free-text/out-of-scope routes, and distinguish pasted-text processing from true OCR wiring.

Use this skill when auditing or remediating Copilot Studio agents in the Therapy AI Agents Dev environment.

Hard scope guard:
- Allowed environment only: `https://orgbd048f00.crm.dynamics.com`
- Allowed tenant: `03cc92c3-986c-4cf4-ae27-1478cf99d17f`
- Do not query, patch, publish, clone, push, pull, or otherwise touch Ensign Default / `org3353a370.crm.dynamics.com` while using this skill.
- If an existing Kiro/script helper points at `org3353a370`, do not run it as-is. Copy/adapt the logic to a temporary Therapy-only script or local-source audit.

## Required Companion Skills

Load these before running the workflow:
- `clinical-swarm-guardrails`
- `clinical-swarm-deployment`
- `copilot-studio-pipeline`
- `copilot-studio-validate`
- `copilot-studio-manage-agent`

## Microsoft Learn Grounding

Before authoring or changing audit rules, check Microsoft Learn for the current best-practice language. Minimum pages:
- Copilot Studio implementation overview
- Topic authoring best practices
- Trigger phrase best practices
- Agent instructions
- Responsible AI / Copilot Studio service card where clinical, legal, or high-impact actions are in scope

Audit rules based on current Learn guidance:
- Keep topics bite-sized and reusable; avoid overlapping intents.
- Use 5-10 varied, short, complete trigger phrases per NLU-triggered custom topic.
- Create disambiguation/slot-filling when topics overlap rather than allowing ambiguous routing.
- Agent instructions must be grounded in configured tools, knowledge sources, topics, agents, and variables; do not instruct the agent to use resources it does not have.
- Do not modify or suppress Microsoft citation behavior in instructions.
- In sensitive domains, define clear action boundaries, use approvals/HITL for consequential actions, ground outputs in trusted data, apply RBAC, test thoroughly, monitor, and iterate.

## Workflow: One Agent at a Time

For each Therapy AI Dev agent, complete all steps before starting the next agent.

1. Context pass
   - Read `agent.mcs.yml`, topics, actions, knowledge, and any local README/spec files for that agent.
   - Identify the agent's role in the swarm: hub/orchestrator, dashboard, specialist, compliance, regulatory, meeting support, or synthesis.
   - **Purpose alignment (CRITICAL — do this BEFORE topic-level analysis):** Ask the user (or infer from AGENT.md/agent.mcs.yml description) what the agent's CORE FUNCTION is. Write a one-sentence purpose statement. Then classify every topic as ALIGNED (matches core function), PARTIALLY ALIGNED (could help but needs trimming), MISALIGNED (contradicts the function or is out of scope), or ORPHAN (never reached). Present this classification to the user for confirmation BEFORE deep-diving into individual topic YAML. Getting this wrong wastes the entire audit — Kevin corrected this on TheraDoc (Jun 30 2026) when the audit initially treated a focused post-session documentation assistant as a general-purpose workbench.
   - Confirm expected bot ID against the Therapy AI Dev registry before any live call.

2. Discovery
   - Prefer local source audit first.
   - If live state is needed, query only `https://orgbd048f00.crm.dynamics.com/api/data/v9.2` with `_parentbotid_value eq '<botId>'`.
   - Categorize components: 9 topics/connections, 14 file knowledge, 15 GPT metadata, 16 web/SharePoint knowledge, 19 trigger phrases.

3. Audit dimensions
   - Overview: name, description, role clarity, icon metadata if available.
   - Instructions: size, duplicate section headers, corruption, contradictory JSON/prose mandates, unsupported citation manipulation, missing healthcare guardrails.
   - Knowledge: source names/descriptions, duplicate/redundant sources, web browsing fit, configured resources matching instructions.
   - Tools/actions/flows: orphan references, missing flow IDs, action descriptions, safe boundaries, HITL for consequential clinical output.
   - Topics: YAML validity, system-topic skip, trigger phrase count/quality/overlap, EndDialog/clearTopicQueue, SearchAndSummarize settings, unsupported SearchSpecificFiles/SearchAllKnowledgeSources, oversized additionalInstructions, orphan Question nodes.
   - **Routing integrity (added Jun 30 2026):** Trace every BeginDialog reference to confirm the target topic exists. Flag duplicate routers (two topics routing to the same discipline/note-type matrix with different targets). Flag Card topics that collect data via AdaptiveCard but have no SearchAndSummarizeContent, no flow invocation, and no EndDialog — these are data sinks that produce no output.
   - **Orphan topic detection (added Jun 30 2026):** For each custom topic, check if it is reachable via (a) trigger phrases (NLU), (b) BeginDialog from another topic, or (c) the router's routing matrix. Topics unreachable by any path are orphans — verify whether they're dead code or should be wired in.
   - **Card-vs-Intake gap (added Jun 30 2026):** When a discipline has both a `*Card` topic (AdaptiveCard data collection) and an `*Intake` topic (Question nodes + SearchAndSummarizeContent), verify the Card topic actually generates output. Pattern: Card topics often collect rich data but lack note generation; Intake topics collect minimal data but generate notes. Route to the one that works.
   - **Duplicate condition detection:** Flag ConditionGroups with empty actions (conditions that check values but do nothing). Flag duplicate conditions (same condition appearing twice in one group).
   - Settings: moderation, authentication/access assumptions, web/code interpreter settings where represented in source.
   - Evaluation readiness: test set coverage, single-response and conversational scenarios, no missing-document eval design errors.

4. Fix priority
   - Security/compliance/HIPAA defects.
   - Environment and settings misalignment.
   - Broken topic/action YAML that blocks validation or publish.
   - Routing/trigger overlap and topic proliferation.
   - Knowledge configuration defects.
   - Instruction compression/corruption cleanup last.

5. Safe local fixes
   - Strip BOM and CR corruption only on custom, customizable components; do not patch system topics or inactive/deprovisioned managed agents for cosmetic line-ending cleanup.
   - Remove contradictory instruction text when the intended format is clear from the agent role.
   - Add or normalize `clearTopicQueue: true` on custom-topic `EndDialog` nodes.
   - Remove invalid `SearchAllKnowledgeSources` / `SearchSpecificFiles` patterns when local schema/tests confirm they are unsupported.
   - Keep system topics untouched unless only reading them. System-topic CR/BOM differences are report-only unless they block validation and the user explicitly approves UI repair.

6. Live fixes
   - Back up exact live records first.
   - Treat Copilot Studio UI as source of truth and prefer UI/CDP evidence before and after any live draft repair.
   - Do not assume `content` and `data` have identical server-side semantics. Inspect the live component, normalize local exported topic files to the `kind: AdaptiveDialog` body, and use the supported authenticated path for the current session. See `references/copilot-studio-live-yaml-repair.md` for the Playwright/CDP + Dataverse-origin decision ladder.
   - `content` field PATCH is blocked by a server-side validator for topics with complex YAML (e.g., `InvokeFlowAction`, adaptive expressions, multi-line actions). When the live UI editor shows changed content but the scanner still flags `content` as broken because it reads the old/cached `content`, the fix is to PATCH `data` with the corrected body from the UI-visible source, then update the QA scanner to prefer `data` over `content` for topic parse checks. See `references/copilot-studio-live-yaml-repair.md` section "`data`-field-only repair pattern (Jun 30, 2026)".
   - Do not publish without explicit user approval. Publishing affects shared users.

7. Verification
   - Run local schema/lint/test validation after edits.
   - For `pipeline/scripts/schema-lookup.bundle.js validate`, validate dialog-like source only (`agent.mcs.yml`, `actions/*.mcs.yml`, `topics/*.mcs.yml`) and exclude `settings.mcs.yml`, `connectionreferences.mcs.yml`, knowledge files, scratch/export/log folders; otherwise the validator reports false `No kind property` failures on non-dialog components.
   - If `InvokeAction` appears in topic action lists and schema validation fails, convert to `InvokeFlowAction` only after confirming the node carries an `action:` reference and re-validating that file.
   - When helper/repair scripts are changed and no canonical suite exists, use the ad-hoc tempfile verifier pattern from `copilot-studio-validate` (`references/ad-hoc-verification-after-repair-scripts.md`): syntax-check scripts, run dry-runs without `--apply`, verify Therapy-only scope guards, validate active dialog-like files, clean up the temp verifier, and report as ad-hoc verification rather than suite green. If a fresh verification reminder appears after a prior verifier, rerun a new temp verifier; do not cite stale evidence.
   - For live Dataverse repair scripts, include safety checks for: explicit Therapy AI Dev URL, explicit Ensign Default block guard, no Ensign Default HTTPS target literal, `--apply` required for writes, null/missing component-name-safe filename handling, and a material-change filter that avoids live PATCHes for cosmetic CR/BOM-only normalization.
   - After live `--apply`, immediately rerun the script without `--apply` and require `PATCHED=0`, `PATCH_ERROR=0`, and no remaining `WOULD_PATCH` lines before reporting the safe auto-fix pass complete. Remaining `UNFIXED` lines should be called out as deeper targeted repairs, not hidden as green.
   - When Kevin says the live UI is the source of truth, do not stop at Dataverse/API evidence. Verify both the live Dataverse backing records and at least one representative Copilot Studio UI page/screenshot under Therapy AI Dev. Use `references/live-ui-source-of-truth-verification.md`.
   - For broad fleet QA/checklist/autonomous-loop requests, use `references/autonomous-qa-loop-checklist.md`: create a read-only Therapy-only scanner/checklist first, seed the backlog from live records plus known remaining blockers, require visual UI tab evidence for every agent, then iterate repairs and draft evaluations until each agent exceeds 95% on Single Response and Conversational testing.
   - For local-source-only remediation batches before live/UI repair, use `references/local-safe-repair-batches.md`: prioritize safe `agent.mcs.yml` metadata fixes such as conversation starters, orchestration/routing language, and healthcare/HITL/disclaimer guardrails; validate each file, rerun the read-only scanner, and report pre/post backlog counts without implying live or published behavior changed.
   - Distinguish local source, live draft/source UI, and published-agent behavior. Do not imply published users see a change unless publish was explicitly approved and run.
   - If `manage-agent validate` has `.mcs/conn.json`, run it against Therapy env only.
   - Record fixed issues, remaining manual/UI-only fixes, live UI/source verification evidence, and validation output in a timestamped report.

## Therapy AI Dev Registry

Environment: `https://orgbd048f00.crm.dynamics.com`
Tenant: `03cc92c3-986c-4cf4-ae27-1478cf99d17f`

Core swarm agents (verified live via `pac copilot list` Jun 30 2026):
- SNF Command Center V2 — `9f3e370c-a747-f111-bec6-0022480b6bd9` — Orchestrator Hub
- SNF AI Dashboard V2 — `bd570423-cf47-f111-bec5-70a8a5b1c3a3` — Data Visualization
- TheraDoc Workbench — `e09954e1-4af8-47c6-8ef4-d1d9335bf2e6` — Post-session PT/OT/SLP documentation assistant (click buttons to capture session data with minimal typing, AI generates polished clinical note). Local workspace: `D:/my agents copilot studio/TheraDoc/`
- Pacific Coast Case Historian — `ad635500-cf47-f111-bec5-70a8a5b1c3a3` — Longitudinal Analysis
- Pacific Coast QM Coach V2 — `ea52ad9c-8233-f111-88b3-6045bd09a824` — Quality Measures
  (live name differs from registry: "Pacific Coast QM Coach V2" not "SimpleLTC QM Coach V2")
- Pacific Coast Denial Defense V2 — `6d7815b4-ce47-f111-bec5-70a8a5b1c3a3` — Denial Management
- Therapy Report Prep V2 — `fd1bce12-cf47-f111-bec5-70a8a5b1c3a3` — Report Generation
- Pacific Coast Compliance Analyzer — `19779839-7b6e-4362-925b-8ddf03979f7d` — Compliance Audit
- Pacific-Coast Regulatory Hub V2 — `ea901efc-d043-4023-88a6-8ac4c561a4d5` — Regulatory Reference
- PacCoast Daily + Weekly Medicare Meeting — `ee72fe1a-0882-4dec-9959-ace1fbb74280` — Meeting Support
- Pacific-Coast Clinical Synthesis Lab V2 — `89c7415d-df73-490c-9d78-4829cfbc2f84` — Clinical Synthesis
- POSTette_Compliance_Agent — `03b08692-aa24-4159-986b-cfad8fed6865` — Compliance (NEW, not in original registry)
- CoE Autonomous Agent Builder — `8f33b0e3-5b2e-f111-88b3-00224806baad` — Utility (NEW)
- Meta-Agent Builder — `4e00c251-3941-f111-88b3-70a8a59a9512` — Utility (NEW)

Note: PT_Specialist, OT_Specialist, SLP_Specialist bot IDs from the original clinical guardrails
are NOT visible via `pac copilot list` — they may be managed/imported agents or have been
deprovisioned. Verify before making live API calls against those IDs.

## Scope Cleanup Workflow (added Jun 30 2026)

When an agent has topics misaligned with its core purpose:

1. **Classify every topic** as ALIGNED / PARTIALLY ALIGNED / MISALIGNED / ORPHAN during the purpose alignment step.
2. **Create a removal manifest** (`REMOVAL_MANIFEST.txt`) listing topics to remove, grouped by reason (out-of-scope, replaced by Cards, shared topics replaced by discipline-specific ones).
3. **Do NOT delete files locally** — the manifest is a guide for live agent cleanup via Copilot Studio UI or Dataverse API. Local files stay until the user explicitly removes them.
4. **Create replacement topics** (Card-based) before marking Intake topics for removal, so the routing matrix has valid targets.
5. **Update the router** to point to new Card topics and remove out-of-scope utility actions.

Example: TheraDoc had 56 custom topics. After scope cleanup: 27 kept (10 core + 17 Cards), 35 marked for removal, 13 system unchanged.

## References

- `references/live-dataverse-repair-safety.md` — safety and verification pattern for live Dataverse YAML repair scripts, including null component names, cosmetic CR/BOM skip logic, and post-apply dry-run checks.
- `references/live-ui-source-of-truth-verification.md` — two-layer verification pattern when the live Copilot Studio UI is the source of truth: Dataverse backing record checks plus browser/CDP UI screenshot evidence, with draft-vs-published wording.
- `references/autonomous-qa-loop-checklist.md` — class-level pattern for creating a read-only Therapy AI Dev fleet checklist/scanner, seeding a backlog from live records, enforcing visual UI evidence across Overview/Settings/Knowledge/Tools/Agents/Topics/Evaluation, and looping repairs/evals until each agent is >95% Single Response and Conversational.
- `references/copilot-studio-live-yaml-repair.md` — Playwright/CDP live YAML repair decision ladder: correct environment ID vs tenant default URLs, multiple Copilot Studio `More` buttons, code-editor click no-op fallback, Dataverse-origin authentication, topic-body normalization from `kind: AdaptiveDialog`, and no-publish verification evidence.
- `references/theradoc-workbench-audit-2026-06-30.md` — TheraDoc Workbench full audit: 56 topics, routing integrity gaps (duplicate routers, Card-vs-Intake data sinks, 12+ orphan topics), missing OCR topic, remediation priority list, knowledge/action inventory.

## Output
## TheraDoc Workbench Specifics (2026-06-30)

Bot ID: `e09954e1-4af8-47c6-8ef4-d1d9335bf2e6`
Purpose: Post-session PT/OT/SLP documentation with click-button capture (AdaptiveCards), minimal typing, AI-generated notes.

### Architecture Pattern (Card-based documentation)
The correct flow is: AdaptiveCard (click buttons) → SearchAndSummarizeContent (generate note from card data) → SendActivity (show DRAFT) → BeginDialog → AuditExistingNote → EndDialog with clearTopicQueue: true.

Topics that collect data via AdaptiveCard but have NO generation are broken dead-ends. The original agent had 7 Card topics with no generation — all needed SearchAndSummarizeContent added.

### Key Findings from Full Audit
- 56 custom topics analyzed; 35 were out-of-scope or misaligned (too many free-text questions)
- Clean set: 27 custom + 13 system = 40 topics
- 10 new Card topics created (Progress/Recert/Discharge for PT/OT/SLP + ST Daily)
- NoteIntakeRouter simplified to 2-step flow: Note Type → Discipline → Card
- Out-of-scope topics: CrossDisciplineConflictAuditor, EHRFinalizerGateway, SignificantChangeDetector, GoalBank, SkilledJustification, PlanOfCare, NursingHandoff, DoREmail, etc.
- Misaligned topics: All Intake topics with 10-28 free-text Question nodes (replaced by Card approach)

### Topic Naming Convention
Card topics: `{Discipline}{NoteType}Card.mcs.yml` (e.g., PTDailyNoteCard.mcs.yml)
All Card topics follow identical structure: AdaptiveCardPrompt → SearchAndSummarizeContent → SendActivity → BeginDialog(AuditExistingNote) → EndDialog(clearTopicQueue:true)

### Push Method
manage-agent push fails (LSP binary `vscode-jsonrpc/node` not available). Use CDP batch-patch via Kiro Chrome instead — see copilot-studio-pipeline skill for `cdp_patch_topics.cjs` pattern.

## Output
Create a timestamped markdown/JSON report under the project audit-results folder with:
- Agent-by-agent context summary
- Findings by severity and category
- Fixes applied
- Remaining manual/UI-only fixes
- Validation commands and real outputs
- Confirmation that Ensign Default was not touched
