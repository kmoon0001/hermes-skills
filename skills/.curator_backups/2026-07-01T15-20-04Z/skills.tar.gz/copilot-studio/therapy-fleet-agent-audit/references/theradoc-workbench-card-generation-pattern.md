# TheraDoc Card → Generation → Audit Pattern

## Purpose
Post-session documentation assistant for PT/OT/SLP using click buttons (AdaptiveCards) with minimal typing.

## Core Flow
```
User says "document today"
  → NoteIntakeRouter (discipline + note type selection)
  → Card Topic (AdaptiveCard with click buttons)
    → SearchAndSummarizeContent (generates note from card data)
    → SendActivity (shows DRAFT with review instructions)
    → BeginDialog → AuditExistingNote (compliance check)
    → EndDialog with clearTopicQueue: true
```

## Card Topic Template

After AdaptiveCardPrompt outputType, add:

```yaml
    # --- STEP 2: Generate NOTE_TYPE from Card Data ---
    - kind: SearchAndSummarizeContent
      id: gen_discipline_noteType
      userInput: "=Concatenate(\\"Generate a skilled DISCIPLINE NOTE_TYPE. SECTIONS - 1. Header 2. Diagnosis 3. Subjective 4. Objective 5. Assessment with skilled justification 6. Plan 7. Signature. Use only provided data. Clean plain text. VAR1 \\", Text(Topic.var1), \\" VAR2 \\", Text(Topic.var2), \\".\\")"

    - kind: SendActivity
      id: draft_discipline_noteType
      activity: |-
        DRAFT - CLINICAL REVIEW REQUIRED

        {Topic.Answer}

        Review before EHR entry. Say audit for compliance check.

    - kind: BeginDialog
      id: audit_discipline_noteType
      input:
        binding:
          incomingDiscipline: ="DISCIPLINE"
          incomingDocumentType: ="NOTE_TYPE"
      dialog: pcca_theradocworkbench.topic.AuditExistingNote

    - kind: EndDialog
      id: end_discipline_noteType
      clearTopicQueue: true
```

## YAML Quoting Pitfall

SearchAndSummarizeContent `userInput` with `Concatenate()` containing colons or braces MUST use double-quoted string with escaped inner quotes:

```yaml
userInput: "=Concatenate(\\"text with colons: item 1\\", Text(Topic.var), \\"more text\\")"
```

NOT:
```yaml
userInput: =Concatenate("text with colons: item 1", Text(Topic.var), "more text")
```

The unquoted form breaks YAML parsing because colons and braces are YAML-special characters.

## Verified Working Topics (Jun 30 2026)

### Fixed Cards (existing — added generation)
| Topic | Discipline | Note Type | Card Fields |
|-------|-----------|-----------|-------------|
| PTDailyNoteCard | PT | Daily Note | 15 fields |
| OTDailyNoteCard | OT | Daily Note | 12 fields |
| SLPDailyNoteCard | SLP | Daily Note | 13 fields |
| PTEvaluationCard | PT | Evaluation | 18 fields |
| OTEvaluationCard | OT | Evaluation | 13 fields |
| SLPEvaluationCard | SLP | Evaluation | 13 fields |
| RecertificationDischargeCard | Shared | Recert | 10 fields |

### New Cards (created Jun 30 2026)
| Topic | Discipline | Note Type | Card Fields |
|-------|-----------|-----------|-------------|
| PTProgressNoteCard | PT | Progress | 8 fields (date, task, assist, goal progress, pain, notes, justification, therapist) |
| PTRecertCard | PT | Recertification | 7 fields (date, skilled need, goals, rehab potential, justification, modified POC, therapist) |
| PTDischargeCard | PT | Discharge | 7 fields (date, reason, functional status, HEP, disposition, safety, therapist) |
| OTProgressNoteCard | OT | Progress | 9 fields (date, task, assist, goal, pain, cognitive, notes, justification, therapist) |
| OTRecertCard | OT | Recertification | 7 fields (same pattern as PT) |
| OTDischargeCard | OT | Discharge | 7 fields (date, reason, status, caregiver, disposition, recommendations, therapist) |
| SLPProgressNoteCard | SLP | Progress | 9 fields (date, focus, diet, cueing, accuracy, goal, notes, justification, therapist) |
| SLPRecertCard | SLP | Recertification | 7 fields (same pattern as PT) |
| SLPDischargeCard | SLP | Discharge | 7 fields (date, reason, diet, HEP, caregiver, recs, therapist) |
| STDailyNoteCard | ST | Daily Note | 8 fields (date, focus, diet, cueing, accuracy, notes, justification, therapist) |

### Total: 17 Card topics covering Daily/Eval/Progress/Recert/Discharge for PT/OT/SLP + Daily for ST
