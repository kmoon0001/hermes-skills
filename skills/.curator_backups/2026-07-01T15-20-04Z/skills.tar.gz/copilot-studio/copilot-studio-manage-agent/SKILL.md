---
name: copilot-studio-manage-agent
description: Push, pull, clone, publish, and validate Copilot Studio agent content via manage-agent.bundle.js LSP binary.
tags: [copilot-studio, dataverse, push, pull, clone, publish, validate]
---

# Manage Agent

Push, pull, clone, publish, and validate Copilot Studio agent content via the VS Code extension's LanguageServerHost LSP binary.

## IMPORTANT: Do Not Modify Scripts
manage-agent scripts are pre-built bundles. If script fails:
1. Report error as-is
2. Do not attempt to fix
3. Direct user to https://github.com/microsoft/skills-for-copilot-studio/issues
4. Suggest VS Code extension as fallback

## Prerequisites
1. Copilot Studio VS Code extension installed (ms-copilotstudio.vscode-copilotstudio)
2. Environment details from .mcs/conn.json (tenant ID, environment ID, environment URL, agent management URL)

## Auth
Two auth flows:
- Push/pull/clone/changes/list-agents: interactive browser login, tokens cached 90 days
- Auth command: device code flow for chat/test token

No separate auth step needed before push/pull. Commands handle token acquisition automatically.

## Commands

### Pull (download remote changes)
```bash
node "D:/my agents copilot studio/pipeline/scripts/manage-agent.bundle.js" pull --workspace <path> --tenant-id <id> --environment-id <id> --environment-url <url> --agent-mgmt-url <url>
```

### Push (upload local changes)
ALWAYS pull before push to get fresh row versions (avoids ConcurrencyVersionMismatch).
Push auto-validates all .mcs.yml files before pushing. Add --force to bypass (not recommended).
```bash
node "D:/my agents copilot studio/pipeline/scripts/manage-agent.bundle.js" push --workspace <path> --tenant-id <id> --environment-id <id> --environment-url <url> --agent-mgmt-url <url>
```

### Clone (download agent to new local folder)
Requires --agent-id or --url. Uses Island API token automatically.
With URL (recommended):
```bash
node "D:/my agents copilot studio/pipeline/scripts/manage-agent.bundle.js" clone --workspace <path> --tenant-id <id> --url <copilotStudioUrl>
```

### Validate (check YAML before pushing)
Validates all .mcs.yml files using LSP binary's full diagnostics.
```bash
node "D:/my agents copilot studio/pipeline/scripts/manage-agent.bundle.js" validate --workspace <path> --tenant-id <id> --environment-id <id> --environment-url <url> --agent-mgmt-url <url>
```
Returns JSON: { valid: true|false, summary: { errors: N, warnings: N }, files: [...] }

### Publish (make draft agent live)
Uses Dataverse PvaPublish bound action directly (no LSP binary needed).
ALWAYS confirm with user before publishing (makes agent live for all shared users).
```bash
node "D:/my agents copilot studio/pipeline/scripts/manage-agent.bundle.js" publish --workspace <path> --tenant-id <id> --environment-url <url> [--timeout <ms>]
```
Timeout: 300000ms (5 minutes).

### List Agents
```bash
node "D:/my agents copilot studio/pipeline/scripts/manage-agent.bundle.js" list-agents --tenant-id <id> --environment-url <url> [--no-owner]
```

### List Environments
```bash
node "D:/my agents copilot studio/pipeline/scripts/manage-agent.bundle.js" list-envs --tenant-id <id>
```

## Direct Dataverse repair fallback

If the user cannot complete the Copilot Studio API/LSP interactive login but `pac`/Azure auth can access the Dataverse environment, use the targeted Dataverse `botcomponents` repair workflow instead of repeatedly asking the user to sign in.

See `references/dataverse-data-only-topic-repair.md` for the tested pattern.

**PITFALL: `pac org fetch` crashes on `botcomponents` entity (pac CLI v2.7.4+).** Any FetchXML query against `botcomponents` causes a .NET stack overflow regardless of filter, page size, or attributes. Use the Dataverse REST API directly via `auth_helper.cjs` + `fetch()` instead. The `bot` entity works fine with `pac org fetch`.

Key rules:
- Query `botcomponents` with `_parentbotid_value eq '<botId>' and componenttype eq 9` and back up exact live records before patching.
- Prefer minimal `data` field patches for YAML/metadata repairs; avoid whole-record replacement.
- Be careful with `content`: it may contain a leading `# Topic Name` header and PATCHing it can fail with `Unexpected character encountered while parsing value: #`. If that happens, patch only `data` and verify by re-querying.
- Publish afterward with `pac copilot publish --environment <orgUrl> --bot <botId>`.
- Verify with `pac copilot list --environment <orgUrl>` if `pac copilot status` fails.

## Error Handling
| Error | Cause | Resolution |
| Extension not found | VS Code extension not installed | Install from marketplace |
| ConcurrencyVersionMismatch | Push without fresh versions | Pull first, then push |
| Token expired + refresh failed | Refresh token expired (~90 days) | Re-auth |
| PvaPublish failed | Insufficient permissions | Verify publish permissions |
| `Cannot find module 'vscode-jsonrpc/node'` during LSP validate | Local VS Code extension/runtime dependency not available to the bundle | Do a local YAML syntax sanity check, then use direct Dataverse repair only for targeted fixes; do not edit bundled scripts |
| Dataverse PATCH says `Unexpected character encountered while parsing value: #` | Attempted to PATCH a field containing a leading Markdown/header line, commonly `content` | Stop whole-record/content patch attempts; patch only the minimal `data` field change and verify by re-querying |
| `pac copilot status` complains about `componentstate_Property` | PAC status-command quirk in some tenants/CLI versions | Use successful publish output plus `pac copilot list --environment <orgUrl>` to verify Published/Active state |

## Output Format
All commands output JSON with status field. status: "ok" for success, status: "error" for failure.
