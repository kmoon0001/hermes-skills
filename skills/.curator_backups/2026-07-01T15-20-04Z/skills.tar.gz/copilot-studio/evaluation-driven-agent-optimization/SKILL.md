---
name: evaluation-driven-agent-optimization
description: "Looping workflow to optimize Copilot Studio agents: analyze → plan → fix → review → re-review → loop until >95% SR and Conv. Based on Microsoft Learn evaluation triage framework."
version: 1.0.0
author: Hermes Agent
tags: [copilot-studio, evaluation, optimization, loop, microsoft-learn]
---

# Evaluation-Driven Agent Optimization Loop

Systematic workflow to push Copilot Studio agents above 95% on both Single Response and Conversation evaluations. Based on Microsoft Learn evaluation triage framework.

## The Loop

```
┌──────────────────────────────────────────────────────────────┐
│                    OPTIMIZATION LOOP v2                       │
│                                                               │
│  LAYER 0: FREEZE BASELINE                                     │
│  ├─ 0a. Check publish timestamp (stale evidence guard)        │
│  └─ 0b. If agent republished after last eval → RE-RUN first   │
│                                                               │
│  LAYER 1: SINGLE AGENT OPTIMIZATION (existing)                │
│  ├─ 1. CONTEXT  → Load scores, agent config                   │
│  ├─ 2. ANALYZE  → Root cause from failures                    │
│  ├─ 3. PLAN     → MS Learn checklist + fixes                  │
│  ├─ 4. EXECUTE  → Apply fixes via Playwright                  │
│  ├─ 5. TEST     → Trigger ONE eval type (SR or Conv)          │
│  ├─ 6. REVIEW   → Compare to baseline                         │
│  └─ 7. DECIDE   → Loop or done                                │
│                                                               │
│  LAYER 2: ORCHESTRATION TESTING (TDA plan)                    │
│  ├─ End-to-end routing: PT/OT/SLP classification              │
│  ├─ Multi-discipline contradiction scan                       │
│  ├─ Part A SNF / Part B outpatient paths                      │
│  ├─ No-document fallback behavior                             │
│  ├─ Placeholder-citation regression                           │
│  └─ PHI-safe guidance                                        │
│                                                               │
│  LAYER 3: PRODUCTION READINESS (TDA plan)                     │
│  ├─ Live/source alignment export                              │
│  ├─ Duplicate agent cleanup                                   │
│  ├─ ALM: solutions, env vars, connection refs                 │
│  └─ Rollback: known-good restore path                         │
└──────────────────────────────────────────────────────────────┘
```

## Layer 0: FREEZE BASELINE (NEW — from TDA plan)

Before analyzing ANY failures, check if the evidence is stale.

```
IF last eval date < last publish date:
  → STALE EVIDENCE. Re-run evaluation first.
  → Never diagnose stale failures as current truth.

IF last eval date >= last publish date:
  → FRESH EVIDENCE. Proceed to analyze.
```

**Why this matters:** The OT June 13 eval showing 91% was run BEFORE the June 14-15 publishes. Those failures (cite:1, Citation-1) were already fixed in the published instructions. We were chasing ghosts.

## Microsoft Learn Triage Order (updated)

From both MS Learn and the TDA plan, the correct triage order is:

1. **Infrastructure health** — Is the platform healthy? Agent published? Connected?
2. **Evaluation quality** — Is the response acceptable but the grader failed? Fix the test.
3. **Expected answer stale** — Is the expected answer wrong? Fix the test.
| **Agent behavior** — Does the agent actually behave wrong? Fix the agent config.
5. **Platform limitation** — Can't be fixed by config? Document and escalate.

**⚠️ Anti-Hedging Balance Rule:** Removing hedging is correct, but the replacement instruction must NOT tell the model to fabricate. "Write as if you have the document" causes fabricated scores/findings → grader detects as inaccurate → SR regresses. Instead: "Provide authoritative compliance guidance per standards. Do not fabricate specific findings for unseen documents." See `copilot-studio-instructions-editor` pitfall 23b.

## ⚠️ CRITICAL: Never Blame the Platform Without Evidence

When eval scores drop, the FIRST instinct should be to investigate topic content, NOT to blame the platform/model/system. The user explicitly corrected this pattern:

> "theres a root cause. even with my other agents, you said it was a platform or system thing but it was erroring because it was broken guard topics and broken logic"

**The correct diagnostic sequence is:**
1. Dump ALL topic content via Dataverse API (`componenttype eq 9`)
2. Check EVERY topic for: `kind: Question` nodes, `buttons:` (interactive menus), missing `EndDialog`, `SearchAndSummarizeContent` issues
3. Map eval test cases to topics — find which topics handle which questions
4. ONLY AFTER confirming all topics are clean → consider platform/model causes

**Common topic-level root causes (check BEFORE blaming platform):**
- Question nodes in topics → agent asks questions instead of answering → eval fails
- AdaptiveCard/menu topics → agent returns interactive card instead of text → eval fails
- Empty/stub topics → agent returns unhelpful response → eval fails
- Broken action references → agent hits system error → eval fails

## Step 0: SESSION RECOVERY — Reconstruct Multi-Session State

When starting a NEW session on a long-running optimization project (multiple prior sessions across days), reconstruct state BEFORE entering the optimization loop. Don't ask the user to repeat context — pull it programmatically.

### Recovery Workflow

```
1. BROWSE recent sessions (session_search with no args)
   → Identify which sessions are related to this project

2. DISCOVER by topic (session_search with query)
   → Search for agent names, "evaluation", "score", "fix", "regression"
   → Use limit=5-10 since optimization work spans multiple sessions

3. READ key sessions (session_search with session_id)
   → Get first 20 + last 10 messages for each relevant session
   → Focus on: what was fixed, what scores were achieved, what's pending

4. SCROLL into specifics (session_search with session_id + around_message_id)
   → When a session mentions score tables, fix attempts, or regression analysis
     that got truncated, scroll to the specific message IDs mentioned

5. SYNTHESIZE into a status table before entering the loop
```

### Status Table Template

After recovery, present the user with this format BEFORE entering the loop:

```
=== CURRENT SCORES + 3-RUN AVERAGES ===

           SR (3-run avg)    Conv (3-run avg)    Latest
OT:        98% (99/96/100)   98% (95/100/100)     95% Conv
PT:        88% (88/94/82)    77% (90/85/55)       88% SR
SLP:       92% (90/94/-)     80% (75/80/85)       75% Conv
TDA:       83% (91/85/73)    95% (100/95/90)     100% Conv

=== WHAT WENT WRONG (summary of regressions) ===
1. [Root cause 1] — [evidence]
2. [Root cause 2] — [evidence]

=== WHAT NEEDS TO HAPPEN ===
1. [Priority action 1]
2. [Priority action 2]
```

### Key Recovery Signals to Extract

- **Last known scores** per agent per test type
- **What changes were made** since last stable baseline
- **Which changes caused regressions** and by how much
- **What files are ready** for paste (instruction files, topic YAMLs)
- **What's blocked** (auth expired, SPA issues, rate limits)
- **User preferences** expressed in prior sessions (file-only delivery, manual paste, etc.)

### Pitfall: Don't Re-Diagnose from Stale Session Data

Session history shows WHAT was done, but the LIVE scores may have changed since. After recovery, always pull fresh scores (Step 1) before entering the loop. Session data establishes context; live data drives decisions.

## Step 1: CONTEXT — Load Current State

**⚠️ STALE EVIDENCE CHECK FIRST** (from TDA plan):

```bash
# For each agent, check:
# 1. Last publish timestamp (from Overview page)
# 2. Last evaluation timestamp (from Evaluation page)
# 3. If eval date < publish date → STALE. Re-run eval before diagnosing.
```

**What to collect:**
- Latest SR and Conv scores for each agent
- Score trend (improving, stable, regressing)
- **Last publish timestamp** (critical — do not diagnose stale failures)
- **Last evaluation timestamp** (critical — must be AFTER last publish)
- **Agent model status** — check Overview page for "Your selected agent model was retired" text. Model changes cause 5-15% score swings.
- **Agent model currently selected** — Open Overview page and look for "GPT-5 Chat" or other model name near "Select your agent's model". The active model is displayed on the overview page, not in a popup.
- Last known fixes applied
- **Duplicate agent detection** — `TDA_v2_MultiDiscipline`, `Therapy_Report_Prep_Assistant` may confuse tests
- Any test set modifications

### Model Retirement Detection (CRITICAL)

When you see this text on any agent's Overview page:
```
Your selected agent model was retired, so we updated your agent to use another model.
```
This is a **shared root cause** that explains simultaneous Conv regression across ALL agents. Model changes cause 5-15% score variance. Do NOT diagnose individual topics or instructions when this signal is present — the model behavior change affects everything.

**Detection via Playwright/CDP:**
```javascript
const text = await page.evaluate(() => document.body.innerText);
const modelRetired = text.indexOf('was retired') >= 0;
```

**Remediation:** First re-run evals after model change to establish new baseline. Only investigate and fix failures that persist beyond the new baseline. Do not make topic/instruction changes before re-baselining.

### Inactive Guard Topic Detection (NEW — Highest Priority Check)

**⚠️ Check this BEFORE any YAML or instruction analysis.** Inactivated exact-match intake topics (Eval Guards, * Intake, Conv Guard) are the #1 Conv score killer. When >25% of topics are inactive, test case queries fall through to generic generative AI, producing ungraded responses.

**Detection via Dataverse API:**
```javascript
const allUrl = `/api/data/v9.2/botcomponents?$select=name,statecode&$filter=_parentbotid_value eq '${botId}' and componenttype eq 9&$top=50`;
const all = await (await fetch(allUrl, { credentials: 'include' })).json();
const inactive = all.value.filter(t => t.statecode === 1);
```

**Fix — Batch activation via PATCH:**
```javascript
for (const topic of inactive) {
  await fetch(`/api/data/v9.2/botcomponents(${topic.botcomponentid})`, {
    method: 'PATCH', credentials: 'include',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ statecode: 0 })
  });
}
```

**Evidence:** PT had 16/31 topics inactive (52%), Conv 74%. Activating all 16 pushed Conv to 95%.

### Dataverse API Topic Creation Pitfalls

**⚠️ Topics created via Dataverse API POST are INVISIBLE in Copilot Studio UI unless `data` field is set.**

When creating topics via `POST /api/data/v9.2/botcomponents`, the response returns 204 (success) and the topic exists in Dataverse. But it will NOT appear in the Copilot Studio UI's topic list because the `data` field is null.

**Fix:** After creating the topic, PATCH the `data` field with content (can be the same as `content` field, or a minimal shell):
```javascript
// After POST creates the topic, PATCH data field:
await fetch(url, {
  method: 'PATCH',
  credentials: 'include',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ data: yamlContent })
});
```

**Verification:** After PATCH, confirm `data` field is not null:
```javascript
const resp = await fetch(url, { credentials: 'include', headers: { 'Accept': 'application/json' } });
const data = await resp.json();
// data.data should not be null/empty
```

**⚠️ Dataverse API PATCH `content` field is REJECTED with 400 error.**

When trying to replace a topic's `content` field via `PATCH /api/data/v9.2/botcomponents(id)`, the API returns 400 with:
```
"Unexpected character encountered while parsing value: k. Path '', line 0, position 0."
```

This happens because the API's JSON parser tries to parse the YAML content as JSON (the 'k' is from 'kind:'). The cause is unclear — the same format works for some topics but not others. Possible factors:
- Topics created via UI have different internal metadata
- The `content` field may have validation rules that differ by topic
- The API may require the content to be in a specific envelope format

**Workaround:** Use Monaco editor injection via `document.execCommand('insertText')` instead of the Dataverse API. See Monaco injection section below.

### Monaco Editor Injection via execCommand

**⚠️ Clipboard paste (`navigator.clipboard.writeText` + Ctrl+V) does NOT work in Monaco editor.**

The reliable injection method is `document.execCommand('insertText')`:

```javascript
// 1. Focus the Monaco editor textarea
const textarea = document.querySelector('.monaco-editor textarea');
if (textarea) textarea.focus();

// 2. Select all content
await page.keyboard.press('Control+a');
await new Promise(r => setTimeout(r, 500));

// 3. Insert new content via execCommand
const result = document.execCommand('insertText', false, yamlContent);
// result === true means success

// 4. Trigger dirty state (Space + Backspace)
await page.keyboard.press('Space');
await new Promise(r => setTimeout(r, 200));
await page.keyboard.press('Backspace');
await new Promise(r => setTimeout(r, 1000));

// 5. Click Save button
const btns = Array.from(document.querySelectorAll('button'));
const saveBtn = btns.find(b => b.innerText.trim() === 'Save' && b.offsetParent !== null);
if (saveBtn) saveBtn.click();
```

**⚠️ Save can still silently fail.** After clicking Save, verify the content persisted by navigating away and back, or by reading the topic via Dataverse API. If the content didn't persist, the user must manually paste and save.

**Topic navigation pattern:**
```
https://copilotstudio.microsoft.com/environments/{ENV_ID}/bots/{BOT_ID}/adaptive/{TOPIC_GUID}
```
This navigates directly to the topic's visual editor. Then click "More" → "Open code editor" to access Monaco.

### Reading Agent Instructions

Instructions are stored in the `data` field of the type-15 `GptComponentMetadata` `botcomponent` in Dataverse, NOT in a `contenteditable` div or a `textarea` on the overview page.

**Do NOT use these unreliable approaches:**
- Navigating to `/instructions` URL — shows collapsed overview, instructions not visible
- Clicking Edit button #1 on Overview — may open Details panel instead (description/model editor)
- Reading `content` field from `botcomponent` API — always null

**Reliable approach — Dataverse API (see `references/dataverse-instruction-extraction.md`):**
```javascript
const filter = `_parentbotid_value eq '${botId}' and componenttype eq 15`;
const url = `/api/data/v9.2/botcomponents?$select=botcomponentid,data&$filter=${encodeURIComponent(filter)}`;
const resp = await fetch(url, { credentials: 'include', headers: { 'Accept': 'application/json' } });
const data = await resp.json();
const instructions = data.value[0].data; // contains "instructions: |" YAML
```

**⚠️ NEVER rely on the Edit button approach for instruction reading.** On this setup, Edit button #1 opens the agent Details panel (Name/Description/Model), NOT the Instructions editor. The correct edit button is inside `[data-testid=agent-instructions-card]`.

### Production Baseline Check

```
For each agent in production scope:
- Is this the canonical agent or a duplicate?
- Bot ID verified against source manifest?
- Published state confirmed?
- Synchronized state confirmed?
```

## Step 2: ANALYZE — Root Cause from Failures

### Test Case Mapping Technique (do this FIRST)

Read the Conv test set and map each question to a topic:

1. Navigate to agent → Evaluation → Click Conv test set (20 cases)
2. Read all test case questions
3. Match each question to a topic (by trigger query or topic name)
4. Any question WITHOUT a matching topic will fail

**Example (SLP):**
```
Test case: "Can you determine if caregiver safety is adequately addressed?"
→ No matching topic → FAILS
→ Fix: Create SLP Caregiver Competency Assessment topic
```

**Pattern:** Compare your topic structure to agents that hit 100% Conv. If they have a topic you don't, that's likely the gap.

### Microsoft Learn Grading Criteria

General Quality evaluates 4 criteria (ALL must pass):

| Criterion | Definition | Common Failure |
|-----------|-----------|----------------|
| **Relevance** | Response addresses the question | Off-topic, misunderstood intent |
| **Groundedness** | Response based on provided context | Hallucination, unsupported claims |
| **Completeness** | Response covers all aspects | Truncated, missing sections |
| **Abstention** | Agent attempted to answer | Refused, asked to rephrase |

### #1 Root Cause: Inactive Guard Topics (NEW — June 2026)

**⚠️ CHECK THIS BEFORE ANY YAML OR INSTRUCTION ANALYSIS.** Inactivated exact-match intake topics (Eval Guards, * Intake, Conv Guard) are the single highest-impact Conv score killer. When >25% of topics are inactive, test case queries fall through to generic generative AI, producing ungraded responses.

**Detection via Dataverse API — check statecode for every agent's topics:**
```javascript
const filter = `_parentbotid_value eq '${botId}' and componenttype eq 9 and statecode eq 1`;
const url = `/api/data/v9.2/botcomponents?$select=name&$filter=${encodeURIComponent(filter)}&$top=50`;
const resp = await fetch(url, { credentials: 'include', headers: { 'Accept': 'application/json' } });
const inactive = await resp.json();
if (inactive.value.length / totalTopics > 0.25) {
  // >25% inactive — fix immediately
}
```

**Fix — Batch activation via Dataverse PATCH:**
```javascript
for (const topic of inactiveTopics) {
  await fetch(`/api/data/v9.2/botcomponents(${topic.botcomponentid})`, {
    method: 'PATCH',
    credentials: 'include',
    headers: { 'Content-Type': 'application/json', 'OData-MaxVersion': '4.0', 'OData-Version': '4.0' },
    body: JSON.stringify({ statecode: 0 })
  });
}
// Then publish the agent for changes to take effect
```

**Evidence (Jun 15, 2026):** PT had 16/31 topics inactive (52%) — all Eval Guard intakes. Conv was 74% volatile. Activating all 16 pushed Conv to 95% on the very next run. SLP had 2 inactive Caregiver Conv Guards.

**Corollary: When checking other agents for the same pattern**, if only one agent has inactive guards, routing conflicts cause asymmetric Conv scores. PT was the only agent with 52% inactive → only PT had Conv 74% while OT had 95%.

### NEW Root Cause: Instruction-Evaluation Design Mismatch (June 2026)

When agent instructions are changed to a new behavioral pattern but evaluation test cases still expect the OLD pattern, the agent fails for following its own instructions. This is distinct from "stale expected answer" — the expected answer may be clinically correct, but the conversational FLOW it expects (ask-first vs answer-first) conflicts with the agent's current instructions.

**Detection technique — Dataverse componenttype 19 analysis:**
```javascript
// Extract evaluation case definitions
const filter = `_parentbotid_value eq '${botId}' and componenttype eq 19`;
const url = `/api/data/v9.2/botcomponents?$select=name,botcomponentid,data&$filter=${encodeURIComponent(filter)}&$top=5000`;
// Parse each case's `data` field for MultiTurnEvaluationCase
// Count cases where expected agent turns contain "please provide", "record_id", "could you confirm"
// Compare to current instructions' behavioral rules
```

**Quantified evidence (Jun 18, 2026):**
| Agent | Conv Cases | Expect Ask-First | % | Current Instructions | Conflict |
|-------|-----------|-----------------|---|---------------------|----------|
| PT    | 904       | 852             | 94% | "answer directly, do not ask follow-up" | YES |
| SLP   | 1020      | 1006            | 98% | "answer directly, do not ask follow-up" | YES |
| TDA   | 794       | 0               | 0%  | routing only | NO |
| OT    | 1199      | 916             | 76% | asks clarifying questions (never changed) | NO |

OT scores 95% with 76% ask-first cases because OT instructions were never changed to answer-first. The tests match OT's natural behavior. PT/SLP instructions WERE changed but the tests weren't updated.

**Microsoft Learn classification:** "If the agent response is acceptable, fix the evaluation."

**Fix options (per Microsoft Learn):**
1. Update evaluation cases to match desired production behavior (add synthetic note content, accept answer-first)
2. Switch to General quality grading without rigid expected transcripts ("General quality judges relevance, groundedness, completeness, and abstention")
3. Create new test set alongside existing (avoids destabilizing current baseline)

**Recommended: Option 2** — Microsoft Learn says "For General quality, expected answers are not required for open-ended broad clinical/compliance questions."

### NEW Root Cause: Topic Interactive Menu Failures (June 2026)

When an agent has many custom topics designed as interactive wizards (menus, cards, guided workflows), single-response evaluations fail because the topic fires and returns an interactive prompt instead of a text answer. The grader expects a direct answer but gets "Please select an option" or a card.

**Detection:** Categorize eval failures into buckets:
- **Interactive menu** — topic fires, returns card/menu/wizard instead of text
- **System error** — topic fires, action fails, returns error message
- **Misroute** — question routes to wrong topic (greeting, welcome)
- **Instruction-level** — actual content/grounding issue (traditional diagnosis)

**Evidence (QM Coach V2, June 19, 2026):**
| Category | Count | % of failures |
|----------|-------|---------------|
| Interactive menus | 20 | 69% |
| System errors (broken actions) | 7 | 24% |
| Misrouted to greeting | 2 | 7% |

The instruction cleanup (removing CRITICAL/NEVER, consolidating sections) did NOT improve the 71% score because ALL failures were topic-level.

**Fix approaches (in priority order):**
1. **Fix broken actions first** (system errors) — check connector auth, action nodes, error handling
2. **Fix misrouted topics** — check trigger phrases, topic priority order
3. **Restructure interactive topics** — best approach: give text answer FIRST, then offer interactive menu as follow-up. This satisfies both eval (single-response) and real users (guided workflows)
4. **Narrow trigger phrases** — general questions like "workflow menu" shouldn't trigger interactive wizards
5. **Add text-only fallback** — when topic detects it's in single-response mode, return text instead of card

**Key insight:** Agents with 30+ interactive topics will score low on single-response evals regardless of instruction quality. The eval framework expects text answers; interactive topics return cards. This is a structural mismatch, not an instruction problem.
## Key Lesson
When >50% of eval failures are topic-level (menus/errors/misroutes), instruction changes won't help. Fix topics first.

## Topic Creation via Dataverse API (June 2026 — NEW)

When creating topics via Dataverse API POST to `botcomponents`, TWO fields must be set for the topic to be visible in the Copilot Studio UI:

1. **`content`** — The full topic YAML (AdaptiveDialog with triggerQueries, BeginDialog, etc.)
2. **`data`** — A minimal AdaptiveDialog shell template (NOT the full content)

**Without `data` field:** Topic exists in Dataverse (queryable via API) but does NOT appear in the Copilot Studio UI. The agent cannot route to it. PAC publish succeeds but topic is invisible.

**With `data` = full YAML content:** Topic appears in UI but causes MASSIVE eval regression. QM Coach V2 SR dropped from 95% to 23% when `data` was set to full YAML (1818 chars) instead of the minimal shell (121 chars). The Copilot Studio engine uses `data` for routing/matching — full content in `data` confuses the routing engine.

**Correct `data` field value (minimal shell):**
```yaml
kind: AdaptiveDialog\r\nbeginDialog:\r\n  kind: OnRecognizedIntent\r\n  id: main\r\n  intent: {}\r\n\r\ninputType: {}\r\noutputType: {}
```

**Comparison of working vs broken topics:**
| Field | Working topic (Escalate QM Concern) | Broken topic (Coaching Corner) |
|-------|-------------------------------------|-------------------------------|
| content | 1301 chars (full YAML) | 1818 chars (full YAML) |
| data | 121 chars (minimal shell) | 1818 chars (full YAML) |
| SR eval | 95% | 23% (caused regression) |

**Detection via Dataverse API:**
```javascript
// Check if topic has data field set correctly
const topic = await fetch(`${ORG}/api/data/v9.2/botcomponents(${id})`, { credentials: 'include', headers });
const data = await topic.json();
const dataLen = (data.data || '').length;
const contentLen = (data.content || '').length;
// If dataLen > 300, data field has full content (WRONG — should be ~121 chars)
// If dataLen === 0, data field is null (WRONG — topic invisible in UI)
// If dataLen is 100-150, data field is minimal shell (CORRECT)
```

**Fix — set data to minimal shell:**
```javascript
await fetch(`${ORG}/api/data/v9.2/botcomponents(${id})`, {
  method: 'PATCH', credentials: 'include',
  headers: { 'Content-Type': 'application/json', 'OData-MaxVersion': '4.0', 'OData-Version': '4.0' },
  body: JSON.stringify({ data: 'kind: AdaptiveDialog\r\nbeginDialog:\r\n  kind: OnRecognizedIntent\r\n  id: main\r\n  intent: {}\r\n\r\ninputType: {}\r\noutputType: {}' })
});
```

**Summary:** For Dataverse API topic creation, POST with `content` (full YAML) + `data` (minimal shell), then PATCH `name` and `schemaname` if needed. Always verify both fields after creation. Publish after all topics are created.

## Topic GUIDs (Dataverse API, componenttype=9)

Key topics for fixes:
| Topic | GUID |
|-------|------|
| DoR Summary | bd0a8d0d-a9ea-4c6d-8cc1-008dc26f104e |
| Resident Outlier Analysis | acaf7325-bbf1-4657-886b-c883769654a2 |
| HIPAA Guardrail | 85492644-9856-f111-bec6-7ced8d3b6116 |
| QM - HIPAA Guardrail | 5a8d5c91-bb36-41f2-abdb-d06e551f0950 |
| LATEST RESIDENT SUBMISSION ROUTER | 89492644-9856-f111-bec6-7ced8d3b6116 |
| QM - Certification Recert MDS Alignment | a2d42672-bd86-401f-a91d-73c2db7b9a01 |
| QM Severity Classification | b804a07e-2674-47f7-83a1-44f2f5deeaf2 |
| SNF - Quality Measure Email Generator | 96492644-9856-f111-bec6-7ced8d3b6116 |
| QM Escalation Rules | 94492644-9856-f111-bec6-7ced8d3b6116 |
| WORKFLOW MENU | 3bef494a-9856-f111-bec6-7ced8d3b6116 |
| QM Driver Analysis | 8f492644-9856-f111-bec6-7ced8d3b6116 |
| HITL APPROVAL | 87492644-9856-f111-bec6-7ced8d3b6116 |
| Power BI - Run a Query Against a Dataset | 8b492644-9856-f111-bec6-7ced8d3b6116 |

Full GUID map: `D:/my agents copilot studio/qm_coach_v2_topic_guids.md`
Fix plan: `D:/my agents copilot studio/qm_coach_v2_fix_plan.md`

## HIPAA Guardrail Fix (June 2026)

The HIPAA Guardrail topic (85492644) was missing trigger phrases for natural language:
- "ensure HIPAA compliance"
- "HIPAA compliant"
- "HIPAA compliance when working with quality measure data"
- "QM processes are HIPAA compliant"

Also, the topic's flow asked a follow-up question AFTER the HIPAA answer, which the eval interpreted as not answering. Fix: replace follow-up with EndDialog.

## LATEST RESIDENT SUBMISSION ROUTER Fix (June 2026)

This topic had:
1. Empty template variable: "Facility confirmed: ." (facility name was blank)
2. cite:1 metadata leak in the response
3. Trigger queries didn't match eval phrasing ("latest resident submissions affecting quality measures")

Fix: rewrite as direct text answer with proper trigger phrases, remove facility confirmation flow, clean citations.

## Power BI Connector Plan (June 2026)

Dashboard: "One Clinical Outcomes Dashboard" on Microsoft Fabric (Restricted-Reports workspace)
Pages: Clinical Outcomes - Current Patients, ADLs and Ambulation
Auth: Service principal (Option A — correct for healthcare AI)

Full plan: `D:/my agents copilot studio/qm_coach_v2_powerbi_plan.md`
Architecture: Copilot Studio → Power BI Connector → Power BI REST API (Execute Queries) → Semantic Model → DAX Query → JSON

Prerequisites:
1. Azure AD app registration (Client ID, Secret, Tenant ID)
2. Service principal added to Power BI workspace as Contributor
3. Tenant settings: "Allow service principals to use Power BI APIs" = ON
4. Tenant settings: "Dataset Execute Queries REST API" = ON
5. Workspace ID + Dataset ID from Fabric URL

Query levels:
- Level 1: Facility QMs dropping (DAX FILTER on QualityMeasures)
- Level 2: Patient-level decline detection (DAX TOPN on PatientOutcomes)
- Level 3: General QM trends vs national benchmarks

ONE Clinical Protocol cross-reference: declining QMs → map to relevant protocol (Low Vision, Contracture Management, Sensory Integration, etc.)

HIPAA: aggregate facility data in chat, patient-level only through secure workflow, mask names/IDs, DRAFT label on all clinical recommendations.

Connector response limit: 500KB per MS Learn. Use DAX TOPN() and SUMMARIZE() to filter data.

### Eval Failure Categorization Pattern (June 2026, QM Coach V2)

Before diving into individual failures, categorize ALL failures into buckets. This prevents misdiagnosing topic-level issues as instruction problems.

**Process:**
1. Navigate to eval results → click "Fail (N)" tab to filter
2. Read each failure's question + agent response
3. Assign each to a category:

| Category | Signal | Fix Level | Example |
|----------|--------|-----------|---------|
| **System error** | "I hit a system error" | Topic action | Broken connector, dead child agent |
| **Misroute** | Answer from wrong topic | Topic trigger | HIPAA question → Greeting |
| **Interactive menu** | Card/menu/wizard response | Topic structure | "Please select an option" |
| **Prompt injection** | Metadata/template leak | Topic template | "cite:1", "Facility confirmed: ." |
| **Instruction-level** | Content/grounding issue | Instructions | Wrong clinical advice, missing citations |

**Decision rule:** If >50% of failures are topic-level (categories 1-4), instruction changes won't help. Fix topics first, re-evaluate, then consider instructions.

**Evidence:** QM Coach V2 had 29 failures. Categorization revealed 69% were interactive menus, 24% system errors, 7% misroutes. Instruction cleanup had zero effect on score. Full analysis at `D:/my agents copilot studio/qm_coach_v2_fix_plan.md`.

### Root Cause Checklist

**⚠️ Step 0 — Check topic statecodes FIRST** via Dataverse API before touching anything else.

**Topic coverage gaps (check SECOND — after inactive topic check):**
- [ ] Map each test case to a topic — if no topic matches, that test case will fail
- [ ] Compare topic lists across agents — PT/OT/SLP should have matching topic types
- [ ] Check for missing caregiver, recertification, or guard topics
- [ ] Evidence: SLP Conv 90% because caregiver topic was missing (PT/OT had one, SLP didn't)

**Topic coverage gaps (check FIRST):**
- [ ] Map each Conv test case to a topic — any test case without a matching topic will fail
- [ ] Compare topic structure to agents that hit 100% Conv (PT/OT pattern)
- [ ] Check for missing caregiver topic — PT/OT/SLP all need one for 100% Conv
- [ ] Use test case mapping technique: read Conv test set → match each question to a topic → identify gaps

**Topic-level issues (most common):**
- [ ] `Keep response under 800 characters` in `additionalInstructions`
- [ ] Missing `Cite by natural source name` citation rules
- [ ] Missing `EndDialog + clearTopicQueue: true`
- [ ] Topic YAML missing `kind: AdaptiveDialog` root
- [ ] Topic has `cite:1` placeholder instructions

**Agent-level issues:**
- [ ] **Agent DESCRIPTION conflicts with instructions** — e.g., "Returns deterministic JSON with SHAP-style feature attribution" in the description while instructions say "Use RESPONSE FORMAT: 1. Classification, 2. Compliance Findings...". GPT-5 Chat follows the description and returns JSON → eval fails. Check via Overview page → Details section → Description field. Fix via Playwright: click first Edit button → textarea.fill(newDesc) → Save. **Evidence: PT SR 96%→82% from description conflict.**
- [ ] Instructions have conditional RESPONSE FORMAT that breaks SR
- [ ] Instructions refuse to help or ask to rephrase
- [ ] Instructions have `cite:1` or metadata tag output
- [ ] "Allow ungrounded responses" is OFF

**System issues:**
- [ ] CB topic has 800-char limit (can hurt OR help — test both ways)
- [ ] Test set modified (check "last modified" date)
- [ ] Non-deterministic variance (>10% between runs)

### Multi-Turn Failure Patterns (Microsoft Learn)

For Conv evaluation failures, trace back to the first turn where the conversation diverged:

| Symptom | Root Cause | Fix |
|---------|-----------|-----|
| Agent re-asks for info already provided | Context management gap | Add: "Preserve record_id, discipline, document type across turns. Never re-ask." |
| Agent contradicts earlier response | Consistency gap | Add: "Maintain consistency with previous responses." |
| Agent loses context from prior turn | Conversation state not preserved | Check tool outputs persist across turns |
| Failure only after 5+ turns | Context length exceeded | Consider conversation summarization |
| Agent refuses on turns 2-3 | Missing EndDialog + clearTopicQueue | Add EndDialog as last action in every topic |

### TDA-Specific Considerations

TDA is a ROUTING agent, not an audit agent. It routes to PT/OT/SLP specialists. Key differences:
- **Shorter responses may score better** (focused routing vs verbose audit)
- **800-char limit in CB can HELP** (prevents over-elaboration)
- **The grader expects routing decisions**, not full audits

⚠️ **CRITICAL LESSON**: Removing 800-char limits from TDA CB caused 99% → 92% regression. For routing agents, SHORT focused responses score better. For audit agents (OT/PT/SLP), REMOVE the limit.

**Rule**: Audit agents → remove 800-char. Routing agents → keep 800-char.

## Step 3: PLAN — Microsoft Learn Checklist

### Pre-Fix Checklist

- [ ] Read current agent instructions
- [ ] Read all topic YAMLs (extract via PAC or CDP)
- [ ] Check CB topic `additionalInstructions`
- [ ] Check "Allow ungrounded responses" setting
- [ ] Identify which criteria fail (Relevance/Groundedness/Completeness/Abstention)
- [ ] Map failures to specific topics

### Fix Priority Order

1. **Agent instructions** — RESPONSE FORMAT, citation rules, no-refusal
2. **CB topic** — 800-char limit (test BOTH ways for routing agents)
3. **Audit topics** — 800-char removal, citation rules, EndDialog
4. **Guard topics** — if present, ensure proper routing

### Fix Templates

**Audit topic `additionalInstructions`:**
```
Audit this [document type] for Medicare compliance. Analyze against CMS Chapter 15, [discipline] guidelines.
[Specific audit criteria]
Use risk levels (High/Moderate/Low). Cite CMS Chapter 15 and [discipline] guidelines by natural source name. Do not output cite:1 or metadata tags.
Be concise but complete. Prioritize accuracy over strict length limits.
```

**CB topic `additionalInstructions` for routing agents:**
```
1. Cite specific CMS Ch. 15, 42 CFR, [discipline] standards. Include at least one regulatory reference per response.
2. When asked to audit without document text: state key Medicare defensibility elements then ask for content.
3. Keep responses under 800 characters. Provide top 3-4 most relevant requirements.
4. When knowledge sources contain relevant content, cite it inline by natural source name. Never refuse to provide information.
```

⚠️ For routing agents (TDA), KEEP the 800-char limit in CB. For audit agents (OT/PT/SLP), REMOVE it.

## Step 4: EXECUTE — Apply Fixes

**⚠️ Pre-check: Chrome CDP on port 9223.** If Chrome is not responding on
`http://127.0.0.1:9223/json/version`, restart it with the ONLY reliable method.

**⚠️ CDP connection exhaustion:** Always `await page.close()` and `await browser.close()` at the end of every Playwright script. Leaving pages open accumulates CDP connections. When the pool is exhausted, `connectOverCDP` hangs at "ws connected" but never initializes (timeout after 30-60s). The `curl` health check still works because it's HTTP, not WebSocket. **Fix:** kill Chrome and restart. **Prevention:** close pages in every script, reuse a single page across navigations instead of opening new ones.

**⚠️ Chrome kill can break terminal sessions:** If a terminal has an active CDP/WebSocket connection to Chrome when `taskkill //F //IM chrome.exe` runs, the terminal receives SIGINT (exit code 130) on EVERY subsequent command — the session is permanently broken. **Fix:** close all Playwright connections (`browser.close()`) before killing Chrome. If the terminal is already broken, use `execute_code` which creates fresh subprocess sessions.

```powershell
# Kill all Chrome, restart with debug port pointing to ORIGINAL user data dir
# (this preserves auth cookies — no re-login needed)
powershell.exe -ExecutionPolicy Bypass -Command "
Get-Process chrome -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Seconds 3
\$args = '--remote-debugging-port=9223','--remote-allow-origins=*','--no-first-run','--user-data-dir=C:\Users\kevin\AppData\Local\Google\Chrome\User Data'
Start-Process 'C:\Program Files\Google\Chrome\Application\chrome.exe' -ArgumentList \$args
Start-Sleep -Seconds 8
try { Invoke-WebRequest -Uri 'http://127.0.0.1:9223/json/version' -UseBasicParsing -TimeoutSec 5; Write-Host 'CDP OK' } catch { Write-Host 'CDP FAIL — retry once more' }
"
```

**Critical detail:** `--user-data-dir` MUST point to the ORIGINAL Chrome profile. This preserves existing Microsoft login cookies — no re-authentication required. Using a fresh or non-existent user-data-dir breaks auth and forces re-login.

NEVER use `cmd.exe //c start` — it silently fails with exit 0 but no debug port opens. NEVER use bare `start` in MSYS — it breaks the terminal permanently (exit 130). NEVER use a fresh or temp user-data-dir — auth cookies won't transfer.

Use the `cdp-instructions-injection` skill for topic YAML injection:

```javascript
// Connect to Chrome
const browser = await chromium.connectOverCDP('http://127.0.0.1:9223');
// Navigate to Overview → Topics → Click topic → More → Open code editor
// Inject YAML via clipboard (Ctrl+A → Ctrl+V)
// Wake save tracker (Space + Backspace)
// Click Save
```

### Batch Fix Workflow (NEW — validated June 15)

When multiple topics across multiple agents need the same fix (e.g., 800-char removal):

1. **Extract templates** via `pac copilot extract-template` (works for agents with <60 components)
2. **Scan all topics** for the issue pattern (800-char limits, missing EndDialog, etc.)
3. **Generate fix files** — one YAML per topic with the fix applied
4. **Get topic GUIDs** via Dataverse API: `_parentbotid_value eq '${botId}' and componenttype eq 9`
5. **Inject via direct GUID URLs**: `${BASE}/adaptive/${guid}` — navigate, wait for Save button, More → Code editor → Inject → Save
6. **Publish** each agent after all topics injected

**Key advantage**: Direct GUID navigation bypasses the slow, paginated SPA topics list. Each topic loads independently.

**PAC limits**: Crashes on agents with 60+ components (SLP 64, TDA 67). For these, use CDP code editor or manual approach.

### Publish After Fixes

Always publish the agent after applying fixes. Unpublished changes don't affect evaluations.

### Verify Before Testing (CRITICAL — must use normalized string check)

**⚠️ Non-breaking space trap — indexOf checks lie.** The Monaco editor renders text with non-breaking spaces (`\u00a0`) instead of regular spaces. `text.indexOf('800')` returns -1 even when "Keep responses under 800 characters" is present — the actual text is `Keep\u00a0responses\u00a0under\u00a0800\u00a0characters`.

**Correct verification — normalize non-breaking spaces first:**
```javascript
const raw = await page.evaluate(() => {
  const lines = document.querySelectorAll('.monaco-editor .view-lines .view-line');
  return Array.from(lines).map(l => l.textContent).join('\n');
});
const verify = raw.replace(/\u00a0/g, ' ');
const stillHas800 = /\b800\b/.test(verify);
```

**Red flag — length mismatch:** If read-back is 30-40% shorter than injected (e.g., 1312 vs 1906 chars), the save was silently rejected. Monaco only renders the viewport — the old content persisted. The only reliable fix is manual: user types a character + Backspace to trigger React dirty state, then clicks Save.

Similarly, also update key learnings:

```markdown
19. **Injection save can silently fail** — textarea.value setter + Space+Backspace doesn't trigger React onChange for Monaco editors. Non-breaking spaces cause false-negative verification. Length mismatch (injected 1906 vs verify 1312) means save was rejected. See `cdp-instructions-injection` skill.
```

### Prep Alternative Fixes (While Waiting)

While test runs, prepare Plan B fixes in case the primary fix doesn't work:
- Identify other root causes from the ANALYZE step
- Draft alternative YAML or instruction changes
- Save to files for quick injection in next loop

## Step 5: TEST — Trigger ONE Evaluation Type

**RULE: Target ONE eval type per loop to isolate variables.**

### Choosing Which Type to Test

| Current State | Test Type | Why |
|---------------|-----------|-----|
| SR < 95% | Single Response | Fix SR-specific issues first |
| Conv < 95% | Conversation | Fix Conv-specific issues first |
| Both < 95% | SR first | SR is the foundation; Conv builds on it |
| Both ≥ 95% | Neither | Done! Run 3x to confirm stability |

### Pre-Test: Map Test Cases to Topics

Before testing, map each test case to a topic. This identifies coverage gaps BEFORE running the eval.

```javascript
// Navigate to eval page → click test set → read test cases
// For each test case, identify which topic should handle it
// If no topic matches → that test case WILL fail → create topic first
```

**Evidence**: SLP Conv 90% because 2/20 test cases asked about caregiver documentation but SLP had no caregiver topic. PT/OT both had one → 100% Conv.

### Live Evaluation Gateway API Shortcut

When the UI is slow or you need to sweep multiple agents, use the direct PowerVA gateway API pattern in `references/live-evaluation-gateway-api.md`. Capture the SPA `authorization` and `x-cci-*` headers from the live Evaluation page, then use:
- `GET /makerevaluations?count=10` to list runs
- `POST /makerevaluations` with `testSetId` to start a run
- `GET /makerevaluations/{runId}/details` to fetch case-level details

Important: raw browser cookies alone are not enough; missing `x-cci-*` headers commonly returns 400. Generate a fresh `x-ms-client-request-id` UUID for each request.

### Triggering Evaluation Automation

Use `auto_eval.cjs` which triggers an eval and monitors until complete:

```bash
node skills/copilot-studio/evaluation-driven-agent-optimization/scripts/auto_eval.cjs
```

**Pitfall**: Windows background (`stdin is not a tty`) fails for browser scripts. Use foreground only.

**Evaluation tab click pattern**: Agent-level tabs (Overview, Knowledge, Topics, Activity, Evaluation, Analytics) are `<button>` elements containing a `<span>`, NOT `role="tab"`. Click the parent BUTTON of the Evaluation SPAN. After clicking, wait 20-30s for SPA to render evaluation content. Reliable path: navigate to `/testing` → wait for 1500+ chars → click Evaluation via parent button pattern → wait for "New evaluation" text. Direct `/evaluation` URL also works but takes 20-30s. See `copilot-studio-development-workflow/references/evaluation-tab-model-detection.md` for full pattern and code.

**Copilot Studio rate limit**: Only one active eval per agent. The same agent cannot run SR and Conv simultaneously, but different agents can have active runs at the same time. If a launch returns `fairusagepolicy.botactiverunquotaviolated`, wait for that agent’s active run to finish, then immediately start its counterpart.

## References
- `references/api-topic-creation-and-interactive-wizards.md` — API topic creation (data field requirement) and interactive wizard failures (Question nodes break SR eval)
- `references/qm-coach-v2-topic-audit-june-2026.md` — QM Coach V2 topic audit: 20 topics analyzed, 2 broken (Question nodes), 7 clean custom, eval regression root cause
- `references/surgical-vs-full-yaml-replacement.md` — NEVER full-YAML-replace; surgically remove offending lines
- `references/qm-coach-v2-eval-failure-analysis.md` — Example of topic-driven interactive menu failures (48 topics, 71% score, 69% of failures from menus not instructions)
- `references/tda-plan-key-takeaways.md` — Key insights from TDA Orchestration Production Readiness Action Plan
- `references/drift-quantified-analysis.md` — Full quantified drift statistics from 100 eval runs per agent (PT/SLP/TDA/OT), root cause layers, instruction complexity vs variance correlation, practical recommendations for interpreting non-deterministic scores
- `references/eval-case-instruction-mismatch-detection.md` — Detect when evaluation cases expect old behavioral patterns (ask-first) that conflict with current instructions (answer-first). Dataverse componenttype 19 analysis technique, quantified PT/SLP/OT/TDA mismatch data, Microsoft Learn fix options
- `references/dataverse-eval-case-update.md` — ⚠️ READ BEFORE USE. Dataverse API technique for evaluation cases (componenttype 19). **CRITICAL PITFALL: Do NOT use this to rewrite MultiTurnEvaluationCase data to change conversational flow.** Attempting to transform prompt-first cases to answer-first by rewriting the `data` field collapsed 6-turn conversations into 2-turn single-response cases, breaking the evaluation system. The correct approach per Microsoft Learn is to change the GRADING METHOD to General quality (which doesn't require rigid expected transcripts), not rewrite test case data. The API technique is valid for reading/querying cases, but modifications to the YAML structure are fragile and risk corrupting the evaluation.
- `scripts/auto_eval.cjs` — Automated eval trigger and monitor script
- `references/inactive-topic-detection.md` — Detect and batch-activate inactive guard topics via Dataverse API (PT Conv 74%→95% fix)
- `references/eval-trigger-pattern.md` — Correct button sequence: click "Evaluate" on test set card, NOT "New evaluation"

### Manual Evaluation (Corrected)

**⚠️ "New evaluation" opens a test set CREATOR, not a RUN dialog.** Clicking it shows options to upload CSV, select language, or write questions — this creates a new test set, not run an existing one.

**Correct sequence to run an existing test set:**
1. Navigate to agent → Evaluation tab
2. Find the test set card (e.g., "20 test cases • Data type: conversation")
3. Click the **"Evaluate"** button ON the test set card
4. A dialog opens — click **"Run"**
5. Confirm if needed — click **"Run"** again

**Both "New evaluation" and test set card "Evaluate" trigger new eval runs (June 2026).** "New evaluation" opens a "Manage profile and connections" dialog — select an account first, then click Run. The test set card "Evaluate" button does the same. **Do NOT click "Evaluate" buttons in the results rows** — those open existing result details, not new runs.

See `references/eval-trigger-pattern.md` for details and common pitfalls.

**Pitfall: Pre-eval dialog requires account selection.** The "Manage profile and connections" dialog's "Run" button only works AFTER selecting an account from the dropdown. If clicking Run does nothing, the account wasn't selected.

**Copilot Studio rate limit**: The practical API limit is one active evaluation run per agent. SR and Conv for the same agent must be sequential, but OT/PT/SLP/TDA can run in parallel. If the UI shows a broader disabled state, verify with the gateway run list before assuming a global lock.

```
SR test set: 100 cases, Data type: single response
Conv test set: 20 cases, Data type: conversation
```

### Wait for Results

Evaluations take 5-15 minutes. Monitor the eval page until status changes from "Running" to a percentage.

## Microsoft Learn Instruction Budget Consolidation

When instructions grow past ~50 lines, the model follows them inconsistently. Microsoft Learn calls this the "instruction budget problem." Symptoms:
- Previously passing test cases start failing after unrelated instruction changes
- Agent follows some rules correctly but ignores others
- Fixes for one scenario cause regressions in another
- Failures appear inconsistent across similar test cases

**Consolidation technique (produced 16-23% size reduction):**

1. **CONSOLIDATE** — Merge overlapping rules. Citation rules appeared 5x in PT instructions, now 1x. "No tool JSON" appeared 4x, now 1x. "Answer directly" appeared 3x, now 1x.
2. **PRIORITIZE** — Put critical rules first. Models attend more to beginning and end of prompts. Order: SCOPE → RESPONSE FORMAT → RESPONSE BEHAVIOR → CLINICAL CONTENT → SAFETY.
3. **SIMPLIFY** — Remove redundant XAI & TRANSPARENCY section (rules already in BEHAVIOR). Condense clinical content lists.
4. **EXTERNALIZE** — Move static reference data (clinical checklists, CPT code lists) into knowledge sources instead of the system prompt.

**Before/after (Jun 18, 2026):**
| Agent | Old | New | Reduction |
|-------|-----|-----|-----------|
| PT | 5096 chars (61 lines) | 3949 chars (46 lines) | 23% |
| SLP | 4504 chars (60 lines) | 3618 chars (46 lines) | 20% |
| TDA | 1888 chars (29 lines) | 1587 chars (25 lines) | 16% |

**Rules preserved:** conditional format (PT), unconditional (SLP), soft language (no CRITICAL/MANDATORY/NEVER), clinical content requirements, safety disclaimers.

## Microsoft Learn 3-Run Baseline Methodology

Per Microsoft Learn "Handling non-determinism in scores":

1. **Run the full evaluation set at least 3 times** before treating any score as a baseline. Use the average as your working score.
2. **Up to 5% variance = normal.** If variance >10%, investigate grader reliability before diagnosing agent problems.
3. **For <30 test cases:** 1 failed case = 3%+ score change. Don't over-interpret small movements.
4. **For 50+ test cases:** treat 5%+ change as meaningful.
5. **Flaky test cases** (pass 2/3 runs): If the agent produces two different but both-acceptable responses, the evaluation is too rigid.

**Baseline template:**
```
| Agent | Type | Run 1 | Run 2 | Run 3 | Average | Variance | Status |
|-------|------|-------|-------|-------|---------|----------|--------|
| PT    | Conv | 85%   | 90%   | 90%   | 88.3%   | 5%       | PASS   |
| PT    | SR   | 88%   | 94%   | 82%   | 88.0%   | 12%      | INVESTIGATE GRADER |
```

**Status thresholds:**
- Variance ≤ 5%: PASS — use average as baseline
- Variance 5-10%: BORDERLINE — monitor, may need more runs
- Variance > 10%: INVESTIGATE GRADER — per Microsoft Learn, diagnose grader reliability before agent problems

## Stabilization Sub-Workflow (Microsoft Learn, June 2026)

When the primary problem is score FLUCTUATION rather than consistently low scores, use this 5-step stabilization workflow before entering the optimization loop. This addresses non-determinism, stale evaluation design, and instruction budget problems that cause scores to swing ±10-15% between runs.

### Step 1: Establish 3-Run Baselines
Run each evaluation set (SR and Conv) 3 times per agent. Record averages and variance. Per Microsoft Learn:
- ≤5% variance = normal, use average as baseline
- 5-10% variance = borderline, monitor
- \>10% variance = investigate grader reliability before diagnosing agent

### Step 2: Identify Flaky Test Cases
Analyze evaluation case definitions via Dataverse componenttype 19. Count cases with prompt-first expected patterns vs current instruction behavior. The key metric: what % of cases expect behavioral patterns that conflict with current instructions?

Detection pattern for prompt-first:
```python
prompt_first = [x for x in conv_cases if 'please provide' in x['data'].lower()
                or ('record_id' in x['data'].lower() and 'provide' in x['data'].lower())]
```

If >50% of cases conflict with current instructions → evaluation setup is the root cause, not agent defects.

### Step 3: Fix Stale Evaluation Cases
Per Microsoft Learn: "If the agent response is acceptable, fix the evaluation."
- Option A: Update test cases to include synthetic note content and accept answer-first behavior
- Option B (recommended): Switch to General quality grading without rigid expected transcripts
- Option C: Create new test set alongside existing (avoids destabilizing baseline)

**⚠️ CRITICAL PITFALL: Do NOT rewrite MultiTurnEvaluationCase `data` fields via Dataverse API.**
A transform function that collapses multi-turn conversations into fewer turns corrupts the
YAML structure (line endings, quoting, activity count). This broke all 4 agents' evaluations
and required a full revert of 40 cases. The correct approach is Option B — change the grading
method in the Copilot Studio UI, not the test case data. See `references/dataverse-eval-case-update.md`.

### Step 4: Consolidate Instructions
Per Microsoft Learn "instruction budget problem":
1. CONSOLIDATE: merge overlapping rules (citation rules 5x→1x, no-tool-JSON 4x→1x)
2. PRIORITIZE: critical rules first (models attend to beginning/end of prompts)
3. SIMPLIFY: remove redundant sections
4. EXTERNALIZE: move clinical checklists into knowledge sources

Produced 16-23% size reduction across PT/SLP/TDA without changing semantic meaning.

### Step 5: Verify Stabilization
Rerun each evaluation 3 times after fixes. Compare variance to Step 1 baselines. Target: ≤5% variance across 3 runs. If variance >10% persists after fixes → grader reliability issue (platform limitation). Document and escalate per Microsoft Learn.

## Drift Root Cause Analysis (Quantified — June 2026)

When scores fluctuate across runs with NO instruction changes, the cause is platform-level non-determinism, not agent configuration. See `references/drift-quantified-analysis.md` for full statistics from 100 eval runs per agent.

### The Three Layers of Non-Determinism

1. **Response generation** — GPT-5 Chat samples differently each run. Same prompt → different output. ~5-10% variance floor.
2. **Grader evaluation** — Copilot Studio's "General quality" grader is ALSO an LLM. Borderline answers grade as pass or fail depending on grader sampling. Compounds with layer 1.
3. **Context accumulation** — In conversation tests, each turn's non-deterministic output becomes the next turn's context. Errors compound. This is why conversation scores have 2-3x the variance of single-response scores.

### Quantified Variance (100 runs each, June 2026)

| Agent | Type | Min | Max | Avg | Range |
|-------|------|-----|-----|-----|-------|
| PT | Conv | 0% | 100% | 83.5% | 100% |
| PT | SR | 34% | 99% | 87.2% | 65% |
| SLP | Conv | 35% | 100% | 85.9% | 65% |
| SLP | SR | 35% | 100% | 88.3% | 65% |
| TDA | Conv | 35% | 100% | 86.4% | 65% |
| TDA | SR | 73% | 100% | 92.5% | 27% |
| OT | Conv | 5% | 100% | 68.0% | 95% |
| OT | SR | 56% | 100% | 90.8% | 44% |

### Key Insight: Instruction Complexity Correlates with Variance

| Agent | Instruction Lines | SR Range | Conv Range |
|-------|-------------------|----------|------------|
| TDA | 28 lines (simplest) | 27% (most stable) | 65% |
| SLP | 59 lines | 65% | 65% |
| PT | 60 lines + conditional format | 65% (least stable) | 100% (worst) |

More instructions = more surface area for the model to randomly drop/ignore/misinterpret. Each instruction is a coin flip. Conditional logic (PT's "use format for document questions only") adds another layer of variance.

### OT's 99% is Ecosystem, Not Instructions

OT achieves 99% single-response because of its ecosystem: 0 guard topics (no interference), 8 knowledge sources (rich grounding), 5 purpose-built audit topics. Copying OT's instruction structure to SLP caused 90%→75% regression. The portable elements are behavioral patterns (ban weak phrases, format-per-question, conciseness), not the instruction structure itself.

### Practical Implications

- **A "true score" is the median of 5+ runs**, not any single run
- **100-case test sets are the only reliable signal** — 10/20-case runs are noisy (PT 10-case = 70%, same agent same hour = 90% on 20-case)
- **No instruction change can eliminate the 5-10% variance floor** — this is the platform
- **The only lever that works beyond instructions is the ecosystem approach**: knowledge sources, purpose-built topics, topic-level additionalInstructions
- **Instruction-level changes past ~90% avg are fighting noise with noise**

### Variance Check (Updated)

**⚠️ NON-DETERMINISTIC VARIANCE IS REAL.** All 3 audit agents simultaneously regressed on Conv in the same time window. Microsoft Learn confirms "Up to 5-10% variance between runs is normal." The simultaneous drop is variance + stale evidence, not real regression.

Run evaluation 3 times and take MEDIAN to confirm stability:
- Median ≥ 95%: DONE for this test type
- Median 90-94%: Borderline, instruction improvements may help
- Median < 90%: Real gap, investigate root cause
- Any single run < 80% on a 20-case set: IGNORE (sample noise)

## Step 6: REVIEW — Read Results and Compare

### Read Scores

```bash
# Navigate to eval page, read latest score
# Compare to baseline (score before this loop)
```

### Compare to Baseline

| Result | Action |
|--------|--------|
| Score improved, ≥95% | ✅ Test type done. Check other type next loop. |
| Score improved, <95% | 🔄 Progress. Re-analyze remaining failures, loop again. |
| Score same | ⚠️ Fix didn't work. Try alternative approach. |
| Score regressed | ❌ Revert fix. Try different root cause. |

### Single-Run vs Median Interpretation

A single eval run is a SAMPLE, not a measurement. Interpret accordingly:
- Score ≥ 95%: Likely true ≥ 90%, treat as passing
- Score 85-94%: Inconclusive — could be 90%+ true score with noise
- Score < 85%: Likely a real gap — investigate
- Score < 70%: Almost certainly a real problem (even with noise)

Run 3x and use median for decisions. Do not chase single-run dips.

## Step 7: DECIDE — Loop or Done

```
IF all agents ≥95% SR AND Conv (3-run average):
  → DONE. Update skill with final scores.
ELSE IF current test type ≥95%:
  → NEXT LOOP: Switch to other test type (SR↔Conv)
ELSE IF score improved but <95%:
  → NEXT LOOP: Re-analyze remaining failures, same test type
ELSE IF score regressed:
  → NEXT LOOP: Revert fix, try alternative, same test type
ELSE IF score unchanged:
  → NEXT LOOP: Different root cause, same test type
```

### Loop Iteration Rules

1. **One fix per loop** — Don't batch multiple changes. Isolate what works.
2. **One test type per loop** — Don't test SR and Conv together.
3. **Always compare to baseline** — Not to the previous loop.
4. **Revert on regression** — Never leave a bad fix in place.
5. **Document every change** — Update skill with what worked/didn't.
6. **Report format** — Give a compact score table (Agent | SR | Conv | Change) and the single next action. No paragraph explanations around the table; the user knows the context.

### Cross-Agent Orchestration Loop (User's Preferred Pattern)

When optimizing ALL agents (not just one), the user prefers a sweep-and-loop pattern:

```
FOR each agent in [OT, PT, SLP, TDA]:
  FOR each test_type in [SR, Conv]:
    1. Pull latest eval results for ALL agents (not just current)
    2. Identify ALL failures across all agents, all test types
    3. Create prioritized checklist (worst agent first)
    4. Fix ONE agent, ONE test type
    5. Re-pull ALL results for ALL agents
    6. DECISION POINT:
       - If ANY fix was made (even one) → LOOP BACK to step 1
         (re-analyze everything from scratch with fresh results)
       - If NO fixes needed → advance to next test type or agent
```

**The key rule: ANY fix = mandatory full re-analysis.** Even fixing a single topic YAML triggers a full re-sweep. The user does not want "batch fixes then test once" — they want "fix one thing, re-verify everything, decide next move."

**Why this matters:** Fixes in one agent can affect routing in shared-orchestration agents (TDA). A PT instruction fix might change how TDA routes PT queries. Only a full re-sweep catches cross-agent effects.

**Implementation:** After each fix+publish+eval cycle:
1. Scrape ALL 4 agent eval pages (SR + Conv for each)
2. Build a full score matrix: Agent × TestType × Score
3. Compare to previous matrix
4. Pick the single worst cell (lowest score) as the next fix target
5. If the matrix improved AND all cells ≥95% → DONE
6. If the matrix improved but some cells <95% → fix next worst cell
7. If the matrix regressed → revert the last fix, try alternative

### When to Stop Looping

Stop and report blockers when ANY of these are true:
- 3 consecutive loops produce no improvement on the same cell
- Score is stuck at the same value despite different root-cause attempts
- Platform/model retirement detected (shared root cause, not fixable by config)
- All cells ≥95% → DONE

Every fix cycle output should look like:

## Root Cause: Interactive Question Nodes Break SR Eval (June 2026)

When a topic contains `kind: Question` or `kind: AdaptiveCardPrompt` nodes, single-response evaluations FAIL because the agent responds with a question (asking for input) instead of a text answer. The eval grader expects a direct answer.

**Detection via Dataverse API:**
```python
# Check for Question nodes in topic content
for topic in topics:
    if 'kind: Question' in topic['content']:
        print(f"BROKEN: {topic['name']} has Question node")
```

**Fix — Replace with SearchAndSummarizeContent + EndDialog:**
```yaml
# BEFORE (broken — interactive wizard):
actions:
  - kind: Question
    id: question_xxx
    variable: init:Topic.selectedFacility
    prompt: Which facility should this review cover?
  - kind: AdaptiveCardPrompt
    id: card_xxx
    card: |-
      ={"type":"AdaptiveCard","actions":[...]}
  - kind: EndDialog

# AFTER (fixed — direct text answer):
actions:
  - kind: SearchAndSummarizeContent
    id: answer_xxx
    userInput: =System.Activity.Text
    additionalInstructions: |-
      [Instructions for generating the text answer]
    allowLatencyMessage: false
    applyModelKnowledgeSetting: true
    responseCaptureType: FullResponse
  - kind: EndDialog
    id: end_xxx
```

**Evidence (QM Coach V2, June 2026):** DoR Summary (3 Question nodes + AdaptiveCard) and Resident Outlier Analysis (3 Question nodes + ClosedListEntity) caused SR eval to drop from 95% to 12%. After replacing with SearchAndSummarizeContent pattern, score should recover.

**Pattern:** Topics designed as interactive wizards (asking multiple questions before answering) are structurally incompatible with single-response evals. The eval sends one question and expects one text answer. If the topic responds with "Which facility?" or an AdaptiveCard, the eval grades it as a failure.

**Key insight from user:** "Even with my other agents, you said it was a platform or system thing but it was erroring because it was broken guard topics and broken logic." ALWAYS check topic content for Question nodes before blaming the platform or model.

## Pitfall: Dataverse API PATCH Content Field Returns 400 (June 2026)

When trying to PATCH the `content` field of a botcomponent via the Dataverse API (`/api/data/v9.2/botcomponents({id})`), the API returns HTTP 400 with:
```json
{"error":{"code":"0x80040265","message":"Unexpected character encountered while parsing value: k. Path '', line 0, position 0."}}
```

The error occurs because the API tries to parse the YAML content as JSON. The 'k' is the first character of "kind: AdaptiveDialog".

**Root cause:** The Copilot Studio Dataverse API has strict validation on the `content` field. Direct YAML content is rejected.

**Workaround:** Use the Copilot Studio UI code editor to update topic content:
1. Navigate to topic URL: `${CS_URL}/environments/${ENV}/bots/${BOT}/adaptive/${TOPIC_ID}`
2. Click More → Open code editor
3. Select all (Ctrl+A)
4. Inject via `document.execCommand('insertText', false, newYaml)`
5. Type Space + Backspace to trigger dirty state
6. Click Save

**⚠️ Pitfall: Monaco execCommand save can silently fail.** The injected content appears in the editor (verify shows correct content), but clicking Save may not persist the changes. The Monaco editor's React state doesn't always sync with the DOM after `execCommand`. If the verify shows correct content but the Dataverse API still returns old content after save, the save failed silently. The only reliable fix is manual: user types a character + Backspace to trigger React dirty state, then clicks Save.

## Pitfall: Topic `data` Field Required for UI Visibility (June 2026)

Topics created via Dataverse API POST to `botcomponents` with only the `content` field set will NOT appear in the Copilot Studio UI. The UI reads the `data` field, not `content`.

**Detection:** Topics exist in Dataverse API (statecode=0, correct parentbotid) but don't appear in the Copilot Studio Topics page.

**Fix:** Set the `data` field to the same YAML content as `content`:
```javascript
await fetch(url, {
  method: 'PATCH',
  body: JSON.stringify({ content: yaml, data: yaml })
});
```

**Comparison with working topics:** Pre-existing topics have `data` set to the empty shell template (~121 chars) while `content` has the full YAML (~1300+ chars). Topics created via API need `data` set explicitly.

**Evidence (QM Coach V2, June 2026):** 4 topics created via API had `data: null`. Setting `data` to full YAML made 3/4 visible in the UI. The `schemaname` format (`qm_coach_*` vs `cr917_agent.topic.*`) is immutable after creation but doesn't affect visibility.

## Key Learnings (Microsoft Learn Validated)

**Operating principle:** NEVER ASK WHEN YOU CAN ACT. If a tool can do it, execute immediately. Do not ask permission for things within your capability. Only ask when there's genuine ambiguity or a destructive irreversible action with no clear path. This applies to: killing/restarting Chrome, running scripts, injecting YAML, triggering evaluations, reading scores — all are within scope.

1. **Topic `additionalInstructions` is the #1 root cause** — not agent instructions
2. **800-char limits HELP routing agents** (TDA) but HURT audit agents (OT/PT/SLP)
3. **Non-deterministic variance is 5-10%** — retest 2-3x before investigating
4. **CB topic affects ALL unmatched queries** — changes here have wide impact
5. **Clipboard paste doesn't trigger React dirty state** — must type Space + Backspace
6. **Topics page SPA doesn't render reliably** — use Overview page topic links
7. **System topics not on Overview** — must navigate to Topics page (often blank)
8. **PAC crashes on 60+ component agents** — use CDP/Playwright instead
9. **Question nodes break Conv flow** — audit topics must NOT ask conversational questions (OT 95%→86% regression). Direct SearchAndSummarizeContent → EndDialog only.
10. **Trigger queries must match test cases verbatim** — copy exact wording from eval test cases. Don't rephrase or generalize.
11. **Cross-signal degradation**: All agents dropping together = shared root cause (platform/model update, not individual topic failures). Per MS Learn Layer 4.
12. **Windows background `stdin is not a tty`** — browser automation must run FOREGROUND on Windows. Background mode fails.
13. **Copilot Studio rate limit**: Only 1 eval at a time. "Only one test at a time" disables Run button.
14. **Power Fx expression syntax** — Use `{Topic.varName}` NOT `{$Topic.varName}` in prompt fields.
15. **Missing caregiver topic** — SLP Conv 90%→85% root cause was no caregiver topic matching PT/OT pattern.
16. **All agents share the same 21 knowledge sources** — KB changes affect all agents.
17. **Simultaneous regression = shared root cause** — NOT individual topic issues (Microsoft Learn Layer 4).
18. **Caregiver topic required for Conv** — PT/OT/SLP all need one for caregiver test cases.
19. **Non-deterministic variance across agents** — all 3 audit agents can regress simultaneously (100→90, 100→89, 90→85) due to platform variance, not individual changes.
20. **SLP Conv regression without 800-char limits** — SLP Conv dropped 95%→80% but ALL SLP topics verified clean (no 800-char limits). Root cause was NOT topic YAML — investigate model/instructions/platform changes.
21. **Batch injection via GUID URLs** — Navigate to `${BASE}/adaptive/${topicGuid}` for direct topic access. Poll for Save button (up to 30s) instead of fixed timeout. 10/10 OT topics and 2/2 PT topics injected successfully this way.
22. **Dataverse API for topic discovery** — `_parentbotid_value` (not `botid`) + `componenttype eq 9` returns all topics with GUIDs. Essential for batch injection workflow.
23. **NEVER full-YAML-replace topics from old templates** — scores REGRESS (94%→88%) because old template YAMLs lack post-export optimizations (added trigger queries, model descriptions, routing hints). Only SURGICALLY remove the offending line. See `references/surgical-vs-full-yaml-replacement.md`.
24. **Topic statecode activation via Dataverse** — INACTIVE guard topics cause massive score drops. Query `statecode eq 1` via Dataverse API, then PATCH `{ statecode: 0 }` to activate. PT had 16/31 topics inactive → Conv 74%→95%.
25. **Agent description affects model behavior** — The description field on the Overview page is read by the model as system-level context. If it says "Returns deterministic JSON with SHAP-style feature attribution" but instructions say "Use RESPONSE FORMAT: 1. Classification, 2. Compliance Findings...", GPT-5 Chat follows the DESCRIPTION (JSON) over the instructions (natural language). PT SR dropped 96%→82% from this conflict. Fix: edit description to match actual output format. Rule: audit agents should say "Returns compliance findings with risk levels, scores, and recommendations", NOT "Returns JSON".
26. **Agent description editing via Playwright** — On Overview page, the FIRST "Edit" button opens the Details panel (Name/Description/Model), NOT the instructions editor. The description is a `<textarea>`. Steps: click first Edit button → wait 5s → find textarea with old description text → `ta.fill(newDesc)` → click Save button. The textarea contains the full description text (e.g., 708 chars). Save button appears after fill.
27. **Evaluation tab SPA navigation** — Direct URL to `/evaluation` often lands on the test pane. Reliable approach: navigate to `/overview` first, wait 15s, then click the Evaluation tab via JS: `document.querySelectorAll('span.fui-Tab__content')` → find span with text "Evaluation" → `span.parentElement.click()`. Wait 15s for eval content to render. The nav items are Fluent UI `<button>` containing `<span class="fui-Tab__content">`, NOT standard `<a>` links.
28. **Publish dialog backdrop intercept** — After clicking Publish, a confirmation dialog appears with `fui-DialogSurface__backdrop` that intercepts pointer events on the main button. Fix: click the Publish button INSIDE the dialog using `page.locator('[role="dialog"] button:has-text("Publish")').click({ force: true })` or target the dialog-specific button.
11. **Caregiver topic required for Conv** — PT/OT/SLP all need one for caregiver test cases
12. **Power Fx expressions** — use `{Topic.varName}` NOT `{$Topic.varName}` ($ causes errors)
13. **Creating new topics via automation doesn't work** — user must create manually, then inject YAML
14. **Non-deterministic variance across agents** — all 3 audit agents can regress simultaneously (100→90, 100→89, 90→85) due to platform variance, not individual changes
15. **SLP Conv regression without 800-char limits** — SLP Conv dropped 95%→80% but ALL SLP topics verified clean (no 800-char limits). Root cause was NOT topic YAML — investigate model/instructions/platform changes.
16. **Batch injection via GUID URLs** — Navigate to `${BASE}/adaptive/${topicGuid}` for direct topic access. Poll for Save button (up to 30s) instead of fixed timeout. 10/10 OT topics and 2/2 PT topics injected successfully this way.
17. **Dataverse API for topic discovery** — `_parentbotid_value` (not `botid`) + `componenttype eq 9` returns all topics with GUIDs. Essential for batch injection workflow.
20. **Inactive guard topics are the #1 Conv killer** — Check `statecode eq 1` on componenttype 9 for EVERY agent before touching YAMLs or instructions. Activate via Dataverse PATCH `statecode: 0`. PT Conv went from 74%→95% solely from reactivating 16 inactive Eval Guard topics.
21. **Monaco non-breaking space trap** — Simple `indexOf('800')` on Monaco DOM content returns false negatives because Monaco uses `\u00a0` (non-breaking space) instead of regular spaces. Always normalize with `.replace(/\u00a0/g, ' ')` before checking. Length mismatch between injected and re-read content means the save was silently rejected.
29. **Dual non-determinism compounds** — Both the response model (GPT-5 Chat) AND the Copilot Studio grader are non-deterministic LLMs. Response variance ±5% + grader variance ±5% = combined ±7-10%. A "true 90%" agent scores 80%-100% on any single run. Use median of 3-5 runs for optimization decisions.
30. **Instruction complexity amplifies variance** — TDA (28 lines, no conditional logic) has the most stable SR scores (27% range across 100 runs). PT (60 lines, conditional RESPONSE FORMAT) has the least stable (100% range in conversation). Each instruction is a coin flip; conditional logic adds a branching decision the model must make correctly every time.
31. **Test case count affects noise** — 10-case runs are unreliable (PT 10-case = 70%, same hour 20-case = 90%). 20-case runs swing 55%-100%. Only 100-case runs have enough signal for trend analysis. Ignore 10/20-case outliers.
32. **OT's 99% is ecosystem not instructions** — OT achieves 99% SR from 0 guard topics + 8 knowledge sources + 5 purpose-built audit topics, not from instruction wording. Copying OT's instruction structure to SLP caused 90%→75% regression. The portable elements: ban weak phrases, unconditional format, conciseness. Keep discipline-specific content.
33. **"True score" = median of 5+ runs** — A single eval run is a sample, not a measurement. Score ≥ 95% = likely true ≥ 90%. Score 85-94% = inconclusive. Score < 85% = likely real gap. Score < 70% = almost certainly a problem. Do not chase single-run dips.
34. **Conversation "context tax"** — Multi-turn tests have 2-3x the variance of single-response tests because non-deterministic turn 1 becomes turn 2's context, compounding errors. PT SR range = 65%, Conv range = 100%. TDA SR range = 27%, Conv range = 65%. This gap is structural, not fixable by instructions.
35. **QA read-only mode** — When the user says "qa run only without actions" or "analysis only", do NOT make changes. Analyze, report findings, and stop. Present the analysis as data + conclusions, not as a plan to fix.
36. **Simultaneous multi-agent regression = platform** — When SLP, PT, and TDA all drop at the same time with no instruction changes, the cause is GPT-5 Chat sampling variance or model update, not individual agent config. Do NOT diagnose individual topics/instructions when all agents move together. Retest 3x with median before investigating.
37. **Instruction-evaluation design mismatch** — When instructions change behavioral pattern (ask-first → answer-first) but test cases still expect the old pattern, the agent fails for following its own instructions. PT 94% of conv cases expect "ask for record_id" but instructions say "answer directly." OT scores 95% because its instructions were never changed. Microsoft Learn: "If agent response is acceptable, fix the evaluation." Detect via Dataverse componenttype 19 analysis. See `references/eval-case-instruction-mismatch-detection.md`.
38. **Microsoft Learn 3-run baseline** — Run eval 3x, use average. ≤5% variance = normal. >10% = investigate grader first. For <30 test cases, 1 failed case = 3%+ swing. For 50+ cases, 5%+ change is meaningful. Flaky cases (pass 2/3) = evaluation too rigid.
39. **Instruction budget consolidation** — Microsoft Learn: as prompts grow, instruction conflicts become more likely. Consolidate overlapping rules (PT had citation rules 5x, now 1x), prioritize critical rules first, simplify verbose sections, externalize clinical checklists into knowledge sources. Produced 16-23% size reduction across PT/SLP/TDA without changing semantic meaning.
40. **General quality grading for open-ended questions** — Microsoft Learn: "General quality judges relevance, groundedness, completeness, and abstention. Expected answers are not required for open-ended broad clinical/compliance questions." Switch from rigid MultiTurnEvaluationCase to General quality when evaluation cases have stale conversational flow expectations.
41. **NEVER rewrite MultiTurnEvaluationCase data via Dataverse API** — Attempting to transform evaluation cases from prompt-first to answer-first by rewriting the `data` field collapsed 6-turn conversations into 2-turn cases, breaking the evaluation system for ALL agents. The YAML structure is extremely sensitive to line endings (`\r\n` vs `\n`), text quoting, and activity count. The correct fix per Microsoft Learn: change the GRADING METHOD to General quality in the Copilot Studio UI, which doesn't require rigid expected transcripts. If you must modify test case data, use the Copilot Studio UI, not the API. Reverting required restoring 40 cases from backup JSON files.
42. **Instruction consolidation reduces variance** — Microsoft Learn's "instruction budget problem" guidance: consolidate overlapping rules (citation rules 5x→1x), prioritize critical rules first, simplify verbose sections. Produced 16-23% size reduction across PT/SLP/TDA. Fewer instructions = fewer coin flips for the model = more consistent responses.
44. **Topic interactive menu failures dominate when agents have 30+ guided topics** — QM Coach V2 had 48 custom topics, most designed as interactive wizards. 20/29 eval failures (69%) were topics returning menus/cards instead of text answers. Instruction cleanup had zero effect on score. Fix: restructure topics to give text answer first, offer interactive menu as follow-up.
45. **Chrome CDP hangs on heavy SPA eval pages** — Navigating to eval detail pages with 100 test cases causes Chrome to hang (30s CDP timeout). Fix: `--disable-background-timer-throttling --disable-renderer-backgrounding` flags. If already hung, kill + restart Chrome; the `curl` health check still works (HTTP not WebSocket) so it's deceptive.
46. **Copilot Studio Topics page requires overflow tab navigation** — `/topics` URL redirects to `/overview`. The Topics tab is hidden behind the "+N" overflow tab. Click the overflow tab, then click "Topics" from the dropdown at coordinates visible in the dropdown list. The dropdown also shows Knowledge, Tools, Agents, Activity, Evaluation, Analytics, Channels.
47. **Conversation eval breaks after topic deletion** — Deleting topics via Dataverse API causes conversation evals to return 0% with "Error" on all cases. The agent returns empty ("--") because it routes to deleted topics. Single-response evals are unaffected because they don't use multi-turn routing. FIX: Republish after deletion (re-indexes topic list), then re-run conversation eval. The republish takes ~15 min to propagate. Evidence: QM Coach V2 deleted 10 duplicates → SR 95% but Conv 0%.
48. **"By agent" topics use AI routing, not trigger phrases** — Modern Copilot Studio agents use "By agent" trigger type for custom topics. The agent's AI picks the topic based on the topic's name + description, NOT keyword matching. Adding triggerPhrases to "By agent" topics has no effect. Focus on topic descriptions for routing. Only "Phrases" trigger type uses keyword matching. — When ALL modified agents return 0% Error, run an UNMODIFIED agent (e.g., OT if you only changed PT/SLP/TDA) as a control. If control also returns 0%, it's confirmed platform-wide. If control passes, the issue is agent-specific. June 18, 2026: OT (untouched) also got 0%, proving evaluation service failure. Also check: pac copilot list (all bots Active/Provisioned = env healthy), Dataverse API (bot table query works = API healthy). If env + API healthy but evals fail = evaluation service is the broken component.

49. **API-created topics need `data` field set** — When creating topics via Dataverse API POST, the `data` field must be set to the empty shell template (NOT null, NOT full YAML). The `content` field gets the full YAML. Setting `data` to full YAML causes eval regression (95%→12%) because the engine uses `data` for matching. Setting `data` to null makes the topic invisible in the Copilot Studio UI. See `references/api-topic-creation-and-interactive-wizards.md`.
50. **Interactive wizard topics break SR eval** — Topics with `kind: Question` nodes that ask multiple questions before answering (facility selection, audience selection, pattern selection) cause single-response eval failures. The eval expects a text answer; the wizard responds with a question. Fix: restructure to provide direct text answer FIRST via SendActivity, then offer interactive wizard as follow-up. DoR Summary and Resident Outlier Analysis both had 3 Question nodes each.
51. **Never blame the platform first** — When eval scores drop dramatically (95%→12%), the root cause is almost always topic-level (Question nodes, missing EndDialog, interactive menus, inactive guards), not platform/model issues. Always check topic content before assuming platform problems. This pattern confirmed across PT, OT, SLP, TDA, QM Coach V2. — A topic with wrong `componentName` or wrong `kind` (e.g., `OnUnknownIntent` instead of `OnRecognizedIntent`) crashes the entire agent publish with "Something went wrong" (full page crash with Session Id). The frontend `$kind` parser fails at `Array.reduce`. QM Coach V2's Power BI topic had the Fallback topic's content pasted in. DETECTION: Query all topics via Dataverse API, check for componentName mismatches, 0-char content, and wrong intent kinds. FIX: Delete the corrupted topic via API, republish.
50. **Stub topics cause publish instability (Jun 19, 2026)** — Topics with <300 chars containing "under development" or "placeholder" are stubs. Having 18 stubs caused intermittent publish crashes. Delete all stubs via Dataverse API before publishing. QM Coach V2 had 18 stubs deleted → publish crash fixed.
51. **Topic cleanup sequence matters (Jun 19, 2026)** — When cleaning up an agent with many topics, delete in this order: (1) empty/0-char topics, (2) stubs, (3) duplicates, (4) broken references, (5) interactive menus. After each batch, republish to verify no crash. Don't delete everything at once — incremental deletion helps isolate which batch caused a publish failure.
52. **Dataverse API POST creates invisible topics (Jun 20, 2026)** — Topics created via `POST /api/data/v9.2/botcomponents` return 204 success but are INVISIBLE in Copilot Studio UI unless the `data` field is also set. The `content` field alone is not enough. After creating a topic via API, PATCH the `data` field with the YAML content. Without this, the topic exists in Dataverse (queries return it) but doesn't appear in the topic list.
53. **Dataverse API PATCH content field rejection (Jun 20, 2026)** — `PATCH /api/data/v9.2/botcomponents(id)` with `{ content: yamlString }` returns 400 with "Unexpected character encountered while parsing value: k". The API's JSON parser tries to parse the YAML content as JSON. Cause unclear — works for some topics but not others. Workaround: use Monaco editor injection via `document.execCommand('insertText')` instead.
54. **Monaco `execCommand('insertText')` works but save can silently fail (Jun 20, 2026)** — `document.execCommand('insertText', false, yamlContent)` successfully replaces Monaco editor content (verified by reading back from DOM). But clicking Save may not persist the changes. The Space+Backspace dirty-state trick doesn't always trigger React's onChange. If content doesn't persist after save, user must manually paste and save.
55. **Never blame the platform without evidence (Jun 20, 2026)** — When eval scores drop, the FIRST action must be to dump all topic content via Dataverse API and check for Question nodes, interactive menus, missing EndDialog, and stubs. Do NOT assume it's a platform/model issue. User explicitly corrected this: "theres a root cause. even with my other agents, you said it was a platform or system thing but it was erroring because it was broken guard topics and broken logic." The topic diagnostic pattern (check `kind: Question`, `buttons:`, missing EndDialog) catches 90%+ of eval failures.
52. **Topic `data` field must be minimal shell (Jun 20, 2026)** — When creating topics via Dataverse API POST, the `data` field MUST be set to the minimal AdaptiveDialog shell (~121 chars), NOT the full YAML content. Setting `data` to full YAML (1818 chars) caused QM Coach V2 SR to drop from 95% to 23%. The Copilot Studio engine uses `data` for routing/matching — full content in `data` confuses the routing engine. Without `data`, topic is invisible in UI. Correct: `data` = shell template, `content` = full YAML. See `references/dataverse-topic-creation.md`.

49. **Interactive Question nodes break SR eval** — Topics with `kind: Question` or `kind: AdaptiveCardPrompt` nodes cause single-response eval failures. The agent responds with a question instead of a text answer. Fix: replace Question/AdaptiveCard nodes with `SearchAndSummarizeContent` + `EndDialog`. QM Coach V2 had DoR Summary (3 Question nodes) and Resident Outlier Analysis (3 Question nodes) causing 95%→12% SR regression.
50. **Dataverse API PATCH content field returns 400** — Patching `content` field of `botcomponents` via `/api/data/v9.2/botcomponents({id})` returns 400 "Unexpected character encountered while parsing value: k". The API tries to parse YAML as JSON. Workaround: use Copilot Studio UI code editor with `document.execCommand('insertText')`.
51. **Monaco execCommand save silently fails** — `document.execCommand('insertText', false, text)` injects content into Monaco editor after Ctrl+A, but Save may not persist. The injected content appears correct in the editor but doesn't trigger React's onChange. The only reliable fix is manual user paste + Save.
52. **Topic `data` field required for UI visibility** — Topics created via Dataverse API POST with only `content` set won't appear in Copilot Studio UI. Must also set `data` field. Pre-existing topics have `data` = empty shell template (~121 chars), `content` = full YAML (~1300+ chars).
53. **NEVER blame platform before checking topic content** — User correction: "Even with my other agents, you said it was a platform or system thing but it was erroring because it was broken guard topics and broken logic." ALWAYS audit topic YAML for Question nodes, broken actions, and interactive menus before diagnosing platform/model issues.
54. **Live evaluation Gateway API + per-agent quota** — For multi-agent sweeps, capture the Evaluation page's SPA `authorization` plus `x-cci-*` headers and call PowerVA gateway directly. Cookies alone are insufficient. Use `GET /makerevaluations?count=10`, `POST /makerevaluations`, and `GET /makerevaluations/{runId}/details`. The active-run quota is per agent: SR and Conv for the same agent must be sequential, but different agents can run simultaneously. See `references/live-evaluation-gateway-api.md`.
55. **Eval detail parsing pitfall** — Do not mark cases failed by scanning for metric property strings like `abstention: No`, `relevance: Yes`, or `completeness: Yes`; those are often passing values. Use `aggregatedGraderResults` for totals and each case/query metric `evaluationResult`, `executionState`, and `errorCodes` for failures. The full details live under `details.testCases[]`.

See `copilot-studio/instructions-editor/references/topic-audit-and-cleanup.md` for the full audit methodology.

## Topic Cleanup Before Instruction Fixes (Critical Priority)

When an agent has 30+ topics, **run topic cleanup BEFORE instruction changes**. Topic-level issues cause 90%+ of eval failures, not instruction problems. See `references/topic-cleanup-before-instructions.md` for the full diagnostic sequence and impact evidence.

## Anti-Pattern: Blaming the Platform (June 2026)

When eval scores drop dramatically (e.g., 95% → 12%), NEVER assume it's a platform/model issue first. The root cause is almost always topic-level:

1. Check topic content for `kind: Question` nodes (interactive wizards break SR)
2. Check guard topics for broken logic
3. Check for inactive topics (statecode != 0)
4. Check for missing EndDialog
5. Check for interactive menus/cards (AdaptiveCardPrompt)

**Evidence:** QM Coach V2 SR dropped 95% → 12%. Initial diagnosis blamed platform. Actual root cause: DoR Summary and Resident Outlier Analysis were interactive wizards with 3 Question nodes each. Restructuring to direct-text-answer-first pattern would fix it.

See `references/api-topic-creation-and-interactive-wizards.md` for the full analysis.

## Topic Cleanup Impact on Eval Scores

Deleting stub, duplicate, and interactive menu topics can dramatically improve eval scores without changing instructions. On QM Coach V2: 71% → 95% after deleting 31 topics (18 stubs, 10 duplicates, 3 broken).

**Why it works:**
- Stub topics ("under development") return unhelpful responses
- Interactive menu topics return cards/menus instead of text answers (eval expects text)
- Duplicate topics cause routing confusion
- The agent's general knowledge (grounded in knowledge sources) gives better answers than stub/interactive topics

**When to try:** Before rewriting instructions or topics, audit the topic list first. Use the Dataverse API to classify all topics by content length and content type. Delete stubs (< 300 chars), duplicates, and interactive menus. Republish and re-eval.

See `copilot-studio-development-workflow/references/topic-audit-cleanup.md` for the full audit workflow.

## Therapy Audit SR Eval: No-Caveat Standards-Check Pattern

For therapy documentation Single Response evals, the General Quality grader often marks clinically correct caveats as abstention/incomplete. Avoid leading with phrases like “cannot confirm without the note,” “mock audit,” “typical note,” or “please provide the note.” Instead answer directly with a standards-based check:

```text
Compliant only if the note includes: ...
Noncompliant/missing if: ...
Risk level: ...
Recommended compliant wording: ...
```

This pattern mattered for SLP daily notes, recertification, evaluation prognosis/POC, progress-note baseline comparison, discharge status/follow-up, and for TDA routing prompts that ask for PT/OT/SLP audits without source text. See `references/therapy-audit-eval-no-caveat-pattern.md` for the exact session-proven details and caution about parsing `details.testCases[].queries[].metrics.queryResponseMetrics[]`.

## TDA Routing Agent Specifics

TDA is an orchestration router, not an audit agent. Its instructions must explicitly reference:

1. **Connected child agents by exact name** — PT_Specialist, OT_Specialist, SLP_Specialist. Copilot Studio uses these names to route to the actual connected agents. If the instructions just say "route to the PT specialist" without the exact connected agent name, routing may fail. Always verify the exact connected agent names in Copilot Studio before writing TDA instructions.

2. **Medicare Part A/B routing context** — TDA must understand and infer Medicare context from the user's question:
   - Part A: SNF stays under PDPM, MDS assessments, Section GG functional outcomes, Part A evaluation/progress notes, recertification periods
   - Part B: Outpatient therapy, Plan of Care (485), CPT billing codes, discharge summaries
   - TDA should infer the Medicare part from context (e.g., "SNF daily note" = Part A; "outpatient progress note" = Part B) and pass this to the specialist
   - Without this context, TDA produces generic routing that doesn't set up the specialist for success

3. **Discipline-specific routing triggers** — Map each discipline to its document types:
   - PT: evaluation, daily note, progress note, recertification, discharge, CPT coding (97161-97164), caregiver training, fall risk, gait/balance
   - OT: evaluation, daily note, progress note, recertification, discharge, splinting/orthotics, caregiver competency, ADLs, functional cognition
   - SLP: evaluation, daily note, dysphagia, cognitive-communication, voice, motor speech, AAC, caregiver education, tracheostomy

4. **Keep TDA instructions SHORT** — TDA scored most stable with simplest instructions (28 lines, 27% SR range). Adding verbose routing logic increases variance. The specialist produces the full audit; TDA just routes.

**Pitfall: TDA instructions without child agent names.** If TDA instructions say "route to the appropriate specialist" without naming PT_Specialist/OT_Specialist/SLP_Specialist, the routing may not find the connected agents. Always use the exact Copilot Studio connected agent names.

## Windows Notepad Opening Pitfall

When opening files in Notepad from git-bash terminal:
- `cmd.exe /c start notepad "path"` — often opens behind other windows, user can't see it
- `powershell.exe -Command "Start-Process notepad -ArgumentList 'path'"` — same issue
- **Reliable fallback**: Open File Explorer to the directory with `Start-Process explorer -ArgumentList 'D:\path'` and let the user double-click the files

User preference: Always open instruction files FIRST before doing anything else. The user wants to review and paste instructions into Copilot Studio as the first action.

**Notepad opening is unreliable** — `powershell.exe Start-Process notepad` and `cmd.exe /c start notepad` both often open Notepad behind other windows where the user can't see it. The user will say "I don't see Notepad" or "it's not showing up."

**Reliable approach:**
1. First try: `powershell.exe -Command "Start-Process notepad -ArgumentList 'path'"`
2. If user says they can't see it: open the FOLDER instead with `powershell.exe -Command "Start-Process explorer -ArgumentList 'D:\path'"` and let them double-click
3. If even that fails: just tell them the file path and let them open it manually

Do NOT keep retrying Notepad opens — if the first attempt fails, switch to folder approach immediately.

## Pitfalls

### CDP/Playwright: functions defined outside `page.evaluate` cannot be called inside it

When writing Dataverse batch-patch scripts that connect via CDP (`chromium.connectOverCDP`), any helper function (like `replaceInput`) defined in the Node outer scope is NOT available inside `page.evaluate`. The evaluate callback runs in the browser context, not the Node context.

**Symptom:** `ReferenceError: replaceInput is not defined` inside `page.evaluate`.

**Fix:** Do the replacement inline inside `page.evaluate`:
```javascript
const oldData = String(row.data || '');
const body = {
  name: row.name === tc.q ? newQ : row.name,
  data: oldData.split(tc.q).join(newQ)
};
```

### Grader analysis: do not search raw JSON for failure strings

When analyzing eval results, do NOT search the raw detail JSON for strings like `"abstention":"Yes"` or `"completeness":"No"` to identify failures. These strings appear inside the grader's `explanations` text field (which describes what the grader found), NOT in the actual metric values.

**Correct approach:** Read `graderMetrics.queryResponseMetrics[0].properties.abstention` (and `.relevance`, `.completeness`) as the actual metric values. `"No"` for abstention and `"Yes"` for relevance/completeness are PASSING signals. A case fails only when `executionState` is not `Evaluated`, or when the actual metric values indicate failure.

### PowerVA gateway: daily 20-run quota per agent

The PowerVA evaluation gateway enforces a rolling 24-hour quota of 20 runs per agent. This is separate from the active-run limit. When exceeded, the API returns HTTP 422 with `fairusagepolicy.botrunquotaviolated`.

**Workflow:** Before each launch, count recent runs with `startTime` within 24h. If at 20, stop and record handoff. Each run (including cancelled ones) counts toward the quota.

### Windows background processes: use Python, not Node

The `terminal` tool's `background=true` mode runs through bash on Windows. Node.js scripts started this way fail with `stdin is not a tty`. Use Python scripts for long-running background polling instead.

### Static catch-all guardrails have a ceiling

For therapy audit agents, a static `SendActivity` catch-all answer (returned for ALL unmatched questions) scores ~85% at best. Longer answers regress to ~78%. The agent answers better when it routes to the right topic and answers directly. Fix routing (trigger phrases, modelDescription) instead of expanding catch-all text. See `copilot-studio-instructions-v9/references/ot-superanswer-guardrail-pattern.md` for the full OT case study.

## Linked Files

- `references/score-calibration-mismatch.md` — when eval score Match fails but Risk Match passes: common calibration failures (recert scored too low, bad notes floored too low, excellent notes not capped at 95) with rubric and debugging steps.
- `references/therapy-audit-eval-no-caveat-pattern.md` — Therapy audit SR eval pattern: avoid source-text caveats that grade as abstention; use direct “Compliant only if...” standards checks; includes TDA/SLP session-proven details and eval-detail parsing path.
- `references/topic-content-diagnostic.md` — Topic content diagnostic pattern: dump all topics via Dataverse API, check for Question nodes, interactive menus, missing EndDialog, stubs. Includes fix templates.
- `scripts/start_chrome_cdp.ps1` — PowerShell script to kill + restart Chrome with CDP port 9223 (preserves auth)
- `references/model-retirement-detection.md` — Detecting "model was retired" shared root cause for simultaneous Conv regression patterns, detection script, and remediation workflow.
- `references/slp-conv-test-case-mapping.md` — Full SLP Conv test case mapping (20 cases, used for caregiver topic diagnosis)
- `references/dataverse-instruction-extraction.md` — Read agent instructions via Dataverse `data` field (reliable, avoids SPA quirks) | `passagenttesting` skill | 
- `references/inactive-topic-detection.md` — Detect and batch-activate inactive guard topics via Dataverse API (PT Conv 74%→95% fix)
- `references/eval-trigger-pattern.md` — Correct button sequence: click "Evaluate" on test set card, NOT "New evaluation"
- `references/kb-description-fix.md` — Fix blank/auto-generated knowledge source descriptions via Dataverse API PATCH
- `references/agent-description-conflict.md` — Agent description conflicts with instructions causing SR regression (PT 96%→82%) + Playwright fix technique
- `copilot-studio-topic-yaml-fixes` skill — YAML fix templates and pitfalls
- `references/power-bi-connector-setup.md` — Power BI connector setup for Copilot Studio agents (service principal auth, DAX queries, HIPAA guardrails)
- `references/qm-coach-v2-topic-audit.md` — Example topic overlap audit: 62→52 topics, 10 duplicates deleted, eval 71%→95%
- `references/dataverse-topic-creation.md` — Dataverse API topic creation: `data` field must be minimal shell, causes 95%→23% SR if wrong

| Agent | Bot ID | Type | Notes |
|-------|--------|------|-------|
| OT | `73b45e98-af7a-443a-aa12-6d8a05118530` | Audit | 5 topics, unconditional RF |
| PT | `593407f3-539b-490f-84ac-d74e13216c81` | Audit | 5 topics, conditional RF |
| SLP | `6e437a77-a5dc-4984-90eb-4924eab10006` | Audit | 5 topics + Dysphagia, always RF |
| TDA | `4d0ed0d3-30f6-f011-8406-000d3a37eba2` | Routing | Routes to specialists, KEEP 800-char CB |

Environment: `Default-03cc92c3-986c-4cf4-ae27-1478cf99d17f`
