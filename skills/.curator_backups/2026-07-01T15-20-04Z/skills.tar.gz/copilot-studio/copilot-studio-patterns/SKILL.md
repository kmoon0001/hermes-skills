---
name: copilot-studio-patterns
description: "Pattern library index for Copilot Studio agent design — 15 proven patterns for JIT context, routing, hardening, observability, and more."
---

# Copilot Studio Pattern Library

Pattern library for Copilot Studio agent design. Patterns are recommendations, not requirements.

## Pattern Index

### JIT Glossary (patterns/jit-glossary.md)
Loads customer-specific acronyms into global variable on first message so orchestrator can expand them before searching knowledge.
When: glossary/acronym list needed, knowledge search quality poor due to abbreviations.

### JIT User Context (patterns/jit-user-context.md)
Loads current user's M365 profile (country, department) into global variables for personalized answers.
When: country/department/role-aware answers needed, agent needs M365 Users connector.

### Dynamic Topic Redirect (patterns/dynamic-topic-redirect.md)
Uses Switch expression inside BeginDialog to route to different topics based on variable.
When: route to one of several topics based on variable, replace nested ConditionGroup nodes.

### Prevent Child Agent Responses (patterns/prevent-child-agent-responses.md)
Stops child agents from messaging users directly by instructing them to use output variables.
When: child agent should return data without messaging user, parent controls all responses.

### Date Context (patterns/date-context.md)
Injects current date into agent instructions using Power Fx for accurate date-relative responses.
When: date-relative questions, schedules/calendars/deadlines, date interpretation causing confusion.

### Orchestrator-Generated Variables (patterns/orchestrator-variables.md)
Uses AutomaticTaskInput to classify or extract structured data from user's message at orchestration time — zero extra cost.
When: route knowledge searches by category, extract classification without asking user.

### Prevent Tool Call Leaks (patterns/prevent-tool-call-leaks.md)
Stops orchestrator from leaking internal reasoning and tool call metadata to end user.
When: users see raw JSON in responses, agent has connector actions invoked indirectly.

### Channel-Aware Behavior (patterns/channel-aware-behavior.md)
Detects host channel from System.Activity.ChannelId and gates behavior per surface (Teams, M365 Copilot, web, Direct Line, voice).
When: feature works on one channel but breaks on another, need to detect Teams vs M365 Copilot.

### RAI Error Handling (patterns/rai-error-handling.md)
Classifies Azure OpenAI content-filter errors by subcode in OnError topic. Azure OpenAI only.
When: industry-specific error messages for RAI violations, category-specific handling.

### Line Breaks in Messages (patterns/line-breaks-in-messages.md)
Uses `<br /><br />` inside message/question nodes for reliable paragraph spacing across channels.
When: bot messages feel like walls of text, multi-part questions need visual separation.

### Knowledge Hold Message (patterns/knowledge-hold-message.md)
Sends randomized hold message during knowledge search so users know agent is working.
When: noticeable knowledge-search latency, users abandoning conversations.

### Deterministic MCP Calls (patterns/deterministic-mcp-calls.md)
Workarounds for MCP tool invocation reliability. Option 1: name tool in instructions. Option 2: child agent wrapper.
When: MCP tool must fire every time for specific intent but orchestrator skips it.

### Chain of Thought Logging (patterns/chain-of-thought-logging.md)
Sends high-level Thinking messages during multi-step orchestration for observability.
When: agent uses multiple tools/MCP servers/child agents, users experience long silences.

### Conversation History Variable (patterns/conversation-history-variable.md)
Captures best-effort conversation transcript into variable for escalation, logging, downstream automation.
When: need conversation context for live-agent escalation, downstream tool needs history.

### Teams Production Hardening (patterns/teams-production-hardening.md)
Eight coordinated production patterns for Teams and M365 Copilot: reinstalls, stale context, resets, diagnostics.
When: deploying/hardening agent on Teams, stale context after long-running conversation.

### Action Execution Order (patterns/action-execution-order.md)
SendActivity as the first action in a topic fires BEFORE SearchAndSummarizeContent or AnswerQuestionWithAI. The guardrail text is what the eval grader evaluates. Removing the guardrail without adding a replacement SendActivity causes `unsupportedactivity.notextresponse` execution failures (not grader failures — the eval framework can't capture Topic.Answer without an explicit send).
When: editing topic action flow, adding/removing guardrails, troubleshooting ExecutionFailed eval results, or optimizing topic response quality.

### Card → Generation → Audit (patterns/card-generation-audit.md)
Collects structured clinical data via AdaptiveCard (click buttons, minimal typing), generates a polished note via SearchAndSummarizeContent, then routes to compliance audit. For post-session documentation assistants where therapists capture session data with button clicks and the AI writes the note.
When: building a documentation agent that should minimize typing, AdaptiveCard data collection topics that need note generation, or clinical note workflows requiring compliance review after generation.

## Combining Patterns
- JIT Glossary + JIT User Context -> merge into single conversation-init topic
- Date Context + JIT User Context -> both in instructions
- Orchestrator Variables + JIT User Context -> classify AND personalize
- RAI Error Handling + Teams Production Hardening -> handle subcodes first, then diagnostic card
- Knowledge Hold Message + Chain of Thought Logging -> reduce perceived latency

## How to Use
Advisor: present as suggestion, explain challenge solved, use status-appropriate language (proven/recommended/experimental).
Author: when implementing chosen pattern, read pattern file for correct YAML structure.

Read pattern files at: D:/my agents copilot studio/pipeline/patterns/
