---
name: copilot-studio-add-node
description: Add or modify nodes in existing Copilot Studio topics (SendActivity, Question, ConditionGroup, etc.)
category: copilot-studio
---

# Add Node to Topic

Add or modify nodes in existing Copilot Studio topics. Nodes are elements inside a topic's actions array (SendActivity, Question, ConditionGroup, etc.). Different from actions/*.mcs.yml which are connector-based TaskDialogs.

For generative answers (SearchAndSummarizeContent, AnswerQuestionWithAI), use copilot-studio-add-generative-answers instead.

## Instructions

1. Auto-discover agent directory: Glob **/agent.mcs.yml. NEVER hardcode.

2. Parse arguments to identify node type, target topic file, and whether modifying existing node.

3. Look up node schema:
```bash
node "D:/my agents copilot studio/pipeline/scripts/schema-lookup.bundle.js" resolve <NodeType>
```

4. Read existing topic file to understand structure.

5. Generate/modify node with unique ID (format: <nodeType>_<6-8 random alphanumeric>) and all required properties.

6. Determine correct insertion point in actions array.

## Common Node Types

| Node | Purpose | Key Properties |
| SendActivity | Send message | kind, id, activity |
| Question | Ask user input | kind, id, variable, prompt, entity |
| SetVariable | Set/compute value | kind, id, variable, value |
| SetTextVariable | Set text with interpolation (YAML-only) | kind, id, variable, value |
| ConditionGroup | Branching logic | kind, id, conditions |
| BeginDialog | Call another topic | kind, id, dialog |
| EndDialog | End topic | kind, id |
| CancelAllDialogs | Cancel all topics | kind, id |
| AdaptiveCardPrompt | Adaptive Card | kind, id, card, output, outputType |
| SearchAndSummarizeContent | Generative answers | kind, id, variable, userInput |
| CreateSearchQuery | AI search query | kind, id, userInput, result |

## Generative Orchestration (GenerativeActionsEnabled: true)
- Prefer AutomaticTaskInput over Question nodes
- Still use Question for conditional asks or end-of-flow confirmations
- Prefer topic outputs over SendActivity for results

## Power Fx Quick Reference
- Expressions start with =
- String interpolation uses {}
- Variable init on first assignment: variable: init:Topic.MyVar
- Common: Text(), Now(), IsBlank(), !IsBlank()

## Example: Question Node
```yaml
- kind: Question
  id: question_k7xPm2
  variable: init:Topic.UserName
  prompt: What is your name?
  entity: StringPrebuiltEntity
  alwaysPrompt: true
  interruptionPolicy:
    allowInterruption: false
```

## Important
- Unique IDs: random 6-8 alphanumeric. Duplicate IDs cause errors.
- Verify node type exists in schema before generating.
- ConditionGroup needs at least one condition item with its own unique ID.
