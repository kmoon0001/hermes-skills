---
name: copilot-studio-validate
description: "Validate Copilot Studio agent YAML files — schema validation (local) and LSP-based validation (environment-aware). Use before publishing or after editing."
version: 1.0.0
author: Copilot Studio Pipeline
license: MIT
platforms: [windows, linux, macos]
metadata:
  hermes:
    tags: [copilot-studio, validation, yaml, schema, lsp]
    homepage: https://learn.microsoft.com/microsoft-copilot-studio/
---

# Validate Agent YAML

Validate Copilot Studio agent YAML files using two complementary methods.

## Method 1: Schema Validation (local, no auth needed)
```bash
node "D:/my agents copilot studio/pipeline/scripts/schema-lookup.bundle.js" validate <path-to-yml-file>
```
Checks structural correctness: action kinds, property placement, required fields.

## Method 2: LSP-based Validation (needs .mcs/conn.json)
```bash
node "D:/my agents copilot studio/pipeline/scripts/manage-agent.bundle.js" validate --workspace <path-to-agent-folder> --tenant-id <tenantId> --environment-id <envId> --environment-url <envUrl> --agent-mgmt-url <mgmtUrl>
```
Checks: YAML structure, Power Fx expressions, schema validation, cross-file references, environment-specific checks.
Connection details come from .mcs/conn.json.

## Workflow
1. Locate agent workspace (directory containing .mcs/conn.json)
## Workflow
1. Locate agent workspace (directory containing .mcs/conn.json). If no `.mcs/conn.json` exists, use explicit tenant/environment/agent IDs from the local manifest or project source-of-truth rather than inventing defaults.
2. Run schema validation first (fast, local)
3. Run LSP validation if conn.json exists (comprehensive)
4. Parse JSON output:
   - valid: true -> all files pass (may have warnings)
   - valid: false + summary.errors > 0 -> report as FAIL
   - summary.warnings > 0 -> report as WARN
5. If `pac copilot publish` fails after local validation passes, query the bot row's `synchronizationstatus.lastFinishedPublishOperation.diagnosticDetails` before guessing. The publish diagnostics can identify the exact topic/action and schema error even when the UI shows many topic errors. Example durable pattern: `MissingRequiredProperty ApiVersion` plus `DataSources cannot be empty` on a `SearchAndSummarizeContent` action usually means an unsupported datasource block was inserted into that node; remove the unsupported block and revalidate.
6. If the system requires fresh verification after edits and there is no canonical test/lint/build command, create a focused temporary verifier under the OS temp directory using `tempfile` with a `hermes-verify-` filename prefix. Run it against the changed behavior, clean it up when possible, and explicitly report it as ad-hoc verification rather than suite green. For repair/audit script changes, follow `references/ad-hoc-verification-after-repair-scripts.md`.
7. Report findings:
8. Report findings:
```
Validation Results for: <agent-name>
[PASS] <filename> — no issues
[FAIL] <filename> — <error message> (line X)
[WARN] <filename> — <warning message> (line X)
Summary: X files checked, Y errors, Z warnings
```

## For Additional Context on Errors
```bash
node "D:/my agents copilot studio/pipeline/scripts/schema-lookup.bundle.js" resolve <kind>
```

## Both Validations Are Complementary
- Schema: structural correctness (action kinds, property placement)
- LSP: Power Fx expressions, cross-file references, environment-specific rules
If either fails, fix issues before reporting success.

## When to Use
- After authoring or editing topic YAML files
- Before pushing changes to Dataverse
- When debugging publish failures
- As a gate in the publish pipeline
