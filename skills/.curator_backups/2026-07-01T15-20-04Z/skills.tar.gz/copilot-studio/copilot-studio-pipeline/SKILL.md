---
name: copilot-studio-pipeline
description: "Build, lint, deploy, and evaluate any Copilot Studio agent using D:/my agents copilot studio/pipeline/ scripts. Agent-agnostic: load alongside copilot-studio-<agent-name> for bot-specific IDs and rules."
version: 3.2.0
author: Copilot Studio Pipeline
license: MIT
platforms: [windows, linux, macos]
metadata:
  hermes:
    tags: [copilot-studio, dataverse, publish, auth, oauth, pac-cli, anti-corruption]
    homepage: https://learn.microsoft.com/microsoft-copilot-studio/
---

# Copilot Studio Pipeline — Universal Working Rules

**Rule-authoring procedure:** prefer decision-procedure framing over NEVER/ALWAYS rules. Reserve NEVER for hard engineering limits (broken OAuth). Reserve ALWAYS for code-enforced invariants (lint runs automatically). See `references/` for detailed rules per concern.

## Decision Procedure

1. **Say no to bad requests.** If a request is unsafe, against best practices, overcomplicates things, or contradicts existing work, decline with reasoning. Don't implement just because the user asked — protect the code. (User-explicit instruction, 2026-06-22.)
2. **Auth:** route through `auth_helper.cjs`. Chain: `az login` → AzureCliCredential → MSAL cache. On failure: `InteractiveBrowserCredential` (opens browser popup). On decline: ask framed as request, offer "skip this run". Skip app registration client secrets unless tenant requires it.
   - **PITFALL: `az login` tokens don't include Dynamics 365 claims.** The Azure CLI token works for ARM but returns 401 on Dataverse. Use `InteractiveBrowserCredential` with `clientId: '04b07795-8ddb-461a-bbee-02f9e1bf7b46'` and scope `https://<org>.crm.dynamics.com/user_impersonation`. This opens a browser popup each time — there's no persistent token cache between Node.js processes. For batch operations, get the token ONCE and reuse it across all API calls in a single script.
   - **PITFALL: `pac` CLI has persistent auth that works.** `pac auth select` + `pac copilot publish` use their own token store. Use `pac` for publish operations; use `InteractiveBrowserCredential` only for Dataverse API PATCH calls.
   ### `pac` CLI env mismatch.** `pac auth list` shows which environment is active. If publishing fails with "Copilot with ID not found", the active profile is pointing at the wrong org. Fix: `pac auth create --url <target_org_url>` to add the correct environment, then `pac copilot publish --bot <botId>`.
      - **PITFALL: Multi-environment pac auth.** When working across Therapy AI Dev (`orgbd048f00`) and Ensign Default (`org3353a370`), `pac auth list` shows the last-added env as active. After `pac auth create --url https://orgbd048f00.crm.dynamics.com`, Therapy Dev becomes active. To switch back: `pac auth select --index <N>`. Always verify with `pac auth list` before publish operations. The `manage-agent.bundle.js list-agents` command works against whichever env the `--environment-url` points to, independent of pac auth state.
3. **Lint is a gate:** run `topic_lint.cjs` BEFORE writing topics to Dataverse. Block on R1-R4 errors; R5-R13 are warnings. See `references/taxonomy-rules.md` for rule details.
4. **MSAL auth scripts need stdin:** When running Node.js scripts that use `@azure/msal-node` + `PersistenceCreator` from Hermes terminal (git-bash), prepend `echo "" |` to avoid `stdin is not a tty` errors. Example: `echo "" | node ./scripts/my_script.cjs`. This feeds an empty line to the MSAL browser-auth fallback prompt.
4. **Eval is append-only:** add rows to `eval_history.jsonl`, never rewrite.
5. **Don't overwrite non-empty topic content blindly.** GET first. If content is non-empty and you have a stub, stop and ask.
5. **Don't overwrite non-empty topic content blindly.** GET first. If content is non-empty and you have a stub, stop and ask.
6. **Live eval quota is real:** if `fairusagepolicy.botrunquotaviolated` appears, stop launching runs and switch to analysis/handoff until the 24-hour quota resets. If `botactiverunquotaviolated` appears, poll the active run.
7. **Validate generated YAML before eval:** parse every patched `.after.yml`/backup after `ConditionGroup`, `SendActivity`, or `additionalInstructions` edits. Dataverse `204` does not prove YAML is valid.
8. **No-text eval failures are output bugs:** `unsupportedactivity.notextresponse` means the runner saw no plain text; repair the topic/action fallback before interpreting General Quality.
9. **NEVER patch `bot.synchronizationstatus` via API.** The platform actively manages this field. Patching it gets silently reverted and can break the pac CLI with `System.ArgumentException: Invalid response format`. If pac CLI crashes after a status patch, restore the EXACT original JSON structure (including all required fields like `lastFinishedPublishOperation`, `currentSynchronizationState`, `lastPublishedDetails`) and only change `state` to `Idle`.
10. **Be autonomous.** Do obviously correct actions. Reserve questions for genuine ambiguity.
11. **Deliver files, not chat-pasted code.** No `MEDIA:` tags in CLI.

## Copying Agents Between Environments

Two approaches exist:

1. **Solutions method (official MS Learn)** — the recommended ALM path. Create a custom solution, add agents, export as .zip, import into target environment. See `references/solutions-copy-between-environments.md` for full steps, what transfers, and pitfalls. Use when: you need exact copies across environments, compliance requires official methods, or agents have complex dependency graphs.

2. **manage-agent.bundle.js clone + push** — clone agent to local folder, change target env credentials, push. Use when: you need a quick copy for testing, or the solutions method is blocked by missing security roles. Not the official ALM path.

Prefer approach 1 unless there's a specific blocker.

## Workflow Defaults

Topic YAML edits → topic_lint.cjs → test_topics.cjs → write `data` field to Dataverse via API → pac copilot publish → eval_bot capture.

- Source of truth depends on task class:
  - Topic/YAML pipeline work: local YAML file per agent is the source of truth. Never edit topics only in Dataverse.
  - Live Copilot Studio UI work (knowledge sources, uploaded files, source descriptions, official-source toggles, user explicitly says "live UI is source of truth"): inspect and edit the live UI directly, then verify the UI state. Do not substitute stale local exports for live UI facts.
- MS Learn = source-of-truth for API schemas. Pull docs before writing against unknown endpoints.
- Don't hand-roll a YAML parser.
- **`data` field** = authoring YAML, patchable via Dataverse API PATCH.
- **`content` field** = compiled/runtime YAML, only patchable via Copilot Studio UI. Publishing does NOT sync `data` → `content`.

## Pipeline Folder Layout

```
D:/my agents copilot studio/pipeline/
├── auth_helper.cjs         # DefaultAzureCredential chain + InteractiveBrowserCredential fallback
├── topic_lint.cjs          # R1-R7, R9-R13 lint over topic YAMLs (R8 removed — HITL is a design choice, not a lint error)
├── test_topics.cjs         # Automated test suite (yaml, structure, lint, knowledge, triggers)
├── publish_pipeline.cjs    # Auth → Lint → Test → Empty-check → pac publish → Eval-capture
├── eval_bot.cjs            # Tries PP REST eval API; falls back to "unavailable" row; gates
├── routing_matrix.json     # Per-topic intent / triggers / expected_response_shape
├── eval_history.jsonl      # Append-only run history (git-track it)
├── agents/                 # Per-agent config files (BOT_ID, ENV_ID, ORG_URL, topic path)
│   └── <agent-name>.json
└── references/             # Per-concern rule files (see below)
    ├── anti-corruption-checklist.md  # Pre-patch detection, write pattern, post-patch verify
    ├── taxonomy-rules.md             # Copilot Studio taxonomy rules + lint rule mapping
    ├── hitl-patterns.md             # HITL confirmation patterns (MS Learn best practice)
    ├── common-pitfalls.md           # Known failure modes + R1-R13 mapping
    ├── api-endpoints-verified.md    # Endpoint status catalog
    └── preferred-auth.md            # Auth decision tree
```

## Reference Files (load when needed)

| File | When to load |
|------|-------------|
| `references/therapy-ai-agents-master-reference.md` | **START HERE** — full journey, remediation log, all rules, FAQ, agent-specific details |
| `references/anti-corruption-checklist.md` | Before ANY patch to botcomponent data field |
| `references/taxonomy-rules.md` | When authoring or reviewing topic YAML |
| `references/hitl-patterns.md` | When building patient-facing confirmation flows |
| `references/common-pitfalls.md` | When debugging publish failures or eval regressions |
| `references/content-vs-data-fields.md` | Why `content` PATCH fails (400) and only `data` is writable via API |
| `references/api-endpoints-verified.md` | Before writing code against a new API endpoint |
| `references/dataverse-api-quirks.md` | Before patching botcomponent fields via Dataverse API — content vs data, auth, \r issues |
| `references/playwright-auth-pattern.md` | When writing Playwright tests against Copilot Studio (storageState auth, Dataverse API alternative) |
| `references/preferred-auth.md` | When auth chain fails and you need the fallback procedure |
| `references/ms-skills-for-copilot-studio-repo.md` | Microsoft's open-source Copilot Studio plugin: schema-lookup, manage-agent, eval-api, templates, patterns. Use for schema validation, push/pull via LSP binary, draft eval testing, and YAML template reference. |
| `references/pacific-coast-case-historian-v2.md` | PCCH V2 agent: bot ID, schema, topic inventory, connected agents, fixes applied, lint status. Load when working on this agent. |
| `references/solutions-copy-between-environments.md` | MS-supported method for copying agents between environments using Power Platform solutions. Step-by-step, what transfers, pitfalls. Load when user wants to duplicate/migrate agents across environments. |
| `references/static-audit-pac-org-fetch.md` | Fallback static audit: use `pac org fetch` + Python to extract all component YAML when `pac copilot extract-template` crashes (PAC CLI v2.7.4 bug). Parses raw PAC output to `.mcs.yml` files for linting/audit. |

## Microsoft's Open-Source Plugin (schema-lookup, manage-agent, eval-api)

Cloned at `C:\Users\kevin\skills-for-copilot-studio`. See `references/ms-skills-for-copilot-studio-repo.md` for full details.

Key tools we can integrate:
- **schema-lookup.bundle.js** — validates YAML against the 884KB JSON schema. Use BEFORE writing topics to prevent hallucinated `kind:` values. This is the #1 source of YAML errors.
- **manage-agent.bundle.js** — push/pull/clone/publish via the VS Code extension's LSP binary. Alternative to `pac copilot publish` + Dataverse API PATCH. Auto-validates before push.
- **eval-api.bundle.js** — test DRAFT agents via Power Platform Evaluation API without publishing. Critical for autonomous iteration loops: edit → validate → eval on draft → fix → repeat.
- **17 YAML templates** in `templates/` — starting points for topics, actions, knowledge, variables, agents. All use `_REPLACE` placeholders for unique IDs.
- **14 patterns** in `patterns/` — proven implementation patterns (JIT glossary, channel-aware behavior, deterministic MCP calls, etc.)

**Prerequisites for manage-agent**: VS Code Copilot Studio extension (`ms-copilotstudio.vscode-copilotstudio`) must be installed — it provides the LSP binary.

## `data` vs `content` Field: Patching Limitation

The Dataverse API `PATCH` on `botcomponent.data` updates authoring YAML but does NOT sync to `content` (runtime YAML). Publishing reads from `content`. If `content` has broken YAML, publish fails with `MissingRequiredProperty` even though `data` is valid. The only fix is editing the topic in Copilot Studio UI → More → Open code editor. No API path to patch `content`.

## `SearchAndSummarizeContent` Must Have `SendActivity`

Every topic with `SearchAndSummarizeContent` + `variable: Topic.Answer` MUST have a `SendActivity` node (`activity: =Topic.Answer`) before `EndDialog`. Without it, the eval framework sees no text response → `unsupportedactivity.notextresponse`. The `EndDialog` must also have `clearTopicQueue: true`.

## How to Research (MS Learn MCP pattern)

1. `mcp_microsoft_learn_microsoft_docs_search` with the most specific query.
2. Read the canonical doc. Note: a single doc can hide multiple endpoints.
3. For API surface, hit `mcp_microsoft_learn_microsoft_docs_fetch` against the `learn.microsoft.com/en-us/rest/api/...` reference.
4. Find a *related* called-out endpoint — cross-check before assuming.
5. Confirm with a live probe via `auth_helper.getBearerToken(scope)` + `fetch()`.

## Automated Testing

```bash
node test_topics.cjs                                  # test all topics
node test_topics.cjs --agent qm_coach_v2              # test specific agent
```

Also runs automatically as step 3/6 in `publish_pipeline.cjs`. Exit 0 = pass, exit 1 = must fix before publish. System topics (OnUnknownIntent) and aggregate files (consolidated/fine_tuned) are skipped automatically.

## Debugging

All scripts use Node.js `console.log/error/warn`. Pipe to log file: `node publish_pipeline.cjs qm_coach_v2 2>&1 | tee pipeline.log`. When things break: check `probe()` for auth, `topic_lint.cjs` for YAML errors, `eval_history.jsonl` for last successful run.

## Microsoft Repo Tools (added 2026-06-25)

The `microsoft/skills-for-copilot-studio` repo scripts are now available at `D:/my agents copilot studio/pipeline/scripts/`. These COMPLEMENT the existing pipeline tools — they don't replace them.

| Script | Purpose | When to Use |
|--------|---------|-------------|
| `schema-lookup.bundle.js` | Local YAML validation + schema queries | BEFORE writing any YAML — verify kind values exist |
| `manage-agent.bundle.js` | Push/pull/clone/publish via VS Code LSP binary | Push local changes to cloud, pull remote changes |
| `eval-api.bundle.js` | PP Evaluation API — test DRAFT agents | Eval on draft WITHOUT publishing — fast iteration |
| `connector-lookup.bundle.js` | Connector operations lookup | When adding/editing connector actions |
| `chat-with-agent.bundle.js` | Detect auth mode + M365 SDK chat | Testing published agents |
| `directline-chat.bundle.js` | DirectLine v3 chat | Testing agents with no auth / manual auth |

**CRITICAL: eval-api tests DRAFT agents.** This changes the iteration loop:
```
OLD: edit → lint → publish → eval → fix → republish → re-eval
NEW: edit → lint → eval-api (draft) → fix → re-eval → publish (only when passing)
```
Use `eval-api.bundle.js` for rapid iteration. Only publish after eval passes.

**Schema-lookup prevents hallucinated kinds.** The #1 YAML error source is using `kind:` values that don't exist in the schema. ALWAYS run `schema-lookup.bundle.js kinds` or `schema-lookup.bundle.js search <kind>` before writing YAML.

## How to Extend

Before adding any new feature, fallback, or abstraction, run this check:
1. Does the existing auth chain / lint / test already handle this case?
2. Will this add code that needs maintenance but rarely gets used?
3. Is there a simpler path (e.g. "don't do that" instead of "add a fallback for when it fails")?

- Auth: `require('./auth_helper.cjs').getBearerToken(scope)`. Never re-implement.
- Lint rule: add R14+ to `topic_lint.cjs` with MS Learn reference at top.
- Test: add `test*` function in `test_topics.cjs`, call from `main()`.
- Pipeline stage: drop `.cjs` in pipeline folder, add `stepN+1()` to `publish_pipeline.cjs`.
- New agent: create `agents/<agent-name>.json` with bot_id, env_id, org_url, topic_path.

## Dataverse API: content vs data Fields (Jun 22, 2026)

**`content` field is NOT writable via PATCH** — despite MS Learn listing it as `IsValidForUpdate: True`. PATCHing `content` returns 400: "Unexpected character encountered while parsing value: k". The platform has a server-side plugin that rejects direct writes. Only `data` (OBI format) is writable.

**`pac copilot publish` does NOT sync `content` from `data`** — after publishing, `content` remains stale if it was previously different from `data`. The two fields stay out of sync.

**Implication**: To update the live agent's behavior, you must update `content` through the Copilot Studio UI (code editor), NOT via the Dataverse API. The API can only update `data`, `name`, `statecode`, and `description`.

**Workaround for topic fixes**: If the `data` field already has the correct YAML (no Question nodes, uses Activity.Text), the fix is done — but `content` must be updated via the UI for the live agent to use it. Guide the user to paste YAML into the code editor.

## Session Pitfalls (Lessons Learned)

### Test before restructure
We restructured SKILL.md into reference files BEFORE running the test suite on the live agent. This was backwards — we built rules around assumptions, not data. **Always run test_topics.cjs on the agent first, see what fails, fix the agent, THEN restructure docs.**

### Exclude aggregate files from linting and testing
Files matching `consolidated|fine_tuned|all_topics|backup|archive` are `pac copilot pull` export artifacts — source control snapshots with empty sub-entries. They trigger false failures. Both `topic_lint.cjs` and `test_topics.cjs` now filter them out.

### Skip system topics (OnUnknownIntent)
Topics with `beginDialog.kind: OnUnknownIntent` are system topics (Conversational Boosting, Fallback, etc.). They have no trigger phrases by design. Both `topic_lint.cjs` and `test_topics.cjs` skip them.

### R8 (HITL) was too broad
R8 fired on ANY topic with SearchAndSummarizeContent + EndDialog but no AdaptiveCard. This caught informational topics (DoR Summary, Resident Outlier) that search knowledge and display results — they don't take actions. Per MS Learn, Adaptive Card confirmation is for actions (write to EHR, send to patient), not for displaying information. Removed R8 from both linter and test suite.

### InteractiveBrowserCredential opens browser every time
`InteractiveBrowserCredential` from `@azure/identity` opens a browser popup for EVERY `getToken()` call if the cached token is expired. The token expires in ~1 hour. Each new Node.js process needs a fresh browser interaction. User frustration: "why does it keep asking login".

**Fix**: Get the token ONCE at the start of the script and reuse it for all API calls. Do NOT call `getToken()` in a loop or per-request. Pass the token string to all functions.

**Better alternative**: Use `pac` CLI for publish operations (it has persistent auth). Use `InteractiveBrowserCredential` only for Dataverse API calls that `pac` can't do.

### GPT instruction corruption detection
Query `botcomponents` where `componenttype eq 15` for the bot using `_parentbotid_value` (not `botid`). Check for:
- Size above 6000 chars (QM Coach V2 was 7768 — above ceiling)
- Duplicate section headers ("RESPONSE LENGTH" appears >1x)
- Ghost components (0-char empty entries — delete them)
- Mid-word splices, BOM characters

### GPT instruction remediation workflow
When eval scores are low, follow this diagnosis path:
1. Query GPT components (`componenttype eq 15`) — check size and duplication
2. If >6000 chars: compress. Remove inline knowledge source list (model already has access via knowledge config). Consolidate overlapping sections.
3. Check topic `additionalInstructions` for overlap with GPT-level instructions. Each topic should have ≤4 focused bullets (Kiro guardrail). Detailed format guidance belongs at topic level; behavioral guidance belongs at GPT level.
4. Delete ghost components (0-char entries).
5. PATCH via Dataverse API, publish, re-test.

### Dataverse API auth (Jun 22, 2026)
- `az login` tokens DON'T work for Dataverse — returns 401 "insufficient_claims" even with correct resource audience. The `az` token is for Azure Resource Manager, not Dynamics 365.
- `InteractiveBrowserCredential` from `@azure/identity` works but opens a browser popup each time and tokens expire fast (~1 hour). No persistent cache between Node.js processes.
- `pac` CLI has persistent auth and works for `pac copilot publish`, but there's no way to extract the token for use in custom scripts.
- **Workaround for scripts**: Use `InteractiveBrowserCredential` with `tokenCachePersistenceOptions: { name: 'session_name', enableUnprotectedStorage: true }` to cache tokens within a single process. All API calls must happen in the same Node.js process — token can't be reused across processes.
- **Best path for topic updates**: Edit topics in Copilot Studio UI (code editor) rather than via API. The API can PATCH `data` but NOT `content`, and publishing doesn't sync them.

### content vs data field divergence (Jun 22, 2026)
- `data` = source YAML (authoring format). PATCHing works via API.
- `content` = compiled YAML (runtime format). PATCHing fails with 400 even for identical content.
- Publishing does NOT sync `content` from `data`. They can diverge.
- If `content` has stale patterns (e.g., Question nodes) but `data` is correct, the live agent may still exhibit the old behavior.
- **The only way to update `content` is through the Copilot Studio UI code editor.**
- Pattern: topics with correct `data` but stale `content` need manual UI fix + publish.

### System topics are off-limits (Jun 22, 2026)
- DO NOT modify system topics (Multiple Topics Matched, End of Conversation, Goodbye, Conversational boosting, etc.) via Dataverse API.
- Modifying them breaks `pac copilot publish` with a generic "Failed" error.
- If accidentally modified, user must reset them in Copilot Studio UI (topic menu → Reset to default).
- System topics have `beginDialog.kind: OnSystemRedirect` or `OnSelectIntent` — detect and skip these in batch operations.

### Routing matrix must use YAML filenames
The routing_matrix.json originally used display names ("Coaching Corner") but YAML files use snake_case ("coaching_corner"). Rebuilt to use actual YAML filenames as identifiers, pulled trigger phrases directly from YAML.

### Dataverse `content` field is NOT patchable via API
**CRITICAL:** Despite MS Learn listing `content` as IsValidForUpdate: True, the Dataverse API rejects PATCH requests on the `content` field with "Unexpected character encountered while parsing value: k". The platform has a server-side plugin that processes `content` differently from `data`. **Only `data` is patchable via API.** The `content` field can only be updated through the Copilot Studio UI. See `references/dataverse-api-quirks.md` for full details.

### `data` does NOT sync to `content` on publish
Publishing via `pac copilot publish` succeeds but does NOT regenerate `content` from `data`. The two fields can diverge: `data` (authoring YAML, writable via API) and `content` (compiled/runtime YAML, only writable via UI). If `data` is correct but `content` is stale, the live agent uses the stale `content`. **To sync, edit the topic in Copilot Studio UI and save.**

### `content` field can be EMPTY (0 chars) for most topics
After API patches to `data`, the `content` field may remain at 0 chars for most topics. Only topics that were previously published successfully have non-zero `content`. When the platform tries to publish, it compiles `data` → `content`. If the `data` YAML was previously broken (malformed indentation, missing properties), the compilation produces invalid content missing required properties like `ExpressionText`. The publish error `MissingRequiredProperty 'ExpressionText'` on `end-topic` or `search-answer` action IDs means the compiled content is broken. Fix: rebuild `data` with clean YAML structure, then publish from Copilot Studio UI.

### `synchronizationstatus` cannot be overridden via API
The platform's internal state machine manages the `synchronizationstatus` field on the `bot` entity. PATCHing it via Dataverse API returns 204 but the platform immediately reverts to its internal state (e.g., "Synchronizing"). Do not waste time trying to reset stuck publish states via API. The only way to clear a stuck publish is from the Copilot Studio UI (cancel if available, then re-publish).

### pac CLI crashes on modified `synchronizationstatus`
If `synchronizationstatus` JSON is modified (e.g., removing `lastFinishedPublishOperation` or changing structure), `pac copilot publish` crashes with `System.ArgumentException: Invalid response format`. The pac CLI's `CopilotPublishStatus.FromJsonString` requires the exact original JSON structure. Fix: do not modify `synchronizationstatus` via API. If it's already broken, publish from Copilot Studio UI instead.

### `\r` characters from Dataverse API break YAML parsing
The Dataverse API returns `content` and `data` fields with `\r` (carriage return) line separators embedded in YAML block scalars. When written to files, these `\r` characters break `js-yaml` parsing. **Always strip `\r` from API responses before YAML processing:** `content.replace(/\r/g, '')`.

### System topics are protected — do not modify
Topics named "Multiple Topics Matched", "End of Conversation", "Goodbye", "On Error", "Reset Conversation", "Conversational boosting", "Sign in" are system topics. Modifying their `data` field (e.g., removing Question nodes) breaks `pac copilot publish`. **These topics are managed by the platform — leave them alone.**

### Question-node topics and Single Response eval
Topics with `kind: Question` nodes that ask "please paste the document" before answering will fail Single Response eval — the eval expects a direct answer, not a question. Fix: remove the Question node, set `userInput: =System.Activity.Text`, connect trigger directly to `SearchAndSummarizeContent`. This fix must be done in the Copilot Studio UI (see `content` field pitfall above).

### Schema validation MUST precede YAML authoring
NEVER write a `kind:` value without verifying it exists via `schema-lookup.bundle.js`. Hallucinated kind values are the #1 source of YAML errors. Use `kinds` to list all valid values, `resolve` to get full structure, `search` to find by keyword. The schema file is 884KB/27604 lines — always use the script, never load the full JSON.

### `.mcs.yml` files cause R1 false positives
Agents cloned via `pac copilot pull` or Copilot Studio export use `.mcs.yml` file extension. The `topic_lint.cjs` R1 rule checks for periods in topic names, but treats the `.mcs.yml` extension as part of the name — flagging every file. **Ignore R1 errors on `.mcs.yml` files.** The actual topic display name is in the YAML `componentName` field (e.g., "PT Clinical Analysis"), not the filename. R1 only matters for `.yaml` files where the filename IS the topic name.

### System topic sub-entries in bundled `.mcs.yml` files
Exported `.mcs.yml` files can contain MULTIPLE topic definitions bundled in one file. `topic_lint.cjs` parses each sub-topic separately, producing entries like `ConversationStart.mcs [topic 1/7]`. System topics (OnUnknownIntent, OnError, OnSystemRedirect) in these bundles have empty `beginDialog.actions` and 0 trigger phrases by design — these are NOT errors. Filter lint output by removing lines containing `[topic` to see only the real custom topic issues.

### ConditionGroup+Question removal recipe (SR eval fix)
Topics with `kind: Question` nodes in `elseActions` of a `ConditionGroup` cause Single Response eval collapse (95→12%). The proven fix:

1. Delete the entire `ConditionGroup` block (from `- kind: ConditionGroup` to the next top-level `- kind:` action)
2. Change `userInput:` on the `SearchAndSummarizeContent` node from `=Topic.PastedNote` (or similar variable) to `=System.Activity.Text`
3. Verify the topic still has `kind: EndDialog` with `clearTopicQueue: true`

This removes the "please paste your notes" question and makes the topic answer directly from whatever the user sends. Validated on 11 topics in Pacific Coast Case Historian (2026-06-26). Topics with legitimate multi-step Question flows (e.g., OCRTextExtraction with file→type→goal collection) are exempt — but ensure they end with `EndDialog`.

### BOM character stripping
Exported YAML files sometimes start with `\uFEFF` (BOM). This breaks `js-yaml` parsing. Fix: `sed -i '1s/^\xEF\xBB\xBF//' filename.mcs.yml` (bash) or read as buffer and slice off first 3 bytes if they match `0xEF 0xBB 0xBF`.

### `npm run test` must be configured for verification
When setting up Playwright tests, update `package.json` scripts to: `"test": "npx playwright test tests/agent-smoke.spec.ts"`. The default placeholder (`echo "Error: no test specified" && exit 1`) causes verification failures even when tests pass via `npx playwright test` directly. Always configure the npm script.

### `pac org fetch` crashes with stack overflow on `botcomponents`
pac CLI v2.7.4+ has a bug where querying the `botcomponents` entity (even with `count='5'` or `page='1'`) causes a .NET stack overflow in `ZipIterator`. This affects any FetchXML query against `botcomponents` regardless of filter or page size. The `bot` entity works fine.

**Workaround:** Use the Dataverse REST API directly via `auth_helper.cjs` + `fetch()`, or use the browser to inspect agent content. Do NOT attempt `pac org fetch --xml "...entity name='botcomponents'..."`.

### `pac copilot extract-template` crashes in v2.7.4
`pac copilot extract-template --bot <id> --templateFileName <path> --templateVersion 1.0.0 --overwrite` loads all components successfully ("Loaded 37 components...") then crashes with `System.ArgumentException` and a session ID. This is a PAC CLI bug in v2.7.4 — not a parameter issue.

**Workaround:** Use `pac org fetch` with custom XML including `botcomponent.data` attribute to extract component YAML, then parse the raw output. Or use `manage-agent.bundle.js clone` if the VS Code Copilot Studio LSP is available. Do not loop retrying `extract-template` after the first crash.

### `pac env list` for environment GUID discovery
When switching between environments (Dev vs Prod), use `pac env list` to find the environment GUID in the "Environment ID" column. Match by "Display Name" (e.g., "Therapy AI Agents Prod"). Use this GUID with `--environment` or `--environment-id` flags. The Copilot Studio environment URL format `https://copilotstudio.microsoft.com/environments/<friendlyName>-<tenantId>/bots/...` is NOT the same as the Dataverse environment GUID used by `pac auth create --environment <guid>`.

### CDP Batch Topic Patching (Kiro Chrome)
When `manage-agent push` fails (LSP binary `vscode-jsonrpc/node` unavailable) and Dataverse API auth needs browser interaction, use CDP with Kiro Chrome's cached auth:

1. Launch Chrome with Kiro profile: `chrome.exe --remote-debugging-port=9223 --user-data-dir="C:\Users\kevin\AppData\Local\Programs\Kiro\.playwright-auth"`
2. Navigate to Dataverse org to establish auth session
3. Use `fetch()` from browser context to PATCH `botcomponents.data` field for each topic
4. Script: `D:/my agents copilot studio/pipeline/cdp_patch_topics.cjs`
5. Usage: `node cdp_patch_topics.cjs patch-all` (patches all local .mcs.yml files to matching live topics)
6. Rate limit: 500ms between PATCH calls
7. Auth check: if `window.location.href` contains `login`, the session needs refresh

**PITFALL:** Kiro Chrome's auth may expire. If CDP script reports "Not authenticated", user must log in via the Chrome window on their machine first, then re-run the script.

### manage-agent push fails with LSP binary
`manage-agent.bundle.js push` fails with `Cannot find module 'vscode-jsonrpc/node'` when the VS Code Copilot Studio extension's LSP binary has dependency issues. This is a known issue — do not edit the bundle script. Use CDP batch-patch or Copilot Studio UI code editor instead.

### MS Learn URL discovery when direct guesses fail
Copilot Studio docs are restructured frequently — guessed URLs 404. Use the TOC JSON to find correct pages:
```bash
curl -sL "https://learn.microsoft.com/en-us/microsoft-copilot-studio/toc.json" | python -c "
import json,sys
data=json.load(sys.stdin)
def walk(items):
    for i in items:
        h=i.get('href',''); t=i.get('toc_title','')
        if any(k in (t+h).lower() for k in ['solution','export','import','copy','alm']):
            print(f'{t}: {h}')
        walk(i.get('children',i.get('items',[])))
walk(data.get('items',[]))
"
```
This returns the actual slugs (e.g., `authoring-solutions-import-export`) which you prefix with `/microsoft-copilot-studio/` to build the full URL.

### Browser automation can't expand Copilot Studio instruction editors
The "Edit" button next to Instructions in Copilot Studio's Overview page doesn't expand a contenteditable div in automated browsers (Playwright/Puppeteer). The page renders the same content after clicking. This is likely due to React state management or conditional rendering that doesn't trigger in headless/CDP contexts.

**Workaround:** Use the Dataverse REST API to read instruction content (botcomponent type 15), or use `manage-agent.bundle.js clone` to pull agent content locally. Don't waste time trying to click Edit in browser automation.

## Process Rules

- **Finish one agent before starting the next.** User has an explicit ordering. Do not jump between agents mid-task. Complete all fixes for one agent (topic fixes → instruction fixes → publish → eval) before moving to the next. User called this out when I started working on SLP instead of QM V2.
- **Test before restructure.** Always run `test_topics.cjs` on the actual agent BEFORE building new rules or restructuring docs. Validate with real data first, then organize. Don't build infrastructure around assumptions.
- **Skip aggregate files in tests.** `test_topics.cjs` skips files matching `consolidated|fine_tuned|all_topics|backup|archive` — these are `pac copilot pull` export snapshots, not active topic definitions. Same filter as `topic_lint.cjs` for R5 overlap.
- **Skip system topics in tests.** Topics with `beginDialog.kind: OnUnknownIntent` are system topics (Conversational Boosting, Fallback, etc.) — they don't have custom triggers and aren't expected to pass custom topic rules.
- New reference file: add to `references/`, add one-line pointer in the Reference Files table above.
- **Copy agents between environments:** solutions method (official) vs clone+push (quick). Solutions method requires System Customizer role and Dataverse on target. See `references/solutions-copy-between-environments.md`.
