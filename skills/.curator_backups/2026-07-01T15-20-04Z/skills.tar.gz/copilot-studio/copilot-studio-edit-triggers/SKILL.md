---
name: copilot-studio-edit-triggers
description: Modify topic triggers — trigger phrases (triggerQueries) and model description (modelDescription) in Copilot Studio topic YAML files.
---

# Edit Topic Triggers

Modify how a topic gets triggered: trigger phrases (triggerQueries) and model description (modelDescription).

## Instructions

1. Auto-discover agent directory: Glob **/agent.mcs.yml. NEVER hardcode.

2. Find target topic: Glob <agent-dir>/topics/*.topic.mcs.yml

3. Read topic file and identify what to change.

4. Check settings.mcs.yml for GenerativeActionsEnabled — determines which mechanism matters most.

## Model Description (modelDescription)
Natural language description at root of AdaptiveDialog telling generative orchestrator when to route to this topic. When GenerativeActionsEnabled: true, this is the PRIMARY routing mechanism.

```yaml
kind: AdaptiveDialog
modelDescription: This topic helps users order a pizza by collecting their preferred size, toppings, and delivery address.
beginDialog:
  kind: OnRecognizedIntent
  id: main
```

### Best Practices
- Write clear, specific sentence describing what the topic does and when to use it
- Focus on user's intent: "Use this topic when the user asks for..."
- Include key scenarios the topic covers
- Keep concise but complete
- Avoid vague descriptions like "This topic handles requests"

### When to Add/Edit
- ALWAYS add modelDescription to OnRecognizedIntent topics when GenerativeActionsEnabled: true
- Update when topic purpose/scope changes
- System triggers (OnError, OnUnknownIntent, OnConversationStart) don't need modelDescription

## Trigger Phrases (triggerQueries)
Used for intent recognition. Live inside beginDialog.intent.triggerQueries.
Only OnRecognizedIntent topics have editable trigger phrases.

### Operations
- Add phrases: append to triggerQueries
- Remove phrases: delete from triggerQueries
- Replace phrases: swap old for new
- Rewrite all: replace entire triggerQueries array

### Best Practices
- Use 5-10 phrases per topic
- Cover synonyms and variations
- Include different sentence structures (questions, statements, keywords)
- Avoid overlap between topics
- Keep phrases short and natural
- Mix formal and informal phrasing

### Example
```yaml
kind: AdaptiveDialog
modelDescription: This topic helps users with greeting and introduction.
beginDialog:
  kind: OnRecognizedIntent
  id: main
  intent:
    displayName: Greeting
    triggerQueries:
      - Hello
      - Hi
      - Hey
      - Good morning
      - Good afternoon
```

## Limitations
- Cannot change trigger TYPE (e.g., OnRecognizedIntent to OnConversationStart) — requires recreating topic
- Cannot add triggers to system topics that don't use OnRecognizedIntent
