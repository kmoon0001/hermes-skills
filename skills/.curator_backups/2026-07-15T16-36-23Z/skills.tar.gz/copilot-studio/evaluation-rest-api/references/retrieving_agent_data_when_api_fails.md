# Retrieving Agent Data When Standard API Calls Fail

## Problem
When attempting to access Copilot Studio agent data via the Power Platform Dataverse API (e.g., to retrieve current topic instructions, component details, or evaluation results), you may encounter authentication or token validation errors such as:
- `Error: Unable to validate token`
- `Error code: 0x80060888`
- `UnauthenticatedUser` errors

These issues can occur due to:
- Expired or improperly scoped access tokens
- Service-to-service authentication challenges in certain environments
- Temporary issues with the Azure AD token acquisition process

## Solution: Leverage Previously Captured Session Data
When direct API calls fail, you can fall back to using data that was previously captured during an authenticated browser session. This approach leverages the fact that while service-to-service authentication might be problematic, an interactive user session in the browser often remains valid.

### Step 1: Capture Live Agent Data (During a Working Session)
Use a tool like Playwright to connect to an existing Chrome/Edge debugging session and extract the agent's component data via the Dataverse API using the browser's authenticated session.

Example script structure:
```javascript
const { chromium } = require('playwright-core');
const fs = require('fs');
const path = require('path');

(async () => {
  // Connect to Chrome debugger endpoint (adjust port as needed)
  const browser = await chromium.connectOverCDP('http://127.0.0.1:9223');
  const context = browser.contexts()[0] || await browser.newContext();
  const page = await context.newPage();
  
  const org = 'https://yourorg.crm.dynamics.com';
  const botId = 'your-bot-id-guid';
  
  // Navigate to org to establish context
  await page.goto(org, {waitUntil: 'domcontentloaded', timeout: 45000});
  await page.waitForTimeout(10000);
  
  // Fetch bot components (adjust filter as needed)
  const filter = `_parentbotid_value eq '${botId}' and (componenttype eq 9 or componenttype eq 15)`;
  const url = `${org}/api/data/v9.2/botcomponents?$select=botcomponentid,name,componenttype,statecode,description,schemaname,content,data&$filter=${encodeURIComponent(filter)}&$top=5000`;
  
  const result = await page.evaluate(async ({org, url}) => {
    const r = await fetch(url, {credentials:'include', headers:{
      'Accept':'application/json',
      'OData-MaxVersion':'4.0',
      'OData-Version':'4.0'
    }});
    return {status:r.status, text:await r.text()};
  }, {org, url});
  
  // Save to file for later analysis
  const outDir = './path/to/save/dumps';
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, {recursive:true});
  fs.writeFileSync(path.join(outDir, `${botId}_components_response.json`), result.text, 'utf8');
  
  await page.close();
  await browser.close();
})();
```

### Step 2: Extract Specific Information from the Dumped Data
Once you have the JSON dump file, you can parse it to extract the information you need.

Example (Node.js) to extract instructions (componenttype 15):
```javascript
const fs = require('fs');
const path = require('path');

const filePath = './path/to/dumps/TDA_components_response.json';
const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
const components = data.value || [];

// Find the instructions component (componenttype 15)
const instructionsComponent = components.find(c => c.componenttype === 15);
if (instructionsComponent) {
  console.log('Instructions Component ID:', instructionsComponent.botcomponentid);
  console.log('Instructions Component Name:', instructionsComponent.name);
  console.log('Instructions Data (first 500 chars):');
  console.log(instructionsComponent.data?.substring(0, 500) || 'No data field');
} else {
  console.log('No component with componenttype 15 (instructions) found');
}

// You can similarly extract other component types:
// - componenttype 9: Topics
// - componenttype 16: Entities
// - etc.
```

### When to Use This Approach
- You need to inspect the current state of an agent's topics/instructions for debugging
- Standard API calls are failing due to authentication issues
- You have access to a machine where the agent was recently viewed in a browser (so a recent dump exists or can be created)
- You are troubleshooting evaluation score discrepancies and need to verify what content is actually deployed

### Advantages
- Bypasses service-to-service authentication issues
- Uses the same authenticated context as a logged-in user
- Provides access to the exact same data that the web interface sees
- Can be done without modifying the agent or requiring additional permissions

### Limitations
- Data is only as fresh as the last dump
- Requires initial setup to capture the data
- Large bots may result in large JSON files
- Does not allow for making changes (for that, you would still need working API access)

## Integration with Existing Workflows
This technique complements the existing fallback strategy mentioned in the evaluation-rest-api skill ("Fallback: CDP-sniff from a Chrome session"). It provides a concrete implementation of that fallback concept, allowing you to:
1. Capture agent state during a working session
2. Retrieve and analyze that state later when API access is problematic
3. Use the extracted information to inform fixes, updates, or evaluation preparations

For example, if you're troubleshooting why an agent's evaluation score dropped, you could:
1. Compare the current deployed instructions (from a fresh dump) against a known-good version
2. Identify unintended changes that may have been introduced
3. Use this information to guide a targeted fix