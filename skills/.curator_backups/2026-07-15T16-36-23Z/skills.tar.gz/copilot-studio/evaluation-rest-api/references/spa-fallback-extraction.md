# SPA Body Text Fallback — Evaluation Score Extraction

When the REST API returns RouteNotFound (June 2026+), extract scores from
the Copilot Studio evaluation SPA page.

## Proven Approach

```javascript
const { chromium } = require('playwright-core');
const authPath = 'D:/my agents copilot studio/.playwright-auth/state.json';
const envId = 'Default-03cc92c3-986c-4cf4-ae27-1478cf99d17f';

const browser = await chromium.launch({
  headless: true,
  executablePath: 'C:/Program Files/Google/Chrome/Application/chrome.exe',
  args: ['--no-sandbox'],
});
const ctx = await browser.newContext({ storageState: authPath });
const page = await ctx.newPage();

// Navigate and wait for grid
await page.goto(
  `https://copilotstudio.microsoft.com/environments/${envId}/bots/${botId}/evaluation`,
  { timeout: 30000, waitUntil: 'domcontentloaded' }
);
await page.waitForTimeout(25000); // SPA needs long render time
await page.keyboard.press('Escape'); // dismiss overlays
await page.waitForTimeout(2000);

const text = await page.evaluate(() => document.body.innerText);
```

## Parsing the Grid

The body text renders as a flat list. Each evaluation run row follows this pattern:

```
<run name>
<test case count> • Data type: <single response|conversation>
Evaluate
<test set name>
<initials>
<author>
<timestamp>
General quality
End of interactive chart.
<score>%
```

### Reliable Parse Pattern

Scores are consistently N lines after "Data type:" markers:

```javascript
const lines = text.split('\n');
const runs = [];
let currentRun = null;

for (let i = 0; i < lines.length; i++) {
  const l = lines[i].trim();
  
  // Detect start of a run row (test case count + data type)
  if (l.includes('test cases • Data type:')) {
    const isSR = l.includes('single response');
    const name = lines[i - 1]?.trim() || '?';
    
    // Score is typically 7-9 lines after "Data type:" line
    for (let j = i; j < Math.min(i + 12, lines.length); j++) {
      const pctMatch = lines[j].trim().match(/^(\d+)%$/);
      if (pctMatch) {
        runs.push({
          name,
          type: isSR ? 'SR' : 'Conv',
          score: parseInt(pctMatch[1]),
          state: lines.slice(i - 5, j + 1).join(' | ').includes('Running') ? 'Running' : 'Completed'
        });
        break;
      }
    }
  }
}
```

## Distinguishing Runs by Age

Timestamps use relative formatting:
- `X:XX AM/PM today` — today's runs
- `X:XX AM/PM yesterday` — yesterday's
- `X:XX AM/PM <day>` — older

The "Recent results" section shows ~10-15 most recent runs. Older runs
scroll off the visible grid but are still in body text.

## Limitations

- **No per-case failure details** — only aggregate scores visible
- **No aiResultReason** — cannot distinguish refusal vs incomplete vs ungrounded
- **Score only** — pass/fail counts not directly in body text (only percentage)
- **Takes 25-30s per agent** — much slower than REST API (when it works)
