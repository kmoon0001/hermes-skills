# Failure Pattern Diagnosis from Eval API Data

## How to Read `metricsResults[0].result`

### Common `data` object patterns:

| abstention | relevance | groundedness | completeness | Meaning |
|-----------|-----------|--------------|-------------|---------|
| No | Yes | Yes | Yes | ✅ PASS |
| No | Yes | Yes | No | Response complete but missing some expected content |
| No | Yes | No | No | "Knowledge sources not cited" — KB quality issue |
| Yes | NA | NA | NA | CB refusal |
| No | No | No | No | Irrelevant (likely record_id loop) |

### Failure root causes by `aiResultReason` text:

| Reason contains... | Root cause | Fix |
|-------------------|------------|-----|
| "refuses to help" | CB fallback triggered | Update CB activity string |
| "record_id" / "record ID" | Test uses record IDs agent can't resolve | Instruction: never ask for record IDs |
| "(no reason)" or null | Single-response test | Use Copilot Studio UI to inspect |
| Empty string | Conversation failure (ungrounded) | KB quality audit |

## Fixes by Failure Type

### "Knowledge sources not cited" (completeness:No + groundedness:No)
- Compare meaning is NOT available for conversation testing (Single Response only)
- Fix: KB quality audit — descriptions, Official marking, remove duplicate SharePoint sources

### CB refusal (abstention:Yes)
- Fix: Update CB YAML activity string to redirect, not refuse

### Record_id loop
- Fix: Add instruction "Never ask for record IDs when clinical text is present"
- Accept as test case limitation per MS Learn Layer 2

## Compare Meaning Limitation
- Only available for Single Response test sets
- Conversation test sets only support "General quality"
- MS Learn: "Aim for 80-90%" — some conversation failures are platform limitations
