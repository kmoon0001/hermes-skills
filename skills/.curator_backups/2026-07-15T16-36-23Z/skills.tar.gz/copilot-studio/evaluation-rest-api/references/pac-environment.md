# pac CLI Environment Switching

## Problem

`pac` CLI frequently connects to the wrong Dataverse environment. Even after `pac org select`, subsequent commands may revert to a previous environment.

## Solution

Always explicitly select the environment before queries:

```bash
pac org select --environment "https://org3353a370.crm.dynamics.com/"
```

Then verify:
```bash
pac org list
```

The `*` indicates active environment. If it shows the wrong one, re-select.

## Bot Envrionment Mapping

| Bot | Environment URL | Org |
|-----|----------------|-----|
| OT / SLP / PT / TDA | https://org3353a370.crm.dynamics.com/ | Ensign Services (default) |
| Therapy AI Dev copies | https://orgbd048f00.crm.dynamics.com/ | Therapy AI Agents Dev |

## pac org fetch Pitfalls

- **Bot table queries crash pac** — `pac org fetch` against `bot` entity with conditions causes `System.InvalidOperationException`. Use `botcomponent` table instead.
- **Memo fields crash pac** — Selecting `content` or `data` fields from `botcomponent` causes `System.ArgumentOutOfRangeException`. Read topic YAML via CDP code editor instead.
- **Componenttype filter:** Topics = 9, Knowledge Sources = 14/16, Bot File Attachments vary.
