# CDP Evaluation Score Extraction (When REST API Is Down)

When the Power Platform REST API returns RouteNotFound (token routing prefix injection
breaks the `/copilotstudio` path), fall back to CDP-driven SPA text extraction.

## Workflow

1. Connect to Chrome via WebSocket on port 9223
2. Navigate to the evaluation page via `Page.navigate`
3. Wait 25-30s for SPA to render
4. Extract `document.body.innerText` via `Runtime.evaluate`
5. Parse run names with regex `/^Evaluate\s+\S+\s+\d{6}_\d{4}$/`
6. Scores appear as standalone `^\d+%$` lines in the grid output

## Example Output (SLP_Specialist, June 12, 2026)

```
Evaluate SLP_Specialist 260612_0432  |  Conv  |  85%
Evaluate SLP_Specialist 260612_0405  |  SR    |  92%
Evaluate SLP_Specialist 260612_0229  |  SR    |  96%
```

## Pitfalls

- **First page load may return 0-200 chars**: Copilot Studio SPA needs a "warm" tab. Navigate to overview first, then evaluation.
- **Account picker blocks the page**: After sign-in, the OAuth redirect lands at `/auth#code=...`. Must `Page.navigate` again to the overview URL after auth code is detected.
- **Run extraction requires correct regex**: The run name format is `Evaluate AGENT_NAME YYMMDD_HHMM` (space-separated agent name and timestamp). `\S+\s+\d{6}_\d{4}` matches this.
- **Body text may show Running overlay**: If an evaluation is in progress, the body text will be short (~1300 chars vs ~20k for a loaded grid).

## Comparison: REST API vs CDP SPA

| Method | Reliability | Speed | Token Required |
|--------|------------|-------|----------------|
| REST API | RouteNotFound on api.powerplatform.com | Instant | Yes (Bearer) |
| CDP SPA text | Works when API is down | 30-40s per agent | No (uses Chrome auth) |
