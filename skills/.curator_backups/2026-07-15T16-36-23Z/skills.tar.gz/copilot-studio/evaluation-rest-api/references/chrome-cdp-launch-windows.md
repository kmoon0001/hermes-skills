# Chrome CDP Launch — Windows

Launching Chrome with `--remote-debugging-port=9223` on Windows requires specific steps.
The flag is silently ignored if Chrome is already running or if launched on the default profile.

## Reliable Launch Sequence

### 1. Kill ALL Chrome instances
```bash
taskkill //F //IM chrome.exe
```

### 2. Launch with clean user data directory
Use `exec()` from Node.js (NOT `spawn` — the flag is ignored):
```javascript
const { exec } = require('child_process');
exec('"C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe" --remote-debugging-port=9223 --user-data-dir="C:\\Users\\kevin\\chrome-debug-profile" --no-first-run --no-default-browser-check');
```

### 3. Wait for port
Poll `http://127.0.0.1:9223/json/version` — Chrome takes 3-8 seconds to start:
```javascript
let attempts = 0;
const interval = setInterval(() => {
  attempts++;
  http.get('http://127.0.0.1:9223/json/version', (res) => {
    // Ready when response contains "Browser": "Chrome/..."
    clearInterval(interval);
  }).on('error', () => {
    if (attempts >= 20) { clearInterval(interval); /* timeout */ }
  });
}, 1000);
```

### 4. Auth
The clean profile has no Copilot Studio cookies. Navigate to any CS page, detect the login redirect, and wait for the user to sign in. Auth cookies persist in the clean profile for subsequent sessions.

```javascript
// After navigation, check for login page
const url = (await send('Runtime.evaluate', { 
  expression: 'window.location.href', returnByValue: true 
}))?.result?.value;

if (url.includes('login.microsoftonline.com')) {
  console.log('Sign in required. Waiting for user...');
  // Poll URL until redirected to copilotstudio.microsoft.com
}
```

## What Does NOT Work

- `spawn()` from Node.js — flag silently ignored
- `cmd.exe /c start` from bash — doesn't pass flags reliably
- Launching without `--user-data-dir` on default profile — flag ignored
- Background mode (`terminal(background=true)`) on Windows — always fails with "stdin is not a tty"
- `&` backgrounding in foreground terminal mode — rejected by Hermes terminal

## Full Working Script

See `scripts/launch_chrome_windows.cjs` in the skill's scripts directory.
