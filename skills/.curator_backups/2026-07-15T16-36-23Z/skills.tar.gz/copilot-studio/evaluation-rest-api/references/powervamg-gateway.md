# powervamg SPA Gateway — Verified Recipe (tenant a944fdf0, 2026-07-12)

The documented `api.powerplatform.com/copilotstudio/.../makerevaluation/testruns` endpoint
returns 404 RouteNotFound in this tenant. The Copilot Studio SPA calls a different gateway
that WORKS for start + poll + score reads. This file is the condensed, copy-modify recipe.

## Base + headers
```
const G = 'https://powervamg.us-il107.gateway.prod.island.powerapps.com';
const E = 'a944fdf0-0d2e-e14d-8a73-0f5ffae23315';   // envId (BapEnvironmentId)
const B = 'ad635500-cf47-f111-bec5-70a8a5b1c3a3';   // botId (PCCH)
function req(u, method, token) {
  return new Promise((resolve, reject) => {
    const a = new URL(u);
    const o = { hostname: a.hostname, port: 443, path: a.pathname + a.search, method,
      headers: { 'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json',
        'X-CCI-ApplicationSource': 'Web', 'X-CCI-BapEnvironmentId': E, 'X-CCI-BotId': B,
        'X-CCI-CdsBotId': B, 'X-CCI-TenantId': '03cc92c3-986c-4cf4-ae27-1478cf99d17f',
        'X-CCI-OrganizationId': '62945552-72f5-f011-aa23-6045bd003938',
        'x-ms-user-agent': 'PVA-Portal/1.0.0', 'Accept': 'application/json',
        'Origin': 'https://copilotstudio.microsoft.com' } };
    const r = https.request(o, res => { let d=''; res.on('data',c=>d+=c); res.on('end',()=>resolve({status:res.statusCode,body:d})); });
    r.on('error', reject); r.end();
  });
}
```

## Start run
```
const r = await req(G + `/api/botmanagement/v2/environments/${E}/bots/${B}/makerevaluations`,
                     'POST', token, { testSetId: 'e1b7f7fc-e03a-4470-a29c-8ec5f77c6813' });
const { runId, state } = JSON.parse(r.body);   // state: "Queued"
```

## Read run + extract pass rate (NOTE: aggregatedGraderResults, NOT testResults)
```
const d = await req(G + `/api/botmanagement/v2/environments/${E}/bots/${B}/makerevaluations/${runId}/details`, 'GET', token);
const s = JSON.parse(d.body);
const st = s.state;                                  // "InProgress" | "Completed" | "Failed"
const a = s.aggregatedGraderResults || [];
let succ=0, fail=0, inv=0;
for (const m of a) {
  if (m.name==='totalSucceeded') succ=m.count;
  else if (m.name==='totalFailed') fail=m.count;
  else if (m.name==='totalInvalid') inv=m.count;
}
const total = succ+fail+inv;
const rate = total ? Math.round(succ/total*100) + '%' : 'n/a';
// s.runOnPublishedBot: false  -> ran on DRAFT
// s.testResults / s.testCasesResults  -> ALWAYS EMPTY on this gateway (do not poll)
```
Per-case failure reasons are NOT in this API — portal drill-down only. SR failures have no aiResultReason.

## Grader-instance variance
graderId differs per run (same criteriaType ResponseQualityGeneral). A small % swing between
two runs of the same agent/test set can be grader noise, not a real regression. Note graderId.

## Headless eval-token capture (the gateway needs the portal session token)
The Dataverse/MSAL token returns 403 here (audience mismatch). Capture the SPA session token:
```
const { chromium } = require('playwright-core');
const fs = require('fs'), path = require('path'), { execSync } = require('child_process');
const UD = path.join(process.env.LOCALAPPDATA, 'Microsoft', 'Edge', 'User Data');
const TMP = path.join(process.env.USERPROFILE, 'AppData', 'Local', 'Temp', 'edge_pw_profile');
// 1. live Edge owns UD -> exitCode=21. Copy it:
fs.rmSync(TMP, { recursive: true, force: true }); fs.mkdirSync(TMP, { recursive: true });
execSync(`xcopy "${UD}" "${TMP}" /E /I /H /R /Y /Q`, { stdio: 'ignore' });
// 2. launch against the COPY:
const b = await chromium.launchPersistentContext(TMP, { channel: 'msedge', headless: true, args: ['--remote-debugging-port=0','--no-sandbox'] });
const pg = await b.newPage();
let cap=null;
pg.on('request', r => { if (cap) return; const au=r.headers()['authorization'];
  if (au && au.startsWith('Bearer ') && /powervamg|copilotstudio|botframework/.test(r.url())) cap=au.replace(/^Bearer\s+/i,''); });
await pg.goto(`https://copilotstudio.microsoft.com/environments/${E}/bots/${B}/evaluation`, { waitUntil:'domcontentloaded', timeout:45000 }).catch(()=>{});
let w=0; while(!cap && w<35){ await pg.waitForTimeout(1500); w+=1.5; }
await b.close();
if (cap) fs.writeFileSync('C:/Users/kevin/AppData/Local/Temp/pva.txt', cap);
// token ~2824 chars, short-lived (~1h). Re-capture on 403.
```

## Background-shell lifetime cap (Hermes terminal)
terminal(background=true) shells die at ~600s. Pollers must write progress to a JSON file each
iteration and be re-launched every ~8 min until state==="Completed". Check the JSON file, not the process.
