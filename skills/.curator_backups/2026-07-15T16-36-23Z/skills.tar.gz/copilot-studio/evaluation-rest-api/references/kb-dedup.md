# KB Deduplication Guide — Copilot Studio Agents

## The Problem
Individually uploaded files (PDFs, text files) often duplicate content already in SharePoint folders. This wastes the 25-source GPT filter limit and crowds retrieval context with noise. Each source eats a slot AND competes for the GPT filter's attention.

## MS Learn Rule
**"If >25 sources, GPT filters by description."** Under 25 sources, ALL sources are sent. With blank/generic descriptions, the filter can't distinguish duplicates from unique content → retrieval picks the wrong source → ungrounded failures.

## All 4 Agents — Full Source Inventory (2026-06-12)

### OT_Specialist (11 sources — 10 websites + 1 SP, NO uploaded files)
- AOTA Scope of Practice (website)
- AOTA Home Modifications Practice (website)
- AOTA Occupational Therapy Practice Framework (website)
- AOTA Standards and Competencies (website)
- AOTA Documentation Practice Resources (website)
- AOTA Functional Cognition Practice (website)
- AM-PAC Outcome Measure - Boston University (website)
- NINDS Patient/Caregiver Education (website)
- CDC Clinical Resources (website)
- CMS Medicare Learning Network — Therapy (website)
- **Pacific Coast Therapy Swarm SP** (shared)
- **Core Clinical Manuals SP** (shared)
- **NOT present:** AOTA-APTA-ASHA Joint Consensus (in PT, TDA but missing from OT)
- **Verdict:** No uploaded files = no dedup issues. Missing the Joint Consensus.

### PT_Specialist (11 sources — websites + files)
- APTA Clinical Practice Guidelines (website)
- CMS Medicare Learning Network — Therapy (website)
- **Pacific Coast Therapy Swarm SP** (shared)
- **Core Clinical Manuals SP** (shared)
- PT Documentation Patterns (file)
- Neurologic Outcome Measures CPG (file)
- AOTA-APTA-ASHA Joint Consensus Statement (file — also in TDA)
- MDS Section GG Decision Tree (file)
- PT Documentation Compliance Specialist (file)
- Section GG alignment and PDPM classification (file)
- Fall Risk Documentation (file)
- **Verdict:** Some overlap with Core Clinical Manuals SP — verify if Ch.15 duplicates exist. Joint Consensus shared with TDA.

### SLP_Specialist (7 sources — leanest)
- ASHA Scope of Practice (website)
- CMS Medicare Learning Network (website)
- **Pacific Coast Therapy Swarm SP** (shared)
- **Core Clinical Manuals SP** (shared)
- Dysphagia Clinical Competency Assessment Tool (file)
- SLP Documentation Compliance Patterns Reference (file)
- ASHA NOMS National Outcomes Measurement System (file)
- **Verdict:** Cleanest agent. 2 SharePoint + 2 websites + 3 unique files.

### TDA (10+ sources — mostly files)
- **Pacific Coast Therapy Swarm SP** (shared)
- **Core Clinical Manuals SP** (shared)
- AOTA-APTA-ASHA Consensus Statement (file — also in PT)
- Patient-Driven Payment Model (PDPM) (file — in SP as PDPM-*.pdf? Check)
- SNF PDPM Classification Walkthrough (file — in SP as PDPM-*.pdf? Check)
- Common Therapy Documentation Compliance Gaps (file)
- Ensign 7 Habits Documentation Framework (file)
- Part A vs Part B Medicare Quick Reference (file)
- **Verdict:** PDPM files likely duplicate Core Clinical Manuals SP. Joint Consensus shared with PT.

## Known Duplicates (All 4 Agents)

### Confirmed: SharePoint ↔ Files
| Agent | Uploaded File | In SharePoint? | Action |
|-------|--------------|----------------|--------|
| SLP | CMS MDS 3.0 Section GG | ✅ MDS 3.0 RAI Manual 2026.pdf | REMOVE from SLP |
| TDA | Medicare Benefits Policy Manual | ✅ Ch.15 in SP | REMOVE from TDA |
| TDA | Medicare Part B Maintenance | ✅ In SP | REMOVE from TDA |
| TDA | PDPM files | ✅ PDPM-*.pdf in SP | REMOVE from TDA |
| TDA | Clinical Decision Support | ✅ CMS-Jimmo in SP | REMOVE from TDA |
| SLP | 42 CFR 424.24 | ✅ CFRs.docx in SP | REMOVE from SLP |

### Cross-Agent File Duplicates
| File | OT | PT | SLP | TDA | Action |
|------|----|----|-----|-----|--------|
| AOTA-APTA-ASHA Joint Consensus | ✗ | ✓ | ✗ | ✓ | Keep in PT+TDA, add to OT |
| CMS Medicare Learning Network | ✓ | ✓ | ✓ | ✗ | Keep in all (different specialty config) |

## Fix

**CRITICAL ORDER — do NOT skip steps.** Removing duplicate files before fixing
SharePoint folder names destroys the only working retrieval path without providing
a replacement, causing fleet-wide regression (all 4 agents dropped simultaneously,
June 2026).

1. **Rename SharePoint folders FIRST** to keyword-rich names (~100 chars per folder).
   See `passagenttesting` skill `references/sharepoint-regression-pattern.md` for
   before/after templates.
2. **THEN remove individually uploaded files** that are now in SharePoint.
3. Keep ONE canonical source per content type (prefer SharePoint for shared docs).
4. Add specific descriptions to ALL remaining sources (see kb-description-detection.md).
5. For files duplicated across agents (Joint Consensus), keep in agent-specific KBs
   with tailored descriptions per agent context.
