# Playwright SPA Fallback — When REST API Is Unavailable

When the Evaluation REST API returns RouteNotFound (token scoping or gateway changes) or the API is otherwise unavailable, use Playwright to extract evaluation scores directly from the Copilot Studio SPA.

## Auth: Playwright with Persistent State

```javascript
const { chromium } = require('playwright-core');
const authPath = 'D:/my agents copilot studio/.playwright-auth/state.json';

const browser = await chromium.launch({
  headless: true,
  executablePath: 'C:/Program Files/Google/Chrome/Application/chrome.exe',
  args: ['--no-sandbox'],
});
const ctx = await browser.newContext({ storageState: authPath });
const page = await ctx.newPage();
```

**Auth refresh workflow**: When the persistent state expires (shows "Pick an account"), launch headed mode (`headless: false`), let the user click through the account picker, then save auth state via `page.context().storageState({ path: authPath })`. After refresh, headless mode works again.

## Eval Page Extraction Timing

```javascript
await page.goto(
  `https://copilotstudio.microsoft.com/environments/${envId}/bots/${botId}/evaluation`,
  { timeout: 60000, waitUntil: 'domcontentloaded' }
);
await page.waitForTimeout(25000); // SPA needs 20-30s to render the eval grid
await page.keyboard.press('Escape'); // dismiss popups
await page.waitForTimeout(2000);

const text = await page.evaluate(() => document.body?.innerText || '');
// Returns 13,000-22,000 chars when SPA renders successfully
```

**Pitfall**: If body is ~100-500 chars, popups are blocking. Press Escape × 8 with 300ms delays, then retry.

**Pitfall**: If body is 0 chars, auth is expired. Relaunch in headed mode for manual re-auth.

**Pitfall**: If an evaluation is running, the grid won't show for that agent. OT showed 465 chars (evaluation running overlay) vs normal 13,000+.

## Run Parsing Regex

Each evaluation run appears in the body text as a block:

```
Evaluate OT_Specialist 260612_0405
100 test cases • Data type: single response
Evaluate
Evaluate OT_Specialist
MK
Moon, Kevin
4:05 AM today
Running
```

Or for completed runs:

```
Evaluate OT_Specialist 260612_0247
100 test cases • Data type: single response
...
2:47 AM today
General quality
End of interactive chart.
91%
```

**Run name regex**: `/^Evaluate\s+\S+\s+\d{6}_\d{4}$/` — note the SPACE between agent name and timestamp (not underscore).

**Score regex**: `/^\d+%$/` — appears 2-4 lines after the run name.

**Data type detection**: Check for `conversation` vs `single` (case-insensitive) in the lines following the run name. "single response" and "conversation" both appear.

**Status detection**: `Running` or `Failed` as standalone lines indicate non-completed runs. Absence of these + presence of `General quality` = completed.

## Full Extraction Script Pattern

```javascript
const lines = text.split('\n');
for (let i = 0; i < lines.length; i++) {
  const l = lines[i].trim();
  if (/^Evaluate\s+\S+\s+\d{6}_\d{4}$/.test(l)) {
    const runName = l.split(' ').pop(); // timestamp part
    let score = '', isRunning = false, dt = '';
    for (let j = i + 1; j < Math.min(i + 10, lines.length); j++) {
      const nl = lines[j].trim();
      if (/conversation/i.test(nl)) dt = 'Conv';
      if (/single/i.test(nl)) dt = 'SR';
      if (nl === 'Running') isRunning = true;
      if (/^\d+%$/.test(nl)) score = nl;
    }
    // Output: runName | dt | score | running?
  }
}
```

## Comparison: REST API vs Playwright SPA

| Method | Speed | Reliability | Token Scope | Best For |
|--------|-------|-------------|-------------|----------|
| REST API | <1s | High | Read-only eval | CI/CD, nightly runs |
| Playwright SPA | 25-30s/agent | Medium (SPA-dependent) | None needed (uses browser auth) | One-off checks, API down |

When the REST API returns RouteNotFound (June 2026 observed), the Playwright SPA method is the fallback. It's slower but works reliably with the persistent auth state.
