# Eval API — Working Scoring Pattern

## Quick Reference

```javascript
const https = require('https');
const fs = require('fs');

// Token from CDP capture (any agent's page, api.powerplatform.com scope)
const token = fs.readFileSync('pp_token.txt', 'utf8').trim();
const envId = 'Default-03cc92c3-986c-4cf4-ae27-1478cf99d17f';

function apiGet(botId, path) {
  return new Promise((r) => {
    const p = encodeURI(`/copilotstudio/environments/${envId}/bots/${botId}/api/makerevaluation${path}&api-version=2024-10-01`);
    https.get({ hostname: 'api.powerplatform.com', path: p, headers: { 'Authorization': `Bearer ${token}` } }, res => {
      let b = ''; res.on('data', c => b += c); res.on('end', () => { try { r(JSON.parse(b)); } catch(e) { r({}); } });
    }).on('error', () => r({ value: [] }));
  });
}

async function getScore(botId, runId) {
  const detail = await apiGet(botId, `/testruns/${runId}`);
  const tcs = detail.testCasesResults || [];
  let pass = 0, fail = 0, refuse = 0, incomplete = 0, ungrounded = 0;
  
  for (const tc of tcs) {
    const m = tc.metricsResults?.[0], status = m?.result?.status;
    const reason = m?.result?.aiResultReason || '', data = m?.result?.data || {};
    if (status === 'Pass') pass++;
    else if (status === 'Error') err++;
    else {
      fail++;
      if (reason.includes('refuses to help')) refuse++;
      if (data.completeness === 'No') incomplete++;
      if (data.groundedness === 'No') ungrounded++;
    }
  }
  return { total: pass+fail, pass, fail, rate: pass+fail>0 ? Math.round(pass/(pass+fail)*100) : 0, refuse, incomplete, ungrounded };
}

// List latest 5 runs
const runs = await apiGet(botId, '/testruns?$orderby=startTime%20desc&$top=5');
for (const run of runs.value) {
  const state = {0:'NotStarted',1:'InProgress',2:'Completed',3:'Failed'}[run.state];
  if (state !== 'Completed') { console.log(`${run.name}: ${state}`); continue; }
  const s = await getScore(botId, run.id);
  console.log(`${run.name}: ${s.pass}/${s.total}=${s.rate}% (${s.refuse} refusals, ${s.incomplete} incomplete)`);
}
```

## Key Gotchas

- **api-version MUST be `2024-10-01`** — `1` and `2023-03-01-preview` return 400 or empty
- **State is numeric**: 0=NotStarted, 1=InProgress, 2=Completed, 3=Failed
- **testCasesResults embedded in detail**, NOT in list response
- **aiResultReason only for Conversation** — SingleResponse runs return null
- **Token is per-agent**: captured from OT page works for OT, may not work for TDA. Re-capture from each agent.
- **Token is READ-ONLY** — cannot trigger evaluations
- **$filter by componenttype DOES NOT work** on botcomponents endpoint — use different queries
