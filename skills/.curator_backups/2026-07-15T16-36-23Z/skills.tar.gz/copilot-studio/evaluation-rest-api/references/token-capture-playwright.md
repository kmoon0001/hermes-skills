# Token Capture via Playwright CDP (Proven Pattern)

## Setup

```javascript
const { chromium } = require('playwright-core');
const fs = require('fs');

const browser = await chromium.launch({
  headless: false,
  executablePath: 'C:/Program Files/Google/Chrome/Application/chrome.exe',
});
const ctx = await browser.newContext({
  storageState: 'D:/my agents copilot studio/.playwright-auth/state.json'
});
const page = await ctx.newPage();
const cdp = await page.context().newCDPSession(page);
await cdp.send('Network.enable');

let token = null;
cdp.on('Network.requestWillBeSent', (params) => {
  const h = params.request.headers;
  if (h.Authorization?.startsWith('Bearer ') && params.request.url.includes('api.powerplatform')) {
    token = h.Authorization.replace('Bearer ', '');
    fs.writeFileSync('pp_token.txt', token);
  }
});

await page.goto('https://copilotstudio.microsoft.com/environments/.../bots/BOTID/overview', ...);
await page.waitForTimeout(15000);
// Token should be captured within 15s from SPA API calls
```

## Token Scope

- Captured token works for `api.powerplatform.com` evaluation endpoints (GET only)
- Does NOT work for Dataverse API (`org*.crm.dynamics.com` returns 401)
- Does NOT work for botcomponents API (different route)
- Valid ~1 hour from capture
- Token is typically 3500-4500 characters
