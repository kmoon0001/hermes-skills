# KB Description Detection

## MS Learn Rule
Per Microsoft Learn: "If there are more than 25 different knowledge sources, the agent filters the knowledge sources by using an internal GPT model based on the description given to the knowledge source." Blank descriptions = the GPT filter essentially ignores the source.

## What to Flag

### 1. EMPTY — 0/2500 characters
Microsoft never filled it in. Fix: Write a description per MS Learn format — what the source contains AND when to use it.

### 2. GENERIC — Microsoft auto-generated boilerplate
Patterns to detect:
- "This knowledge source searches information contained in [filename].txt"
- "searches the"
- "this knowledge source searches"
- "this source searches information contained"

These are auto-filled by Microsoft when you add a file. They tell the GPT filter NOTHING about when to use the source vs other sources.

### 3. One-line only
Single sentence that doesn't describe specificity. "CMS standards for medical necessity" is better than blank but barely helps the filter distinguish between 10+ sources.

## MS Learn Description Format
Every description should answer TWO questions:
1. **What does it contain?** (content summary)
2. **When should the filter pick this source?** (trigger scenarios)

Good example:
> "CMS Medicare Program Integrity Manual Chapter 3 — medical necessity determination criteria, coverage policy guidelines, and documentation standards for outpatient therapy services. Use when users ask about medical necessity, concurrent documentation requirements, or coverage denial reasons for therapy services."

Bad example (auto-generated):
> "This knowledge source searches information contained in Medicare_Program_Integrity_Manual_Chapter_3.txt"

## SharePoint Limitation

**SharePoint sources in Copilot Studio do NOT have editable descriptions.** Unlike individually uploaded files, SharePoint folder sources have NO description textarea — the folder path/name IS the only thing the GPT filter sees for routing.

### Workaround A — Rename the SharePoint folder (best for shared content)

The folder name acts as the sole description. Rename it to include keyword-rich content identifiers that tell the GPT filter what's inside.

**Formula:** `[Short Name] - [Comma-separated topic keywords]`

Example (before → after):
- Before: `Core Clinical Manuals for Medicare A, PDPM vs. Part B, LTC Rehabilitation`
- After: `Core Clinical Manuals - CMS: PDPM, Part B, MDS 3.0, Jimmo, Ch5/Ch15, Integrity, MSCA, MSP, PIP, 42 CFR`

- Before: `Pacific Coast Therapy Swarm Shared Knowledge Library`
- After: `Pacific Coast Therapy Swarm - Ensign compliance, audit standards, and documentation rules for OT/PT/SLP`

**Guidelines:**
- Keep names ~100 chars (longer may truncate in UI, but GPT filter sees the full path)
- Every word = potential routing keyword for GPT filter
- All agents sharing the folder benefit instantly — one rename improves all agents
- To rename: go to SharePoint doc library → "..." on folder → Rename

### Workaround B — Upload files individually from SharePoint (max precision)

For maximum description control, upload each PDF individually instead of the whole folder. Individual uploads give a 2500-char description field with per-file edit. Trade-off: uses more of the 25-source limit.

### Workaround C — Hybrid (recommended)

Use SharePoint folders for broad shared content (CMS manuals, regulatory docs) and individual file uploads with descriptions for specialty-specific content (PT CPGs, ASHA NOMS, PT Documentation Patterns).

## Per-Agent Status

### SLP (7 sources)
- ASHA Scope of Practice — ✅ has description ("Use this source for questions about SLP scope of practice...")
- CMS Medicare Learning Network — ✅ 335/2500 chars
- Pacific Coast Therapy Swarm SP — ✅ has description
- Core Clinical Manuals SP — ✅ has description
- Dysphagia Competency Assessment — ❓ UNKNOWN
- SLP Documentation Compliance Patterns — ❓ UNKNOWN
- ASHA NOMS — ✅ has description (but may be auto-generated "searches information contained in")
- **2 possibly blank:** FOIS Scoring Guide, 2025 Part B MSCA Rubric (may have been removed)

### TDA (10+ sources)
- Pacific Coast Therapy Swarm SP — ❓ UNKNOWN
- Core Clinical Manuals SP — ✅ has description
- All remaining files — ✅ descriptions present
- **0 blanks confirmed**

### OT (11 sources)
- All sources are public websites or SharePoint — **check needed**
- Website sources may have auto-titles with no editable descriptions
- **10 website sources likely missing descriptions**

### PT (11 sources)
- **Full check needed** — no prior session data

## Detection Tool
Run `scripts/detect_generic_descriptions.cjs` to automatically scan all 4 agents.

Note: The SPA Copilot Studio Knowledge page often fails to render in headless mode. If detection returns no results, the page didn't load — retry with headless: false and a long timeout (180s+).
