# CDP Token Capture Fix — 2026-07-03

## Problem
`scripts/cdp_ws_capture.cjs` has a hardcoded `TARGET_ID` from a prior session. Running it fails with "Tab not found" on any new browser session.

## Fix
Use `scripts/cdp_capture_token.cjs` instead — it finds the eval tab by URL pattern rather than hardcoded ID:

```bash
cd "D:/my agents copilot studio/pipeline"
node "D:/my agents copilot studio/pipeline/scripts/cdp_capture_token.cjs"
```

The script:
1. Lists all open tabs via `http://127.0.0.1:9223/json/list`
2. Finds the tab whose URL contains both `copilotstudio` and `evaluation`
3. Connects via WebSocket
4. Enables `Fetch.enable` to intercept PPAPI calls
5. Reloads the page
6. Captures the `Authorization: Bearer` header from `powerplatform.com` requests
7. Saves to `%USERPROFILE%\.copilot-studio-cli\test-agent-token.txt`

## Token Properties
- Length: ~4520 chars
- Expiry: ~15-60 minutes
- Works for: PPAPI eval operations (list test sets, start runs, poll)
- Does NOT work for: Dataverse API (different scope)

## SPA Score Reading
When PPAPI detail endpoint returns 404 RouteNotFound (known regional rollout issue), scores can be read from the evaluation SPA page via CDP:

```javascript
// Navigate to eval URL, wait 30-60s for SPA hydration
const text = await page.evaluate(() => document.body.innerText);
// Parse: find 'Completed' blocks, look for 'N%' near 'Data type:' markers
const scores = [...text.matchAll(/Completed[^]*?data type[^]*?(\d+)%/gi)];
```

Verified Jul 3 2026: PCCH eval scores (89% SR, 42% Conv) extracted from SPA via CDP when PPAPI detail returned 404.
