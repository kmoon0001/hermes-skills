# powervamg /details — Per-Case Grader Extraction (HEADLESS, no browser)

Verified 2026-07-12 against PCCH (env a944fdf0). The `powervamg` gateway
`/details` endpoint returns FULL per-case forensics. The earlier belief that
per-case reasons required the SPA/browser drill-down was WRONG — it applied
only to the empty top-level `testCasesResults` array, not `details.testCases`.

## Critical gotcha
Per-case data is populated ONLY for `state=Completed` runs. A run that is
`InProgress` returns `testCases: []` and `aggregatedGraderResults` shows 0
scored. If you query mid-flight you will wrongly conclude "no per-case data".
Wait for `state=Completed`.

## JSON path (the part that trips people up)
```
makerevaluations/{runId}/details
  .details.testCases[i]          <-- NESTED under `details`, NOT top-level
     .queries[0].query           user turn text
     .queries[0].answer          agent answer (RAW — can contain leaked
                                  Power Fx like "=Topic.Answer" or "=If(IsBlank(")
     .graderMetrics.queryResponseMetrics[0]
        .evaluationResult        'Pass' | 'Fail'
        .properties              {abstention, relevance, completeness, groundedness}
                                  values are 'Yes'/'No'/'None'
        .aiResultReason          grader critique (present on failures; richest on Conv)
```
Both SR and Conv expose `properties`. Do not classify from a substring scan of
`answer` (it misfires — a markdown heading contains no '=' but a real leak
like "=Topic.Answer" does; trust the grader `evaluationResult`).

## Working script
```python
import json, urllib.request

TOKEN = open(r'C:/Users/kevin/.copilot-studio-cli/test-agent-token.txt').read().strip()
ENV  = 'a944fdf0-0d2e-e14d-8a73-0f5ffae23315'
BOT  = 'ad635500-cf47-f111-bec5-70a8a5b1c3a3'
GW   = 'https://powervamg.us-il107.gateway.prod.island.powerapps.com/api/botmanagement/v2'
HDRS = {'X-CCI-ApplicationSource':'Web','X-CCI-BapEnvironmentId':ENV,'X-CCI-BotId':BOT,
        'X-CCI-CdsBotId':BOT,'X-CCI-TenantId':'03cc92c3-986c-4cf4-ae27-1478cf99d17f',
        'X-CCI-OrganizationId':'62945552-72f5-f011-aa23-6045bd003938',
        'Accept':'application/json','Origin':'https://copilotstudio.microsoft.com'}

def get(runid):
    url = f"{GW}/environments/{ENV}/bots/{BOT}/makerevaluations/{runid}/details"
    r = urllib.request.Request(url); r.add_header('Authorization', f'Bearer {TOKEN}')
    for k,v in HDRS.items(): r.add_header(k,v)
    return json.loads(urllib.request.urlopen(r, timeout=120).read())

d = get('RUNID_HERE')
for i, tc in enumerate(d['details']['testCases']):
    qrm = (tc.get('graderMetrics') or {}).get('queryResponseMetrics') or []
    if not qrm: 
        print(i, 'NO_METRIC'); continue
    m = qrm[0]; p = m.get('properties') or {}
    res = (m.get('evaluationResult') or '').lower()
    q = (tc.get('queries') or [{}])[0].get('query','') if tc.get('queries') else ''
    a = (tc.get('queries') or [{}])[0].get('answer','') if tc.get('queries') else ''
    if res == 'pass': 
        continue   # only print fails
    print(f"[{i}] abs={p.get('abstention')} rel={p.get('relevance')} "
          f"comp={p.get('completeness')} gnd={p.get('groundedness')}")
    print("  Q:", q[:120])
    print("  A:", a[:160])
    reason = m.get('aiResultReason') or ''
    if reason: print("  GRADE:", reason[:240])
```

## Failure-classification cheat sheet (from PCCH forensics)
| properties | typical root cause | fix |
|---|---|---|
| comp=No, rel=Yes, abs=Yes | Agent returned generic "X should be documented" boilerplate instead of extracting the patient data that WAS in the query | Add a DATA-RICH EXTRACTION rule to instructions: extract actual values from provided text; never substitute a template |
| abs=Yes, answer hedges "no info in sources / standards-based framework" | Data-sparse prompt; grader pattern-matches abstention | Add direct-answer instruction block for no-document prompts |
| answer literally `=Topic.Answer` or `=If(IsBlank(...` | Raw Power Fx leaked (SendActivity formula not evaluated) | Replace with literal text or `=Topic.Answer` only where it is the correct variable reference |
| gnd=No | KB gap (answer correct but not in sources) | Enrich KB / tighten additionalInstructions |

## Token note
The gateway token (`test-agent-token.txt`) expires ~1h. Refresh headlessly via
the MSAL cache script before a long poll or on 403:
`node ~/skills-for-copilot-studio/scripts/refresh_eval_token.cjs`
(The trailing `Assertion failed: UV_HANDLE_CLOSING` is a harmless Node exit
artifact — the token file is written successfully; check `wc -c` on the file.)
