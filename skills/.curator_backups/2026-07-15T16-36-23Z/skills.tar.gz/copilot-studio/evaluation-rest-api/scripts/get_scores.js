const https = require('https');
const fs = require('fs');

// Usage: node get_scores.js <botId> [count]
const botId = process.argv[2] || '73b45e98-af7a-443a-aa12-6d8a05118530';
const top = parseInt(process.argv[3] || '5');
const token = fs.readFileSync('pp_token.txt', 'utf8').trim();
const env = 'Default-03cc92c3-986c-4cf4-ae27-1478cf99d17f';

function api(path) {
  return new Promise((r) => {
    https.get({ hostname: 'api.powerplatform.com', path: encodeURI(path), headers: { 'Authorization': `Bearer ${token}` } }, res => {
      let b = ''; res.on('data', c => b += c); res.on('end', () => { try { r(JSON.parse(b)); } catch(e) { r({}); } });
    }).on('error', () => r({}));
  });
}

async function getScore(runId) {
  const d = await api(`/copilotstudio/environments/${env}/bots/${botId}/api/makerevaluation/testruns/${runId}?$expand=testCasesResults&api-version=2024-10-01`);
  const tcs = d.testCasesResults || [];
  let pass=0, fail=0, err=0, refuse=0, incomplete=0, ungrounded=0, irrelevant=0, abstain=0;
  for (const tc of tcs) {
    const m = tc.metricsResults?.[0], s = m?.result?.status, reason = m?.result?.aiResultReason || '', data = m?.result?.data || {};
    if (s==='Pass') pass++; else if (s==='Error') err++;
    else { fail++; if(reason.includes('refuses'))refuse++; if(data.completeness==='No')incomplete++; if(data.groundedness==='No')ungrounded++; if(data.relevance==='No')irrelevant++; if(data.abstention==='Yes')abstain++; }
  }
  return { pass, fail, err, total: pass+fail+err, rate: Math.round(pass/(pass+fail+err)*100)||0, refuse, incomplete, ungrounded, irrelevant, abstain };
}

async function main() {
  const runs = await api(`/copilotstudio/environments/${env}/bots/${botId}/api/makerevaluation/testruns?$orderby=startTime%20desc&$top=${top}&api-version=2024-10-01`);
  if (!runs.value?.length) { console.log('No runs found'); return; }
  
  console.log(`Latest ${Math.min(top, runs.value.length)} runs for ${botId}:\n`);
  for (const run of runs.value) {
    const t = new Date(run.startTime).toLocaleString('en-US', { timeZone: 'America/Los_Angeles', month:'2-digit', day:'2-digit', hour:'2-digit', minute:'2-digit' });
    if (run.state !== 'Completed') { console.log(`  ${t}  ${run.state}  — in progress`); continue; }
    const s = await getScore(run.id);
    const flags = [];
    if (s.refuse) flags.push(`${s.refuse}refusal`);
    if (s.incomplete) flags.push(`${s.incomplete}incomplete`);
    if (s.ungrounded) flags.push(`${s.ungrounded}ungrounded`);
    if (s.irrelevant) flags.push(`${s.irrelevant}irrelevant`);
    if (s.abstain) flags.push(`${s.abstain}abstain`);
    console.log(`  ${t}  ${s.pass}/${s.total}=${s.rate}%  ${flags.length ? '('+flags.join(', ')+')' : ''}`);
  }
}
main().catch(e => console.error(e));
