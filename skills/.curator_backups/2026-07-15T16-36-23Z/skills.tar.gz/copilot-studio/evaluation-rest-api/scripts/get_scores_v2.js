const https = require('https');
const fs = require('fs');
const token = fs.readFileSync('pp_token.txt', 'utf8').trim();
const envId = 'Default-03cc92c3-986c-4cf4-ae27-1478cf99d17f';
const botId = 'BOT_ID_HERE';

function api(path) {
  return new Promise((r) => {
    https.get({ hostname: 'api.powerplatform.com', path: encodeURI(path), headers: { 'Authorization': `Bearer ${token}` } }, res => {
      let b = ''; res.on('data', c => b += c); res.on('end', () => { try { r(JSON.parse(b)); } catch(e) { r({}); } });
    }).on('error', () => r({}));
  });
}

async function getScore(runId) {
  const d = await api(`/copilotstudio/environments/${envId}/bots/${botId}/api/makerevaluation/testruns/${runId}?$expand=testCasesResults&api-version=2024-10-01`);
  const tcs = d.testCasesResults || [];
  let pass=0, fail=0, err=0, refuse=0, incomplete=0, ungrounded=0, irrelevant=0, abstain=0;
  
  for (const tc of tcs) {
    const m = tc.metricsResults?.[0];
    const status = m?.result?.status;
    const reason = m?.result?.aiResultReason || '';
    const data = m?.result?.data || {};
    
    if (status === 'Pass') pass++;
    else if (status === 'Error') err++;
    else {
      fail++;
      if (reason.includes('refuses')) refuse++;
      if (data.completeness === 'No') incomplete++;
      if (data.groundedness === 'No') ungrounded++;
      if (data.relevance === 'No') irrelevant++;
      if (data.abstention === 'Yes') abstain++;
    }
  }
  
  return { pass, fail, err, total: pass+fail+err, rate: (pass+fail+err)>0?Math.round(pass/(pass+fail+err)*100):0, refuse, incomplete, ungrounded, irrelevant, abstain };
}

async function main() {
  const runs = await api(`/copilotstudio/environments/${envId}/bots/${botId}/api/makerevaluation/testruns?\$orderby=startTime%20desc&\$top=5&api-version=2024-10-01`);
  
  for (const run of (runs.value || [])) {
    const state = run.state; // STRING: "NotStarted"|"InProgress"|"Completed"|"Failed"
    const time = new Date(run.startTime).toLocaleString('en-US', { timeZone: 'America/Los_Angeles', month:'2-digit', day:'2-digit', hour:'2-digit', minute:'2-digit' });
    
    if (state !== 'Completed') {
      console.log(`${time} ${state}`);
      continue;
    }
    
    const s = await getScore(run.id);
    console.log(`${time} ${s.pass}/${s.total}=${s.rate}% r:${s.refuse} i:${s.incomplete} ung:${s.ungrounded} irr:${s.irrelevant} abs:${s.abstain}`);
  }
}

main().catch(e => console.error(e));
