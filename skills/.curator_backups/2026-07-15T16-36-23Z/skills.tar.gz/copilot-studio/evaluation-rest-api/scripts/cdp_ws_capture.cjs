const WebSocket = require('ws');
const fs = require('fs');
const path = require('path');
const http = require('http');

const TOKEN_FILE = path.join(process.env.USERPROFILE, '.copilot-studio-cli', 'test-agent-token.txt');

(async () => {
  // Find the Copilot Studio eval tab
  const pages = await new Promise((resolve, reject) => {
    http.get('http://127.0.0.1:9223/json/list', res => {
      let d = ''; res.on('data', c => d += c); res.on('end', () => resolve(JSON.parse(d)));
    }).on('error', reject);
  });
  
  const target = pages.find(p => p.url.includes('copilotstudio.microsoft.com'));
  if (!target) { console.log('Copilot Studio tab not found'); process.exit(1); }
  console.log('Found tab:', target.title.slice(0, 80));

  const ws = new WebSocket(target.webSocketDebuggerUrl);
  let token = null;
  const startTime = Date.now();

  // ONE handler — never replaced
  ws.on('message', (raw) => {
    const msg = JSON.parse(raw.toString());
    
    if (msg.method === 'Fetch.requestPaused' && !token) {
      const req = msg.params.request;
      const auth = req.headers['Authorization'] || req.headers['authorization'];
      const url = req.url;
      
      if (url.includes('powerplatform.com') || url.includes('makerevaluation')) {
        console.log('REQ:', url.slice(0, 120));
        if (auth) {
          token = auth.replace(/^Bearer\s+/i, '');
          console.log('TOKEN CAPTURED!');
        }
      }
      ws.send(JSON.stringify({ id: 9999, method: 'Fetch.continueRequest', params: { requestId: msg.params.requestId } }));
      return;
    }
    
    if (Date.now() - startTime > 45000 && !token) {
      console.log('Timeout — no token found');
      ws.close();
      process.exit(1);
    }
  });

  ws.on('open', () => {
    console.log('Connected');
    ws.send(JSON.stringify({ id: 1, method: 'Fetch.enable', params: { patterns: [{ urlPattern: '*' }] } }));
    ws.send(JSON.stringify({ id: 2, method: 'Page.reload' }));
    console.log('Reloading...');
  });

  const check = setInterval(() => {
    if (token) {
      clearInterval(check);
      fs.mkdirSync(path.dirname(TOKEN_FILE), { recursive: true });
      fs.writeFileSync(TOKEN_FILE, token);
      console.log('OK: Token saved (' + token.length + ' chars)');
      ws.close();
      process.exit(0);
    }
  }, 1000);

  ws.on('close', () => { clearInterval(check); if (!token) process.exit(1); });
  ws.on('error', (e) => { console.error('WS error:', e.message); process.exit(1); });
})().catch(e => { console.error(e.message); process.exit(1); });
