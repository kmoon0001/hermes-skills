// compare_all_knowledge.cjs — Cross-agent KB comparison scanner
// Usage: NODE_PATH="C:/Users/kevin/AppData/Roaming/npm/node_modules" node <path>/scripts/compare_all_knowledge.cjs
// Requires: .playwright-auth/state.json in D:/my agents copilot studio/
// Scans OT, PT, SLP, TDA knowledge pages and prints source lists
// Use with headless:true (no window) and terminal timeout=180s
// The browser stays open (chrome) for inspection

const { chromium } = require('playwright-core');

(async () => {
  const browser = await chromium.launch({ headless: false, executablePath: 'C:/Program Files/Google/Chrome/Application/chrome.exe' });
  const ctx = await browser.newContext({ storageState: 'D:/my agents copilot studio/.playwright-auth/state.json' });
  const page = await ctx.newPage();

  const results = {};

  for (const [name, botId] of [
    ['OT', '73b45e98-af7a-443a-aa12-6d8a05118530'],
    ['PT', '593407f3-539b-490f-84ac-d74e13216c81'],
    ['SLP', '6e437a77-a5dc-4984-90eb-4924eab10006'],
    ['TDA', '4d0ed0d3-30f6-f011-8406-000d3a37eba2'],
  ]) {
    await page.goto('https://copilotstudio.microsoft.com/environments/Default-03cc92c3-986c-4cf4-ae27-1478cf99d17f/bots/'+botId+'/knowledge', { timeout: 30000, waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(8000);
    for (let i=0;i<5;i++) { await page.keyboard.press('Escape'); await page.waitForTimeout(200); }
    await page.evaluate(() => { for(const b of document.querySelectorAll('button')){const t=(b.textContent||'').trim();if(['Got it','Skip','Dismiss','Close','OK','Confirm'].includes(t))b.click()} });
    await page.waitForTimeout(3000);

    const text = await page.evaluate(() => document.body?.innerText || '');
    results[name] = text.substring(0, 3000);
  }

  for (const [name, text] of Object.entries(results)) {
    console.log('\n===== ' + name + ' =====');
    console.log(text);
  }

  console.log('\nBROWSER_STAYS_OPEN');
  while(true) await new Promise(r => setTimeout(r, 60000));
})().catch(e => { console.error(e.message); process.exit(1); });
