// Detects empty or Microsoft-auto-generated knowledge source descriptions
// across all 4 agents (SLP, TDA, OT, PT). Run this when troubleshooting
// ungrounded evaluation failures to check Layer 1.5 (KB quality) first.
//
// Uses Playwright + persistent auth. Flags:
//   ❌ EMPTY — 0 chars (Microsoft never filled it)
//   ⚠️ GENERIC — matches "searches information contained in" boilerplate
//   ✅ Good — has a real description
//
// Generic patterns (Microsoft auto-generated):
//   "This knowledge source searches information contained in [filename].txt"
//   "searches the"
//   "this knowledge source searches"

const { chromium } = require('playwright-core');

(async () => {
  const browser = await chromium.launch({
    headless: false,
    executablePath: 'C:/Program Files/Google/Chrome/Application/chrome.exe',
  });
  const ctx = await browser.newContext({
    storageState: 'D:/my agents copilot studio/.playwright-auth/state.json',
  });
  const page = await ctx.newPage();
  const cdp = await page.context().newCDPSession(page);

  const agents = [
    ['SLP', '6e437a77-a5dc-4984-90eb-4924eab10006'],
    ['TDA', '4d0ed0d3-30f6-f011-8406-000d3a37eba2'],
    ['OT', '73b45e98-af7a-443a-aa12-6d8a05118530'],
    ['PT', '593407f3-539b-490f-84ac-d74e13216c81'],
  ];
  const GENERIC = [/searches information contained in/i, /this (source|repository) searches/i];

  for (const [name, botId] of agents) {
    console.log(`\n=== ${name} ===`);
    await page.goto(
      `https://copilotstudio.microsoft.com/environments/Default-03cc92c3-986c-4cf4-ae27-1478cf99d17f/bots/${botId}/knowledge`,
      { timeout: 60000, waitUntil: 'domcontentloaded' }
    );
    await page.waitForTimeout(10000);
    for (let i = 0; i < 5; i++) {
      await page.keyboard.press('Escape');
      await page.waitForTimeout(300);
    }
    await page.evaluate(() => {
      for (const b of document.querySelectorAll('button')) {
        const t = (b.textContent || '').trim();
        if (['Got it', 'Skip', 'Dismiss', 'Close', 'OK', 'Confirm'].includes(t)) b.click();
      }
    });
    await page.waitForTimeout(2000);

    // Get source links from main content
    const sources = await page.evaluate(() => {
      const result = [];
      const links = document.querySelectorAll('main a, [role="main"] a, section a, [role="link"]');
      for (const link of links) {
        const txt = (link.textContent || '').trim();
        const r = link.getBoundingClientRect();
        if (
          txt.length > 10 &&
          r.width > 50 &&
          r.width < 700 &&
          r.y > 150 &&
          !txt.includes('Skip') &&
          !txt.includes('Copilot for') &&
          !txt.includes('troubleshooting') &&
          !txt.includes('Find ')
        ) {
          result.push({ text: txt.substring(0, 60), x: r.x + 10, y: r.y + r.height / 2 });
        }
      }
      return result;
    });

    if (sources.length === 0) {
      console.log('  No knowledge source links found');
      continue;
    }

    console.log(`  Found ${sources.length} sources`);

    for (const src of sources) {
      await cdp.send('Input.dispatchMouseEvent', {
        type: 'mousePressed',
        x: src.x,
        y: src.y,
        button: 'left',
        clickCount: 1,
      });
      await cdp.send('Input.dispatchMouseEvent', {
        type: 'mouseReleased',
        x: src.x,
        y: src.y,
        button: 'left',
        clickCount: 1,
      });
      await page.waitForTimeout(2500);

      const desc = await page.evaluate(() => {
        const tas = document.querySelectorAll('textarea');
        for (const ta of tas) {
          const val = (ta.value || ta.textContent || '').trim();
          if (val.length > 10 && !val.startsWith('http')) return val.substring(0, 200);
        }
        return '(empty)';
      });

      const isEmpty = desc === '(empty)' || desc.length < 5;
      const isGeneric = GENERIC.some((p) => p.test(desc));

      if (isEmpty) console.log(`  ❌ ${src.text.substring(0, 35)} — EMPTY`);
      else if (isGeneric)
        console.log(`  ⚠️ ${src.text.substring(0, 35)} — GENERIC: "${desc.substring(0, 60)}"`);
      else console.log(`  ✅ ${src.text.substring(0, 35)}`);

      await page.keyboard.press('Escape');
      await page.waitForTimeout(500);
    }
  }

  await browser.close();
  process.exit(0);
})().catch((e) => {
  console.error(e.message);
  process.exit(1);
});
