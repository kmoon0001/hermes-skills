---
name: copilot-studio-topic-assessment
description: >-
  Assessments and guidelines for evaluating topic necessity in Copilot Studio agents.
  Helps determine which topics add value vs create noise, with focus on eval score
  stability and core agent purpose alignment.
---

# Topic Assessment Framework

## Quick Decision Tree

1. Does the topic have `triggerQueries:` with clear phrases? → If NO, it's a shell topic
2. Does it address the agent's core purpose? → If NO, skip it
3. Does it duplicate existing coverage? → If YES, remove it
4. Can it be a simple text answer? → If YES, it maintains 95% eval

## Shell Topic Patterns

| Pattern | Finding | Action |
|---------|---------|--------|
| `intent: {}` | No trigger queries | Shell - requires manual/flow activation |
| `OnUnknownIntent` | Catch-all behavior | Verify it's the actual Fallback topic |
| `SearchAndSummarizeContent` in topic body | Interactive search | May cause eval regression (use sparingly) |
| `InvokeFlowAction` | Requires Power Automate flow | Verify flow exists before adding |

## Red Flag Indicators

**Remove without adding:**
- Resident-level analysis topics (for facility QM agents) — use resident outlier workflow instead
- Gateway topics requiring downstream flows that don't exist (e.g., LATEST RESIDENT ROUTER → Resident Outlier Analysis flow)
- Topics with duplicate trigger phrases to existing topics (check for overlap)
- Topics that would exceed 12-15 custom topics (routing instability)
- Shell topics (`intent: {}`) that have no trigger activation path
- Topics using `SearchAndSummarizeContent` in topic body (can cause eval regression)
- **Topics with `kind: Question` nodes before `SearchAndSummarizeContent`** — the Question asks "please paste the document" which fails Single Response eval (eval expects direct answer, gets a question). Fix: remove Question node, set `userInput: =System.Activity.Text`, connect trigger directly to SearchAndSummarizeContent. Must be done in Copilot Studio UI (API can't patch `content` field).

## Example: LATEST RESIDENT SUBMISSION ROUTER Assessment

- Type: Gateway topic with `triggerQueries:` present
- Requires: Resident Outlier Analysis flow + Dataverse lookup
- Scope mismatch: Resident outliers ≠ facility QM coaching
- Impact: Topic count inflation without core value
- **Decision: EXTRANEOUS - skip**

## Value-Add Patterns

**Add these topics when they address core agent purpose:**

- Clinical Coaching (Coaching Corner) — Text-based guidance aligned to clinical protocols
  - Triggers: coaching corner, clinical coaching, need coaching advice
  - Format: Simple bullet points referencing ONE Clinical protocols
  - Example: Falls prevention, ADL decline, pain management coaching
  
- Accountability Matrix (RACI) — Role-based responsibility assignment
  - Triggers: accountability matrix, RACI matrix, who is responsible
  - Format: Table output with Responsible/Accountable/Consulted/Informed
  - Use: For action item ownership documentation

- Severity Classification — Issue prioritization guidance
  - Triggers: severity classifications, qm severity, classify severity
  - Format: Clear Critical/High/Medium/Low levels with timeframes

- Workflow Navigation Menu — Topic discovery aid
  - Triggers: workflow menu, qm workflow menu, access workflow
  - Format: List of available workflows with brief descriptions

**Implementation Notes:**
- Use simplified text-answer format (`SendActivity` + `EndDialog`) to maintain eval stability
- Include `clearTopicQueue: true` on action topics to prevent conversation bleed
- Reference existing knowledge sources (ONE Clinical protocols, CMS Ch.15) in topic content

## Eval Preservation Strategy

- Keep topics in simple text-answer format where possible
- Use `EndDialog` on every leaf topic
- Add `clearTopicQueue: true` on action topics
- Avoid nested conditions in topics

### Topic Coverage Checklist

- [ ] Escalation workflow covered
- [ ] Action plan workflow covered
- [ ] Driver analysis covered
- [ ] Trend reporting covered
- [ ] Clinical coaching covered
- [ ] No duplicate triggers
- [ ] No shell topics activated

## Reference Files

- `references/assessment-template.md` — Template for documenting topic assessments
- `references/latest-resident-submission-assessment.md` — Completed assessment example
- `templates/coaching-corner-template.yaml` — Verified template for coaching topics
- `templates/coaching-corner-validated.yaml` — Production-ready Coaching Corner topic YAML
- `references/manual-injection-pattern.md` — When CDP unavailable, use manual Convert-to-YAML
- `references/shell-topic-assessment-pattern.md` — Decision matrix for shell topics