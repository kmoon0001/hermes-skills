# Topic Assessment Template

Use this template when evaluating whether topics should be added to a Copilot Studio agent.

## Assessment Form

```
## TOPIC ASSESSMENT: [Topic Name]

### Type Analysis
- Has triggerQueries: [yes/no]
- Intent type: [OnRecognizedIntent / OnUnknownIntent / empty {}]
- Uses SearchAndSummarizeContent: [yes/no]
- Uses InvokeFlowAction: [yes/no]

### Scope Match
- Core agent purpose: [description]
- Topic purpose: [description]
- Match (Y/N): [yes/no]
- Notes: [gaps or overlaps]

### Redundancy Check
- Duplicate triggers with: [existing topic names or 'none']
- Duplicate purpose with: [existing topic names or 'none']

### Infrastructure Requirements
- Required flows: [list or 'none']
- Required entities: [list or 'none']
- Required knowledge sources: [list or 'none']

### Decision
[ADD / SKIP / REMOVE] - [reason]

### Eval Impact
- Topic count change: [+N / -N / 0]
- Risk level: [low/medium/high]
```

## Completed Assessments

### LATEST RESIDENT SUBMISSION ROUTER
- Type: Gateway with triggers
- Requires: Resident Outlier Analysis flow
- Scope: Resident-level outlier analysis
- Core purpose: Facility-level QM coaching
- Decision: SKIP - Resident outlier analysis is outside core QM Coach scope
- Impact: Would increase topic count without added value for facility QM users