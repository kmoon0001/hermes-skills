# LATEST RESIDENT SUBMISSION ROUTER Assessment

## Assessment Form

### Type Analysis
- Has triggerQueries: yes
- Intent type: OnRecognizedIntent
- Uses SearchAndSummarizeContent: no (gateway topic)
- Uses InvokeFlowAction: yes (routes to Resident Outlier Analysis flow)

### Scope Match
- Core agent purpose: Facility-level QM coaching and analysis
- Topic purpose: Resident-level outlier detection and handoff to Resident Outlier Analysis
- Match (Y/N): NO
- Notes: Resident outlier analysis is NOT facility QM coaching. QM Coach V2 does facility-level analysis, not resident-level deep dives.

### Redundancy Check
- Duplicate triggers with: none (unique trigger phrases)
- Duplicate purpose with: Resident Outlier Analysis (downstream topic)

### Infrastructure Requirements
- Required flows: Resident Insight Dataverse Lookup (88ce03b7-6b25-f111-8341-000d3a33801d)
- Required entities: ResidentFacilityOptions (ClosedListEntity with 12 facilities)
- Required knowledge sources: Uses SearchAndSummarizeContent in downstream topic

### Decision
SKIP - Resident outlier analysis is outside core QM Coach V2 scope. The agent is designed for facility-level QM analysis. Adding resident-level outlier topics increases topic count without clear value for the intended audience (therapy leadership, nursing/IDT teams).

### Eval Impact
- Topic count change: 0 (not added)
- Risk level: HIGH (if added) — topic count inflation + scope mismatch would likely reduce eval score