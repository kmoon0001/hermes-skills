# Topic Injection via Manual Convert-to-YAML Pattern

When browser automation (CDP) is unavailable, use this manual workflow:

## Steps

1. In Copilot Studio, navigate to your agent → Topics → + Add topic → From blank
2. Enter the topic name
3. Click "..." menu → Select "Convert to YAML" (NOT Monaco paste)
4. Delete the auto-generated content in the YAML editor
5. Copy the validated YAML from your local topic_templates file
6. Paste into the editor
7. Save → Publish → Test

## Why Not Monaco Paste

- Monaco editor can corrupt YAML (truncates content)
- CDP DOM reading shows "8 chars — empty" after paste
- Use "Convert to YAML" for reliable injection

## Verification

After injection, verify:
- Topic content length > 1000 chars (indicates full content)
- Topic has `AdaptiveDialog` and `EndDialog`
- No "Something went wrong" publish errors
- Single-response eval >=95%

## Topic Count Target

For eval stability, target 15-20 custom topics maximum. Beyond this, routing conflicts emerge and eval scores drop.

## Files Location

Topic YAML files: `D:/my agents copilot studio/topic_templates/`
- coaching_corner.yaml
- accountability_matrix.yaml
- qm_severity_classification.yaml
- workflow_menu.yaml