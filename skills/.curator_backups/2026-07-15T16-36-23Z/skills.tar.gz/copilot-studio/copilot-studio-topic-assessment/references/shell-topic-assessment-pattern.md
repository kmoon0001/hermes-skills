# Topic Necessity Assessment — Shell Topics

When evaluating shell topics (`intent: {}`) for addition to a Copilot Studio agent, use this decision matrix:

## Shell Topic Assessment Flow

| Question | Decision |
|----------|----------|
| Does it have `triggerQueries:`? | **NO** = Shell topic — requires manual/flow activation |
| Is it `OnUnknownIntent`? | **YES** = System catch-all — only have ONE (Fallback) |
| Does it call an InvokeFlowAction? | **YES** = Verify flow exists before adding |
| Does it have interactive Question nodes? | **YES** = May hurt single-response eval scores |

## Shell Topic Categories

### Gateway Topics (e.g., LATEST RESIDENT SUBMISSION ROUTER)
- Has `triggerQueries:` but routes to another topic via `BeginDialog`
- **Decision**: SKIP if downstream topic missing; adds complexity without direct value

### Empty Trigger Topics
- `intent: {}` — no trigger queries defined
- **Decision**: SKIP — topic never activates automatically

### Search Topics
- Uses `SearchAndSummarizeContent` in topic body
- **Decision**: May hurt eval — agent knowledge layer already handles search; skip if redundant

### Flow-Required Topics
- Uses `InvokeFlowAction` with flow GUID
- **Decision**: Verify flow exists; if not, SKIP — broken flow references crash publish

## Assessment Example: QM Coach V2

| Topic | Triggers | Shell? | Action |
|-------|----------|--------|--------|
| Coaching Corner | Yes | No | ADD — direct value, ONE protocols |
| Accountability Matrix | Yes | No | ADD — RACI for actions |
| QM Severity Classification | Yes | No | ADD — severity guidance |
| Workflow Menu | Yes | No | ADD — navigation aid |
| LATEST RESIDENT ROUTER | Yes | No (gateway) | SKIP — requires Resident Outlier flow |
| SNF Email Generator | Yes | No (redundant) | SKIP — overlaps with DoR Summary |
| QMINTAKE | No (`intent: {}`) | Yes | SKIP — shell topic |
| FacilityQMAnalysis | No (`intent: {}`) | Yes | SKIP — requires Power BI flow |
| DoRSummary | No (`intent: {}`) | Yes | SKIP — shell, already live simpler version |

## Eval Preservation Pattern

For topics that maintain eval stability:
- `SendActivity` with complete answer (no Questions)
- `EndDialog` on every path
- No `InvokeFlowAction` unless flow verified
- No duplicate trigger phrases to existing topics
- Content references knowledge sources (ONE protocols, CMS standards)

## Key Finding: Topic Count Stability

- 15-20 topics = stable eval (~95%)
- 30+ topics = routing conflicts emerge
- Shell topics inactive in trigger routing but still consume topic slots
- Delete unused/dormant topics rather than adding new ones