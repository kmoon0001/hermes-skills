---
name: copilot-studio-decision-tree
description: Best Practices Decision Tree for building Copilot Studio agents — orchestration mode, knowledge sources, entities, tools, automation flows, and AI model selection. Use when architecting or reviewing agent design.
---

# Copilot Studio Best Practices Decision Tree

Source: Azure/Copilot-Studio-and-Azure (decision tree doc)

## 1. Orchestration Mode

**Generative AI (Recommended)** — Model interprets intent, dynamically chooses response. Can combine topics, tools, and knowledge in one answer. Auto-questions for missing details. Write clear descriptions for topics, tools, and knowledge sources.

**Classic / Rule-based** — Predefined trigger phrases map to single topic. Only does what you explicitly script. Tight control but less adaptive.

**Decision**: Default to Generative unless strict compliance requires predetermined scripts.

## 2. Information Handling

| Approach | Best For | How |
|----------|----------|-----|
| **Knowledge Sources** | Informational Q&A (policies, manuals, FAQs) | Index SharePoint, PDFs, websites, Dataverse. Provide descriptive names. |
| **Scripted Topics** | Procedural/transactional (multi-step flows) | Add input/output variables, fallback handling, logic branches |
| **Both Combined** | Best coverage | Knowledge for Q&A + Topics for transactions |

## 3. Entities (Data Extraction)

- **Prebuilt**: Age, DateTime, Currency, Email, Person Name — auto-detect from utterances
- **Custom Closed List**: Finite categories with synonyms (e.g., IssueType: {Email, VPN, Hardware})
- **Custom Regex**: Pattern matching (order numbers, employee IDs)
- **Slot Filling**: Auto-prompt user for required entity values when missing

## 4. External Tools

| Method | When to Use |
|--------|-------------|
| **Power Platform Connectors** | Microsoft + 3rd party; easiest path |
| **REST API (direct)** | Simple integrations when no connector exists |
| **Agent Flows** | Multi-step logic within Copilot Studio (no extra license) |
| **Power Automate Flows** | Reusable enterprise flows; may need license |
| **MCP Server** | Advanced custom back-ends |
| **Prompt Tool** | On-demand AI transformation/disambiguation |
| **Computer Vision (RPA)** | Legacy systems with no API — last resort |

**Best Practice**: Give every tool a clear name + description. The AI uses descriptions to decide when to invoke.

## 5. Automation Choice

| Flow Type | License | When |
|-----------|---------|------|
| **Agent Flows** | Built-in (no extra) | Agent-specific operations, start here |
| **Power Automate Flows** | May need separate license | Reuse existing flows, long-running, maintained by other teams |

## 6. AI Model Selection

| Type | Models | Recommendation |
|------|--------|---------------|
| Default (General) | GPT-4.1, GPT-5 Chat, Claude Sonnet 4.5/4.6 | Start here for most cases |
| Deep Reasoning | GPT-5 Reasoning, Claude Opus 4.6 | Complex multi-step reasoning, document analysis |
| Auto/Adaptive | GPT-5 Auto | Let platform route dynamically per turn |
| Experimental | GPT-5.3 Chat, GPT-5.4 Reasoning, Grok 4.1 | Dev only — not for production |

**Best Practice**: Start with Default. Move to Deep if struggling with complex tasks, General if too slow/verbose.

## Summary Flow
1. Orchestration → Generative (default) or Classic
2. Info → Knowledge Sources for Q&A + Topics for transactions
3. Entities → Prebuilt + Custom as needed
4. Tools → Connectors first, Agent Flows for composition
5. Automation → Agent Flows inside, PA Flows for reuse
6. Model → Default, adjust by task complexity
