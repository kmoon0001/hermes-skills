# CDP WebSocket Token Capture for PPAPI Eval Auth

When device-code and localhost redirect auth both fail, capture a PPAPI Bearer token from the user's already-authenticated browser session via Chrome DevTools Protocol.

## When to Use

- Device-code flow blocked by tenant Conditional Access
- Localhost redirect fails with AADSTS50011 (redirect URI mismatch)
- User already signed into Copilot Studio in Edge/Chrome

## Prerequisites

Browser must be running with remote debugging:
```powershell
# Edge with user profile (preserves Copilot Studio auth cookies)
Start-Process 'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe' `
  -ArgumentList '--remote-debugging-port=9223','--remote-allow-origins=*','--no-first-run','--user-data-dir=C:\Users\kevin\AppData\Local\Microsoft\Edge\User Data'
```

## Capture Script Pattern

```javascript
const WebSocket = require('ws');
// 1. Get tab list: GET http://127.0.0.1:9223/json/list
// 2. Find Copilot Studio eval tab by URL
// 3. Connect WebSocket to tab's webSocketDebuggerUrl
// 4. Enable Fetch interception: Fetch.enable { patterns: [{ urlPattern: '*' }] }
// 5. Reload page: Page.reload
// 6. Intercept Fetch.requestPaused events
// 7. Extract Authorization header from powerplatform.com requests
// 8. Save token to %USERPROFILE%\.copilot-studio-cli\test-agent-token.txt
```

## Token Usage

```python
token = Path(os.path.expandvars(r'%USERPROFILE%\.copilot-studio-cli\test-agent-token.txt')).read_text().strip()
headers = {'Authorization': f'Bearer {token}'}
# Use with PPAPI endpoints
```

## Pitfalls

- Tab IDs are dynamic — search by URL pattern, not hardcoded ID
- Token expires quickly — capture immediately before eval
- Edge reports as "Edg/149.x" in CDP, Chrome as "Chrome/149.x"
- Must use user's profile dir to preserve auth cookies
- CDP `curl` health check (HTTP) can succeed while WebSocket connection hangs (pool exhaustion)
