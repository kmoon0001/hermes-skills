# Headless Playwright portal-token capture (locked-profile workaround)

When the eval Gateway (`powervamg...gateway.prod.island.powerapps.com`) needs the
Copilot Studio **portal session token** (the `Authorization: Bearer` header the
Copilot Studio web app sends) and:
- the MSAL `api://96ff4394...` token is rejected by the gateway (403/404), and/or
- no browser is running with `--remote-debugging-port` for CDP capture, and
- the user has OK'd headless capture,

use `playwright-core` (Edge channel) to launch a **headless** browser from a COPY of
the live Edge profile, navigate to the eval page, and capture the first
`Authorization: Bearer` header. Validated 2026-07-12 (PCCH SR re-run, returned 200 Queued).

## Why copy the profile (critical)
Launching Playwright against the LIVE Edge `user-data-dir` fails:
`browserType.launchPersistentContext: Failed to launch the browser process ... exitCode=21`
because the running Edge process already owns that directory. Copy it to a temp dir
first — sign-in cookies travel with the copy, so no re-auth is needed:
```
xcopy "%LOCALAPPDATA%\Microsoft\Edge\User Data" "%TEMP%\edge_pw_profile" /E /I /H /R /Y /Q
```
Then launch against `%TEMP%\edge_pw_profile`, never the live path.

## Capture + run recipe (condensed)
```js
const { chromium } = require('playwright-core');
const fs = require('fs'), path = require('path');
const envId = '<env-guid>', botId = '<bot-guid>';
const G = 'https://powervamg.us-il107.gateway.prod.island.powerapps.com';
const cacheFile = path.join(process.env.USERPROFILE, 'AppData', 'Local', 'Temp', 'pva.txt');
const tmpUd = path.join(process.env.USERPROFILE, 'AppData', 'Local', 'Temp', 'edge_pw_profile');

// 1. (after xcopy) launch headless against the COPY
const browser = await chromium.launchPersistentContext(tmpUd,
  { channel: 'msedge', headless: true, args: ['--remote-debugging-port=0', '--no-sandbox'] });
const page = await browser.newPage();
let captured = null;
page.on('request', r => {
  if (captured) return;
  const auth = r.headers()['authorization'];
  if (auth && auth.startsWith('Bearer ') &&
      /powervamg|copilotstudio|botframework/.test(r.url())) {
    captured = auth.replace(/^Bearer\s+/i, '');
  }
});

// 2. navigate — domcontentloaded, NOT networkidle (SPA never idles)
try { await page.goto(
  `https://copilotstudio.microsoft.com/environments/${envId}/bots/${botId}/evaluation`,
  { waitUntil: 'domcontentloaded', timeout: 45000 }); } catch {}
let w = 0; while (!captured && w < 40) { await page.waitForTimeout(1500); w += 1.5; }

fs.writeFileSync(cacheFile, captured);          // token for downstream pollers
await browser.close();

// 3. start the run in the same shot (X-CCI headers REQUIRED)
const run = await req(`${G}/api/botmanagement/v2/environments/${envId}/bots/${botId}/makerevaluations`,
  'POST', { testSetId: '<testset-guid>' }, captured);
// run = { runId, state: "Queued" }
```
The capture works because navigating the eval SPA fires gateway `makerevaluations`
requests carrying the portal session token.

## Gateway endpoint paths (validated 2026-07-12)
- `POST /api/botmanagement/v2/environments/{env}/bots/{bot}/makerevaluations`
  body `{ "testSetId": "<guid>" }` -> `{ runId, state: "Queued" }`
- `GET  .../makerevaluations/{runId}/details`
  -> full run object: `state`, `testCaseCount`, `startTime`, `endTime`,
  `errorCodes[]`, `aggregatedGraderResults[]`. Use for progress + final scores.
- `GET  .../makerevaluations?count=100` -> list runs (may return 0 if scope differs).
- `GET  .../evaluationruns/...` and `/evaluationruns({id})` -> **404**. Wrong path.
- `runOnPublishedBot: false` in the run object = eval graded the **DRAFT** (not the
  published bot). The draft's instructions `botcomponent.data` was PATCHED directly, so the
  change is still evaluated. No action needed unless you only patched published state.

## Pitfalls
- Gateway portal token is short-lived (~1h). Embed a re-capture inside pollers on 403 so
  long SR runs (100 cases, 15-45 min) don't die mid-poll.
- `waitUntil: 'networkidle'` hangs on the eval SPA -> use `domcontentloaded` + poll for header.
- Always copy the profile — never point Playwright at the live Edge `user-data-dir`.
- `playwright-core` + the Edge channel must resolve from the pipeline dir (node_modules
  lives at `D:/my agents copilot studio/pipeline/node_modules`); save/run script there.
- The Dataverse `.default` token returns 403 on this gateway; the MSAL `api://96ff4394`
  token reaches but use the captured portal token to be safe. CDP WebSocket capture is the
  alternative when a browser is already running with `--remote-debugging-port`.
