# Eval set migration + connector-free draft eval pitfalls

Validated during Ensign Default Feedback B repair (Jul 5 2026).

## Migrating Copilot Studio evaluation sets between bots

Dataverse `botcomponent` rows with `componenttype eq 19` include both runnable `EvaluationSet` components and individual test case components (`EvaluationData`, `MultiTurnEvaluationCase`). Copying rows alone is not enough.

Required shape:
- `EvaluationSet` rows are the visible/runnable test sets in the gateway `GET /makerevaluations/testsets` response.
- Individual cases must be children of the set via the botcomponent lookup navigation property:
  `ParentBotComponentId@odata.bind: "/botcomponents(<evaluation-set-botcomponentid>)"`
- The lower-case bind name `parentbotcomponentid@odata.bind` fails with an undeclared-property OData error.
- If cases are copied without the parent lookup, gateway shows visible test-set shells with `numberOfTestCases: 0` even though the cases exist in Dataverse.

Recommended repair flow:
1. Pull source type-19 rows including `botcomponentid,name,schemaname,data,_parentbotcomponentid_value`.
2. Group source cases by `_parentbotcomponentid_value` and classify parent rows whose YAML starts with `kind: EvaluationSet`.
3. Create target EvaluationSet rows first.
4. Copy/create target case rows.
5. PATCH each target case with `ParentBotComponentId@odata.bind` to the matching target set.
6. Verify both Dataverse parent counts and gateway `numberOfTestCases` before starting runs.

## Maker-evaluation connector/auth trap

Draft evals in the `pva-maker-evaluation` channel often cannot use connection-backed knowledge/search/actions unless a valid connection is available to that channel. Failure signatures:
- Agent answers: `Let's get you connected first... Open connection manager...`
- Missing action/flow returns `FlowNotFound`
- The run details mark abstention/relevance failures even when the first topic turn looked reasonable.

For evalability, do not rely solely on `SearchAndSummarizeContent` or connector/flow actions in review topics. Add a connector-free path that can answer the eval prompt directly, or guard the connection-backed path so it does not fire during eval.

## Multi-turn pitfall

Fixing only the first turn is insufficient. In multi-turn evals, second/third turns can fall out of the specialist topic into Conversational Boosting, Greeting, MultipleTopicsMatched, or Fallback, then hit connector-required search or a generic greeting. After patching a specialist topic, inspect `/details` for every query in each test case:
- `details.testCases[].queries[].answer`
- `details.testCases[].queries[].metrics.queryResponseMetrics[]`

Patch the interceptors too:
- Greeting should not answer audit/coaching/documentation requests with a generic hello.
- Fallback should provide connector-free documentation-review guidance instead of an apology when the query is clearly in-scope.
- Conversational Boosting should have a first action that can answer Medicare/documentation questions without requiring a connection, or it will produce connection-manager refusals.

## Score interpretation

Gateway run summary may show a case-level aggregate, but root cause requires `/makerevaluations/{runId}/details`. A case can fail because one later query abstained even if the first query passed. Treat the detail JSON as the source of truth before making more patches.