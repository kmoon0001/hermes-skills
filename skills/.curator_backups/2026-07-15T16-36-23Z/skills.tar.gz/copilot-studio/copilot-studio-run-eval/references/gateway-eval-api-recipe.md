# Gateway Eval API — Proven Curl Recipe (Jul 2026)

Working recipe for PPAPI evaluation through the PowerVA Gateway. Validated on Therapy AI Dev (`a944fdf0-...`).

## Gateway URL Pattern

```text
https://powervamg.us-il107.gateway.prod.island.powerapps.com/api/botmanagement/v2
```

The gateway region (`us-il107`) varies by environment. Capture from the browser via CDP: reload the eval tab and watch `Fetch.requestPaused` for URLs containing `makerevaluation`.

## Required Headers

Every request needs ALL of these:

```bash
-H "Authorization: Bearer $TOKEN"
-H "X-CCI-ApplicationSource: Web"
-H "X-CCI-BapEnvironmentId: $ENV_GUID"
-H "X-CCI-BotId: $BOT_GUID"
-H "X-CCI-CdsBotId: $BOT_GUID"          # same as BotId
-H "X-CCI-TenantId: 03cc92c3-986c-4cf4-ae27-1478cf99d17f"
-H "X-CCI-OrganizationId: 62945552-72f5-f011-aa23-6045bd003938"
-H "x-ms-user-agent: PVA-Portal/1.0.0 (Web; ReactNative: false)"
-H "Accept: application/json"
-H "Origin: https://copilotstudio.microsoft.com"
```

**PITFALL — Missing any X-CCI header returns `MissingRoutingHeader` error.** The gateway requires routing headers; it won't proxy to the agent backend without them.

**PITFALL — OrganizationId is environment-specific.** `62945552-...` is Therapy AI Dev. For Ensign Default, capture from browser.

## List Test Sets

```bash
curl -s -H "Authorization: Bearer $TOKEN" \
  -H "X-CCI-ApplicationSource: Web" \
  -H "X-CCI-BapEnvironmentId: $ENV" \
  -H "X-CCI-BotId: $BOT" \
  -H "X-CCI-CdsBotId: $BOT" \
  -H "X-CCI-TenantId: $TENANT" \
  -H "X-CCI-OrganizationId: $ORG" \
  -H "x-ms-user-agent: PVA-Portal/1.0.0" \
  -H "Accept: application/json" \
  -H "Origin: https://copilotstudio.microsoft.com" \
  "$GW/environments/$ENV/bots/$BOT/makerevaluations/testsets"
```

Response: `{ "testComponents": [{ component: {...}, numberOfTestCases: N, evaluationSetType: "SingleTurn|MultiTurn" }] }`

## Start a Run

```bash
curl -s -X POST \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  ... (all X-CCI headers as above) \
  -d '{"testSetId":"xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"}' \
  "$GW/environments/$ENV/bots/$BOT/makerevaluations"
```

Response: `{ "runId": "...", "state": "Queued", "executionState": "Queued" }`

**PITFALL — Non-existent testSetId returns 200 with no runId.** Always verify the testSetId exists via list endpoint first.

## Poll/List Runs

```bash
curl -s ... "$GW/environments/$ENV/bots/$BOT/makerevaluations?count=10"
```

Response is a JSON array (NOT wrapped in `value`):
```json
[{
  "id": "run-id",
  "state": "Completed|InProgress|Failed|Queued",
  "testCaseCount": 100,
  "evaluationSetType": "SingleTurn|MultiTurn",
  "aggregatedGraderResults": [
    {"$type": "MakerEvaluationRunCountMetric", "name": "totalSucceeded", "count": 38},
    {"$type": "MakerEvaluationRunCountMetric", "name": "totalFailed", "count": 62},
    {"$type": "MakerEvaluationRunCountMetric", "name": "totalInvalid", "count": 0},
    {"$type": "MakerEvaluationRunCountMetric", "name": "totalErrors", "count": 0}
  ]
}]
```

Score = `totalSucceeded / (totalSucceeded + totalFailed) * 100`

**PITFALL — `aggregatedGraderResults` is an array of MakerEvaluationRunCountMetric objects, NOT a dict with graderType/finalScore/passedCount keys.** Different structure than the PPAPI direct endpoint.

## Token Capture (CDP WebSocket)

Token expires ~15 minutes. Re-capture by reloading the eval tab via CDP.

**PITFALL — `cdp_capture_token.cjs` requires the EVALUATION tab open in CDP, not Topics or Overview.** The script searches tabs for "evaluation" in the URL. If only Topics/Overview tabs are open, it fails with "Eval tab not found."

**If no eval tab exists, create one via CDP:**
```bash
# 1. Create tab + navigate
curl -s -X PUT "http://localhost:9223/json/new?url=https://copilotstudio.microsoft.com/environments/<envId>/bots/<botId>/evaluation"
# 2. Navigate it (URL param above may not apply — follow with Page.navigate)
node -e "
const WebSocket = require('ws');
const http = require('http');
const url = 'https://copilotstudio.microsoft.com/environments/<envId>/bots/<botId>/evaluation';
http.get('http://localhost:9223/json/list', res => {
  let d=''; res.on('data',c=>d+=c); res.on('end',() => {
    const tab = JSON.parse(d).find(p => p.url && p.url.includes('evaluation'));
    if (!tab) { console.log('No eval tab'); process.exit(1); }
    const ws = new WebSocket(tab.webSocketDebuggerUrl);
    ws.on('open', () => ws.send(JSON.stringify({id:1, method:'Page.navigate', params:{url}})));
    ws.on('message', raw => { const m=JSON.parse(raw); if(m.id===1){ws.close();process.exit(0);}});
  });
});
"
# 3. Wait 45-60s for SPA hydration, then run capture
sleep 45 && node cdp_capture_token.cjs --port 9223
```

```bash
cd "D:/my agents copilot studio/pipeline/scripts" && node cdp_capture_token.cjs --port 9223
```

Token saved to `%USERPROFILE%\.copilot-studio-cli\test-agent-token.txt`

**PITFALL — Token may fail with 400 Bad Request even when captured successfully.** If Gateway API returns 400, the eval tab may have been closed by the browser. Re-navigate to eval, wait 45s, re-capture.

## Parallel Eval Rules

- Different agents CAN run simultaneously (each has its own active-run limit)
- SR and Conv for the SAME agent must be sequential (one active run per agent)
- Quota: 20 runs per agent per 24 hours
- `fairusagepolicy.botrunquotaviolated` = daily quota hit — stop and hand off
- `fairusagepolicy.botactiverunquotaviolated` = active run already exists — poll/wait

## Python Usage Pattern (validated Windows)

```python
import json, urllib.request, time, os

token_file = os.path.expandvars(r'%USERPROFILE%\.copilot-studio-cli\test-agent-token.txt')
with open(token_file) as f:
    token = f.read().strip()

gw = 'https://powervamg.us-il107.gateway.prod.island.powerapps.com/api/botmanagement/v2'
env = 'a944fdf0-0d2e-e14d-8a73-0f5ffae23315'
bot = 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'

def req(url, method='GET', body=None):
    r = urllib.request.Request(url, method=method)
    headers = {
        'Authorization': f'Bearer {token}',
        'X-CCI-ApplicationSource': 'Web',
        'X-CCI-BapEnvironmentId': env,
        'X-CCI-BotId': bot,
        'X-CCI-CdsBotId': bot,
        'X-CCI-TenantId': '03cc92c3-986c-4cf4-ae27-1478cf99d17f',
        'X-CCI-OrganizationId': '62945552-72f5-f011-aa23-6045bd003938',
        'x-ms-user-agent': 'PVA-Portal/1.0.0',
        'Accept': 'application/json',
        'Origin': 'https://copilotstudio.microsoft.com'
    }
    for k, v in headers.items():
        r.add_header(k, v)
    if body:
        r.data = json.dumps(body).encode()
        r.add_header('Content-Type', 'application/json')
    return json.loads(urllib.request.urlopen(r, timeout=30).read())
```
