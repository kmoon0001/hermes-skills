# Checkpointed Fix Approach (Jul 2026)

When improving Copilot Studio agent scores, apply fixes incrementally with eval checkpoints between each change. This prevents cascading failures and isolates the effect of each change.

## The Problem

Applying multiple fixes then running one eval hides regressions. If scores drop, you don't know which fix caused it. If scores stay the same, you don't know which fix actually helped.

## The Approach

```
Checkpoint 0: Freeze baseline → run both SR and Conv evals
     │
Checkpoint 1: Safe additive fix (e.g., conditional format rules) → run eval
     │
Checkpoint 2: Another safe fix (e.g., EndDialog on system topics) → run eval
     │
Checkpoint 3: Riskier fix (e.g., topic rework) → run eval
     │
...continue until target score met
```

## Fix Priority by Risk

| Risk | Type | Examples | Test After |
|------|------|----------|------------|
| None | Additive instructions | Conditional format rules, citation clarifications | Optional (but recommended) |
| Low | Structural additive | EndDialog + clearTopicQueue, additional trigger phrases | Recommended |
| Medium | Topic rework | Changing trigger type (OnConversationStart→OnRecognizedIntent), adding/removing nodes | Required |
| High | Topic delete/merge | Deleting duplicate topics, merging topics | Required — run full suite |
| Unknown | Reactivating disabled topics | Changing statecode 1→0 on a previously-disabled topic | **Required** — was disabled for a reason; investigate first |

## ⚠️ CRITICAL REGRESSION VALIDATED: OnRecognizedIntent Change Caused Conv Drop (2026-07-09)

**On a Medicare Part B Compliance Agent,** changing `OnConversationStart` to `OnRecognizedIntent` with 15 trigger phrases caused Conv to drop **45% → 30%** (−15 pts). SR dropped slightly **81% → 78%**.

**Hypothesis:** The trigger-phrases approach doesn't match multi-turn conversation flows. Conv test cases have context-dependent follow-up turns that don't match the initial trigger phrases. The ClosedListEntity menu, when triggered mid-conversation, causes routing confusion.

**Recommendation:** For agents that need both SR and Conv scores, leave OnConversationStart topics **deactivated** (statecode=1). Fix SR via conditional instructions format (+10 pts, proven). Fix Conv via EndDialog on system topics. Do NOT attempt to rework the Conversation Start topic unless you're willing to test Conv extensively after the change.

## ConvStart Reactivation Checklist

When reactivating a deactivated Conversation Start topic:

1. READ the topic content first — understand why it was disabled
2. Identify the specific structural issue:
   - `kind: OnConversationStart` → hijacks every conversation (most common cause)
   - Forced menu on every turn → kills SR scores
   - Global variable scope → cross-conversation bleed
3. Fix the issue BEFORE reactivating:
   - Change `OnConversationStart` to `OnRecognizedIntent` if the topic should only fire on specific triggers
   - Replace menu Question with a SendActivity if a welcome message is desired
   - Change Global variables to Topic scoped
4. Reactivate (PATCH statecode=0)
5. Run eval immediately to verify no regression
6. If regression appears, deactivate again and refine the fix

## Failure Category → Root Cause Mapping

From `aggregatedGraderResults` when `/details` endpoint is unavailable:

| Category | Likely Root Cause | Fix |
|----------|------------------|-----|
| ABSTAINED | No relevant topic matched. Agent guardrails blocked response. | Add trigger phrases, or re-enable routing topics |
| INCOMPLETE | Agent answered but missed expected content. Topic routing issue or overly strict format. | Conditional format rules, check topic routing |
| LOW_RELEVANCE | Wrong topic matched. Response off-topic. | Fix trigger phrases, topic descriptions |
| OTHER/ERROR | Format, structural, or transient error. | Check topic YAML for binding errors, re-run |

## Sequential Eval Workflow

1. Start Conv eval (20 cases) — faster, catches routing issues
2. Poll every 10 min via cron: `hermes cron create --schedule "10m" --repeat 20 --prompt "Poll run..."`  
3. When Conv completes: analyze failures → apply Checkpoint 1 → start Conv again
4. Repeat until Conv stabilizes → then run SR eval (100 cases) for precision
5. SR takes longer (30-45 min) but gives stable score measurement
