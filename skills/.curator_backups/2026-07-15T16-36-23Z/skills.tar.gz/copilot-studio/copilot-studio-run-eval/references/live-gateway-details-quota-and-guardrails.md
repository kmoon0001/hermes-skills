# Live Evaluation Gateway: details polling, quota handling, and guardrail validation

Use this when the Copilot Studio UI/gateway path is used instead of the bundled PPAPI eval runner.

## Reliable details endpoint

If `GET /makerevaluations/{runId}` polling is incomplete or a custom poller returns `405 Method Not Allowed`, fetch full progress and results from:

```text
GET /api/botmanagement/v2/environments/{environmentId}/bots/{botId}/makerevaluations/{runId}/details
```

The `/details` response contains `details.testCases[]`, each with:
- `executionState` (`Created`, `Evaluated`, `ExecutionFailed`)
- `queries[0].query`
- `queries[0].answer`
- `graderMetrics.queryResponseMetrics[]`
- `errorCodes` for execution failures

For General Quality scoring, treat a case as passing only when:
- `relevance == "Yes"`
- `completeness == "Yes"`
- `abstention == "No"`
- `groundedness` is absent or `"Yes"`

This mirrors Microsoft Learn's General Quality guidance: relevance, groundedness, completeness, and abstention all matter; one failed criterion means the response is flagged.

## Quota behavior

If starting a run returns:

```text
fairusagepolicy.botrunquotaviolated
The agent has been evaluated more than 20 times in the last 24 hours.
```

Stop launching new runs and record handoff. Do not keep retrying. You may still analyze already-completed run detail files and prepare patches, but final validation must wait for the 24-hour quota window.

If starting a run returns `fairusagepolicy.botactiverunquotaviolated`, there is already an active run for that agent. Poll or wait for the active run rather than starting another.

## Guardrail/static-answer patches: YAML validation pitfall

When inserting `ConditionGroup`/`SendActivity` guardrails before `SearchAndSummarizeContent`, validate the patched topic YAML before assuming the live patch is safe.

Common mistake: replacing `additionalInstructions: |-` and accidentally writing the block at column 1 instead of under the action key. Symptom from YAML parsing:

```text
ScannerError while scanning a simple key
could not find expected ':'
```

Expected shape:

```yaml
      additionalInstructions: |-
        OT PLAN-100 GENERAL QUALITY INSTRUCTIONS.
        - First sentence must directly answer the exact user question.
      applyModelKnowledgeSetting: true
```

Do an ad-hoc YAML parse of generated `.after.yml` backups before running another eval. If invalid, repair indentation first, then validate again.

## Failure-pattern triage for General Quality

When an OT/PT/SLP clinical audit agent fails General Quality:
- `abstention == Yes` with relevance/completeness failures often means the answer was a generic checklist instead of directly checking the user's requested document. Fix with a direct first sentence and conditional determination when no note text is present.
- `groundedness == No` often means the answer added unsupported denial, recoupment, penalty, score, or authorship/supervision claims. Fix by narrowing to source-supported risks only.
- `unsupportedactivity.notextresponse` means the test runner did not receive a text answer. Add a guaranteed plain-text `SendActivity` fallback before `EndDialog` or repair the affected topic/action output; do not treat this as normal answer-quality failure.

OT Plan-100-specific observations:
- For `is/does/can you check/can you audit/can you review my...` prompts, first sentence should answer conditionally from available info before headings or checklists.
- If no document text is available, do not ask for it first; provide the compliance standard and say final validation requires the note.
- Avoid numeric scores/risk tiers unless requested or supported by the provided note/source.
- For Section GG, missing scores weaken objective self-care/mobility evidence and care-planning support; do not claim automatic denial, penalties, or recoupment without source support.


## Handoff minimum

For interrupted eval optimization work, save:
- run ID
- test set ID
- score summary
- failed prompt list with failed criteria
- backup directory for patches
- next command to validate after quota reset
