# CDP WebSocket Token Capture

Reliable method for capturing the PPAPI Bearer token from the user's signed-in Copilot Studio browser session. Used when MSAL interactive login (localhost redirect) and device-code flow are both blocked.

## Prerequisites

1. User's browser (Edge or Chrome) running with `--remote-debugging-port=9223`
2. User signed into Copilot Studio in that browser
3. The Copilot Studio Evaluation page open in a tab

## How It Works

1. Query `http://127.0.0.1:9223/json/list` to find the Copilot Studio eval tab
2. Connect to the tab's WebSocket debugger URL
3. Enable Fetch domain interception for ALL URLs
4. Reload the page → PPAPI requests fire
5. Capture the `Authorization: Bearer <token>` header from the first `makerevaluation` request
6. Save token to `%USERPROFILE%\.copilot-studio-cli\test-agent-token.txt`

## Script Location

The working script is at the pipeline checkout:
`D:/my agents copilot studio/pipeline/scripts/cdp_simple.cjs`

The key design: ONE message handler, URL-based tab discovery, Fetch interception, automatic retry with tab creation.

## Usage

```bash
# Start Edge with CDP (preserves auth cookies from user data dir):
powershell.exe -ExecutionPolicy Bypass -Command "
Get-Process msedge -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Seconds 2
\$args = '--remote-debugging-port=9223','--remote-allow-origins=*','--no-first-run','--user-data-dir=C:\Users\kevin\AppData\Local\Microsoft\Edge\User Data'
Start-Process 'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe' -ArgumentList \$args
"

# Run capture:
powershell.exe -NoProfile -Command "node 'D:/my agents copilot studio/pipeline/scripts/cdp_simple.cjs'"
```

## Token Usage

The raw token goes directly to PPAPI endpoints:
```python
token = pathlib.Path(os.path.expandvars(r'%USERPROFILE%\.copilot-studio-cli\test-agent-token.txt')).read_text().strip()
req.add_header("Authorization", f"Bearer {token}")
```

Token lifetime: ~1 hour. Re-capture when PPAPI returns 401 `TokenExpired`.

## Verified

Jul 1, 2026 — Edg/149.0.4022.98, Therapy Documentation Feedback Agent (Prod), 4487-char token.
