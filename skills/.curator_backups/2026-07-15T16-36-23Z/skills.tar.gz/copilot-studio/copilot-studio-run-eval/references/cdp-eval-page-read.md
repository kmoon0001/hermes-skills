# CDP Page-Read: Extracting Evaluation Results from Copilot Studio UI

When the PPAPI returns ambiguous data (e.g., all-NA metrics on Pass cases, missing pass rates, test case names not visible), use CDP WebSocket to read the evaluation results page content directly from the browser's DOM.

## Why use this instead of PPAPI

- PPAPI returns metrics like `{"abstention":"NA","relevance":"NA","completeness":"NA"}` for some test sets — can't tell if the case passed meaningfully
- UI shows actual pass rate percentages (e.g., "83%") that don't appear in the PPAPI response
- Test set names, case counts, and evaluator info (who ran it, when) are only visible in the UI
- No API endpoint exposes test case question/expected-answer content

## Pattern: CDP Runtime.evaluate

Connect via CDP WebSocket and execute JavaScript in the evaluation page context:

```javascript
const WebSocket = require('ws');
const http = require('http');

// 1. Find the eval tab
const pages = await new Promise((resolve, reject) => {
  http.get('http://127.0.0.1:9223/json/list', res => {
    let d = ''; res.on('data', c => d += c); res.on('end', () => resolve(JSON.parse(d)));
  }).on('error', reject);
});

const target = pages.find(p =>
  p.url.includes('/evaluation') && p.title.includes('Therapy')
);
if (!target) { console.log('No eval page found'); process.exit(1); }

// 2. Connect WebSocket
const ws = new WebSocket(target.webSocketDebuggerUrl);
let msgId = 1;

function send(method, params={}) {
  return new Promise(resolve => {
    const id = msgId++;
    const handler = (raw) => {
      const msg = JSON.parse(raw.toString());
      if (msg.id === id) { ws.removeListener('message', handler); resolve(msg); }
    };
    ws.on('message', handler);
    ws.send(JSON.stringify({id, method, params}));
  });
}

ws.on('open', async () => {
  // Wait for page to settle
  await new Promise(r => setTimeout(r, 3000));

  // Extract all page text
  const result = await send('Runtime.evaluate', {
    expression: `document.body.innerText`,
    returnByValue: true
  });

  if (result.result?.result?.value) {
    console.log(result.result.result.value);
  }

  ws.close();
});
```

## Extracting structured data

The page text contains evaluation results in this pattern:

```
<Score>%
<Run Name>
<N> test cases • Data type: <type>
Evaluate
Completed
<Test Set Name>
<User Initials>
<User Name>
<Timestamp>
```

Parse by scanning for " test cases • Data type:" lines and reading the preceding score, run name, and timestamp.

```javascript
// After getting full page text
const lines = text.split('\n');
for (let i = 0; i < lines.length; i++) {
  if (lines[i].includes('test cases')) {
    const score = lines[i-2]?.trim() + '%' || '?';
    const name = lines[i-3]?.trim() || '?';
    const cases = lines[i].match(/(\d+) test cases/)?.[1] || '?';
    console.log(`${name}: ${score} (${cases} cases)`);
  }
}
```

## Scrolling to reveal more results

The page shows recent results in a scrollable list. Scroll before reading:

```javascript
for (let i = 0; i < 10; i++) {
  await send('Runtime.evaluate', {
    expression: `window.scrollTo(0, document.body.scrollHeight)`,
    returnByValue: true
  });
  await new Promise(r => setTimeout(r, 500));
}
await new Promise(r => setTimeout(r, 2000)); // settle
```

## When to use

1. PPAPI return has suspicious `NA` values for metrics (abstention, relevance, completeness all NA)
2. Need pass rate percentage visible in UI but missing from API response
3. Need test set display names or case counts for cross-reference
4. Want to confirm a specific run's score matches between UI and API

## Limitations

- Only shows what's loaded in the current viewport (may need scrolling)
- SPA may lazy-load results — give extra time for DOM to populate
- Text extraction is unstructured — needs custom parsing per page layout
- Requires browser with CDP port open (see `cdp-ppapi-token-capture.md` for setup)
