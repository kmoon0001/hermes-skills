# Gateway Eval API — Therapy AI Dev Environment

## Environment-specific Gateway URLs

| Environment | Gateway URL | Bot ID | Org ID |
|---|---|---|---|
| **Therapy AI Dev** (a944fdf0) | `https://powervamg.us-il107.gateway.prod.island.powerapps.com` | `ad635500-cf47-f111-bec5-70a8a5b1c3a3` (PCCH) / `b0346795-4876-f111-ab0e-70a8a5b1b8cc` (Part B Compliance) | `62945552-72f5-f011-aa23-6045bd003938` |
| **Ensign Default** (Default-03cc92c3...) | `https://powervamg.us-il106.gateway.prod.island.powerapps.com` | `1c601ace-5255-f111-bec6-000d3a37eba2` | `9eebb312-de15-4b08-a279-8fde1a591832` |

## API Endpoint

```
GET/POST {gateway}/api/botmanagement/v2/environments/{env_short}/bots/{bot_id}/makerevaluations
```

Where `{env_short}` is the short environment GUID (e.g. `a944fdf0-0d2e-e14d-8a73-0f5ffae23315`), NOT the `Default-<guid>` prefix.

## Required Headers

```json
{
  "Authorization": "Bearer <ppapi_token>",
  "Accept": "application/json",
  "Content-Type": "application/json",
  "Origin": "https://copilotstudio.microsoft.com",
  "x-cci-tenantid": "<tenant_guid>",
  "x-cci-bapenvironmentid": "<env_short>",
  "x-cci-cdsbotid": "<bot_id>",
  "x-cci-botid": "<bot_id>"
}
```

## Key Differences from PPAPI (api.powerplatform.com)

| Feature | PPAPI | Gateway |
|---|---|---|
| Base URL | `api.powerplatform.com/copilotstudio/...` | `{gateway}/api/botmanagement/v2/...` |
| List runs response | `{ "value": [...] }` | Direct array `[...]` |
| Start run response | `{ "runId": "..." }` | `{ "id": "...", "runId": "...", "state": "Queued" }` |
| Polling | Direct GET with run ID | List endpoint + match by `id` |
| Score source | `testCasesResults[]` | `aggregatedGraderResults[]` |

## Test Sets

| Test Set ID | Type | Cases | Bot |
|---|---|---|---|
| `fcfea569-fe59-4848-9b17-8d284c8ffe0c` | Conv (MultiTurn) | 20 | Feedback B (b0346795) |
| `7a34e22f-3502-4b74-8f97-9e3175d52d02` | SR (SingleResponse) | 100 | Feedback B (b0346795) |

## Eval Run Times

| Type | Cases | Typical Time |
|---|---|---|
| Conv | 20 | 3-5 minutes |
| SR | 100 | 5-8 minutes |

## Token

**CORRECTED (2026-07-12):** The PowerVA Gateway (`powervamg.us-il107...`) requires the
**Copilot Studio portal session token** — the one captured by CDP from the Evaluation page and
saved to `C:/Users/kevin/AppData/Local/Temp/pva.txt` (and `~/.copilot-studio-cli/test-agent-token.txt`).
Verified: a `403 UnauthenticatedUser` is returned when using either (a) the Dataverse
`https://orgbd048f00.crm.dynamics.com/.default` token, OR (b) the MSAL `api://96ff4394-.../.default`
token. The `96ff4394` (PPAPI app registration) token authenticates `api.powerplatform.com` PPAPI
calls but NOT the PowerVA Gateway. The two audiences are distinct.

- Source of truth for Gateway calls: the portal-session Bearer token from `pva.txt`.
- Lifetime: short (~15-60 min). A 403 `Unable to validate token` means it expired — recapture
  via CDP (`scripts/cdp_capture_token.cjs`) or manual F12 copy from the Eval page.
- Do NOT substitute a Dataverse/MSAL token for Gateway calls.

Pitfall (prior belief, now corrected): the MSAL manage-agent cache `api://96ff4394/.default` scope
is for PPAPI (`api.powerplatform.com`) only — it does NOT mint a valid PowerVA Gateway token.
The `az` Dataverse token is also rejected by the Gateway (`S2S17001: SignatureKeyNotFound`).

## Score Calculation

```javascript
function score(run) {
  const agg = {};
  for (const m of (run.aggregatedGraderResults || [])) agg[m.name] = m.count;
  const total = (agg.totalSucceeded||0)+(agg.totalFailed||0)+(agg.totalErrors||0)+(agg.totalInvalid||0);
  return total ? Math.round((agg.totalSucceeded||0)*1000/total)/10 : null;
}
```
