# Live eval auth URL and verification notes

Use this when `eval-api.bundle.js` starts interactive Microsoft login and the user must sign in directly.

## Durable pattern

1. Start eval auth/listing in a PTY-backed process so the local redirect listener stays alive:

```bash
node scripts/eval-api.bundle.js list-testsets \
  --workspace "<agent workspace>" \
  --tenant-id <tenant-id> \
  --environment-id <environment-id> \
  --agent-id <agent/bot-id> \
  --client-id <client-id>
```

If backgrounding, use PTY and keep the process running while the user signs in.

2. Copy the complete auth URL exactly from process output. It contains required query params including `scope`, `redirect_uri`, `response_type`, `code_challenge`, and `code_challenge_method`.

3. If opening the URL through a browser automation/navigation tool results in Microsoft error `AADSTS900144: The request body must contain the following parameter: 'scope'`, the URL was truncated or query separators were mishandled. Do not troubleshoot credentials. Reopen the exact URL via one of these safer routes:

- In an already-open browser page, set `window.location.href = '<full auth URL>'` from the page context.
- On Windows, open the user's default browser with `os.startfile(full_url)`.

4. When the browser reaches the normal Ensign/Microsoft sign-in form, stop and let the user enter email/password/MFA directly. Do not ask for credentials or MFA codes in chat.

5. Poll/wait the PTY process. Success is the eval command completing and returning test sets/results, not merely the login page appearing.

## Local verification after edits

When no canonical suite exists but YAML files were edited, use an ad-hoc temp verifier rather than claiming suite green:

- Create it under `%LOCALAPPDATA%\\Temp` / `C:\Users\<user>\AppData\Local\Temp` with a `hermes-verify-` filename prefix via `tempfile`.
- Check changed paths exist.
- Run `node --check` for any changed JS helper.
- Run `schema-lookup.bundle.js validate` for changed `.mcs.yml` files.
- Run a full active workspace schema pass over `agent.mcs.yml`, `settings.mcs.yml`, `topics/**/*.mcs.yml`, and `actions/**/*.mcs.yml`.
- Add focused regression checks for the specific bug fixed.
- Delete the temporary verifier afterward when possible.
- Report this explicitly as ad-hoc verification, not canonical suite green.
