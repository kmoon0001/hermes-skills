# Eval Queue Management (Jul 5 2026)

When multiple eval runs stack up (from retry loops, CDP clicks, timed-out scripts), the agent's active-run quota blocks fresh evals. Clear the queue before starting a new one.

## Cancel Stale Runs

```python
import json, urllib.request, os

# Capture token first
# echo | node scripts/cdp_capture_token.cjs --port 9223
token = open(os.path.expandvars(r'%USERPROFILE%\.copilot-studio-cli\test-agent-token.txt')).read().strip()

h = {
    'Authorization': f'Bearer {token}',
    'X-CCI-ApplicationSource': 'Web',
    'X-CCI-BapEnvironmentId': env,
    'X-CCI-BotId': bot,
    'X-CCI-CdsBotId': bot,
    'X-CCI-TenantId': tenant,
    'X-CCI-OrganizationId': org,
    'x-ms-user-agent': 'PVA-Portal/1.0.0',
    'Accept': 'application/json',
    'Origin': 'https://copilotstudio.microsoft.com'
}

gw = 'https://powervamg.us-il107.gateway.prod.island.powerapps.com/api/botmanagement/v2'

# Get all runs
r = urllib.request.Request(f"{gw}/environments/{env}/bots/{bot}/makerevaluations?count=20")
for k, v in h.items(): r.add_header(k, v)
runs = json.loads(urllib.request.urlopen(r, timeout=30).read())

# Cancel every InProgress
for run in runs:
    if run.get('state') == 'InProgress':
        rid = run['id']
        cancel_req = urllib.request.Request(
            f"{gw}/environments/{env}/bots/{bot}/makerevaluations/{rid}/cancel",
            method='PATCH'
        )
        for k, v in {**h, 'Content-Type': 'application/json'}.items():
            cancel_req.add_header(k, v)
        cancel_req.data = json.dumps({'evaluationRunId': rid}).encode()
        result = json.loads(urllib.request.urlopen(cancel_req, timeout=30).read())
        print(f"Cancelled {rid[:12]}: {result.get('state')}")

# Verify clear
r2 = urllib.request.Request(f"{gw}/environments/{env}/bots/{bot}/makerevaluations?count=3")
for k, v in h.items(): r2.add_header(k, v)
runs2 = json.loads(urllib.request.urlopen(r2, timeout=30).read())
active = [r for r in runs2 if r.get('state') == 'InProgress']
assert not active, f"Still {len(active)} active!"
print("Queue clear. Ready.")
```

## Pattern

1. Cancel ALL InProgress/Queued runs
2. Verify queue is clear (no InProgress)
3. Start ONE fresh eval
4. Poll that single run — do NOT start more

## PITFALL — pac CLI caches publish failures

Once `pac copilot publish` fails, it returns the SAME failure timestamp on ALL subsequent calls. Even `pac auth clear` + fresh auth doesn't fix it. The agent IS still published from the last successful run. Verify with Dataverse:

```python
url = f"{ORG}api/data/v9.2/bots({BOT})?$select=publishedon"
# If publishedon is recent, the agent is published
```

Skip pac and use UI publish instead when this happens.
