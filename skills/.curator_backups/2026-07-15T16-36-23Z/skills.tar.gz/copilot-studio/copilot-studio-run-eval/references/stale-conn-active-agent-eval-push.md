# Copilot Studio eval/push guardrails from TheraDoc Workbench session

Use this reference when evals or pushes involve a local workspace that may have stale connection metadata.

## Active-agent identity check

Before pushing or running live/draft evaluations, confirm the active agent identity from a live source, not only from local files.

Recommended check:

```bash
pac copilot list --environment <environment-url>
```

Compare:

- live display name
- Copilot ID
- Component State
- Is Managed
- Status Code / State Code

If two similarly named agents exist, prefer the active/provisioned unmanaged target over a managed/inactive/deprovisioned legacy agent.

## Stale `.mcs/conn.json` pitfall

A workspace `.mcs/conn.json` can point to a legacy/deprovisioned agent even when the folder name looks correct. If commands parse the wrong connection metadata or fail to determine tenant/environment due to JSON/BOM quirks, run with explicit parameters for the active agent instead of trusting the local file.

Durable lesson: verify and correct the connection target; do not capture this as “push/eval is broken.”

## BOM/JSON parse pitfall

Some tooling may print errors like:

```text
Could not parse conn.json: Unexpected token '﻿'
Cannot determine environment ID / tenant ID
```

Treat this as a connection-metadata/BOM parsing issue. Fix the file encoding or pass explicit `--tenant-id`, `--environment-id`, and active agent parameters.

## Eval auth pitfall

If `eval-api.bundle.js` reaches:

```text
No cached token — starting interactive login
```

then the next action is to complete Microsoft auth/cache seeding (browser redirect or device-code helper from `copilot-studio-run-eval`), not to keep retrying the same command in a noninteractive terminal.
