# Gateway Polling with Token Refresh (Python)

Production-grade polling loop with automatic CDP token re-capture.
Validated Jul 4 2026 on Therapy AI Dev (20-case MultiTurn eval).

## Pattern

```python
import json, urllib.request, os, time, subprocess

# Token path: written by cdp_capture_token.cjs
TOKEN_FILE = os.path.expandvars(r'%USERPROFILE%\.copilot-studio-cli\test-agent-token.txt')
GW = 'https://powervamg.us-il107.gateway.prod.island.powerapps.com/api/botmanagement/v2'

def capture_token():
    """Re-run CDP capture script. Token expires ~15 min in practice."""
    subprocess.run(
        ["cmd.exe", "/c",
         'echo | node "D:/my agents copilot studio/pipeline/scripts/cdp_capture_token.cjs" --port 9223'],
        capture_output=True, timeout=30
    )
    with open(TOKEN_FILE) as f:
        return f.read().strip()

def req(url, token, method='GET', body=None):
    """Gateway API request with all required X-CCI headers."""
    r = urllib.request.Request(url, method=method)
    headers = {
        'Authorization': f'Bearer {token}',
        'X-CCI-ApplicationSource': 'Web',
        'X-CCI-BapEnvironmentId': ENV,
        'X-CCI-BotId': BOT,
        'X-CCI-CdsBotId': BOT,
        'X-CCI-TenantId': TENANT,
        'X-CCI-OrganizationId': ORG,
        'x-ms-user-agent': 'PVA-Portal/1.0.0',
        'Accept': 'application/json',
        'Origin': 'https://copilotstudio.microsoft.com'
    }
    for k, v in headers.items():
        r.add_header(k, v)
    if body:
        r.data = json.dumps(body).encode()
        r.add_header('Content-Type', 'application/json')
    return json.loads(urllib.request.urlopen(r, timeout=30).read())

# Start and poll with automatic token refresh
token = capture_token()

# Start eval
result = req(f"{GW}/environments/{ENV}/bots/{BOT}/makerevaluations", token, 'POST',
             {'testSetId': TESTSET_ID})
if 'runId' not in result:
    # Check for active-run quota
    if 'botactiverunquotaviolated' in str(result):
        print("Active run already in progress — polling it instead")
    else:
        raise Exception(f"Failed to start: {result}")

run_id = result['runId']

# Poll loop with token refresh on 4xx
for i in range(25):  # max ~12.5 min at 30s intervals
    time.sleep(30)
    try:
        runs = req(f"{GW}/environments/{ENV}/bots/{BOT}/makerevaluations?count=3", token)
    except urllib.error.HTTPError as e:
        if e.code in (400, 401):
            token = capture_token()  # re-capture on token expiry
            continue
        raise
    
    run = next((r for r in runs if r.get('id') == run_id), None)
    if not run:
        continue
    
    state = run.get('state')
    agr = run.get('aggregatedGraderResults', [])
    succ = next((a['count'] for a in agr if a.get('name') == 'totalSucceeded'), 0)
    fail = next((a['count'] for a in agr if a.get('name') == 'totalFailed'), 0)
    total = succ + fail
    score = round(succ / total * 100) if total > 0 else 0
    
    if state == 'InProgress':
        print(f"  [{succ}P/{fail}F = {score}%]")
    elif state in ('Completed', 'Failed'):
        print(f"DONE: {score}% ({succ}P/{fail}F)")
        break

# Get per-case details for failure analysis
details = req(
    f"{GW}/environments/{ENV}/bots/{BOT}/makerevaluations/{run_id}/details",
    token
)
for tc in details.get('details', {}).get('testCases', []):
    metrics = tc.get('graderMetrics', {}).get('queryResponseMetrics', [])
    if metrics:
        m = metrics[0]
        props = m.get('properties', {})
        explainer = m.get('resultExplainer', '')
        status = m.get('evaluationResult', '?')
        # Common failure patterns:
        #   abstention=Yes, relevance=NA → "agent refuses to help, asks for documents"
        #   relevance=Yes, completeness=Yes, groundedness=No → "response not knowledge-grounded"
        print(f"  [{status}] {props} | {explainer[:100]}")
```

## Gateway URL by Environment

| Environment | Gateway URL |
|-------------|-------------|
| Therapy AI Dev | `powervamg.us-il107.gateway.prod.island.powerapps.com` |
| Ensign Default | `powervamg.us-il106.gateway.prod.island.powerapps.com` |

## Eval Failure Diagnostic Quick-Reference

From `GET /makerevaluations/{runId}/details` → `details.testCases[].graderMetrics.queryResponseMetrics[]`:

| Properties | Meaning | Likely Fix |
|-----------|---------|------------|
| `abstention=Yes, relevance=NA` | Agent refuses to answer, asks for documents | Instructions need "When no documentation is provided" clause |
| `relevance=Yes, completeness=Yes, groundedness=No` | Answer is correct but not knowledge-grounded | Activate Search/Fallback topic, check KB connection |
| `relevance=No` | Wrong or irrelevant answer | Topic routing or KB scope mismatch |
| `completeness=No` | Answer too short/truncated | Instructions need more detail, check response length limits |
