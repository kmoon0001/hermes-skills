# SPA Eval Score Extraction via CDP Runtime.evaluate

When the PPAPI detail endpoint returns 404 `RouteNotFound` (known regional rollout issue for `api.powerplatform.com/copilotstudio/environments/<env>/bots/<bot>/api/makerevaluation/testruns/<id>`), scores are still visible in the Copilot Studio Evaluation SPA page.

## Technique: CDP Runtime.evaluate on document.body.innerText

If the Copilot Studio evaluation page is open in a browser with CDP (`--remote-debugging-port=9223`):

```javascript
const http = require('http');
const WebSocket = require('ws');

http.get('http://127.0.0.1:9223/json/list', res => {
  let d = '';
  res.on('data', c => d += c);
  res.on('end', () => {
    const pages = JSON.parse(d);
    const target = pages.find(p => p.url.includes('copilotstudio') && p.url.includes('evaluation'));
    if (!target) { console.log('Eval tab not found'); return; }

    const ws = new WebSocket(target.webSocketDebuggerUrl);
    ws.on('open', () => {
      ws.send(JSON.stringify({id:1, method:'Runtime.evaluate',
        params:{expression:'document.body.innerText'}}));
    });
    ws.on('message', raw => {
      const msg = JSON.parse(raw.toString());
      if (msg.id === 1) {
        const text = msg.result?.result?.value || '';
        // Parse scores from the flat text
        // Pattern: ...| 83% | PCCH_SR_ITER6 | 100 cases, Data type: single response
        const lines = text.split('\n');
        lines.forEach(l => console.log(l));
        ws.close();
      }
    });
  });
});
```

## Score Parsing Pattern

The SPA renders runs as a flat text grid. Each run row contains:
`{run_name} | {test_cases} cases • Data type: {single response|conversation} | {status} | {author} | {timestamp} | {score}%`

Key patterns:
- Score percentages appear as standalone `N%` on their own line or adjacent to the author/timestamp context
- "Data type: single response" = SR eval
- "Data type: conversation" = Conv eval
- Run names like `PCCH_SR_ITER6` encode SR vs Conv in the name
- Latency: new runs appear as a row with `Status: InProgress` long before the score appears

## When to Use This

- PPAPI `GET /testruns/{id}` returns 404 RouteNotFound (the detail endpoint is broken for this tenant/region)
- PPAPI `GET /testruns` list endpoint works (200) and returns run metadata, but scores are inaccessible via the detail endpoint
- You need to check if recent runs show improvement after applying fixes

## What You Cannot Get

- Per-test-case failure details (which questions passed/failed)
- aiResultReason strings for conversation failures
- The Compare Meaning score (only General Quality is shown in the SPA grid)

These require the PPAPI detail endpoint. If that's broken, accept score-level data only.

## SPA Rendering Pitfalls

**SPA may return 0 chars if page hasn't fully hydrated.** Copilot Studio's React SPA takes 30-60 seconds to render after navigation. Reading body.innerText immediately returns `""` or partial shell. Fix: wait 60s+ before reading, and poll until body.innerText.length > 100.

**Don't use Fetch.enable for SPA extraction.** Enabling `Fetch.enable` (which the CDP token capture script does) intercepts all XHR/fetch requests and breaks the SPA's ability to load data. The page renders as an empty shell. For SPA extraction, use a clean tab without Fetch interception — just `Page.navigate` → wait → `Runtime.evaluate`.

**Fresh tab approach for stuck pages.** If the current evaluation tab returns 0 chars even after 60s, the SPA state may be corrupted from prior Fetch interception. Create a fresh tab via `Target.createTarget` with the eval URL directly, wait 60s, then read. This avoids all prior tab state issues.

**Token capture reloads the page.** The `Fetch.enable` + `Page.reload` pattern in `cdp_capture_token.cjs` causes the SPA to lose its rendered state. After capturing a token, the eval scores won't be readable until the SPA fully re-renders (60s+). Sequence: capture token → read SPA → start runs → capture new token → read SPA.

## Parsing Scores from body.innerText

The SPA renders a flat text grid. Each completed run appears as consecutive lines:
```
{run_name}
{test_cases} cases • Data type: {single response|conversation}
Evaluate
Completed
{test_set_name}
{author}
{timestamp}
{score}%
```

To extract scores programmatically:
```javascript
const text = msg.result?.result?.value || '';
const lines = text.split('\n');
for (let i = 0; i < lines.length; i++) {
  if (lines[i].includes('Automated Test') && i+12 < lines.length) {
    const ctx = lines.slice(i, i+12);
    const score = ctx.find(l => l.trim().match(/^\d+%$/));
    const type = ctx.find(l => l.includes('Data type'));
    const timestamp = ctx.find(l => l.includes('today') || l.includes(':'))
    console.log(ctx[0] + ' | ' + type + ' | ' + score);
  }
}
```

Run names starting with "Automated Test Triggered by API" are eval runs started via the PPAPI programmatically.

## What You Cannot Get

- Per-test-case failure details (which questions passed/failed)
- aiResultReason strings for conversation failures
- The Compare Meaning score (only General Quality is shown in the SPA grid)

These require the PPAPI detail endpoint. If that's broken, accept score-level data only.

## Verified Working

- Therapy AI Dev environment (env: a944fdf0-0d2e-e14d-8a73-0f5ffae23315)
- PCCH agent (bot: ad635500-cf47-f111-bec5-70a8a5b1c3a3)
- Therapy Report Prep (bot: fd1bce12-cf47-f111-bec5-70a8a5b1c3a3)
- Edge browser on port 9223 via CDP WebSocket
- Jul 3-4, 2026: Extracted PCCH SR (89%, 67%), Conv (42%, 40%), and Report Prep (15%) scores
