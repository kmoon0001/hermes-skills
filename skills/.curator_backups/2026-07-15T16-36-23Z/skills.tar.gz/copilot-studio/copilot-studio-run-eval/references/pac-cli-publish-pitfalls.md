# PAC CLI Publish Pitfalls

## Environment Switching
PAC auth profiles can silently revert. Always verify the active environment before publishing:
```bash
pac auth list | grep "*"
```

To publish to a specific environment that isn't the active profile:
```bash
pac copilot publish --environment https://org<id>.crm.dynamics.com/ --bot <bot-id>
```

Using `--environment` with the full org URL forces PAC to use that org regardless of the active profile.

## extract-template Crash (v2.7.4)
`pac copilot extract-template` crashes with `System.ArgumentException` even when all required flags are provided. The command loads components correctly ("Loaded 37 components") but crashes during YAML generation. This is a known bug in PAC v2.7.4.

**Workaround**: Use `pac org fetch` with a custom XML query to extract component data:
```xml
<fetch>
  <entity name="botcomponent">
    <attribute name="botcomponentid" />
    <attribute name="name" />
    <attribute name="componenttype" />
    <attribute name="schemaname" />
    <attribute name="data" />
    <attribute name="statecode" />
    <filter>
      <condition attribute="_parentbotid_value" operator="eq" value="<bot-id>" />
    </filter>
  </entity>
</fetch>
```

Run: `pac org fetch --environment <org-url> --xmlFile fetch.xml > raw.txt`

**Required flags for extract-template** (even though it crashes):
- `--bot` (Copilot ID)
- `--templateFileName` (output path)
- `--templateVersion` (e.g., "1.0.0" — required due to v2.7.4 bug)
- `--overwrite`

## publish Succeeds but Evals Don't Pick Up Changes
After `pac copilot publish` reports "Published successfully!", eval runs may still use old behavior. The publish propagation can take several minutes. If the first post-publish eval shows no improvement, try:
1. Wait 2-3 minutes after publish success
2. Run draft eval (`runOnPublishedBot: false`) — sometimes picks up Dataverse changes faster than published eval
3. Verify the Dataverse data field actually changed before publishing

## Evidence
Jul 1, 2026 — Therapy Documentation Feedback Agent (Prod): 
- extract-template loaded 37 components then crashed
- `pac org fetch` with custom XML successfully extracted all component data
- `pac copilot publish --environment <url> --bot <id>` succeeded
- Post-publish eval showed same 16% until root cause (SearchSpecificFiles) was identified
