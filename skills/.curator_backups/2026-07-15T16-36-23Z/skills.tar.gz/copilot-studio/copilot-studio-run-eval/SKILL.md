---
name: copilot-studio-run-eval
description: "Run evaluations against Copilot Studio agent's DRAFT via PPAPI — no publish needed. List test sets, start runs, poll, fetch results, propose fixes."
version: 1.1.1
author: Copilot Studio Pipeline
license: MIT
platforms: [windows, linux, macos]
metadata:
  hermes:
    tags: [copilot-studio, evaluation, ppapi, draft-eval]
    homepage: https://learn.microsoft.com/microsoft-copilot-studio/
---

# Run Evaluation (PPAPI)

Run evaluations against Copilot Studio agent's DRAFT — no publish needed.
Requires --client-id and --workspace. If no client ID, tell caller to run test-auth first.
All eval-api commands normally run in foreground. If a command prints `No cached token — starting interactive login`, use a PTY-backed interactive run so the local redirect listener stays alive while the user signs in directly in the browser. Do not ask the user to paste credentials or MFA codes in chat. If backgrounding is required to keep working while auth waits, use `pty=true` and poll the process; non-PTY background auth can fail with `stdin is not a tty`.

## Practice Notes (Updated Jul 11 2026)

**PPAPI TOKEN ACQUISITION: Manage-agent MSAL cache CAN mint eval tokens (primary path).**

The manage-agent cache at `~/.copilot-studio-cli/manage-agent.cache.json` (populated by `pac auth` or VS Code extension) CAN mint eval tokens for the Gateway API. Use MSAL `acquireTokenSilent` with scope `api://96ff4394-9197-43aa-b393-6a41652e21f8/.default` — this matches the Power Virtual Agents app registration the cache was originally issued for. See the "Auth via Manage-Agent MSAL Cache" section below for full code. This is faster than CDP capture and doesn't need a browser running.

**PITFALL — CDP capture is the fallback, not primary.** Only use CDP when the MSAL cache is empty or the account is missing from the cache.

**PITFALL — Run MSAL token refresh from the directory where node_modules resolve.** On THIS machine the MSAL modules resolve under `/c/Users/kevin/skills-for-copilot-studio/scripts/node_modules` (NOT `D:/my agents copilot studio/pipeline`). `find /c/Users/kevin -name msal-node -type d` to locate them. Copy `refresh_eval_token.cjs` into that dir, then `NODE_PATH=./node_modules node refresh_eval_token.cjs`. A script saved elsewhere fails with `MODULE_NOT_FOUND`.

**PITFALL — The `az` token for `https://api.powerplatform.com` does NOT work with the eval Gateway.** The PowerVA Gateway uses a PPAPI token scoped to the `96ff4394` app registration, not the `az` CLI Dataverse scope.

**HEADLESS token capture (locked live-browser workaround, validated 2026-07-12):** When the MSAL `api://96ff4394` token is rejected (403/404) by the PowerVA Gateway and you have user OK for headless capture, use `playwright-core` (Edge channel) to launch a **headless** browser from a COPY of the live Edge profile and capture the portal `Authorization: Bearer` header from the eval SPA. CRITICAL: the running Edge already owns its `user-data-dir`, so launching Playwright against it fails with `exitCode=21`. `xcopy` the profile to a temp dir first (cookies travel, no re-auth), then launch against the copy. `waitUntil: 'domcontentloaded'` (never `networkidle` — SPA never idles) and poll for the header. Full recipe + gateway endpoint paths in `references/headless-playwright-edge-token-capture.md`.

**PITFALL — Gateway run endpoints: `makerevaluations`, NOT `evaluationruns`.** Validated 2026-07-12: `GET .../evaluationruns/{id}` and `/evaluationruns({id})` return 404. Use `POST .../makerevaluations` to start (body `{ "testSetId": "<guid>" }` → `{ runId, state }`) and `GET .../makerevaluations/{runId}/details` for progress/final scores. The run object shows `runOnPublishedBot: false` when grading the DRAFT (the PATCHed instructions `botcomponent.data`), so the fix is still evaluated even without publish.
**PITFALL — the `/direct/evaluation/runs` and `/evaluation/runs` paths 404 (validated 2026-07-13).** A one-off status query shaped `GET .../direct/evaluation/runs/{id}`, `GET .../evaluation/runs`, and `GET .../direct/evaluation/runs?pageSize=6` ALL returned `HTTP Error 404: Not Found`. Only the **fully-qualified list path under the environments segment** works: `GET /environments/{env}/bots/{bot}/makerevaluations?$top=6` (JSON **array** response, NOT `{value:[...]}`). Each array element has `id` (the run GUID), `state`, `aggregatedGraderResults[]` with `name`=`totalSucceeded`/`totalFailed` and `count`. To grab one run: filter the array by `x['id'].startswith(RUNID[:8])`. A working one-shot status probe:
```python
import json,urllib.request
TOKEN=open(r'C:/Users/kevin/.copilot-studio-cli/test-agent-token.txt').read().strip()
ENV='<env-guid>'; BOT='<bot-guid>'
GW=f'https://powervamg.us-il107.gateway.prod.island.powerapps.com/api/botmanagement/v2/environments/{ENV}/bots/{BOT}'
H={'Accept':'application/json','Origin':'https://copilotstudio.microsoft.com',
   'X-CCI-ApplicationSource':'Web','X-CCI-BapEnvironmentId':ENV,'X-CCI-BotId':BOT,'X-CCI-CdsBotId':BOT,
   'X-CCI-TenantId':'<tenant>','X-CCI-OrganizationId':'<org>','Authorization':f'Bearer {TOKEN}'}
arr=json.loads(urllib.request.urlopen(urllib.request.Request(f'{GW}/makerevaluations?$top=8',headers=H)).read())
for r in arr:
    ag=r.get('aggregatedGraderResults') or []
    p=f=0
    for m in ag:
        if m.get('name')=='totalSucceeded': p=m.get('count',0)
        if m.get('name')=='totalFailed': f=m.get('count',0)
    print(r['id'][:8], r.get('state'), f"{p}/{p+f}")
```
Note `$top=` (OData) is the param that actually returned data; the older `?count=10` variant also returns an array but `$top` is what was confirmed live. Never build the URL via an f-string containing a literal `}` inside a GUID path segment (`f'.../makerevaluations/{RUNID}/details'` raises `SyntaxError: f-string: single '}' is not allowed`) — build BASE in a var then plain-concat `/`+runid+`/details`.

**CRITICAL — DIRECT PPAPI HOST REJECTS TOKENS IN THIS TENANT.** `https://api.powerplatform.com/copilotstudio/.../api/makerevaluation/...` returns `401 InvalidAudience (S2S17001)` for BOTH the MSAL `api://96ff4394-9197-43aa-b393-6a41652e21f8/.default` token AND `az --resource 96ff4394-9197-43aa-b393-6a41652e21f8` (aud=`96ff4394-...`). Also `az --resource https://api.powerplatform.com` gives 403 (wrong audience, needs headers). The ONLY working host is the **Gateway** below with X-CCI routing headers — do not waste quota on the direct PPAPI host.
- **WORKING Gateway URL (validated 2026-07-12):** `https://powervamg.us-il107.gateway.prod.island.powerapps.com/api/botmanagement/v2`
- Every request needs ALL X-CCI headers (see `references/gateway-eval-api-recipe.md`). Required: `X-CCI-ApplicationSource: Web`, `X-CCI-BapEnvironmentId`, `X-CCI-BotId`, `X-CCI-CdsBotId` (=BotId), `X-CCI-TenantId`, `X-CCI-OrganizationId` (env-specific).
- List: `GET /environments/{env}/bots/{bot}/makerevaluations/testsets` -> `{testComponents:[{component:{displayName,id}, numberOfTestCases, evaluationSetType}]}`
- Start: `POST /environments/{env}/bots/{bot}/makerevaluations` body `{"testSetId":"<guid>"}` -> `{runId, state}`
- Poll: `GET /environments/{env}/bots/{bot}/makerevaluations/{runId}/details` (per-case graderMetrics). Fallback list: `GET .../makerevaluations?count=10` -> JSON array with `aggregatedGraderResults[]` (totalSucceeded/totalFailed).
- A ready, parameterized harness lives at `scripts/eval_harness.py` (uses these exact constants for Therapy AI Dev / PCCH). Copy it into your agent dir and run `python eval_harness.py list|start <id>|poll <id>|last`.
- `scripts/loop_patch_then_eval.py` — full auto "narrow-then-pull" remediation loop: retries a live topic PATCH through a CRM-DNS outage, starts the affected eval, and auto-DELETES (reverts) the additive topic if it regresses below `BASELINE_PCT`. Use when the user approves "both" (narrow first, pull if still failing). Pre-wired with PCCH IDs; edit the CONFIG block for other agents.
- **Token mints via MSAL cache** (`api://96ff4394.../.default` scope) — that token IS accepted by the Gateway host (just not the direct PPAPI host). See Auth section below.

### CDP Chrome Launch Pattern (fallback PPAPI auth path)

Launch Chrome with the DEFAULT profile to preserve Copilot Studio auth cookies. Use `--remote-debugging-port=9223`:
2. Verify CDP: `curl -s http://127.0.0.1:9223/json/version`
3. Navigate to eval page via CDP `Page.navigate` → wait ~10s → `node scripts/cdp_capture_token.cjs`
4. Token at `~/.copilot-studio-cli/test-agent-token.txt`

**PITFALL — Use default Chrome Canary user data dir to preserve Copilot Studio sessions.** Path: `C:\\Users\\kevin\\AppData\\Local\\Google\\Chrome SxS\\User Data`. A fresh `--user-data-dir` requires re-auth.

**PITFALL — `cdp_capture_token.cjs` searches for "evaluation" in the URL.** Navigate to the eval page directly, not the topics or overview tab.

**PITFALL — `browser_navigate` truncates long OAuth URLs** (drops `&scope=` → `AADSTS900144`). Use `browser_console` with `window.location.href` or CDP `Page.navigate` instead.

**PITFALL — `cdp_ws_capture.cjs` has a hardcoded TARGET_ID** that only works on the machine it was captured on. Use `scripts/cdp_capture_token.cjs` — finds eval tab by URL pattern, not hardcoded ID.

**PITFALL — CDP Chrome launch: when no browser is running with `--remote-debugging-port`, launch a separate Chrome instance with the flag. Use `mcp_cua_driver_launch_app` with `--remote-debugging-port=9223` and a fresh `--user-data-dir=...` profile. The existing Chrome instance is unaffected. Verify with `curl -s http://127.0.0.1:9223/json/version`.

**PITFALL — `browser_navigate` truncates long OAuth URLs with query params.** The tool drops everything after the first `&` in some cases, producing `AADSTS900144: The request body must contain the following parameter: 'scope'`. Fix: use `browser_console` to set `window.location.href = '<full URL>'` instead. The full URL including all `&scope=`, `&state=`, `&code_challenge=` params must be preserved.

**PITFALL — CDP token capture requires an EVAL tab, not just any Copilot Studio tab.** The `cdp_capture_token.cjs` script searches for tabs with "evaluation" in the URL. If the browser only has a Topics or Overview tab open, the capture fails with "Eval tab not found." Fix: navigate any Copilot Studio CDP tab to the evaluation page URL first, wait for SPA to load (~30s), then run the capture.

**PITFALL — PPAPI token expiry is ~15 minutes in practice, not 1 hour.** Strategy: capture the token, run ALL test set list operations immediately, then start runs, then poll — re-capture if a 401 appears before polling completes. Re-capture via CDP is fast (~15s).

**PITFALL — SPA text returns 0 chars when SPA hasn't finished hydrating.** Wait 60s after navigation before reading. Don't use Fetch interception for SPA extraction — use a clean tab.

**PITFALL — Unconditional eval instruction blocks cause Conv regression.** "Respond directly" and "Don't ask follow-ups" as unconditional rules drop conversational scores ~20pp. Eval instructions MUST be conditional per MS Learn. Re-run both SR+Conv after changing eval instructions.

**PITFALL — SR and Conv for the same agent must be sequential.** PPAPI enforces one active run per agent at a time. Different agents CAN run simultaneously.

**PITFALL — Eval runs can leave 30-60% of cases in "Pending" state never evaluated.** Observed across multiple Conv eval runs (PCCH V2, 8+ runs, Jul 11 2026). Cases stuck in Pending are not scored and do not count toward aggregated results. Always check the pending/total ratio. If >20% are pending, the run's score may not be representative.

**Poll script pattern — persist as .cjs file to avoid MSAL TTY errors (Validated 2026-07-11):**
When writing Node.js poll scripts that only use `fs` + `https` (no MSAL), inline `node -e` triggers `stdin is not a tty` in background processes because bash passes the stdin handle. Fix: write the script as a `.cjs` file via `write_file`, then run with `node <path>/script.cjs`. The .cjs extension prevents Node from searching for ESM `package.json` and avoids MSAL auto-load issues.

**PITFALL — Combined `sleep 300 && az token && node poll` exceeds the 30s terminal timeout.** The terminal tool's timeout applies to the ENTIRE command chain, not per-command. A 5-minute sleep + 2-second poll = 302s total. Fix: (a) set `timeout=600` on the combined command, or (b) split into two — background the sleep with notify_on_complete, then poll separately.

**PITFALL — Windows path mangling through bash tooling.** When you pass a Windows-style absolute path like `C:\Users\kevin\...` to `write_file`/tools that normalize paths, it can be mis-resolved to `C:\c\Users\kevin\...` (a spurious `c\` prefix) — the file lands OUTSIDE the intended workspace and the tool warns. FIX: use forward-slash MSYS paths (`/c/Users/kevin/...`) for all `write_file`/`terminal`/`cd` operations on this Windows host. Also: copying a `.cjs` script via `write_file` to `C:\Users\...` then `node`-ing it can fail the same way; write to a `/c/Users/...` path or copy with `cp` inside bash. The harness (`scripts/eval_harness.py`) and `refresh_eval_token.cjs` must live at `/c/Users/kevin/...` paths.

**PITFALL — `refresh_eval_token.cjs` exits with a UV assertion crash** (`Assertion failed: !(handle->flags & UV_HANDLE_CLOSING)`) on Windows even on success — the `process.exit(0)` races the MSAL handle close. The token file is written before the crash; treat any non-empty `test-agent-token.txt` as success.

### Auth fallback: device-code cache seeding
If localhost redirect/browser auth gives Microsoft sign-in errors, query parameters get dropped, or the user reports trouble signing in, do not keep looping the same URL. Two fallback paths exist:

**Path A (recommended): CDP WebSocket token capture from browser** — See `references/cdp-ppapi-token-capture.md`. Captures the live Bearer token from an already-authenticated browser tab via Chrome DevTools Protocol. Faster than device-code and bypasses tenant Conditional Access blocks. Requires browser running with `--remote-debugging-port=9223`.

**Path B: Device-code MSAL cache seeding** — Use the bundled helper script.

**PITFALL — redirect URI mismatch (AADSTS50011):** The interactive localhost redirect can fail with `AADSTS50011: The redirect URI 'http://localhost:<port>' specified in the request does not match the redirect URIs configured for the application`. MSAL Node's LoopbackClient chooses a random port, but the Azure app registration may only have specific ports or no localhost URIs. If you see this, the interactive flow is dead for that client — do not retry with different ports (they all fail the same way).

**PITFALL — tenant Conditional Access blocks device-code flow:** If `https://login.microsoft.com/device` returns "you don't have access", the tenant policy blocks device-code authentication. The device-code helper will sit at `device_code` status forever — kill it. Do not retry device code after a tenant-access denial.

**PITFALL — both localhost redirect AND device-code blocked:** When both interactive redirect (AADSTS50011) and device-code (Conditional Access) fail, all automated OAuth paths for the PPAPI client are exhausted. Fall back to manual token capture (see below). Do not loop retrying either flow.

### Automated CDP WebSocket token capture (use `scripts/cdp_capture_token.cjs`)

When both `eval-api.bundle.js` interactive login AND device-code seeding are blocked, use the CDP WebSocket script to capture the token automatically from the user's already-signed-in browser:

```bash
node scripts/cdp_capture_token.cjs
```

**PITFALL — do NOT use `cdp_ws_capture.cjs` or `cdp_simple.cjs`:** Both have hardcoded identifiers from a previous session. `cdp_capture_token.cjs` finds the eval tab by URL pattern instead.

With the token, call PPAPI endpoints directly via `curl` or Python `urllib`. Do NOT attempt to write into the DPAPI-encrypted MSAL cache file. Token expires after ~1 hour.

**Verified**: Jul 1, 2026 — Chrome 149, 4487-char token, Therapy Documentation Feedback Agent (Prod).

### Manual browser DevTools token capture (fallback)

If CDP isn't available, ask the user to extract the Bearer token manually:

1. Have the user open the Copilot Studio Evaluation page in their signed-in browser:
   `https://copilotstudio.microsoft.com/environments/<envId>/bots/<botId>/evaluation`
2. Press F12 → Network tab
3. Refresh the page (F5)
4. Filter by `makerevaluation`
5. Click any request, go to Headers → Request Headers
6. Copy the full `Authorization: Bearer eyJ...` header value
7. Paste the token back to the agent

With the raw token, call PPAPI endpoints directly:
```bash
curl -H "Authorization: Bearer <token>" \
  "https://api.powerplatform.com/copilotstudio/environments/<envId>/bots/<botId>/api/makerevaluation/testsets?api-version=2024-10-01"
```

## Step 1: List test sets

**PITFALL — missing IDs when no `.mcs/conn.json`:** `eval-api.bundle.js` needs `--agent-id`, `--tenant-id`, and `--environment-id` if the workspace lacks `.mcs/conn.json`. Without them it fails sequentially with "Cannot determine agent/tenant/environment ID". Provide all three explicitly. Find the environment GUID with `pac env list` (look for the org name in the "Display Name" column). Find the agent Copilot ID with `pac copilot list`.

### Direct PPAPI via Python (preferred over eval-api.bundle.js)

When the CDP token is captured to `test-agent-token.txt`, skip `eval-api.bundle.js` entirely and call the PPAPI directly. This avoids ALL MSAL auth issues (redirect URI mismatch, device-code blocks, interactive login timeouts).

**PITFALL — `GET /testruns/{id}` detail endpoint may return 404 `RouteNotFound`:** The PPAPI `api.powerplatform.com/copilotstudio/environments/.../api/makerevaluation/testruns/{id}` detail endpoint returns RouteNotFound for some tenants/regions (known public-preview regional rollout issue). The LIST endpoint (`?$top=3`) works fine, but getting scores via the detail endpoint fails. When this happens:
- Accept that per-case detail is unavailable
- Fall back to SPA eval score extraction via CDP `Runtime.evaluate` (see section above)
- Do NOT mistake "no API access" for "scored 0%"

```python
import json, urllib.request, pathlib, os

token = pathlib.Path(os.path.expandvars(r'%USERPROFILE%\\.copilot-studio-cli\\test-agent-token.txt')).read_text().strip()
env_id = "<environment-guid>"
agent_id = "<bot-guid>"
api_ver = "2024-10-01"
base = f"https://api.powerplatform.com/copilotstudio/environments/{env_id}/bots/{agent_id}/api/makerevaluation"

# List test sets
url = f"{base}/testsets?api-version={api_ver}"
req = urllib.request.Request(url)
req.add_header("Authorization", f"Bearer {token}")

with urllib.request.urlopen(req, timeout=30) as resp:
    data = json.loads(resp.read())
for ts in data.get('value', []):
    print(f"  {ts['displayName']} | {ts['totalTestCases']} cases | ID: {ts['id']}")

# Start run
testset_id = "<testset-id>"
url2 = f"{base}/testsets/{testset_id}/run?api-version={api_ver}"
body = {"runOnPublishedBot": False, "mcsConnectionId": "<connection-id>"}  # omit mcsConnectionId if none
req2 = urllib.request.Request(url2, method="POST")
req2.add_header("Authorization", f"Bearer {token}")
req2.add_header("Content-Type", "application/json")
req2.data = json.dumps(body).encode()

with urllib.request.urlopen(req2, timeout=30) as resp:
    run = json.loads(resp.read())
print(f"Run: {run['runId']} | State: {run['state']}")

# Poll until complete
run_id = run['runId']
for i in range(15):
    time.sleep(30)
    url3 = f"{base}/testruns/{run_id}?api-version={api_ver}"
    req3 = urllib.request.Request(url3)
    req3.add_header("Authorization", f"Bearer {token}")
    with urllib.request.urlopen(req3, timeout=30) as resp:
        d = json.loads(resp.read())
    if d['state'] in ('Completed', 'Failed', 'Cancelled'):
        results = d.get('testCasesResults', [])
        passed = sum(1 for x in results if x['metricsResults'][0]['result']['status'] == 'Pass')
        failed = len(results) - passed
        abstains = sum(1 for x in results if x['metricsResults'][0]['result'].get('data',{}).get('abstention') == 'Yes')
        print(f"DONE: {passed}P/{failed}F = {passed*100/len(results):.0f}% | Abstains: {abstains}/{len(results)}")
        break
    print(f"  {(i+1)*30}s: {d['state']}")
```

**Key advantage:** No Node.js dependency, no MSAL cache, no redirect URI issues. 

**PITFALL — `totalTestCases: 0` in the start-run response is normal.** The count shows 0 initially and populates once the run starts processing. Poll the run status to see real counts.

**PITFALL — Test set discovery:** Filter test sets by `displayName` matching the bot name. Multiple versions accumulate with different IDs. The correct test sets have `totalTestCases` matching expected counts (20 for Conv, 100 for SR).

**PITFALL — PPAPI token expiry is ~15 minutes in practice, not 1 hour.** Verified Jul 3 2026 in Therapy AI Dev: the token captured via CDP expired within ~15 minutes, returning 401 `TokenExpired`. The documented ~1 hour lifetime may apply to production environments only. Strategy: capture the token, run ALL test set list operations immediately (fast), then start runs, then poll — re-capture if a 401 appears before polling completes. Re-capture via CDP is fast (~15 seconds) as long as the Copilot Studio eval tab is still open in the browser.

**Token expiration handling:** If PPAPI returns 401 `TokenExpired`, re-run the CDP capture script to get a fresh token. The Copilot Studio eval tab in the user's browser must still be open.

Verification pitfall: after eval/push-related YAML edits, if there is no canonical test suite, create and run a temporary `hermes-verify-*.py` verifier under the user's temp directory, validate changed YAML plus the active workspace, clean it up, and report it as ad-hoc verification rather than suite green. See `references/live-auth-url-and-verification.md`.

Active-agent/connection pitfall: before push/eval, verify the live active/provisioned agent rather than trusting `.mcs/conn.json`; local connection files may point at a managed/inactive/deprovisioned legacy agent or fail due to BOM JSON parsing. See `references/stale-conn-active-agent-eval-push.md`.

### Interactive auth URL handling pitfall
When opening the Microsoft auth URL from tool/browser automation, preserve the full query string. If the browser opens a Microsoft error such as `AADSTS900144: The request body must contain the following parameter: 'scope'`, the URL was truncated or `&scope=...` was dropped. Retry by assigning the full URL through page JavaScript (`window.location.href = '<full URL>'`) or by opening it in the user's local default browser (`os.startfile(url)` on Windows) while the PTY auth listener remains running. Do not ask the user to paste credentials; have them complete sign-in/MFA directly in the browser, then poll the eval process for completion.

## Step 1: List test sets
```bash
node "D:/my agents copilot studio/pipeline/scripts/eval-api.bundle.js" list-testsets --workspace <path> --client-id <id>
```
- No test sets: tell user to create one in Copilot Studio (Evaluate tab > New evaluation). Stop.
- One test set: tell user which one and proceed.
- Multiple: show all and ask user to pick.

## Step 2: Ask about authenticated execution — MANDATORY
Ask user: Does your agent use authenticated knowledge sources or connector actions?
If so, they need a connection ID from https://make.powerautomate.com -> Connections -> Microsoft Copilot Studio connection -> copy connection ID from URL.
Without connection ID, eval runs anonymously and tools/knowledge will NOT be used.
Do NOT proceed until user responds.

**PITFALL — connection ID doesn't always fix abstention:** Even with a valid connection ID from Power Automate, pass rates may not improve if the test set questions fall outside the agent's KB scope. The agent's guardrails (e.g., SOURCE RESTRICTION) will still cause it to abstain when questions don't match KB content. If connection-ID and no-connection-ID runs produce identical pass rates (verified Jul 2026: Therapy Documentation Feedback Agent, 16% both ways), the root cause is test set/agent scope misalignment, not missing auth. Investigate test case content before retrying with different connection IDs.

## Step 3: Start the run
```bash
node "D:/my agents copilot studio/pipeline/scripts/eval-api.bundle.js" start-run --workspace <path> --client-id <id> --testset-id <id> --run-name "Draft eval <date>"
```
Add --connection-id <id> if user provided one. Add --published only if user explicitly asked.

## Step 4: Poll until complete
```bash
node "D:/my agents copilot studio/pipeline/scripts/eval-api.bundle.js" get-run --workspace <path> --client-id <id> --run-id <runId>
```
Poll every 15-30 seconds. Report progress. Stop when state is Completed, Failed, Abandoned, or Cancelled.

### SPA eval score extraction via CDP (when PPAPI detail endpoint is broken)

When `GET /testruns/{id}` returns 404 `RouteNotFound` (known regional PPAPI rollout issue — the list endpoint works but detail fails), scores are still visible in the Copilot Studio Evaluation SPA. Extract them via CDP `Runtime.evaluate`:

1. Open the evaluation page in a CDP-enabled browser (port 9223)
2. Run this from a Node.js environment:
```javascript
const http = require('http');
const WebSocket = require('ws');

http.get('http://127.0.0.1:9223/json/list', res => {
  let d = '';
  res.on('data', c => d += c);
  res.on('end', () => {
    const pages = JSON.parse(d);
    const target = pages.find(p => p.url && p.url.includes('copilotstudio') && p.url.includes('evaluation'));
    if (!target) { console.log('Eval tab not found'); return; }
    const ws = new WebSocket(target.webSocketDebuggerUrl);
    ws.on('open', () => {
      ws.send(JSON.stringify({id:1, method:'Runtime.evaluate',
        params:{expression:'document.body.innerText'}}));
    });
    ws.on('message', raw => {
      const msg = JSON.parse(raw.toString());
      if (msg.id === 1) {
        const text = msg.result?.result?.value || '';
        // Parse scores: look for "N%" near "single response" or "conversation" markers
        const lines = text.split('\n');
        lines.forEach(l => console.log(l));
        ws.close();
      }
    });
  });
});
```
3. Parse the output — each run row has: `{name} | {cases} cases • Data type: {SR|Conv} | {author} | {score}%`

See `references/cdp-spa-eval-extraction.md` for full details and score parsing patterns.

**Limitation:** SPA extraction gives score-level data only (General Quality %). Per-case failure details and aiResultReason strings require the PPAPI detail endpoint — accept score-level data when the API is broken.

### Auth via Manage-Agent MSAL Cache (no browser needed)

The `manage-agent.cache.json` at `~/.copilot-studio-cli/manage-agent.cache.json` is populated by `pac auth` and the VS Code Copilot Studio extension. It can be read by `@azure/msal-node-extensions` `PersistenceCachePlugin` to silently acquire tokens for BOTH PPAPI and Dataverse scopes. This bypasses all CDP, redirect-URI, and device-code auth headaches.

**PITFALL — This only works for the same Windows user that ran `pac auth create`.** The cache is DPAPI-encrypted per-user.

```javascript
const { PublicClientApplication } = require('@azure/msal-node');
const { PersistenceCreator, PersistenceCachePlugin, DataProtectionScope }
  = require('@azure/msal-node-extensions');

const CACHE = path.join(os.homedir(),'.copilot-studio-cli','manage-agent.cache.json');
const TENANT = '<tenant-guid>';
const CLIENT = '51f81489-12ee-4a9e-aaae-a2591f45987d'; // Power Platform CLI

async function getToken(scope) {
  const p = await PersistenceCreator.createPersistence({
    cachePath: CACHE, dataProtectionScope: DataProtectionScope.CurrentUser,
    serviceName: 'copilot-studio-cli', accountName: 'manage-agent',
    usePlaintextFileOnLinux: true
  });
  const app = new PublicClientApplication({
    auth: { clientId: CLIENT, authority: `https://login.microsoftonline.com/${TENANT}` },
    cache: { cachePlugin: new PersistenceCachePlugin(p) }
  });
  const accs = (await app.getTokenCache().getAllAccounts())
    .filter(a => a.tenantId === TENANT);
  const r = await app.acquireTokenSilent({ scopes: [scope], account: accs[0] });
  return r.accessToken;
}
```

**Get PPAPI token (for eval gateway via PowerVA gateway — must use this scope):**
```javascript
const ppapiToken = await getToken('api://96ff4394-9197-43aa-b393-6a41652e21f8/.default');
```

**Reusable script:** `scripts/refresh_eval_token.cjs` in this skill wraps the MSAL token refresh. Run from the directory where `node_modules/@azure/msal-node` resolves (see pipeline-dir pitfall above): `NODE_PATH=./node_modules node refresh_eval_token.cjs`. Replaces `test-agent-token.txt` with a fresh token. Faster than CDP capture and doesn't need a browser. NOTE: the script may print a `UV_HANDLE_CLOSING` assertion at process exit — that is non-fatal; the token file is written before the crash.

**PITFALL — Run MSAL token refresh from the pipeline directory where node_modules resolve.** The MSAL modules are installed in `D:/my agents copilot studio/pipeline/node_modules`. A script saved elsewhere will fail with `MODULE_NOT_FOUND`. Copy to pipeline dir or run the in-skill script from pipeline context.

**PITFALL — Scope MUST be `api://96ff4394-.../.default` for gateway API calls.** Using `https://api.powerplatform.com/.default` triggers `AADSTS500131: Assertion audience does not match` (400 Bad Request). The manage-agent cache's refresh token was issued for the `96ff4394` (Power Virtual Agents) application, not the broader PPAPI audience.

**Get Dataverse token (for PATCHing instructions & topic YAML):**
```javascript
const dvToken = await getToken('https://<org>.crm.dynamics.com/.default');
// Use with: Authorization: Bearer <dv_token> against https://<org>.crm.dynamics.com/api/data/v9.2
```

**Why both are needed:** The PPAPI scope works for eval/gateway endpoints. The Dataverse scope works for PATCHing `botcomponent.data` (instructions, topic YAML). Neither scope covers the other, and CDP-captured tokens are only PPAPI-scoped.

**Run from pipeline context** so `node_modules` resolves. `node -e` works directly for silent MSAL (no `echo "" |` prefix needed — that's only for OBO/interactive flows):
```bash
cd "D:/my agents copilot studio/pipeline"
node -e "...inline script..."
```
**PITFALL — publish via Gateway REST API returns 404.** The endpoint `POST .../publish` on the PowerVA gateway returns 404 for all publish operations. Use `pac copilot publish --bot <bot-id>` instead — it works reliably. Verify with `pac copilot list` to check PublishedOn timestamp. Active eval runs block publish — either wait for completion or cancel via `PATCH .../makerevaluations/{runId}/cancel` first.

For Gateway API usage from the live Copilot Studio Evaluation UI, use the PowerVA gateway API:
- Capture the live Evaluation page's `authorization` and `x-cci-*` headers via CDP WebSocket.
- **ALL requests require X-CCI routing headers** — see `references/gateway-eval-api-recipe.md` for exact values and copy-paste curl commands.
- `GET /makerevaluations/testsets` lists test sets.
- `GET /makerevaluations?count=10` lists runs (returns JSON array, not `{value: [...]}`). Use this as the durable polling fallback: start a run, then poll the list endpoint and match by `id`/`runId` when direct run endpoints fail.
- `POST /makerevaluations` starts a run by `testSetId`.
- Scores via `aggregatedGraderResults[]` — `MakerEvaluationRunCountMetric` objects with `name` (totalSucceeded/totalFailed/...) and `count`.
- `GET /makerevaluations/{runId}/details` fetches full case details and is the preferred source for progress/result analysis. If a custom poller gets `405 Method Not Allowed`, switch to `/details` rather than continuing to retry the failing endpoint.
- In `/details`, score General Quality from `details.testCases[].graderMetrics.queryResponseMetrics[]`: pass only when relevance=Yes, completeness=Yes, abstention=No, and groundedness is absent or Yes.

**Grader metrics structure (validated Jul 11 2026):**
```
{
  "queryResponseMetrics": [{
    "metricType": "ResponseQualityGeneral",
    "properties": {
      "abstention": "Yes|No",
      "relevance": "Yes|No|NA",
      "groundedness": "Yes|No",
      "completeness": "Yes|No|undefined"
    },
    "evaluationResult": "Pass|Fail"
  }]
}
```

**Failure-to-root-cause mapping:**
| Grader Signal | Root Cause | Fix |
|---|---|---|
| completeness=No, relevance=Yes, groundedness=Yes | Truncated answer -- under 4 sentences or 800 char limit in responseInstructions | Remove unconditional length caps; add conditional RESPONSE FORMAT |
| abstention=Yes, relevance=NA | Agent refused -- cannot find in sources | Add EVALUATION CONTEXT block with NEVER abstain, answer with domain expertise |
| groundedness=No, completeness=Yes, relevance=Yes | KB gap -- agent answered correctly but info not in knowledge sources | Enrich KB content OR update additionalInstructions to ground more tightly |
| Answer contains raw `=If(IsBlank(` | SendActivity with conditional Power Fx formula that did not evaluate | Replace `=If(IsBlank(Topic.Answer), ..., Topic.Answer)` with `=Topic.Answer` |

**CORRECTION (2026-07-12) — `=If(IsBlank(Topic.Answer), A, B)` in a SendActivity `activity:` IS valid Power Fx, not a raw-formula leak.** It evaluates to A when the answer is blank, B otherwise — the bot does NOT emit the literal formula. Do not "fix" it by force-replacing with `=Topic.Answer` (that removes the blank-answer guard, a capability regression). The real defect when you see one of these is usually GARBLED TEXT in the blank branch (e.g. a double-sentence like `"No document text detected... for the topic you asked about. For a complete analysis, please paste..."`). Fix = tighten the text branch only, keep the `If(IsBlank(...))` structure. Only treat it as a true leak if the RUNTIME OUTPUT literally shows `=If(IsBlank(` — verify from the actual response, not the YAML.

**CORRECTION — `/details` DOES return per-case data headlessly once `state=Completed`.** The earlier claim that `details.testCases` is empty was based on a mid-flight read (state=InProgress). Validated 2026-07-12 on PCCH SR runs `f1911977`/`5856a26f`: `GET .../makerevaluations/{runId}/details` returns `details.testCases[]` populated with 100 cases at `state=Completed`. Per-case grader reasons ARE available headlessly — no SPA/CDP needed (canonical recipe: `evaluation-rest-api` skill `references/powervamg-percase-recipe.md`).
  - FOR A RUN'S SCORE: use `GET .../makerevaluations?count=10` (JSON array) and read `aggregatedGraderResults[].count` for `totalSucceeded`/`totalFailed`. Score = succeeded/(succeeded+failed)*100. This is what `eval_harness.py last` prints and it matches the SPA.
  - FOR PER-CASE ANALYSIS: read `details.testCases[]`. The correct per-case pass/fail field is `graderMetrics.queryResponseMetrics[0].evaluationResult` (= "Pass"/"Fail"). **DO NOT use the case-level `metrics.evaluationResult`** — it returns "NoResult" and causes "0 fails"/"100 fails" parse bugs. Grader subscores (abstention/relevance/completeness/groundedness) are at `graderMetrics.queryResponseMetrics[0].properties`.
  - ROUTING DIAGNOSTIC per case: `metrics.triggeredTopicIds` (EMPTY = NO topic matched → bot-level generative / GPT-fallback answer) and `metrics.gptFallback` (=true means generative answer, not a topic). This decides whether to fix a TOPIC action or the AGENT INSTRUCTIONS — if most fails hit NO topic, topic-action edits are INERT; promote the fix to the agent instructions type-15 component as a top `# PRIMARY DIRECTIVE` (see `copilot-studio-analyze-evals` "Inline clinical text IGNORED" — topic-action edits were inert there; instructions were the lever).
  - **HARDENING LESSON — when 100% of fails are `gptFallback` (empty `triggeredTopicIds`, `metrics.gptFallback=true`), instruction edits to the DATA-RICH rule do NOT fix them and can REGRESS (validated PCCH 2026-07-12):** adding a "MANDATORY VERBATIM QUOTATION" clause to force the generative path to quote values dropped SR 73%→69%. The generative model paraphrases extracted clinical findings into generic documentation guidance regardless of instruction wording, so the grader's `completeness=No` persists. THE LEVER IS ROUTING, not instructions: these "extract/identify/synthesize X from these [pasted] records" queries must be caught by a TOPIC (trigger phrases: extract/identify/summarize/what was/what is + "from these notes/records") whose flow reads the inline text and is constrained to quote it. If you find yourself adding more "quote verbatim" instruction text to chase gptFallback fails, STOP — switch to a routing/topic fix instead. (Sibling lesson: instruction edits to the type-15 component DID move the score when the failure was instruction-following, e.g. the DATA-RICH EXTRACTION RULE promoting inline text over KB search → +2pts. So: gptFallback=route; instruction-following fail=instructions.)
  - THE ROUTING FIX FOR THIS CLASS (proven PCCH 2026-07-12): add ONE additive catch-all extraction topic — `modelDescription` that names the "extract/identify/synthesize X from pasted text" task, `triggerQueries` in REAL natural language (e.g. "what was the prior level of function", "extract the <element> from these notes"), and a `SearchAndSummarizeContent` whose `userInput` = `=Concatenate("verbatim-extract prompt…", Char(10), System.Activity.Text)` with `applyModelKnowledgeSetting:false` + an additionalInstruction to quote exact values. This targets 100% of the gptFallback cluster and removes nothing. Generalized template: `templates/inline_extraction_topic.mcs.yml`; full pattern + Medicare-Part-B logic source: `copilot-studio-topic-yaml-fixes/references/inline-extraction-gptfallback-fix.md`. Create live via Dataverse POST: `parentbotid@odata.bind:"/bots(<GUID>)"` (NOT `_parentbotid_value` → 0x80060888), `schemaname` with a valid customization prefix (e.g. `auto_agent_XRF5I.` → else 0x800608ad), POST returns 204 with the new id in `OData-EntityId` header. Reusable: `copilot-studio-manage-agent/scripts/create_topic_botcomponent.py`.
  - **HARDENING LESSON #2 — a BROAD catch-all extraction topic can REGRESS SR (validated PCCH 2026-07-13).** The fix class works, but if the new topic's `modelDescription` is too broad it intercepts traffic that previously routed correctly to other topics (or to boosting that was passing), and the new flow's output fails the grader → net SR DROP. Observed: adding `In-Document Clinical Extraction` with a wide modelDescription dropped SR 73%→51% (run `0f96f9b0`, 12 topics incl. the new one). Before declaring victory, ALWAYS re-run the affected eval type and compare against the pre-fix baseline — a high number from an OLD run is NOT your fix. Keep the catch-all's `modelDescription` + `triggerQueries` tightly scoped to the exact failure phrasing; broaden only after confirming no regression. If a post-fix run regresses, the topic is over-matching — narrow the `modelDescription` (remove generic words like "references/reports/notes/case text" that match unrelated queries) rather than pulling the topic. Note: the broad modelDescription wording from the Medicare 94% pattern ("pastes or references clinical records, acute care notes, hospital course, …") is what over-matched here — copy the LOGIC, not the broad phrasing.
  - **REMEDIATION SEQUENCE the user prefers for a regressing additive fix (validated 2026-07-13): "both" = NARROW FIRST, then PULL if narrowing doesn't recover.** (1) Tighten `modelDescription` + `triggerQueries` to the exact failure phrasing; re-run the affected eval type; (2) if the re-run STILL regresses vs the pre-fix baseline, DELETE the additive topic (it was never published — fully reversible, additive-only-compliant) to restore baseline, then attack the real baseline gaps a different way. Do NOT keep a regressing topic live hoping it'll improve on a later run.
  - **When a live Dataverse PATCH is BLOCKED by infra (validated 2026-07-13):** the org-specific CRM host (`{org}.api.crm.dynamics.com`) can intermittently fail DNS resolution (`Non-existent domain` from cox/Google/Cloudflare alike) while the eval Gateway and `login.microsoftonline.com` still resolve. A `botcomponents` PATCH then can't push, so neither narrow NOR pull can land — both are equally blocked. Recovery: (a) retry the PATCH every few minutes until DNS recovers, OR (b) have the user paste the corrected YAML into the Copilot Studio UI topic editor (fastest when at the desk), THEN kick the eval. The regression is still diagnosed; only the push is deferred. Do NOT burn eval quota re-running against an un-patched draft — the re-run only measures the fix once the edit is actually live.
  - **PITFALL — never credit a high score to your fix without confirming the run postdates your change (validated 2026-07-13).** A run's `aggregatedGraderResults` score is meaningless for attribution unless (a) its `startTime` is AFTER your PATCH, and (b) its `topicIds` / `botSnapshotVersion` includes your new/changed component. In one session a PRE-FIX run (`43ef12ee`, 80%, 2026-07-12 06:30, 11 topics, no new topic) was mistaken for improvement when the actual post-fix run (`0f96f9b0`) scored 51%. On every result, check `GET .../makerevaluations/{runId}/details` → `makerEvaluationRun.startTime`, `.topicIds` (grep for your new component GUID), `.botSnapshotVersion` before claiming a result. A run that predates your PATCH is NOT evidence your fix worked.
  - **PITFALL — redirecting `refresh_eval_token.cjs` stdout corrupts the token file (validated 2026-07-13).** The script uses `fs.writeFileSync(TOKEN_FILE, token)` (clean) AND `console.log` status lines. Running `node refresh_eval_token.cjs > token.txt` captures BOTH the token AND the "Token obtained…\nSaved to…" status text into the file, so the file no longer starts with the JWT → every Gateway call 403s. FIX: run the script WITHOUT redirect (`node refresh_eval_token.cjs` — it writes the file itself); only redirect stdout to `/dev/null` if you must (`node refresh_eval_token.cjs >/dev/null`). Verify the file starts with `eyJ` (valid JWT) before using it. This is a distinct failure from token EXPIRY — both present as 403, so always check whether the file content is a clean JWT first.
  - `details.testCases` is EMPTY while the run is `InProgress` — always confirm `state=Completed` before reading per-case data.
**Run-duration reality (Therapy AI Dev, 2026-07-12):** SR (SingleTurn 100 cases) took 45–75 min; Conv (MultiTurn 20) ~20 min. The `eval_harness.py` background poll loop must allow >40 iterations (use `seq 1 50`) or it exits InProgress before completion.

**PITFALL — a poller that scores from `details.testCases` FALSELY reports 0% on a Queued/InProgress run (validated 2026-07-13).** `GET .../makerevaluations/{runId}/details` returns `details.testCases=[]` until `state=Completed`. A poller shaped like `cases = d['details']['testCases']; if cases: print(score(cases)) else: print("0%")` hits the `else` branch immediately when the run is `Queued` or `InProgress` and emits a bogus `0/100 = 0%`, then exits — making it look "done" when the run just started. Symptom seen: a fresh SR rerun printed `[DONE] 0/100 = 0%` with state `Queued` seconds after starting. FIX: (a) gate any score computation on `state==Completed`; (b) better, poll the LIST endpoint `GET .../makerevaluations?$top=6` and read `aggregatedGraderResults[].count` for `totalSucceeded`/`totalFailed` — those counts populate LIVE during InProgress, so you get real progress without touching `/details`; (c) only call `/details` for per-case analysis after `state=Completed`. Never treat an empty `testCases` array as a terminal result.

**PITFALL — background poll loop breaks on token expiry with a FALSE "done" (validated 2026-07-12).** The eval PPAPI token expires ~15 min. A poll loop shaped like `if grep -q "InProgress\|0P/0F"; then sleep; continue; fi; echo DONE_LOOP` FALSELY reports completion when the token expires mid-run: the poll command prints a Python traceback (containing neither "InProgress" nor a terminal state), so it falls through to DONE_LOOP even though the run is still going. FIX: (a) break ONLY on an explicit terminal state and filter to the specific run ID —
```bash
sc=$(python3 eval_harness.py last 2>&1 | grep "$RUN" | head -1)
if echo "$sc" | grep -q "state=Completed\|state=Failed\|state=Cancelled"; then echo "DONE_LOOP"; break; fi
sleep 60
```
and (b) when `last` throws a traceback, refresh the token with `cd ~/skills-for-copilot-studio/scripts && node refresh_eval_token.cjs` (the script lives THERE on this machine — NOT under the agent's project dir; `find ~ -name refresh_eval_token.cjs` if unsure), then resume polling. Do NOT re-baseline; the run keeps going server-side.

**PITFALL — a poll-loop `refresh()` that mints a CRM/`az` token 403s the Gateway (validated 2026-07-12).** A background poll loop whose `refresh()` calls `az account get-access-token --resource https://<org>.crm.dynamics.com` and writes that token to `~/.copilot-studio-cli/test-agent-token.txt` will 403 the GATEWAY on every subsequent call — the Gateway needs the MSAL `api://96ff4394.../.default` eval token, NOT the Dataverse CRM token. Symptom: the loop "refreshes" yet still gets `HTTP Error 403: Forbidden` and crashes. FIX: refresh by running the MSAL script from its dir — `cd ~/skills-for-copilot-studio/scripts && node refresh_eval_token.cjs` (it writes the correct token file itself). Keep the two credential classes STRICTLY separate: CRM token = live Dataverse PATCH only; MSAL eval token = Gateway eval API only. Never overwrite the eval token file with an `az` token.

**PITFALL — Eval started immediately after publish may use pre-publish state.** Verify `synchronizationstatus.lastFinishedPublishOperation.operationEnd` timestamp updated before starting eval. The publish confirmation message from `pac copilot publish` can show a cached timestamp. Always query the Dataverse `bots` entity's `synchronizationstatus` to confirm the operation actually completed after your last patch.

- `PATCH /makerevaluations/{runId}/cancel` cancels an active run. Body: `{"evaluationRunId": "<runId>"}`. Response returns the updated run object with state=Cancelled. After canceling, verify with GET -- queue is clear when no InProgress runs remain.
- Eval queue management (validated Jul 5 2026): When stale evals queue up, cancel ALL InProgress runs, verify clear, then start ONE fresh eval.

**STUCK-RUN RECOVERY (validated 2026-07-12, PCCH): a run can hang `InProgress` with 0 scored cases and no `endTime` for ~2x its normal duration (SR ~55min normally; a hung one sat 1hr+).** Symptom: `GET .../makerevaluations/{runId}/details` shows `state=InProgress`, `endTime=None`, `scored=0`. This blocks the single eval slot (one active run per agent), so no new run can start — `POST /makerevaluations` returns `fairusagepolicy.botactiverunquotaviolated`. Recovery steps:
  1. **`PATCH .../makerevaluations/{runId}/cancel` returns HTTP 405** (the cancel endpoint is NOT supported in this tenant) — so you CANNOT cancel server-side. Do not loop on it.
  2. The only lever is to WAIT for the run to time out on the backend, then start a fresh run. Write the rerun script so the "wait for slot free" loop is long enough: a `for i in range(12): sleep(20)` (~4min) gives up BEFORE the stuck run frees, so no fresh run ever starts. Use a long horizon (e.g. `for i in range(180): sleep(20)` ~60min) OR poll the list endpoint and only start once NO run has `state=InProgress`.
  3. `rerun` pattern that works: (a) loop waiting until `GET .../makerevaluations?$top=5` has no `state=InProgress`; (b) `POST /makerevaluations` with `{"testSetId":..., "runName":"..."}`; (c) poll `/details` to completion. Run it as a tracked background process (`terminal(background=true, notify_on_complete=true)`) so you get the score on completion without polling interactively.
  4. **Python f-string gotcha when building gateway URLs with a GUID constant:** a literal `}` in a path like `f'.../makerevaluations/0f96f9b0.../details'` inside an f-string raises `SyntaxError: f-string: single '}' is not allowed`. Build the base URL once in a variable (`BASE=f'.../{ENV}/bots/{BOT}/makerevaluations'`) then concatenate `BASE + '/' + runid + '/details'` with plain string concat — never inline a non-`{}` brace in an f-string.
  5. This is a PLATFORM flake, not a config problem — the Medicare agent's evals complete fine in the same env, and prior PCCH SR runs finished at 71-73%. Don't "fix" the agent; just re-run. If a rerun also hangs, wait out the timeout and try again; avoid burning the daily quota (`botrunquotaviolated` = 24h lockout).
  6. **A "stuck-looking" run that eventually gets an `endTime` + real `aggregatedGraderResults` has a VALID score — do not dismiss it as a flake.** In one session run `0f96f9b0` sat `InProgress` ~1hr (normally ~55min) then completed at 51% (51 succeeded / 45 failed) — that 51% was the REAL post-fix result and exposed a topic regression. Only a run that NEVER receives an `endTime` and stays 0-scored indefinitely is unusable; a slow-but-completed run is trustworthy. Treat the completed score as your new baseline and re-run only to confirm, not because the slow completion is suspect.
- PITFALL — pac CLI caches publish failures permanently. After a publish fails, pac copilot publish returns the SAME failure timestamp forever even with fresh auth. Verify actual publish state with GET /bots/{id}?$select=publishedon on Dataverse.

Also see `references/live-gateway-details-quota-and-guardrails.md` for quota handling and guardrail validation.

Important quota nuances:
- Active-run limit is per agent. SR and Conv for the same agent must be sequential, but different agents can have active runs at the same time.
- Active-run block error: `fairusagepolicy.botactiverunquotaviolated`.
- Daily quota block error: `fairusagepolicy.botrunquotaviolated` with message similar to `The agent has been evaluated more than 20 times in the last 24 hours. Please wait before trying again.` Stop launching and record handoff when this appears; do not burn time retrying until the 24-hour window resets.

Guardrail-patch validation:
- When inserting static `ConditionGroup` / `SendActivity` guardrails or replacing `additionalInstructions`, validate generated `.after.yml` backups before running another eval. A common regression is malformed indentation under `additionalInstructions: |-`, causing YAML `ScannerError` and potentially invalid topic data. See `references/live-gateway-details-quota-and-guardrails.md`.

Eval-set migration and connector-free draft eval pitfall:
- When copying evals between bots, copy both `EvaluationSet` rows and case rows, then link cases with the exact Dataverse navigation property `ParentBotComponentId@odata.bind`; otherwise gateway shows 0-case set shells. See `references/eval-set-migration-and-connector-free-draft-evals.md`.
- If `/details` shows `Let's get you connected first...`, `FlowNotFound`, or later multi-turn queries falling into Greeting/Fallback/Conversational Boosting, patch connector-free in-scope responses across those interceptors before spending more quota. First-turn fixes alone do not solve multi-turn evals.

## Step 5.5: Analyze failures from aggregated results (when `/details` is broken)

When `GET /testruns/{id}` returns the run but `GET /testruns/{id}/details` returns 404 `RouteNotFound` (known regional PPAPI rollout issue — confirmed Jul 9 2026 for Therapy AI Dev), analyze failures from the aggregated `testCasesResults` array instead:

```python
results = run.get('testCasesResults', [])
passed = 0
failures = []
for r in results:
    mrs = r.get('metricsResults', [])
    if not mrs:
        continue
    result = mrs[0].get('result', {})
    status = result.get('status', 'Unknown')
    if status == 'Pass':
        passed += 1
    else:
        d = result.get('data', {})
        abstain = d.get('abstention', '?')
        relevance = d.get('relevance', '?')
        completeness = d.get('completeness', '?')
        
        if abstain == 'Yes':
            cat = 'ABSTAINED'
        elif relevance == 'No':
            cat = 'LOW_RELEVANCE'
        elif completeness == 'No':
            cat = 'INCOMPLETE'
        else:
            cat = 'OTHER'
        failures.append(cat)

# Score
print(f"Score: {passed}/{len(results)} = {passed*100//len(results)}%")
# Failure breakdown
from collections import Counter
for cat, count in Counter(failures).most_common():
    print(f"  {cat}: {count}")
```

This categorization maps directly to root causes:
- **ABSTAINED** → Agent refused to answer (no relevant topic matched, guardrails blocked)
- **INCOMPLETE** → Agent answered but missed expected content (topic routing issue, overly strict format)
- **LOW_RELEVANCE** → Agent answered off-topic (wrong topic matched)
- **OTHER** → Format or structural issue

### Sequential SR->Conv workflow with cron heartbeat (Jul 9 2026)

PPAPI enforces one active run per agent at a time. Use this pattern:

1. **Start Conv eval** (20 cases, ~10-15 min) — identifies routing/conv failures fastest
2. **Create a cron heartbeat** polling every 10 minutes:
   ```
   hermes cron create --name "Eval Poll" --schedule "10m" --repeat 20 \
     --prompt "Poll run ID <id>. Read token from ~/.copilot-studio-cli/test-agent-token.txt. If Completed, fetch results."
   ```
3. **While waiting, analyze existing failures** — don't sit idle
4. When Conv completes → **analyze → fix → start SR eval** (100 cases, ~15-25 min)
5. Update the cron to poll the SR run ID
6. When SR completes → **analyze → fix → next checkpoint**

**Conv-score killer: a too-NARROW Fallback/Sytem topic.** Confirmed PCCH (2026-07-12): Fallback said "acute hospital records" only, but the agent's real scope is broader SNF case history (SBAR, MDS 3.0, PDPM, discharge, multi-discipline). Multi-turn prompts that didn't mention "acute" got an off-scope fallback → low relevance/abstention → Conv 55%. Fix: broaden the Fallback offer to the full agent scope (additive — keep all existing offers). Also clean any garbled SendActivity fallback text (e.g. `=If(IsBlank(Topic.Answer), "double-sentence...for the topic you asked about...", Topic.Answer)` — valid Fx but reads as a defect; tighten the text branch). Re-run Conv after.

**Conv/SR killer #2: an EMPTY `additionalInstructions` on the Conversational boosting catch-all (validated PCCH 2026-07-12, baseline Conv 55% / SR 71%).** The `SearchAndSummarizeContent` inside the `Conversational boosting` system topic handles everything that doesn't match a named topic. If it has no `additionalInstructions`, unmatched turns get generic/off-scope answers. Fix (additive): add grounding instructions naming the agent scope, KBs, "answer directly — don't ask to re-paste", and the DRAFT disclaimer. This is often the single highest-leverage additive patch because the catch-all sees the most traffic.

**Dataverse botcomponents query specifics for live topic PATCH (validated 2026-07-12):**
- Topics are `componenttype eq 9` filtered by `_parentbotid_value eq '<botId>'`. (componenttype 6 is a different component class — returned only 2 rows.) Instructions/other components use other componenttype values.
- The `data` field is stored as **raw YAML**, NOT JSON. Do not `json.loads` it — string-replace the YAML directly, then PATCH `{"data": <newYAML>}`.
- **PITFALL — Dataverse `botcomponents` COLLECTION GET 400s on `$filter` and on `$select` of non-real columns.** `$select=id,name,componenttype,parentbotcomponentid` returns HTTP 400; the actual PK column is `botcomponentid` (not `id`), and `parentbotcomponentid` is not selectable. `$select=name` works. `$filter=` on `componenttype`/`parentbotcomponentid` also 400s. Workarounds: (a) fetch single records by ID — `GET .../botcomponents(<guid>)?$select=name,data` — that works fine; (b) for a listing, call `GET .../botcomponents?$select=name` (no filter) and filter client-side; (c) the collection spans the WHOLE org — multiple agents share one Dynamics org, so a name-based listing returns components from sibling agents (e.g. Medicare Part B + Pacific Coast Case Historian both appear). Match by human-known topic name, not by assuming org-isolation.
- **Reusable `az` subprocess pattern (Windows/MSYS):** `az` is not on the bare MSYS PATH. Call it by full path with PATH injected: `AZ=r'C:\Program Files\Microsoft SDKs\Azure\CLI2\wbin\az.cmd'; AZP=r'C:\Program Files\Microsoft SDKs\Azure\CLI2\wbin'; env=dict(os.environ); env['PATH']=AZP+';'+env.get('PATH',''); out=subprocess.run([AZ,'account','get-access-token','--resource','https://<org>.crm.dynamics.com'],capture_output=True,text=True,env=env).stdout`. Use this for live Dataverse PATCH tokens (CRM scope only).
- `$select=name,data` works; `$select=displayname` returns HTTP 400 (the column is `name`, not `displayname`). Match a topic by `name` (its display name) case-insensitively.
- Additive live PATCH pattern (no publish needed for DRAFT eval): GET the topic's `data`, `data.replace(OLD, NEW, 1)`, PATCH `botcomponents(<botcomponentid>)`. A ready helper is `scripts/patch_topic.py` in this skill, BUT it calls `az` via `subprocess` which fails on this Windows host (`FileNotFound`) — instead pass the token in from bash: `TOKEN=$(az account get-access-token --resource 'https://<org>.crm.dynamics.com' --query accessToken -o tsv) && python3 - "$TOKEN" <<'PY' ...`. See the "System topics MUST NOT be modified" pitfall — only edit non-system topics via API; system topics (OnError/OnEscalate/OnConversationStart/OnSystemRedirect) go through the UI.

**Fix validation cadence (user rule: verify+validate after every change):** after each live PATCH, re-run the affected eval type SEQUENTIALLY (Conv first — faster, 20 cases; then SR, 100 cases). One active run per agent. Don't claim a fix worked until the post-fix run score is in hand.

**PITFALL — System topics MUST NOT be modified via Dataverse API** (Jul 9 2026):
PATCHing the `data` field on system topics (OnEscalate, OnError, OnSystemRedirect, OnConversationStart) via Dataverse API causes `pac copilot publish` to fail with `SynchronizationSystemError`. The publish is unrecoverable via API — must revert the system topic modifications first, then publish succeeds. System topic modifications must go through the Copilot Studio UI code editor only.

**PITFALL — `totalTestCases: 0` at start is normal.** The POST response may show 0. It populates once the run transitions from Queued to InProgress.

**PITFALL — CDP/Playwright CANNOT reliably save to Monaco code editor in Copilot Studio** (confirmed Jul 9 2026). The Monaco iframe doesn't expose `monaco` globally, CompositionEvent shows a false Save enable but commits original content, and keyboard.insertText writes to the accessibility textarea not the model. Provide paste-ready YAML blocks for manual paste instead.

**PITFALL — confirm WHICH agent an eval screenshot belongs to before acting on it (validated 2026-07-12).** A pasted eval-dashboard screenshot may be a DIFFERENT agent than the one you're hardening. The breadcrumb shows the agent name (e.g. "Evaluate Medicare Part B Compliance Agent 260712_1624" vs "Evaluate Pacific Coast Case Historian"). In one session the user pasted a 94% Medicare-Part-B result while the agent being worked was Pacific Coast Case Historian (a separate bot, `b0346795` vs `ad635500`) — treating the screenshot as the target agent would have sent fixes to the wrong bot. Always read the breadcrumb/agent name and, if it doesn't match the in-flight bot ID, say so and ask which to drive. The two agents share one Dynamics org, so their components and eval runs coexist in the same API responses.

### Find test set IDs matching a specific agent

Multiple test sets accumulate with different IDs over time. Filter by displayName matching the agent name:
```python
bot_name = "Medicare Part B Compliance Agent"
for t in test_sets.get('value', []):
    if bot_name in t.get('displayName', ''):
        print(f"{t['displayName']} | {t['totalTestCases']} cases | {t['id']}")
```
The test set with the matching description but NO `evaluationSetType` field visible from the list endpoint — you must inspect the run results to determine if it's SingleTurn or MultiTurn.

### Sequential SR->Conv workflow

PPAPI enforces one active run per agent at a time. For sequential eval:
1. Start Conv eval (20 cases) first — faster, identifies routing issues
2. Poll every 10 min via cron job for completion
3. When Conv completes, analyze failures and apply fixes
4. Start SR eval (100 cases) — takes longer but gives score stability
5. Poll, analyze, fix

**Key:** SR and Conv for the same agent must be sequential. Different agents CAN run simultaneously.

For long-running evals (Conv ~15-20 min, SR ~30-45 min), use a cron heartbeat:
```bash
hermes cron create --name "Eval Poll" --schedule "10m" --repeat 20 \
  --prompt "Poll run ID <id>, agent <botId>, env <envId>. Read token from ~/.copilot-studio-cli/test-agent-token.txt. If state=Completed, fetch results and start next eval."
```

## Step 6: Propose fixes
For YAML authoring failures: find relevant topic, read it, propose specific edits. Wait for user approval.
After applying: offer to push and re-run (go back to Step 3).
