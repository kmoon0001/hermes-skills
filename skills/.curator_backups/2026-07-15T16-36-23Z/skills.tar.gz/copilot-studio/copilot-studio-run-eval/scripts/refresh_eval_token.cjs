'use strict';
/**
 * refresh_eval_token.cjs
 * 
 * Refreshes the PPAPI evaluation token from the MSAL manage-agent cache.
 * Saves to ~/.copilot-studio-cli/test-agent-token.txt
 * 
 * Usage: node refresh_eval_token.cjs
 *   Must be run from the pipeline directory where @azure/msal-node is installed.
 *   Output: "Token obtained: eyJ... | Saved to C:\Users\...\test-agent-token.txt"
 * 
 * Dependencies: @azure/msal-node, @azure/msal-node-extensions
 *   (installed in pipeline/node_modules)
 * 
 * Why this works: The manage-agent cache (~/.copilot-studio-cli/manage-agent.cache.json)
 *   is populated by `pac auth` or the VS Code Copilot Studio extension. It stores
 *   a refresh token issued for the Power Virtual Agents app registration (client ID
 *   51f81489). MSAL's PersistenceCachePlugin can DPAPI-decrypt the cache and silently
 *   acquire tokens without any interactive login.
 */

const path = require('path');
const os = require('os');
const fs = require('fs');
const { PublicClientApplication } = require('@azure/msal-node');
const { PersistenceCreator, PersistenceCachePlugin, DataProtectionScope } = require('@azure/msal-node-extensions');

const TENANT = '03cc92c3-986c-4cf4-ae27-1478cf99d17f';
const CLIENT = '51f81489-12ee-4a9e-aaae-a2591f45987d';
const CACHE = path.join(os.homedir(), '.copilot-studio-cli', 'manage-agent.cache.json');
const TOKEN_FILE = path.join(os.homedir(), '.copilot-studio-cli', 'test-agent-token.txt');

(async () => {
  const p = await PersistenceCreator.createPersistence({
    cachePath: CACHE,
    dataProtectionScope: DataProtectionScope.CurrentUser,
    serviceName: 'copilot-studio-cli',
    accountName: 'manage-agent',
    usePlaintextFileOnLinux: true
  });
  const app = new PublicClientApplication({
    auth: {
      clientId: CLIENT,
      authority: `https://login.microsoftonline.com/${TENANT}`
    },
    cache: { cachePlugin: new PersistenceCachePlugin(p) }
  });
  const accounts = (await app.getTokenCache().getAllAccounts())
    .filter(a => a.tenantId === TENANT);
  if (accounts.length === 0) {
    console.error('NO ACCOUNTS IN CACHE — run pac auth create first');
    process.exit(1);
  }
  // PPAPI scope for Gateway eval API
  const r = await app.acquireTokenSilent({
    scopes: ['api://96ff4394-9197-43aa-b393-6a41652e21f8/.default'],
    account: accounts[0]
  });
  fs.mkdirSync(path.dirname(TOKEN_FILE), { recursive: true });
  fs.writeFileSync(TOKEN_FILE, r.accessToken);
  console.log(`Token obtained (${r.accessToken.length} chars)`);
  console.log(`Saved to ${TOKEN_FILE}`);
  process.exit(0);
})().catch(e => {
  console.error('ERROR:', e.message);
  process.exit(1);
});
