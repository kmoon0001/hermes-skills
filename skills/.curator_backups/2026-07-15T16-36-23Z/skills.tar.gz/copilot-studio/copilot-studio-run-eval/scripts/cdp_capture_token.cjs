// CDP Token Capture for PPAPI Evals
// Captures Bearer token from Copilot Studio evaluation page via CDP WebSocket
// Usage: node cdp_capture_token.cjs
// Prerequisite: browser running with --remote-debugging-port=9223

const WebSocket = require('ws');
const fs = require('fs');
const path = require('path');
const http = require('http');

const TOKEN_FILE = path.join(process.env.USERPROFILE, '.copilot-studio-cli', 'test-agent-token.txt');

(async () => {
  const pages = await new Promise((resolve, reject) => {
    http.get('http://127.0.0.1:9223/json/list', res => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => resolve(JSON.parse(d)));
    }).on('error', reject);
  });

  // Find eval tab by URL pattern (NOT hardcoded ID)
  const target = pages.find(p => p.url && p.url.includes('copilotstudio') && p.url.includes('evaluation'));
  if (!target) {
    console.log('Eval tab not found. Available tabs:');
    pages.forEach(p => console.log(`  ${(p.title||'?').slice(0,50)} | ${(p.url||'?').slice(0,100)}`));
    process.exit(1);
  }
  console.log('Found eval tab:', target.title);

  const ws = new WebSocket(target.webSocketDebuggerUrl);
  let token = null;
  const start = Date.now();

  ws.on('message', (raw) => {
    const msg = JSON.parse(raw.toString());
    if (msg.method === 'Fetch.requestPaused' && !token) {
      const req = msg.params.request;
      const auth = req.headers['Authorization'] || req.headers['authorization'];
      const url = req.url || '';
      if (url.includes('powerplatform') || url.includes('makerevaluation')) {
        if (auth) {
          token = auth.replace(/^Bearer\s+/i, '');
          console.log('TOKEN CAPTURED');
        }
      }
      ws.send(JSON.stringify({id: 9999, method: 'Fetch.continueRequest', params: { requestId: msg.params.requestId }}));
      return;
    }
    if (Date.now() - start > 60000 && !token) {
      console.log('TIMEOUT - no token found');
      ws.close();
      process.exit(1);
    }
  });

  ws.on('open', () => {
    console.log('Connected, enabling Fetch interception...');
    ws.send(JSON.stringify({id: 1, method: 'Fetch.enable', params: { patterns: [{ urlPattern: '*' }] }}));
    setTimeout(() => {
      console.log('Reloading page...');
      ws.send(JSON.stringify({id: 2, method: 'Page.reload'}));
    }, 1000);
  });

  const check = setInterval(() => {
    if (token) {
      clearInterval(check);
      fs.mkdirSync(path.dirname(TOKEN_FILE), { recursive: true });
      fs.writeFileSync(TOKEN_FILE, token);
      console.log('Token saved (' + token.length + ' chars)');
      ws.close();
      process.exit(0);
    }
  }, 1000);

  ws.on('close', () => { clearInterval(check); if (!token) process.exit(1); });
  ws.on('error', e => { console.error('WS error:', e.message); });
})().catch(e => { console.error(e.message); process.exit(1); });
