const WebSocket = require('ws');
const fs = require('fs');
const path = require('path');
const http = require('http');

const TOKEN_FILE = path.join(process.env.USERPROFILE, '.copilot-studio-cli', 'test-agent-token.txt');

(async () => {
  const pages = await new Promise((resolve, reject) => {
    http.get('http://127.0.0.1:9223/json/list', res => {
      let d = ''; res.on('data', c => d += c); res.on('end', () => resolve(JSON.parse(d)));
    }).on('error', reject);
  });

  // Find by URL containing evaluation path
  const target = pages.find(p => 
    p.url.includes('copilotstudio.microsoft.com/environments/') && 
    p.url.includes('/evaluation')
  );
  
  if (!target) {
    // Create new tab via browser-level endpoint
    console.log('No eval tab found, creating via browser...');
    const version = await new Promise((resolve, reject) => {
      http.get('http://127.0.0.1:9223/json/version', res => {
        let d=''; res.on('data',c=>d+=c); res.on('end',()=>resolve(JSON.parse(d)));
      }).on('error', reject);
    });
    
    const bws = new WebSocket(version.webSocketDebuggerUrl);
    bws.on('open', () => {
      bws.send(JSON.stringify({
        id:1, method:'Target.createTarget', 
        params:{url:'https://copilotstudio.microsoft.com'}
      }));
    });
    console.log('New tab opening... wait 10s then retry');
    await new Promise(r => setTimeout(r, 10000));
    process.exit(2); // caller should retry after tab loads
  }

  console.log('Found eval tab, connecting...');
  const ws = new WebSocket(target.webSocketDebuggerUrl);
  let token = null;
  const startTime = Date.now();

  ws.on('message', (raw) => {
    const msg = JSON.parse(raw.toString());
    if (msg.method === 'Fetch.requestPaused' && !token) {
      const req = msg.params.request;
      const auth = req.headers['Authorization'] || req.headers['authorization'];
      const url = req.url;
      if (url.includes('powerplatform.com') || url.includes('makerevaluation')) {
        console.log('REQ:', url.slice(0, 120));
        if (auth) {
          token = auth.replace(/^Bearer\s+/i, '');
          console.log('TOKEN CAPTURED!');
        }
      }
      ws.send(JSON.stringify({ 
        id: 9999, method: 'Fetch.continueRequest', 
        params: { requestId: msg.params.requestId } 
      }));
    }
    if (Date.now() - startTime > 50000 && !token) { 
      console.log('Timeout — no PPAPI requests captured'); 
      process.exit(1); 
    }
  });

  ws.on('open', () => {
    ws.send(JSON.stringify({ id: 1, method: 'Fetch.enable', params: { patterns: [{ urlPattern: '*' }] } }));
    ws.send(JSON.stringify({ id: 2, method: 'Page.reload', params: { ignoreCache: true } }));
    console.log('Reloading eval page, watching for token...');
  });

  const check = setInterval(() => {
    if (token) {
      clearInterval(check);
      fs.mkdirSync(path.dirname(TOKEN_FILE), { recursive: true });
      fs.writeFileSync(TOKEN_FILE, token);
      console.log('OK: Token saved (' + token.length + ' chars) to ' + TOKEN_FILE);
      process.exit(0);
    }
  }, 500);

  ws.on('close', () => { clearInterval(check); if (!token) process.exit(1); });
  ws.on('error', (e) => { console.error('WS error:', e.message); process.exit(1); });
})().catch(e => { console.error(e.message); process.exit(1); });
