// CDP WebSocket token capture — refresh PPAPI Bearer token from authenticated browser
// Usage: node cdp_simple.cjs
// Saves token to %USERPROFILE%\.copilot-studio-cli\test-agent-token.txt

const { chromium } = require('playwright-core');
const fs = require('fs');
const path = require('path');
const http = require('http');

const TOKEN_FILE = path.join(process.env.USERPROFILE, '.copilot-studio-cli', 'test-agent-token.txt');

(async () => {
  // Find eval tab by URL pattern
  const pages = await new Promise((resolve, reject) => {
    http.get('http://127.0.0.1:9223/json/list', res => {
      let d = ''; res.on('data', c => d += c); res.on('end', () => resolve(JSON.parse(d)));
    }).on('error', reject);
  });

  const target = pages.find(p => p.url.includes('copilotstudio.microsoft.com/environments/') && p.url.includes('/evaluation'));
  
  if (!target) {
    // Create new tab via browser endpoint
    const version = await new Promise((resolve, reject) => {
      http.get('http://127.0.0.1:9223/json/version', res => {
        let d='';res.on('data',c=>d+=c);res.on('end',()=>resolve(JSON.parse(d)));
      }).on('error', reject);
    });
    const bws = new (require('ws'))(version.webSocketDebuggerUrl);
    bws.on('open', () => {
      bws.send(JSON.stringify({id:1, method:'Target.createTarget', params:{url:'https://copilotstudio.microsoft.com/environments/ENV_ID/bots/BOT_ID/evaluation'}}));
    });
    console.log('New tab opening... wait 10s then retry');
    await new Promise(r => setTimeout(r, 10000));
    process.exit(2);
  }

  console.log('Found tab:', target.title.slice(0, 60));

  const WebSocket = require('ws');
  const ws = new WebSocket(target.webSocketDebuggerUrl);
  let token = null;
  const startTime = Date.now();

  ws.on('message', (raw) => {
    const msg = JSON.parse(raw.toString());
    if (msg.method === 'Fetch.requestPaused' && !token) {
      const req = msg.params.request;
      const auth = req.headers['Authorization'] || req.headers['authorization'];
      const url = req.url;
      if (url.includes('powerplatform.com') || url.includes('makerevaluation')) {
        console.log('REQ:', url.slice(0, 130));
        if (auth) {
          token = auth.replace(/^Bearer\s+/i, '');
          console.log('TOKEN CAPTURED!');
        }
      }
      ws.send(JSON.stringify({ id: 9999, method: 'Fetch.continueRequest', params: { requestId: msg.params.requestId } }));
    }
    if (Date.now() - startTime > 50000 && !token) { console.log('Timeout'); process.exit(1); }
  });

  ws.on('open', () => {
    ws.send(JSON.stringify({ id: 1, method: 'Fetch.enable', params: { patterns: [{ urlPattern: '*' }] } }));
    ws.send(JSON.stringify({ id: 2, method: 'Page.reload', params: { ignoreCache: true } }));
    console.log('Reloading...');
  });

  const check = setInterval(() => {
    if (token) {
      clearInterval(check);
      fs.mkdirSync(path.dirname(TOKEN_FILE), { recursive: true });
      fs.writeFileSync(TOKEN_FILE, token);
      console.log('OK: Token saved (' + token.length + ' chars)');
      process.exit(0);
    }
  }, 500);

  ws.on('close', () => { clearInterval(check); if (!token) process.exit(1); });
  ws.on('error', (e) => { console.error('WS error:', e.message); process.exit(1); });
})().catch(e => { console.error(e.message); process.exit(1); });
