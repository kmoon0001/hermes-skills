#!/usr/bin/env python3
"""
Live-topic PATCH helper for Copilot Studio (Dataverse botcomponents).
Reads the live topic YAML `data`, applies a targeted string replacement, and
PATCHes it back. ADDITIVE: only replaces exact old_string->new_string.

USAGE (run from bash; token obtained in bash and passed in):
  TOKEN=$(az account get-access-token --resource 'https://<org>.crm.dynamics.com' --query accessToken -o tsv)
  python3 patch_topic.py "$TOKEN" "<Topic displayName>" "<OLD>" "<NEW>" [--dry]

Topic matched by `name` (displayName). componenttype=9 = topic.
`data` is stored as RAW YAML (NOT JSON) - write it back as a plain string.

NOTE: `subprocess` cannot launch `az` inside python on this host - always
get TOKEN in bash and pass as argv[1] (see command above).
"""
import sys, os, json, urllib.request, urllib.parse

ORG='orgbd048f00'   # <-- set to your org short name
BOT='ad635500-cf47-f111-bec5-70a8a5b1c3a3'   # <-- set to target bot GUID

def get(url, tok):
    r=urllib.request.Request(url); r.add_header('Authorization',f'Bearer {tok}')
    r.add_header('OData-MaxVersion','4.0'); r.add_header('OData-Version','4.0'); r.add_header('Accept','application/json')
    return json.loads(urllib.request.urlopen(r,timeout=120).read())

def patch(url, tok, body):
    r=urllib.request.Request(url, data=body.encode(), method='PATCH')
    r.add_header('Authorization',f'Bearer {tok}'); r.add_header('Content-Type','application/json')
    r.add_header('OData-MaxVersion','4.0'); r.add_header('OData-Version','4.0'); r.add_header('Accept','application/json')
    urllib.request.urlopen(r,timeout=120).read()

def fetch_topic(topic_name, tok):
    q=urllib.parse.urlencode({'$filter':f"componenttype eq 9 and _parentbotid_value eq '{BOT}'",
                              '$select':'botcomponentid,name,schemaname,data','$top':'300'})
    d=get(f"https://{ORG}.crm.dynamics.com/api/data/v9.2/botcomponents?{q}", tok)
    for t in d['value']:
        nm=t.get('name') or ''
        if topic_name.lower() in nm.lower() or topic_name.lower() in (t.get('schemaname') or '').lower():
            return t
    return None

if __name__=='__main__':
    args=sys.argv[1:]
    tok=args[0]; args=args[1:]
    dry='--dry' in args; args=[a for a in args if a!='--dry']
    topic_name, old, new = args[0], args[1], args[2]
    t=fetch_topic(topic_name, tok)
    if not t:
        print("TOPIC NOT FOUND:",topic_name); sys.exit(1)
    data=t.get('data') or ''; cid=t['botcomponentid']
    if old not in data:
        print("OLD STRING NOT FOUND in live topic. Aborting (no change)."); sys.exit(2)
    new_data=data.replace(old,new,1)
    print(f"Patching topic '{t.get('name')}' (id={cid})")
    print(f"  - {old[:90]!r}")
    print(f"  + {new[:90]!r}")
    if dry:
        print("DRY RUN - no write."); sys.exit(0)
    patch(f"https://{ORG}.crm.dynamics.com/api/data/v9.2/botcomponents({cid})", tok, json.dumps({'data':new_data}))
    print("PATCHED OK.")
