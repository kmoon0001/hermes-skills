#!/usr/bin/env python3
"""Copilot Studio eval harness via PowerVA Gateway (X-CCI routing headers).

WORKING PATH (validated 2026-07-12, Therapy AI Dev / orgbd048f00):
The direct PPAPI host https://api.powerplatform.com/copilotstudio/... REJECTS every
token tried (MSAL api://96ff4394.../.default AND az --resource 96ff4394 GUID) with
401 InvalidAudience (S2S17001). The Gateway host below WITH X-CCI headers accepts the
MSAL-cache token. Do NOT use the direct PPAPI host.

"Both types of testing" = SR (SingleTurn, ~100 cases) + Conversation (MultiTurn, ~20 cases).
One active run per agent -> run SR and Conv SEQUENTIALLY (start Conv first; faster).

Usage:
  python eval_harness.py list                       # list test sets
  python eval_harness.py start <testSetId> [name]  # start a run
  python eval_harness.py poll  <runId>              # poll /details
  python eval_harness.py last                        # recent runs (fallback)

Token is read from ~/.copilot-studio-cli/test-agent-token.txt
  (mint it with: copy refresh_eval_token.cjs into the dir where node_modules/@azure/msal-node
   resolves, then `NODE_PATH=./node_modules node refresh_eval_token.cjs`).
"""
import sys, os, json, urllib.request, urllib.error
from collections import Counter

GW  = 'https://powervamg.us-il107.gateway.prod.island.powerapps.com/api/botmanagement/v2'
ENV = 'a944fdf0-0d2e-e14d-8a73-0f5ffae23315'   # Therapy AI Agents Dev
BOT = 'ad635500-cf47-f111-bec5-70a8a5b1c3a3'   # Pacific Coast Case Historian V2
ORG = '62945552-72f5-f011-aa23-6045bd003938'     # env-specific OrganizationId
TEN = '03cc92c3-986c-4cf4-ae27-1478cf99d17f'     # tenant

def token():
    p = os.path.expandvars(r'%USERPROFILE%\.copilot-studio-cli\test-agent-token.txt')
    return open(p).read().strip()

def headers():
    return {
        'Authorization': f'Bearer {token()}',
        'X-CCI-ApplicationSource': 'Web',
        'X-CCI-BapEnvironmentId': ENV,
        'X-CCI-BotId': BOT,
        'X-CCI-CdsBotId': BOT,
        'X-CCI-TenantId': TEN,
        'X-CCI-OrganizationId': ORG,
        'x-ms-user-agent': 'PVA-Portal/1.0.0',
        'Accept': 'application/json',
        'Origin': 'https://copilotstudio.microsoft.com',
    }

def _req(url, method='GET', body=None):
    r = urllib.request.Request(url, method=method)
    for k, v in headers().items():
        r.add_header(k, v)
    if body is not None:
        r.data = json.dumps(body).encode()
        r.add_header('Content-Type', 'application/json')
    return urllib.request.urlopen(r, timeout=120)

def list_sets():
    url = f'{GW}/environments/{ENV}/bots/{BOT}/makerevaluations/testsets'
    d = json.loads(_req(url).read())
    for c in d.get('testComponents', []):
        comp = c.get('component', {})
        print(f"  {comp.get('displayName')} | cases={c.get('numberOfTestCases')} | type={c.get('evaluationSetType')} | id={comp.get('id')}")

def start(tsid, name='Draft eval'):
    url = f'{GW}/environments/{ENV}/bots/{BOT}/makerevaluations'
    body = {'testSetId': tsid, 'runName': name}
    d = json.loads(_req(url, method='POST', body=body).read())
    print(f"RUN STARTED: runId={d.get('runId')} state={d.get('state')}")
    return d.get('runId')

def poll(runid):
    url = f'{GW}/environments/{ENV}/bots/{BOT}/makerevaluations/{runid}/details'
    try:
        d = json.loads(_req(url).read())
    except urllib.error.HTTPError as e:
        if e.code == 404:
            print("details 404 -- falling back to list"); return list_fallback()
        raise
    run = d.get('makerEvaluationRun', d)
    state = run.get('state') or run.get('executionState')
    cases = d.get('testCases', [])
    total = len(cases)
    passed = 0
    cats = Counter()
    for c in cases:
        qrm = c.get('graderMetrics', {}).get('queryResponseMetrics', [])
        if not qrm:
            cats['NO_METRIC'] += 1; continue
        res = qrm[0].get('evaluationResult')
        props = qrm[0].get('properties', {})
        if res == 'Pass':
            passed += 1; cats['PASS'] += 1
        elif props.get('abstention') == 'Yes':
            cats['ABSTAIN'] += 1
        elif props.get('relevance') == 'No':
            cats['LOW_RELEVANCE'] += 1
        elif props.get('completeness') == 'No':
            cats['INCOMPLETE'] += 1
        else:
            cats['OTHER'] += 1
    print(f"state={state} | scored={total}")
    if total:
        print(f"  PASSED={passed}/{total} = {passed*100//total}%")
    for k, v in cats.most_common():
        print(f"  {k}: {v}")
    return state

def list_fallback():
    url = f'{GW}/environments/{ENV}/bots/{BOT}/makerevaluations?count=10'
    arr = json.loads(_req(url).read())
    for r in arr[:5]:
        agg = {m.get('name'): m.get('count') for m in r.get('aggregatedGraderResults', [])}
        s = agg.get('totalSucceeded', 0); f = agg.get('totalFailed', 0)
        tot = s + f or 1
        print(f"  run={r.get('id')} | state={r.get('state')} | {s}P/{f}F = {s*100//tot}% | type={r.get('evaluationSetType')} | cases={r.get('testCaseCount')}")

if __name__ == '__main__':
    a = sys.argv[1:]
    if not a or a[0] == 'list':
        list_sets()
    elif a[0] == 'start':
        rid = start(a[1], a[2]) if len(a) > 2 else start(a[1])
        print("RUNID=" + rid)
    elif a[0] == 'poll':
        poll(a[1])
    elif a[0] == 'last':
        list_fallback()
    else:
        print("unknown cmd: list | start <id> [name] | poll <id> | last")
