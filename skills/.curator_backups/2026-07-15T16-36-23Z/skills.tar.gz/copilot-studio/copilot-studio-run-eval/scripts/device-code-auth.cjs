#!/usr/bin/env node
/**
 * Seed Copilot Studio PPAPI eval MSAL cache using Microsoft device-code auth.
 *
 * Usage:
 *   node scripts/device-code-auth.cjs <tenant-id> <client-id> <scope> <cache-slot> [pipeline-package-json]
 *
 * Example:
 *   node scripts/device-code-auth.cjs \
 *     00000000-0000-0000-0000-000000000000 \
 *     96ff4394-9197-43aa-b393-6a41652e21f8 \
 *     https://api.powerplatform.com/.default \
 *     test-agent \
 *     "D:/my agents copilot studio/pipeline/package.json"
 */
const { createRequire } = require('module');
const os = require('os');
const path = require('path');

const [tenantId, clientId, scope, cacheSlot = 'test-agent', packageJsonPath = process.cwd() + '/package.json'] = process.argv.slice(2);
if (!tenantId || !clientId || !scope) {
  console.error('Usage: node device-code-auth.cjs <tenant-id> <client-id> <scope> <cache-slot> [pipeline-package-json]');
  process.exit(2);
}

// When this script is copied to %TEMP%, normal require() will not see the pipeline's node_modules.
// Resolve MSAL from the pipeline package.json instead.
const pipelineRequire = createRequire(packageJsonPath);
const msal = pipelineRequire('@azure/msal-node');
const { PersistenceCreator, PersistenceCachePlugin, DataProtectionScope } = pipelineRequire('@azure/msal-node-extensions');

async function main() {
  const cacheDir = path.join(os.homedir(), '.copilot-studio-cli');
  const cachePath = path.join(cacheDir, `${cacheSlot}.cache.json`);
  const persistence = await PersistenceCreator.createPersistence({
    cachePath,
    dataProtectionScope: DataProtectionScope.CurrentUser,
    serviceName: 'copilot-studio-cli',
    accountName: cacheSlot,
    usePlaintextFileOnLinux: true,
  });
  const cachePlugin = new PersistenceCachePlugin(persistence);
  const app = new msal.PublicClientApplication({
    auth: { clientId, authority: `https://login.microsoftonline.com/${tenantId}` },
    cache: { cachePlugin },
  });

  const accounts = (await app.getTokenCache().getAllAccounts()).filter(a => a.tenantId === tenantId);
  if (accounts.length) {
    try {
      const result = await app.acquireTokenSilent({ scopes: [scope], account: accounts[0] });
      console.log(JSON.stringify({
        status: 'ok', mode: 'silent', username: result.account?.username,
        tenantId: result.account?.tenantId, expiresOn: result.expiresOn?.toISOString(), cachePath,
      }, null, 2));
      return;
    } catch (e) {
      console.error(`Silent auth failed, continuing with device code: ${e.message}`);
    }
  }

  const result = await app.acquireTokenByDeviceCode({
    scopes: [scope],
    deviceCodeCallback: (response) => {
      console.log(JSON.stringify({
        status: 'device_code', userCode: response.userCode,
        verificationUri: response.verificationUri, expiresIn: response.expiresIn,
        message: response.message, cachePath,
      }, null, 2));
    },
  });

  console.log(JSON.stringify({
    status: 'ok', mode: 'device_code', username: result.account?.username,
    tenantId: result.account?.tenantId, expiresOn: result.expiresOn?.toISOString(), cachePath,
  }, null, 2));
}

main().catch(err => {
  console.error(JSON.stringify({ status: 'error', message: err.message }, null, 2));
  process.exit(1);
});
