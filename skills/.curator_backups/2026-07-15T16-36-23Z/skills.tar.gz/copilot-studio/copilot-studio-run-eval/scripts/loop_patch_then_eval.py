#!/usr/bin/env python3
"""Auto-patch-then-eval-then-revert loop for a Copilot Studio DRAFT topic change.

Orchestrates the user-preferred "BOTH" remediation sequence for a regressing or
unvalidated additive topic change:
  1. Retry the live Dataverse PATCH of a topic until the org CRM host resolves
     (it intermittently fails DNS while the eval Gateway stays reachable).
  2. Start the affected eval type (SR by default) on the DRAFT, poll to completion.
  3. If the score lands BELOW BASELINE_PCT, delete the (additive, unpublished) topic
     and re-eval -> you land back at the best-known passing rate.
  4. If it meets/exceeds baseline, keep the change and stop.

Hard-won gotchas baked in:
  * Token files MUST live on a Windows-visible path (e.g. C:/Users/kevin/...).
    MSYS /tmp is NOT visible to the WindowsApp store python interpreter -> FileNotFound.
  * Eval token comes from refresh_eval_token.cjs (MSAL api://96ff4394 scope) run from
    ITS OWN dir with stdout NOT redirected (redirect corrupts the token file -> 403).
    CRM token comes from `az` (crm.dynamics.com scope). Keep them strictly separate.
  * Poll the LIST endpoint (.../makerevaluations?$top=N) and read
    aggregatedGraderResults[] totalSucceeded/totalFailed -- those populate LIVE during
    InProgress, so you never falsely read 0% from an empty /details testCases array.

CONFIG block below uses Pacific Coast Case Historian (PCCH) IDs as defaults -- replace
for other agents. The topic YAML path points at the real project folder (note the folder
is literally "Pacific Coast Case Historian", NOT "Pacific Case Case Historian").
"""
import json, urllib.request, urllib.error, time, subprocess, os

# ---------------- CONFIG (replace for other agents) ----------------
TOKEN_PATH   = r'C:/Users/kevin/.copilot-studio-cli/test-agent-token.txt'
EVAL_REFRESH = r'C:/Users/kevin/skills-for-copilot-studio/scripts/refresh_eval_token.cjs'
AZ           = r'C:/Program Files/Microsoft SDKs/Azure/CLI2/wbin/az'
ORG          = "62945552-72f5-f011-aa23-6045bd003938"
CID          = "f309e018-6d7e-f111-ab0e-6045bd03f66a"   # topic botcomponent to patch/delete
ENV          = 'a944fdf0-0d2e-e14d-8a73-0f5ffae23315'
BOT          = 'ad635500-cf47-f111-bec5-70a8a5b1c3a3'
SR_SET       = 'c1f6dd5f-2360-48a2-b525-0fc733667644'
YAML_PATH    = r"C:/Users/kevin/Desktop/Pacific-Coast-Therapy-Hub/Pacific Coast Case Historian/topics/In-Document_Clinical_Extraction.mcs.yml"
BASELINE_PCT = 73          # best-known passing rate on this same test set, pre-change
PATCH_RETRIES = 90         # ~45 min of 30s retries waiting for DNS recovery
# ----------------------------------------------------------------

GW = f'https://powervamg.us-il107.gateway.prod.island.powerapps.com/api/botmanagement/v2/environments/{ENV}/bots/{BOT}'
H = {'Accept':'application/json','Origin':'https://copilotstudio.microsoft.com',
     'X-CCI-ApplicationSource':'Web','X-CCI-BapEnvironmentId':ENV,'X-CCI-BotId':BOT,'X-CCI-CdsBotId':BOT,
     'X-CCI-TenantId':'03cc92c3-986c-4cf4-ae27-1478cf99d17f','X-CCI-OrganizationId':ORG}

def eval_tok():
    subprocess.run(['node', EVAL_REFRESH], cwd=os.path.dirname(EVAL_REFRESH),
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return open(TOKEN_PATH).read().strip()

def crm_tok():
    env = dict(os.environ); env['PATH'] = r'C:/Program Files/Microsoft SDKs/Azure/CLI2/wbin' + ';' + env.get('PATH','')
    out = subprocess.run([AZ,'account','get-access-token','--resource',f'https://{ORG}.crm.dynamics.com'],
                         capture_output=True, text=True, env=env).stdout
    return json.loads(out)['accessToken']

def get(url):
    r = urllib.request.Request(url)
    for k,v in H.items(): r.add_header(k,v)
    return urllib.request.urlopen(r, timeout=120).read()

def post(url, body):
    r = urllib.request.Request(url, data=json.dumps(body).encode(), method='POST')
    for k,v in H.items(): r.add_header(k,v)
    r.add_header('Content-Type','application/json')
    return urllib.request.urlopen(r, timeout=120).read()

def patch_crm(content, tok):
    url = f"https://{ORG}.api.crm.dynamics.com/api/data/v9.2/botcomponents({CID})"
    req = urllib.request.Request(url, data=json.dumps({"content":content}).encode(), method="PATCH",
        headers={"Authorization":f"Bearer {tok}","OData-MaxVersion":"4.0","OData-Version":"4.0",
                 "Content-Type":"application/json","Accept":"application/json"})
    return urllib.request.urlopen(req, timeout=90).status

def delete_crm(tok):
    url = f"https://{ORG}.api.crm.dynamics.com/api/data/v9.2/botcomponents({CID})"
    req = urllib.request.Request(url, method="DELETE",
        headers={"Authorization":f"Bearer {tok}","OData-MaxVersion":"4.0","OData-Version":"4.0","Accept":"application/json"})
    return urllib.request.urlopen(req, timeout=90).status

def start_eval():
    H['Authorization'] = f'Bearer {eval_tok()}'
    for i in range(180):
        try:
            arr = json.loads(get(f'{GW}/makerevaluations?$top=5'))
            if not any(r.get('state')=='InProgress' for r in arr):
                d = json.loads(post(f'{GW}/makerevaluations', {'testSetId':SR_SET,'runName':'auto loop SR'}))
                return d.get('runId') or d.get('id')
        except urllib.error.HTTPError as e:
            if e.code==403: H['Authorization'] = f'Bearer {eval_tok()}'
            else: print("wait-err", e.code, flush=True)
        if i%5==0: print(f"[wait-slot] {i}", flush=True)
        time.sleep(20)
    print("[no-free-slot]"); raise SystemExit(1)

def poll_eval(runid):
    last = time.time()
    for i in range(260):
        if time.time()-last > 2400: H['Authorization'] = f'Bearer {eval_tok()}'; last = time.time()
        try:
            arr = json.loads(get(f'{GW}/makerevaluations?$top=6'))
            run = [x for x in arr if x['id'].startswith(runid)][0]
            st = run.get('state'); ag = run.get('aggregatedGraderResults') or []
            p = f = 0
            for m in ag:
                if m.get('name')=='totalSucceeded': p = m.get('count',0)
                if m.get('name')=='totalFailed':    f = m.get('count',0)
            if i%5==0: print(f"[poll] {i} state={st} pass={p} fail={f}", flush=True)
            if st=='Completed':
                if p+f:
                    pct = p*100//(p+f); print(f"[DONE] {p}/{p+f} = {pct}% run={runid}", flush=True); return pct
                print(f"[DONE] Completed no counts run={runid}", flush=True); return None
        except urllib.error.HTTPError as e:
            if e.code==403: H['Authorization'] = f'Bearer {eval_tok()}'
            else: print("poll-err", e.code, flush=True)
        time.sleep(20)
    print("[eval-timeout]"); return None

# ---- PHASE 1: push narrowed topic (retry through DNS outage) ----
print("[phase1] retry narrowed-topic PATCH until CRM host resolves", flush=True)
narrowed = open(YAML_PATH, encoding='utf-8').read()
patched = False
for attempt in range(PATCH_RETRIES):
    try:
        code = patch_crm(narrowed, crm_tok())
        print(f"[PATCH] narrowed OK status={code} attempt={attempt}", flush=True); patched = True; break
    except urllib.error.HTTPError as e:
        print(f"[PATCH] HTTP {e.code} attempt={attempt}; retry", flush=True)
    except Exception as e:
        msg = str(e).lower()
        if 'getaddrinfo' in msg or 'nameresolution' in msg or 'resolve' in msg:
            if attempt%4==0: print(f"[PATCH] DNS-blocked attempt={attempt}; retry in 30s", flush=True)
        else:
            print(f"[PATCH] ERR {e} attempt={attempt}; retry", flush=True)
    time.sleep(30)
if not patched:
    print("[phase1-FAIL] CRM host never resolved; cannot push. Stopping.", flush=True); raise SystemExit(1)

# ---- PHASE 2: eval narrowed ----
print("[phase2] start SR eval on narrowed topic", flush=True)
runid = start_eval()
pct = poll_eval(runid)
print(f"[phase2-result] narrowed run={runid} score={pct}% baseline={BASELINE_PCT}%", flush=True)

# ---- PHASE 3: if below baseline, pull topic (revert) ----
if pct is not None and pct < BASELINE_PCT:
    print(f"[phase3] {pct}% < {BASELINE_PCT}% -> PULL topic (revert to baseline)", flush=True)
    try:
        ds = delete_crm(crm_tok()); print(f"[PULL] delete status={ds}", flush=True)
    except Exception as e:
        print(f"[PULL] ERR {e}", flush=True)
    runid2 = start_eval(); pct2 = poll_eval(runid2)
    print(f"[phase3-result] reverted run={runid2} score={pct2}%", flush=True)
else:
    print(f"[phase3] {pct}% >= {BASELINE_PCT}% -> keep narrowed topic. Done.", flush=True)
print("[ALL-DONE]", flush=True)
