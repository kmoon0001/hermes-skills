# Feedback B Topic Structure Audit — Missing Output Nodes (Jul 6 2026)

## Agent
Topic Therapy Documentation Feedback (bot `b0346795`), Therapy AI Agents Dev (orgbd048f00)
20 topic components total. 6 documentation audit topics diagnosed.

## The Pattern: File-Upload → AI Builder → Silent End

Every documentation audit topic in Feedback B followed this structure:
```
Question (FilePrebuiltEntity) → ConditionGroup
  ├── conditions: [file valid] → InvokeAIBuilderModelAction (output to Global.GlobalAuditResultstext)
  └── elseActions: SendActivity ("no valid file" error)
EndDialog
```

**Problem:** The `SendActivity` is only in the `elseActions` (error path). The success path runs the AI Builder and ends — never displaying the result. User uploads → agent processes → conversation ends silently. This is the "hangs" or "ends with no answer" Kevin was seeing.

## Topics Affected (5/6)

| Topic | Has SendActivity in success path? | Has InvokeFlowAction? | Notes |
|-------|-----|-----|-------|
| Treatment Encounter Note Review | ✗ | ✗ | Missing output + missing flow |
| Recertification/UPOT Review | ✗ | ✗ | Missing output + missing flow |
| Discharge Summary | ✗ | ✗ | Missing output + missing flow |
| Progress Report Review | ✗ | ✗ | Missing output + missing flow |
| Episode of Care | ✗ | ✗ | Missing output + missing flow |
| Evaluation/Assessment and Plan of Care | ✅ | ✅ (OCR flow) | The ONLY working topic |

## Why Evaluation Works

The Evaluation topic has:
1. `InvokeFlowAction` (OCR text extraction via flow `c71672f2-113b-f111-88b4-0022480b6bd9`)
2. `InvokeAIBuilderModelAction` with extracted text as input (not raw file)
3. **`SendActivity`** in the success path: `value: =Global.GlobalAuditResultstext.text`

The other 5 topics have only `InvokeAIBuilderModelAction` with the raw file (`=Topic.TopicUploadedDoc`) and no output SendActivity.

## Secondary Gaps

1. **Missing modeldescription/description metadata** — None of the 6 topics have `modeldescription:` or `description:` in their YAML, only `modelDescription:` (lowercase d, single string). Needed for generative orchestration topic matching.
2. **Blank conversation starter** — GPT metadata has one empty `text:` entry (`Daily Note Compliance Check`), likely causing publish validation failures.
3. **No text input fallback** — All 6 topics only accept file upload via `FilePrebuiltEntity`. Users who type a question instead of attaching a file get the error path.

## Fix Priority

1. **P0:** Add `SendActivity` in success path of 5 silent topics (Treatment Encounter, Recert, Discharge, Progress, Episode of Care)
2. **P1:** Add standardized `modeldescription` + `description` metadata to all 6 topics
3. **P2:** Fix blank conversation starter in GPT metadata
4. **P3:** Consider adding text-paste fallback path

## Dataverse API Usage

All analysis performed via direct Dataverse REST:
- `GET botcomponents?$filter=_parentbotid_value eq 'b0346795-...' and componenttype eq 9`
- Read `data` field to inspect each topic's YAML structure
- Count of `SendActivity` occurrences, `InvokeAIBuilderModelAction`, `InvokeFlowAction`
