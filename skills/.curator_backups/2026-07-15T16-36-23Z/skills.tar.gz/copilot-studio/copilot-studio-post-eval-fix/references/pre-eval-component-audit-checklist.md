# Pre-Eval Component Audit Checklist

Run this audit BEFORE launching evaluations to catch systemic blockers that will tank SR and Conv scores. Query every component type in the agent, verify each item, and fix before wasting eval runs.

## Layer 0: Freeze Baseline + Component Audit

### 0a. Conversation Start (P0 blocker)
- [ ] Is `Conversation Start` topic active? (`statecode=0`)
- [ ] If active: does it have a `kind: Question` node? (ClosedListEntity / FilePrebuiltEntity)
- [ ] If Question node: **DEACTIVATE IT** — OnConversationStart fires before intent matching, every SR test case hits the menu → Abstention failure
- [ ] If deactivated: was statecode successfully set to 1? (re-query to verify)

Fix: PATCH `{"statecode": 1}` on the botcomponent, or replace Question node with `SendActivity` + `EndDialog`.

### 0b. Greeting Topic
- [ ] Does Greeting redirect to Conversation Start via `BeginDialog`?
- [ ] If yes: this creates a menu cycle on every greeting. Remove the redirect or point to Fallback.

### 0c. Review Topic File-Upload Gate (P0 blocker)
- [ ] For EVERY review/audit topic: first action is `kind: Question` with `entity: FilePrebuiltEntity`?
- [ ] If yes: text-only SR evaluation questions hit this and get "Please upload the document" → Abstention failure
- [ ] Mitigation: ensure pure text compliance questions can bypass via a different routing path OR the Fallback handles them

### 0d. Search Mode — SearchSpecificFiles vs SearchAllKnowledgeSources
- [ ] For EVERY SearchAndSummarizeContent: check `fileSearchDataSource.searchFilesMode.kind`
- [ ] `SearchSpecificFiles` = agent can only use N hardcoded files
- [ ] `SearchAllKnowledgeSources` = uses ALL connected KB sources
- [ ] Fix: replace `SearchSpecificFiles` + `files:` block with `SearchAllKnowledgeSources` (no files list)
- [ ] Also check: `knowledgeSources.kind` — should be `SearchAllKnowledgeSources` not `SearchSpecificKnowledgeSources`

### 0e. additionalInstructions on SearchAndSummarizeContent
- [ ] Every SearchAndSummarizeContent node that generates audit output needs `additionalInstructions`
- [ ] Required content: inline citations, report what's present/missing/required, under 900 characters for SR responses
- [ ] Without this: Groundedness=No failures (generic answers, no citation enforcement)

### 0f. Topic Descriptions
Per MS Learn: "Good descriptions = state what topic does, declare what data it collects, instruct model not to ask for it."
- [ ] Every custom topic has a description? (`botcomponents.{name}.description`)
- [ ] Every topic has a `modelDescription:` in its YAML data?
- [ ] Descriptions should be functional (what the topic DOES), not conversational (what to say)
- [ ] System topics (Fallback, Escalate, End of Conversation, etc.) also need modelDescription

### 0g. Fallback Topic
- [ ] Fallback uses `SearchAndSummarizeContent` with `knowledgeSources: SearchAllKnowledgeSources`?
- [ ] Fallback has `additionalInstructions` for grounded citations?
- [ ] Fallback has `modelDescription` telling the orchestrator it handles all unmatched text queries?

### 0h. GPT Instructions — Evaluation Mode
- [ ] Instructions include an EVALUATION MODE section?
- [ ] Does it say "do NOT ask for a document upload" for text-only queries?
- [ ] Does it specify "under 900 characters" for SR responses?
- [ ] Does it say "answer directly from knowledge sources"?
- [ ] Does it say "never defer or ask for more information before answering"?

### 0i. Component Type Inventory
Query all components for the bot and categorize:
- `componenttype=9` (Topics) — log count and verify all active
- `componenttype=14` (Knowledge Sources) — log count, verify KB names
- `componenttype=15` (GPT Instructions) — verify single component, check modelNameHint
- `componenttype=19` (Conversation Starters / Test Cases) — expected count

## Pitfalls

### CRLF Line Endings in Dataverse PATCH
The `data` field YAML uses `\r\n` (CRLF), NOT `\n`. Python `str.replace('needle', 'replacement')` with LF-only patterns silently returns HTTP 204 (success) but the replacement never matches. Always:
- Use `re.sub()` for pattern-based changes on YAML data
- OR use explicit `\r\n` in replace strings
- ALWAYS re-query after PATCH and verify expected substrings exist by reading back the `data` field

Canary check:
```python
assert 'modelDescription:' in patched_data, "CRLF mismatch — patch didn't stick!"
```

### System Topic startBehavior Interferes with modelDescription Insertion
System topics (End of Conversation, Escalate, On Error, Reset Conversation) have `startBehavior:` between `kind: AdaptiveDialog` and `beginDialog:`. To add modelDescription:
```python
# RIGHT — insert after first line
data = data.replace(
    'kind: AdaptiveDialog\r\n',
    f'kind: AdaptiveDialog\r\nmodelDescription: {desc}\r\n'
)
```
Don't match `kind: AdaptiveDialog\nbeginDialog:` — the startBehavior line breaks that pattern.

### Verify-by-Requery is Mandatory
HTTP 204 does NOT mean the patch stuck. Always:
1. GET the component back
2. Parse the `data` field
3. Assert expected substrings existing
4. Only then mark the fix as DONE
