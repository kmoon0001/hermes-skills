# Therapy Doc Feedback Agent — Eval Fix Loop Case Study (Jul 4-5 2026)

## Agent
- Name: Copy Therapy Docuementation Feedback Ag
- Bot ID: b0346795-4876-f111-ab0e-70a8a5b1b8cc
- Environment: Therapy AI Agents Dev (a944fdf0, orgbd048f00)
- Gateway: powervamg.us-il107.gateway.prod.island.powerapps.com
- OrganizationId (X-CCI): 62945552-72f5-f011-aa23-6045bd003938
- Type: New-experience (Claude Sonnet 4.6)
- Baseline: SR=68% (68P/32F), Conv=15% (3P/17F)

## Score Timeline

| Iteration | Conv Score | Change | What Changed |
|-----------|-----------|--------|-------------|
| Baseline | 15% (3P/17F) | - | Original agent — Question-First gate |
| Iter 1 | 5% (1P/18F) | -10pp | Added EVALUATION-SAFE instructions → REGRESSION |
| Iter 2 | 63% (12P/7F) | +48pp | Removed ConversationStart gate + restored instructions |
| Iter 3-5 | 63% (12P/7F) | +0pp | 3 instruction-level grounding directives → NO EFFECT |
| Iter 6 | 63% (12P/7F) | +0pp | Replaced Fallback topic with SearchAndSummarizeContent |
| Iter 7 | TBD | TBD | Must be started after queue drains |

## Root Cause #1: ConversationStart Topic Gate (FIXED)

The `ConversationStart` topic fires on EVERY new conversation with a Question node:
```yaml
kind: Question
prompt: "What type of document would you like reviewed?"
entity: ClosedListEntity (7 items)
```
Forced 6-turn conversations. Only discharge cases passed.

**Fix:** Replaced Question with SendActivity(greeting) + EndDialog. Applied via Dataverse PATCH. **15% → 63% (+48pp).**

## Root Cause #2: Fallback Topic Intercepts Search (FIXED, not verified by eval)

Both Fallback and Search topics have `OnUnknownIntent`. Search has `priority: -1` (lower), so Fallback fires first with "I'm sorry, I'm not sure how to help." Search never runs.

**Fix:** Replaced Fallback with SearchAndSummarizeContent (same pattern as Search topic). Published 5:01 AM Jul 5. Not yet verified by eval — active-run queue racing prevented fresh evals.

## Remaining: 6 groundedness=No (rel=Yes, comp=Yes) + 1 abstention

Three instruction iterations failed (all flat 63%). If Fallback fix doesn't help, the model may not have knowledge access at the platform level for new-experience agents.

## Validated Lessons

1. ConversationStart with Question node = guaranteed Conv failures
2. Instructions fixes for topic-level problems REGRESS (15%→5%)
3. Dataverse `data` PATCH + `pac copilot publish` works for new-experience topics
4. Groundedness=No with rel=Yes comp=Yes resists instruction-level fixes
5. Gateway API (X-CCI headers) = only reliable eval path — SPA doesn't render in background
6. Token expires ~15 min — re-capture before every polling session
7. CDP token capture requires EVAL tab open — Topics tab won't work
8. Active-run queue racing: wait for clear state before starting fresh eval
9. `pac copilot publish` works for new-experience agents after Dataverse data patches
10. **Eval queue management:** PATCH /makerevaluations/{runId}/cancel cancels stale runs. Verify no InProgress before starting fresh.
11. **pac CLI caching bug:** After a publish fails, `pac copilot publish` returns the SAME failure timestamp forever — even with `pac auth clear` + fresh auth. Verify actual publish state via Dataverse `GET /bots/{id}?$select=publishedon`.
12. **MultipleTopicsMatched is toxic for new-experience agents:** `triggerBehavior: Always` + Question node adds 2+ unnecessary turns. Model handles ambiguity natively. Deactivation blocked `pac copilot publish` — fix in-place by removing triggerBehavior: Always and replacing ReplaceDialog→Fallback with CancelAllDialogs+EndDialog.
13. **ThankYou topic missing EndDialog:** Common across new-experience agents — conversation hangs after "You're welcome."
14. **Bot-level config matters:** `useModelKnowledge: true` and `isSemanticSearchEnabled: true` must be set on bot configuration for knowledge grounding to work.
