---
name: copilot-studio-post-eval-fix
description: "Post-evaluation agent repair loop: analyze failures → systemic plan with MS Learn checklist → execute → QA sweep → look-back re-analysis → loop until >95%. Evidence-based, systemic-first, checklist-driven."
version: 1.0.0
author: Hermes Agent
tags: [copilot-studio, evaluation, fix, loop, checklist, ms-learn, qa]
---

# /copilotpostevalfix — Post-Evaluation Agent Fix Loop

Systematic, evidence-based workflow to fix Copilot Studio agents after evaluation. Systemic fixes first, individual remaining fixes second. Checklist-driven with Microsoft Learn grounding.

## Invocation

User says: `/copilotpostevalfix`, "analyze eval failures for PT", "fix the conversational score", "run the eval fix loop on OT"

## The Loop

```
┌──────────────────────────────────────────────────────────────┐
│              /copilotpostevalfix LOOP                          │
│                                                               │
│  PHASE 1: ANALYZE ALL FAILURES                                │
│  ├─ Load eval results (SR + Conv)                             │
│  ├─ Categorize every failure by root cause                    │
│  └─ Pattern-detect: 80%+ same cause → systemic fix           │
│                                                               │
│  PHASE 2: SYSTEMIC PLAN                                       │
│  ├─ Ground in Microsoft Learn best practices                  │
│  ├─ Generate numbered checklist with fix order                │
│  ├─ Prioritize: security → routing → YAML → KB → instructions │
│  └─ Present to user for approval before executing             │
│                                                               │
│  PHASE 3: EXECUTE FIXES                                       │
│  ├─ Work checklist items in order                             │
│  ├─ Systemic/batch fixes first (affect multiple failures)     │
│  ├─ Individual fixes second (single-failure causes)           │
│  └─ Mark each item: DONE / BLOCKED / SKIPPED                  │
│                                                               │
│  PHASE 4: QA SWEEP                                            │
│  ├─ Validate all YAML with js-yaml                            │
│  ├─ Verify data ≠ content (check for stale compiled YAML)     │
│  ├─ Count .bak files vs fix claims (catch inflation)          │
│  ├─ Read actual file content (don't trust self-reports)       │
│  └─ Flag unapplied or incomplete fixes                        │
│                                                               │
│  PHASE 5: LOOK-BACK RE-ANALYSIS                               │
│  ├─ Re-run evaluation                                         │
│  ├─ Compare pre vs post scores                                │
│  ├─ If score dropped → revert, re-triage root cause           │
│  ├─ If score flat → wrong root cause, go to Phase 1           │
│  ├─ If score improved but <95% → remaining failures → Phase 1 │
│  └─ If score ≥95% both SR and Conv → DONE                     │
│                                                               │
│  LOOP: Repeat Phase 1→5 until >95% or 3 iterations plateau    │
└──────────────────────────────────────────────────────────────┘
```

## Phase 1: Analyze All Failures

### 1a. Load Evaluation Results

**PREFER Gateway REST API over CDP/SPA.** The Copilot Studio SPA does NOT render in background tabs (Jul 4 2026 validated: 10+ attempts, multiple sessions, Edge and Chrome). Use the Gateway API exclusively for eval triggering and monitoring.

**Gateway REST API workflow (Therapy AI Dev):**
1. Capture token: `echo "" | node "D:/my agents copilot studio/pipeline/scripts/cdp_capture_token.cjs" --port 9223`
2. Token at: `%USERPROFILE%\.copilot-studio-cli\test-agent-token.txt`
3. Gateway: `https://powervamg.us-il107.gateway.prod.island.powerapps.com/api/botmanagement/v2`
4. Required headers: `Authorization` + 6 `X-CCI-*` headers
5. List test sets: `GET /environments/{env}/bots/{bot}/makerevaluations/testsets`
6. Start run: `POST /makerevaluations` with `{"testSetId": "..."}`
7. Poll: `GET /makerevaluations?count=5` every 30s
8. Scores from `aggregatedGraderResults[]` — `totalSucceeded` / `totalFailed` counts

Full Python pattern and X-CCI header values in: `copilot-studio-run-eval` → `references/gateway-eval-api-recipe.md`

**Fallback: CDP DOM extraction** (only if Gateway API returns 403 Unauthenticated):
Captured PPAPI tokens may not work for all environments. If Gateway API fails, fall back to CDP `Runtime.evaluate` on the Copilot Studio eval tab (requires active foreground tab). Parse scores from `document.body.innerText`.

### 1a2. Structural Diagnostic: "Hangs / Silent End" — Missing Output Node

When a user reports the agent "hangs" or "ends with no answer" for documentation topics, the root cause is often a **missing `SendActivity` in the success path** of a file-upload → AI Builder topic. This is NOT an eval metric failure — it's a YAML defect that prevents any answer from rendering.

**Symptom pattern:** Topic asks "please upload the file", user uploads, agent processes silently, then conversation ends. The AI Builder runs and stores output in a global variable (`Global.GlobalAuditResultstext`) but no node displays it.

**Diagnostic query** (live Dataverse):
```python
filt = f"_parentbotid_value eq '{bot_id}' and componenttype eq 9"
url = f"{base}/botcomponents?$filter={urllib.parse.quote(filt)}&$select=schemaname,data&$top=100"
```

**Checklist per topic:**
1. Does it have `FilePrebuiltEntity` Question node to prompt for upload?
2. Does it have `InvokeAIBuilderModelAction` with `predictionOutput` binding (stored to `Global.GlobalAuditResultstext`)?
3. Does it have a `SendActivity` in the **success path** (inside `conditions:` actions, NOT just `elseActions`)?
4. If the only `SendActivity` is in `elseActions` (error: "no file uploaded"), the topic will silently end after processing — the user sees nothing.

**Fix:** Add a `SendActivity` in the success branch after the AI Builder call using a flat string activity, not a dict with `value`/`text`:
```yaml
- kind: SendActivity
  id: send_audit_results
  activity: "=Global.GlobalAuditResultstext"
```

**Validated:** Therapy Feedback B agent (Jul 2026). 6 doc audit topics — 5/6 had missing SendActivity. All 6 now use flat-string pattern.

### 1a2b. Structural Diagnostic: Blob operator error for FilePrebuiltEntity

When a file-upload topic shows PowerFxError about `.` on Blob values, root cause is `.Content` or `.Name` on a FilePrebuiltEntity variable.

**Symptom:** `The '.' operator cannot be used on Blob values.` runtime error. Fix with `Document_20input: =Topic.TopicUploadedDoc` (no dot notation). Remove InvokeFlowAction OCR extraction — AI Builder handles document text natively.

### 1a2c. Structural Diagnostic: Duplicate YAML sections

Regex find-and-replace on the `data` YAML string can create duplicate sections. Rebuild full YAML from scratch instead. Count occurrences to detect: `[regex]::Matches($data, "InvokeFlowAction").Count`.

### 1b. Get Per-Case Failure Details (Gateway API)

Use the Gateway API `/makerevaluations/{runId}/details` for EXACT failure diagnosis (validated Jul 4 2026). Returns `queryResponseMetrics[]` with `properties` (abstention, relevance, completeness, groundedness) and `resultExplainer`.

```python
details = req(f"{GW}/environments/{env}/bots/{bot}/makerevaluations/{run_id}/details", token)
for tc in details['details']['testCases']:
    for m in tc['graderMetrics']['queryResponseMetrics']:
        props = m['properties']
        explainer = m.get('resultExplainer', '')
        # props: {abstention, relevance, completeness, groundedness}
```

**Quick diagnosis from properties + explainer:**

| Properties | resultExplainer | Likely Fix |
|-----------|----------------|------------|
| `abstention=Yes, relevance=NA` | "agent refuses to help... asks for documents" | Instructions: add "When no documentation is provided" clause |
| `relevance=Yes, completeness=Yes, groundedness=No` | (null) | Activate Search/Fallback topic, check KB connection |
| `completeness=No` | various | Check response length limits, instruction detail |

### 1c. Categorize Every Failure

For each failed test case, classify the root cause:

| Category | Symptom | Common Root Cause |
|----------|---------|-------------------|
| **Question-First** | All failures show same message count (e.g., 6), only specific doc types pass | Agent opens with "What type of document..." gate question instead of direct answer |
| **Structural** | `ExecutionFailed`, `unsupportedactivity.notextresponse` | Missing EndDialog, missing SendActivity |
| **Routing** | Wrong topic matched, low relevance | Trigger phrase overlap, missing triggers |
| **Completeness** | `completeness: No` | Short/truncated answers, 800-char limits |
| **Relevance** | `relevance: No` | Wrong topic, wrong knowledge source |
| **Groundedness** | `groundedness: No` | Hallucination, SearchSpecificFiles restriction |
| **Abstention** | `abstention: Yes` | "I cannot provide medical advice", "Please provide the document first" |
| **Format** | Wrong output structure | Unconditional RESPONSE FORMAT, missing format |
| **Platform** | ALL agents failing simultaneously | Evaluation service outage |
| **Stale Content** | `data` correct but `content` old | Unpublished Dataverse PATCH |

### 1c. Pattern Detection

Count failures by category:
- **80%+ same root cause** → systemic fix (fix the category, not individual cases)
- **Mixed causes** → prioritize by impact (most failures first)
- **1-2 unique failures** → individual fixes after systemic pass

### 1d. Microsoft Learn Grounding

Before proposing fixes, check these MS Learn pages for current guidance:
- https://learn.microsoft.com/microsoft-copilot-studio/guidance/evaluation-triage-overview
- https://learn.microsoft.com/microsoft-copilot-studio/guidance/evaluation-triage-failure
- https://learn.microsoft.com/microsoft-copilot-studio/guidance/evaluation-triage-pattern
- https://learn.microsoft.com/microsoft-copilot-studio/guidance/evaluation-triage-remediation

## Phase 2: Systemic Plan

### 2a. Generate Checklist

Create a numbered, ordered checklist:

```
## Fix Checklist for [Agent Name]

### Systemic Fixes (affect multiple failures)
1. [ ] [P0/P1] [Category] Fix: [description]
   - Affected: N failures
   - MS Learn: [citation]
   - Method: [Dataverse PATCH / UI code editor / pac publish]

### Individual Fixes (single failures)
5. [ ] [P1] [Category] Fix: [description]
   - Affected: 1 failure: "[test case question]"
   - MS Learn: [citation]

### Post-Fix Verification
N. [ ] Validate all YAML
N+1. [ ] Publish agent
N+2. [ ] Wait 90 seconds
N+3. [ ] Re-run evaluation
```

### 2b. Fix Priority Order

1. **P0 — Security/Compliance** — PHI exposure, HIPAA violations
2. **P0 — Structural** — Missing EndDialog, broken YAML, stale content
3. **P1 — Routing** — Trigger phrase overlap, wrong topic matching
4. **P1 — Knowledge** — SearchSpecificFiles, SearchSpecificKnowledgeSources
5. **P1 — Instructions** — Unconditional RESPONSE FORMAT, ask-for-document patterns
6. **P1 — Test Set** — Unanswerable questions ("check my document")

### 2c. Present for Approval

**ALWAYS present the checklist to the user before executing.** Include:
- Failure breakdown by category with counts
- Proposed fixes ordered by priority
- Expected score impact per fix
- Any fixes that need UI access (code editor) vs API-only
- Risk assessment: which fixes could cause regression

Wait for user confirmation before Phase 3.

## Phase 3: Execute Fixes

### 3a. ⚠ CRITICAL: Fix the RIGHT Layer — Topics vs Instructions

**PITFALL — Instructions fix for topic-level problem REGRESSES scores (validated Jul 4 2026, Therapy Doc Feedback: 15% → 5%):**

When conversational failures show ALL cases at the same turn count (e.g., 6 messages) with a consistent "What type of document..." greeting, the root cause is in the **Greeting / OnConversationStart TOPIC**, NOT the instructions. Adding evaluation-safe directives to instructions when the gate is in a topic confuses the model and drops scores.

**Diagnostic table for Conv failures:**
| Symptom | Root Cause Layer | Fix |
|---------|-----------------|-----|
| All failures = same turn count, specific doc types pass | **Topics** (Greeting/Conversation Starters gate question) | Remove greeting gate, use direct prompts |
| Mixed turn counts, "please provide the document" | **Instructions** (ask-for-document pattern) | Fix instructions to answer without docs |
| Only specific doc types pass (e.g., only discharge, only progress) | Greeting routes doc types differently OR KB gap | Check BOTH greeting routing AND KB coverage |

**For new-experience agents:** Conversation Starters appear as suggested-action buttons. Remove gate questions like "What type of document..." Replace with direct action prompts.

**For classic agents:** Check the Greeting topic for Question nodes. Replace with direct routing.

**Why instructions fixes regress:** The model already has domain knowledge (proven by the few passing cases). Adding "evaluation-safe" directives conflicts with topic-level routing, producing lower-quality responses.

See `references/therapy-doc-feedback-case-study.md` for the full validated case.

### 3b. Systemic/Batch Fixes First

Apply fixes that affect multiple failures in one pass:

**EndDialog batch** — All topics missing `clearTopicQueue: true` → add in one sweep
**SearchSpecificFiles batch** — Remove from all audit topics
**Instruction batch** — Single PATCH to `agent.mcs.yml`
**Conversational Boosting** — Apply validated YAML template

### 3b. Individual Fixes Second

After systemic fixes, address remaining unique failures.

### 3c. Fixing New-Experience Agents (ConversationStart Anti-Pattern)

**PITFALL — New-experience agent ConversationStart uses OnConversationStart with Question node:**

Diagnosis: Query all botcomponents with `componenttype eq 9`. Find `ConversationStart` topic. If it contains `kind: Question` with a prompt like "What type of document would you like reviewed?", this fires on EVERY conversation and forces a 6-turn Question-Answer cycle.

**Fix via Dataverse PATCH:**
```yaml
kind: AdaptiveDialog
modelDescription: Brief greeting then end — let Fallback handle the query.
beginDialog:
  kind: OnConversationStart
  id: main
  actions:
    - kind: SendActivity
      id: greeting
      activity: Hello, I am [agent name]. Describe what you need help with.
    - kind: EndDialog
      id: end-topic
      clearTopicQueue: true
```

**PITFALL — `data` patch alone may not trigger recompile for system topics.** `pac copilot publish` compiles `data`→`content` for classic agents but may not for new-experience system topics. If the fix doesn't take effect, open the topic in the SPA code editor and press Ctrl+S to force recompile.

### 3d. Gateway API Eval Orchestration (preferred over SPA)

**PREFERRED — Use Gateway REST API, not the Copilot Studio SPA.** The SPA does not render in background tabs (validated Jul 4-5 2026: 15+ attempts across Edge and Chrome, multiple sessions, CDP + cua-driver). The Gateway API is fully reliable and can be driven from any terminal.

**CDP Token Capture (required for Gateway auth):**
```bash
echo "" | node "D:/my agents copilot studio/pipeline/scripts/cdp_capture_token.cjs" --port 9223
```
Token saved to `%USERPROFILE%\.copilot-studio-cli\test-agent-token.txt`. Expires ~15 min.

**PITFALL — Capture requires the EVAL tab to be open in the browser.** The script searches for tabs with "evaluation" in the URL. If the Topics tab is open instead, navigate to the eval page first via CDP `Page.navigate`, wait 30s, then run capture. Token is 4554 chars. Expires after ~15 min — re-capture before polling if 400/401 errors appear.

**Gateway endpoints (Therapy AI Dev):**
- GW: `https://powervamg.us-il107.gateway.prod.island.powerapps.com/api/botmanagement/v2`
- List test sets: `GET .../makerevaluations/testsets`
- Start run: `POST .../makerevaluations` body `{"testSetId":"..."}`
- Poll: `GET .../makerevaluations?count=5`
- Details: `GET .../makerevaluations/{runId}/details`

**Required X-CCI headers (missing any = MissingRoutingHeader):**
```
X-CCI-ApplicationSource: Web
X-CCI-BapEnvironmentId: {env-guid}
X-CCI-BotId: {bot-guid}
X-CCI-CdsBotId: {bot-guid}
X-CCI-TenantId: 03cc92c3-986c-4cf4-ae27-1478cf99d17f
X-CCI-OrganizationId: {org-guid}  # environment-specific!
```

**PITFALL — OrganizationId varies per environment.** Therapy AI Dev = `62945552-72f5-f011-aa23-6045bd003938`. Capture from browser or use the eval skill's gateway recipe.

**PITFALL — Polling token expiry causes silent 400 errors.** When the Gateway API returns 400 Bad Request during polling, the CDP token has expired. Re-capture immediately and retry. Don't assume the eval failed — it's just an auth issue.

**PITFALL — Active-run queue racing.** When `POST /makerevaluations` returns 422 `fairusagepolicy.botactiverunquotaviolated`, an eval is already running. Wait for it to complete before starting a new one. Don't keep firing `POST` requests — they queue up stale evals that all run against the previous published version.

**Workflow for a truly fresh eval:**
1. Poll until no InProgress runs (check every 10s)
2. Capture fresh token
3. Start one (1) eval
4. Poll every 30s until Completed
5. If 400 during polling, re-capture token and continue

### 3e. Groundedness Failures (new-experience agents)

**PITFALL — `groundedness=No` with `relevance=Yes, completeness=Yes` is a platform-level issue, NOT instruction-level:**

Validated Jul 4-5 2026 on Therapy Doc Feedback agent (Claude Sonnet 4.6, new-experience). After 3 iterations of instruction changes (mandatory citation, CRITICAL cite-or-die directive, shorter focused instructions), groundedness=No persisted across all 6 affected cases. Score flatlined at 63%.

**Root cause: Fallback topic intercepts OnUnknownIntent before Search topic can run.** The Search topic has `priority: -1` (lower than Fallback's default). When both have `OnUnknownIntent`, Fallback fires first and returns "I'm sorry, I'm not sure how to help."

**Fix:** Replace Fallback topic with SearchAndSummarizeContent (same pattern as Search topic):
```yaml
kind: AdaptiveDialog
beginDialog:
  kind: OnUnknownIntent
  id: main
  actions:
    - kind: SearchAndSummarizeContent
      id: search-content
      variable: Topic.Answer
      userInput: =System.Activity.Text
    - kind: ConditionGroup
      id: has-answer-conditions
      conditions:
        - id: has-answer
          condition: =!IsBlank(Topic.Answer)
          actions:
            - kind: SendActivity
              id: sendAnswer
              activity: "{Topic.Answer}"
            - kind: EndDialog
              id: end-topic
              clearTopicQueue: true
      elseActions:
        - kind: SendActivity
          id: noAnswer
          activity: I don't have specific information on that. Could you rephrase?
        - kind: EndDialog
          id: end-fallback
          clearTopicQueue: true
```

**PITFALL — This fix hasn't been verified via eval yet.** The Fallback topic was patched and published at 5:01 AM Jul 5, but all subsequent evals were started pre-publish (queue racing). If this fix works, groundedness should improve. If it doesn't, knowledge sources may not be connected at the model context level for new-experience agents.

Validated Jul 4 2026 on Therapy Doc Feedback agent (Claude Sonnet 4.6, new-experience). After 3 iterations of instruction changes (mandatory citation, CRITICAL cite-or-die, nuclear first-line directive), groundedness=No persisted across all 6 affected cases. Score flatlined at 63%.

Symptoms: Response is relevant and complete but the grader finds no citations from connected knowledge. The model generates good answers from general knowledge without using Search/Conversational Boosting.

Likely causes:
1. Knowledge sources not connected to the model context in new-experience agents
2. Search topic inactive (componenttype 9, schemaname = `*.topic.Search`, statecode = 1)
3. Model not invoking knowledge retrieval even when instructed

**Fix attempts that DON'T work:** Instruction-level citation requirements, mandatory citation rules, knowledge grounding sections. None moved the needle.

**What to try instead:**
1. Verify Search topic is active (`statecode: 0`)
2. Verify knowledge sources are configured in SPA (not just Dataverse)
3. Check if the model actually receives knowledge context (test in Copilot Studio test pane)
4. If model can't access knowledge sources, groundedness cannot be fixed at instructions level

### 3e. Fix Methods (prefer API over UI)

**Fail-fast rule:** If browser automation (CDP, cua-driver) fails 3+ times on the Copilot Studio SPA (blank page, sleeping tab, wrong agent rendering, tab keeps closing), **STOP immediately.** Switch to Dataverse API or give the user paste-ready YAML files. The SPA is notoriously unreliable in background tabs — don't waste turns fighting it.

1. **Dataverse PATCH** (fastest, most reliable) — `PATCH /botcomponents({id})/data`
   - Works for: topic YAML, GPT instructions, conversation starters
   - Auth: `az account get-access-token --resource "https://<org>.crm.dynamics.com/"`
   - Payload: `{"value": "<yaml_string>"}`
   - HTTP 204 = success. Always re-GET to verify.
   - Pitfall: `content` field NOT patchable — needs UI code editor save
2. **Copilot Studio UI code editor** (only for `content` compilation)
   - Needed when: stale `content` field, complex YAML
3. **`pac copilot publish`** — publish after Dataverse PATCH
4. **`manage-agent.bundle.js push`** — for local workspace changes

### 3f. MultipleTopicsMatched Assessment (new-experience agents)

**PITFALL — MultipleTopicsMatched adds unnecessary friction for new-experience agents (validated Jul 5 2026).** This topic fires on `OnSelectIntent` with `triggerBehavior: Always`, showing a "To clarify, did you mean:" disambiguation prompt on EVERY turn. For new-experience agents (Claude Sonnet 4.6+), the model handles intent disambiguation natively — this topic only adds conversation turns that hurt eval scores.

**Assessment:** Query the topic (componenttype=9, schemaname=*.topic.MultipleTopicsMatched). If present with `triggerBehavior: Always`:
- It adds 2+ unnecessary turns per interaction
- Routes "None of these" to Fallback via `ReplaceDialog` which can create trigger loops
- The model is smart enough to disambiguate without it

**Fix options:**
1. Remove `triggerBehavior: Always` — let it fire only on real ambiguity
2. Replace Fallback routing with `CancelAllDialogs` + `EndDialog` to avoid trigger loops
3. If the model handles ambiguity well, deactivate entirely: PATCH `statecode: 0 → 1`

**PITFALL — deactivating MultipleTopicsMatched may block `pac copilot publish`.** The publish validator may reject the change. If deactivation blocks publish, reactivate and fix in-place (removing triggerBehavior: Always).

### 3f2. Routing Fix: 100% gptFallback on "extract X from pasted text" queries

**PITFALL — extraction topics whose `triggerQueries` are robot-phrased never match real user asks, so every data-rich query falls to Conversational Boosting/Fallback and gets paraphrased from general knowledge → `completeness=No` (validated Jul 12 2026, Pacific Coast Case Historian).**

Symptom: 100% of SR (SingleTurn) failures route to gptFallback (no topic triggered). The failing queries look like "What was the prior level of function for this patient before their stroke?" + a pasted clinical record that *contains the answer verbatim*. The agent answers "PLOF would typically refer to..." (generic) instead of quoting the pasted value → grader marks `completeness=No`.

Root cause: the extraction topics exist but their `triggerQueries` are synthetic/robot phrasings ("run OT clinical analysis workflow") that never match how users actually type. The router never fires them. (Confirm via `/makerevaluations/{runId}/details` — the fall-through path shows as gptFallback / no topic.)

**Fix — mine a HIGH-SCORING SIBLING agent for the winning LOGIC (don't copy its domain content), then build/upgrade an additive catch-all extraction topic with three elements:**

1. **Real natural-language `triggerQueries`** taken from the actual failing eval queries — e.g. "what was the prior level of function", "summarize the surgical history from these notes", "identify the primary diagnosis from this ER note". Human phrasings, not command strings. This is the #1 lever (the Medicare Part B agent @94% wins largely on this).
2. **Inline the pasted text into `userInput` via `=Concatenate(...)`** so the model grounds on the provided text with an explicit output structure:
   ```yaml
   userInput: |-
     =Concatenate(
       "Answer using ONLY facts explicitly stated in the text below. Quote exact verbatim values; do not paraphrase or substitute general knowledge. If the element is absent, say so.",
       Char(10), Char(10),
       "USER QUESTION AND PROVIDED TEXT:", Char(10),
       System.Activity.Text
     )
   ```
   Use `Char(10)` for newlines inside the Power Fx formula — literal newlines in a `|-` block scalar break the formula (`PowerFxError`).
3. **`applyModelKnowledgeSetting: false`** for verbatim extraction from pasted records (set `true` only for KB-grounded Q&A topics — mixing them up is a common regression).

**Checkpoint discipline:** verify the live PATCH stuck (re-query the botcomponent's `data` for both `triggerQueries` and `Concatenate`), then re-run SR. Instruction-only fixes cap out: fix5 SR hit 73%, and adding a verbatim clause to *instructions* REGRESSED it to 69% (reverted). The routing/topic layer is where data-rich extraction failures actually get fixed.

**Cross-reference:** creating the new topic live via `botcomponents` POST has its own pitfalls
(`parentbotid@odata.bind`, customization-prefix `schemaname`, `componenttype: 9` as int, 204 not
201) — full recipe in `copilot-studio-yaml-reference` → `references/create-topic-botcomponents-post.md`.

### 3g. Mark Checklist Progress

After each fix:
- **DONE** — Applied and verified
- **BLOCKED** — Needs user action (e.g., UI access, auth)
- **SKIPPED** — Deemed unnecessary after further analysis

## Phase 4: QA Sweep

### 4a. YAML Validation

```bash
# Batch validate all modified YAML files
for f in $(find . -name "*.mcs.yml" -newer .last_fix_timestamp); do
  node pipeline/scripts/schema-lookup.bundle.js validate "$f"
done
```

### 4b. Stale Content Detection

Query `data` vs `content` for every patched topic:
- `data` has `SearchAndSummarizeContent` but `content` has `FallbackCount` → STALE
- Fix: open topic in UI code editor and save (no API path)

### 4b2. GPT metadata regression checks (validated Jul 6 2026)

Before blaming topics, validate the GPT component YAML (`kind: GptComponentMetadata`):
- It must parse as YAML.
- Top-level keys should include `kind`, `displayName`, `instructions`, `conversationStarters`, and `aISettings`.
- `conversationStarters` must be a list with lowercase `title:` / `text:` keys. A root-level `title:` after `aISettings` means a bad merge/paste dropped the `conversationStarters:` wrapper.
- For Therapy Feedback B new-experience, `aISettings.model.modelNameHint` should remain `Sonnet46`; accidental `GPT5Chat` was a regression.
- If eval directives appear after `conversationStarters:` as unkeyed prose, YAML is invalid; move those directives back inside the `instructions: |-` block.

Validated symptom: live component had `keys=['kind','displayName','instructions','aISettings','title']`, no `conversationStarters`, and `modelNameHint: GPT5Chat`. Repair restored 10 starters + `Sonnet46` and re-GET verified.

### 4c. Fix Verification

- Count actual `.bak` files vs fix agent claims
- Read changed files and verify the fix is actually present
- Query Dataverse to confirm PATCH persisted (HTTP 204 ≠ verified)
- For instructions: verify new text is in the `data` field

### 4d. Common QA Pitfalls

- **Subagent self-report inflation** — Fix agents may claim 58 files fixed when only 28 were. Count independently.
- **Wrong workspace path** — QA must use the EXACT path from the fix report, not assume workspace root.
- **Stale `data` field** — Dataverse returns 204 even if content didn't actually take effect. Always re-GET after PATCH.

## Phase 5: Look-Back Re-Analysis

### 5a. Re-Run Evaluation

Publish → wait 90s → run eval → poll for completion.

### 5b. Score Delta Analysis

| Pre | Post | Diagnosis | Action |
|-----|------|-----------|--------|
| 50% | 95% | ✓ Fixed | Done |
| 50% | 75% | Partial fix | Continue, remaining failures are different root cause |
| 50% | 48% | Regression | Revert immediately, re-triage |
| 50% | 52% | Wrong root cause | Go to Phase 1, deeper analysis |
| 50% | 50% | No effect | Fix didn't apply or wrong target |

### 5c. Continue or Conclude

- **Score ≥95% on BOTH SR and Conv** → DONE. Save lessons learned.
- **Score <95% but improved** → Loop back to Phase 1 with remaining failures
- **Score flat or regressed** → Revert changes, re-analyze from scratch
- **3 iterations with no improvement** → Plateau reached. Consider test set modification.

### 5d. Save Lessons Learned

After each completed iteration, append to the `copilot-debug` skill's `references/lessons-learned.md`:
```
## [YYYY-MM-DD] Agent: [name] | Eval Fix Loop Iteration N
Root cause: [category] — [specific]
Fix: [what was changed]
Delta: [before%] → [after%] on [metric]
Lesson: [one-sentence reusable]
```

## Hook Integration

### Option 1: Cron-Based Eval Poller (No Webhook Required)

Copilot Studio does not emit webhooks on eval completion. Use a cron job:

```bash
hermes cron create eval-watcher \
  --schedule "every 10m" \
  --prompt "Check if any running evals have completed. Load copilot-studio-post-eval-fix skill. \
    If an eval just completed for PT, OT, SLP, or TDA: \
    1. Load the eval results from the gateway REST API \
    2. Analyze all failures using the Phase 1 pattern \
    3. Report failure breakdown and proposed checklist \
    4. Wait for user approval before executing fixes" \
  --skills "copilot-studio-post-eval-fix,copilot-studio-eval-loop" \
  --deliver origin \
  --enabled-toolsets "web,terminal,file,delegation"
```

### Option 2: Direct Invocation

User says: `/copilotpostevalfix`, "analyze eval failures for PT", "fix the conversational score"

### Option 3: Post-Publish Hook

After publishing an agent, automatically check for recent eval runs and trigger analysis.

## Additional Authoritative Sources

Beyond Microsoft Learn, ground fixes in:

- **Google Vertex AI Agent Builder** — Agent design patterns: single-purpose agents, clear tool boundaries, guardrails
- **Anthropic Agent Design** — Tool-use best practices: explicit tool descriptions, clear success/failure modes
- **FDA Clinical Decision Support (CDS)** — Non-device CDS criteria: transparency, human review, labeled as advisory
- **NIST AI Risk Management Framework** — AI system testing, monitoring, and iterative improvement
- **HIPAA Technical Safeguards** — Access controls, audit controls, integrity controls for PHI-handling agents
- **Microsoft Responsible AI Standard** — Fairness, reliability & safety, privacy & security, inclusiveness, transparency, accountability

## Microsoft Learn Best Practice Summary

1. **Keep topics bite-sized and reusable** — avoid overlapping intents
2. **5-10 varied, short trigger phrases per NLU topic** — cover edge cases
3. **Agent instructions grounded in configured tools/knowledge** — don't claim access to what doesn't exist
4. **Use conditional RESPONSE FORMAT** — structured for audits, natural for general Qs
5. **Every leaf topic: EndDialog + clearTopicQueue: true** — prevent context bleeding
6. **Prefer SearchAndSummarizeContent over AnswerQuestionWithAI** — better knowledge grounding
7. **KB quality before agent config** — most failures are KB gaps, not logic bugs
8. **Test set questions must be answerable** — "check my document" without document access → rewording needed
9. **Run evaluation 3x** — ±5% LLM grader variance, average for stable measurement
10. **Publish + wait 90s before eval** — allow retrieval propagation

## References

- `references/pre-eval-component-audit-checklist.md` — Pre-eval audit checklist: Conv Start state, file-upload gates, SearchSpecificFiles, descriptions, modelDescriptions, additionalInstructions, GPT eval mode, CRLF pitfalls. Run before wasting eval runs.
- `references/data-vs-content-staleness-detection.md` — Detect stale compiled YAML in `content` field vs live `data`.
- `references/feedback-b-topic-structure-audit.md` — Detailed topic structure audit for Therapy Feedback B agent.
- `references/therapy-doc-feedback-case-study.md` — Validated case study: Conv Start blocking, Groundedness=No troubleshooting, CRLF pitfall.

## Sources

- Microsoft Learn: https://learn.microsoft.com/microsoft-copilot-studio/
- Evaluation triage: https://learn.microsoft.com/microsoft-copilot-studio/guidance/evaluation-triage-overview
- Copilot Studio responsible AI: https://learn.microsoft.com/microsoft-copilot-studio/responsible-ai-overview
- Topic authoring best practices: https://learn.microsoft.com/microsoft-copilot-studio/guidance/topic-authoring-best-practices
