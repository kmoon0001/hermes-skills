---
name: eval-playbook
description: Microsoft's canonical 10-step eval playbook for Copilot Studio agents. Use when planning, running, or triaging evaluations. Formalizes all your empirical eval patterns into Microsoft's official methodology.
---

# Eval Playbook — 10-Step Methodology

Source: microsoft/eval-guide (sett 10-step canonical playbook)

## The Three Layers

| Layer | What it is |
|-------|-----------|
| **10-step playbook** | What eval work to do and in what order |
| **Operational stages** — Discover, Plan, Generate, Run, Interpret | UX/workflow for the session |
| **Per-Agent Eval Maturity Model** — 5 pillars × 5 levels | Outcome scorecard |

## The 10 Steps

### Step 1 — Plan the Eval Effort
Before any test case is written:
- **Eval objective** — one sentence: what "good" looks like and what decisions the evals inform
- **Risk tier** — classify using 5 factors: reach, criticality of error, autonomy/blast radius, regulatory exposure, data sensitivity
- **Named owner** — one person accountable for authoring, reviewing, signing off

### Step 2 — Build the Capability Eval Sets
One eval set per capability dimension:
- **Accuracy/correctness**
- **Faithfulness/groundedness** (hallucination = faithfulness failure, caught HERE not in trust & safety)
- **Relevancy**
- **Style & tone**
- **Reasoning & tool use** (multi-step agents)
Isolate one capability per set — never bundle.

### Step 3 — Build the Trust & Safety Eval Sets
Separate from capability. Categories:
- **Guardrails** (refuse harmful/illegal/policy-violating)
- **Out-of-scope handling**
- **Sensitive-data handling** (PII/PHI/confidential)
- **Prompt-injection / jailbreak resilience**
- **Compliance-specific behaviors**
Primarily deployment gates; slim subset as regression.

### Step 4 — Define Gates and Improvement Targets
- Trust & safety → absolute pass-rate hard gates (often near 100%)
- Capability sets → governed primarily by regression and direction
- Capability launch floors needed before first ship
- High-risk capabilities keep explicit hard floors

### Step 5 — Specify Human Inputs
Make explicit: grading rubrics (domain experts), ground truths (authoritative sources), golden answers (SMEs). Log source→ground-truth dependency map — when source changes, ground truth must be reviewed.

### Step 6 — Validate the Grader
Every pass rate inherits the grader's credibility. LLM-as-judge most fragile — check against human-labeled hard and borderline cases.

### Step 7 — Run the Baseline and Iterate on Failures
Record per-set/per-case results with timestamp + agent version. Every failure is exactly ONE of:
- **Eval-setup problem** — response is acceptable; the eval flagged it wrongly
- **Agent-quality problem** — eval correctly caught a real issue

### Step 8 — Regression Suite
Partition: **regression sets** (run on cadence — per change/nightly/weekly) vs **gate-only sets** (milestones — pre-pilot, pre-production)

### Step 9 — Optimization Loop
Production signals → cluster → decide fix location → ship → re-evaluate against regression suite. Prioritize: thumbs-down > escalations > manual overrides > support tickets > qualitative comments.

### Step 10 — Save Reusable Assets
Three tiers: **Required** (org-wide quality gate), **Recommended** (category), **Opt-in** (domain-specific)

## CSV Contract for Copilot Studio
- Exactly 2 columns: `Question`, `Expected response`
- Testing method assigned per row IN Copilot Studio Evaluate tab after import (not in CSV)
- Group by eval set into separate CSV files

## Invariants
- Steps 1-5 work WITHOUT a running agent — description-based mode is default
- Architecture-aware scoping: prompt-level vs RAG vs agentic changes which capability sets apply
- Every eval plan includes at least one adversarial / trust & safety scenario
- Dashboard is the review checkpoint — no artifacts generated until confirmed
