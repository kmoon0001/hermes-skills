---
name: therapy-fleet-agent-audit
description: Full Copilot Studio Therapy AI Agents Dev audit and remediation workflow, adapted from Kiro .kiro/skills/full-agent-audit.md with hard environment guardrails, Microsoft Learn best practices, and sequential one-agent-at-a-time execution.
tags: [copilot-studio, therapy-ai-dev, audit, remediation, microsoft-learn, healthcare]
---

# Therapy Fleet Agent Audit

Reference for focused documentation-assistant audits: `references/theradoc-workbench-focused-documentation-audit.md` captures the TheraDoc Workbench lesson: verify the active agent vs legacy/deprovisioned names, frame PT/OT/SLP documentation assistants as click-button post-session note generators, audit entry points for old free-text/out-of-scope routes, and distinguish pasted-text processing from true OCR wiring.

Use this skill when auditing or remediating Copilot Studio agents in the Therapy AI fleet.

**Environment guard:**
- Therapy AI Agents Dev: `https://orgbd048f00.crm.dynamics.com` — default, use unless told otherwise
- Therapy AI Agents Prod: `https://org532ca94a.crm.dynamics.com` (Env ID: `6951ccc2-3791-ecf4-987f-3dab97bdc716`) — use only when the user explicitly says PROD
- Ensign Default: `https://org3353a370.crm.dynamics.com` (Env ID: `Default-03cc92c3-986c-4cf4-ae27-1478cf99d17f`) — DO NOT touch by default. Only audit/fix/publish on Ensign Default when the user explicitly says "move to Ensign Default", "ensign environment", or equivalent direct instruction. When the user does, proceed with the full audit workflow against this environment; see Ensign Default Registry section below for agent IDs.
- Tenant: `03cc92c3-986c-4cf4-ae27-1478cf99d17f` (shared across all three environments)
- If an existing Kiro/script helper points at `org3353a370`, do not run it as-is. Copy/adapt the logic to a temporary Therapy-only script or local-source audit.

## Required Companion Skills

Load these before running the workflow:
- `clinical-swarm-guardrails`
- `clinical-swarm-deployment`
- `copilot-studio-pipeline`
- `copilot-studio-validate`
- `copilot-studio-manage-agent`

## Microsoft Learn Grounding

Before authoring or changing audit rules, check Microsoft Learn for the current best-practice language. Minimum pages:
- Copilot Studio implementation overview
- Topic authoring best practices
- Trigger phrase best practices
- Agent instructions
- Responsible AI / Copilot Studio service card where clinical, legal, or high-impact actions are in scope

Audit rules based on current Learn guidance:
- Keep topics bite-sized and reusable; avoid overlapping intents.
- Use 5-10 varied, short, complete trigger phrases per NLU-triggered custom topic.
- Create disambiguation/slot-filling when topics overlap rather than allowing ambiguous routing.
- Agent instructions must be grounded in configured tools, knowledge sources, topics, agents, and variables; do not instruct the agent to use resources it does not have.
- Do not modify or suppress Microsoft citation behavior in instructions.
- In sensitive domains, define clear action boundaries, use approvals/HITL for consequential actions, ground outputs in trusted data, apply RBAC, test thoroughly, monitor, and iterate.

## Severity Classification

Every finding in an audit report MUST be tagged P0 or P1 using these definitions:

**P0 — Critical / Must Fix:** Breaks the agent's core function, blocks publish, causes data loss, or creates measurable runtime failures (no EndDialog causing context bleeding, missing clearTopicQueue causing dialog stack pollution, placeholder flow IDs that crash on invocation, malformed YAML that blocks schema validation, missing EndDialog on the main execution path of an NLU-triggered topic).

**P1 — Important / Should Fix:** Degrades quality, limits evaluation scores, introduces inconsistency, creates maintenance debt, or blocks SR evaluation (multi-Question flows that fail SR eval, useModelKnowledge: false on the sub-agent handling user interaction, empty topics referenced by BeginDialog, overly broad trigger phrases, duplicated/misnamed action files, cosmetic config inconsistencies like mismatched contentModeration between root and sub-agent, ConditionGroup+Question in elseActions, CancelAllDialogs used where EndDialog+clearTopicQueue would suffice).

At the top of every audit report, emit a summary table:
```
| Severity | Count |
|----------|-------|
| **P0** | **N** |
| **P1** | **N** |
```

## Workflow: Parallel Fleet Sweep — Worst-First Prioritized Queue (added 2026-07-03)

For multi-agent fleet sweeps spanning 5+ agents, use this parallelized approach:

1. **Parallel analysis** — Deploy N subagents in parallel (up to 3 per batch), each analyzing 2-4 agents. Each reads all topic YAMLs, agent config, and counts P0/P1 issues.
2. **Priority queue construction** — After all analyses complete, rank agents by P0 count descending (worst first). Write the queue to a file as the single source of sequencing truth.
3. **Sequential Fix + QA from queue** — Fix agents and QA agents pull from the top of the queue. Multiple fix agents can run in parallel on different agents since fixes are per-workspace.
4. **Systemic bulk fix for high-P0 agents** — When an agent has 20+ same-root-cause P0 issues (e.g., missing EndDialog on every topic), do NOT fix them one at a time. Use systemic patterns: EndDialog batch (add to all custom topics in one pass), boilerplate batch (strip template comments from all files), SearchSpecificFiles batch, instruction batch (edit agent.mcs.yml once).
5. **4-phase loop** — The complete per-agent loop is: Analysis → Fix → QA → Eval. Previously the loop stopped at QA. Eval (Phase 3) runs draft evals via PPAPI, polls results, reads scores from SPA if detail endpoint is broken, and loops back to analysis if scores are below 95%.
6. **QA must independently verify** — Never trust fix agent self-reports. Read actual files, count .bak files, run js-yaml validation, spot-check against fix claims. Fix agents sometimes inflate counts or report files as "already clean" that still have issues.

Proven Jul 3 2026: 16 Therapy AI Dev agents analyzed in ~5 min parallel, 12 fixed and QA'd in ~20 min.

## CRITICAL PITFALL: Unconditional EVAL Instruction Blocks Kill Conv Scores (added 2026-07-03)

When the standard instruction fix pattern (EVAL NO-CAVEAT + EVALUATION-SAFE ORCHESTRATION) was applied to ALL 12 agents fleet-wide, PCCH's Conv score dropped from 65% to 42% (-23pp). SR improved only marginally (83% to 89%).

Root cause: Unconditional "respond directly, don't ask follow-up questions" instructions apply to ALL interactions — including normal conversational flows where multi-turn behavior is expected. The grader assigns lower completeness when the agent truncates multi-turn exchanges. This is NOT aligned with MS Learn guidance.

MS Learn-aligned fix: Use CONDITIONAL behavior tied to input context. Replace:
```
## EVALUATION-SAFE ORCHESTRATION
- Respond directly to all questions without asking for additional information first.
```
With:
```
## Handling Evaluation-Style Prompts
When the user's message contains an evaluation-style prompt without specific clinical data:
  - Provide a standards-based compliance framework
  - Label assumptions as "To verify with actual documentation"
When the user provides detailed clinical data:
  - Follow the normal multi-turn workflow
  - Ask clarifying questions as needed
```

Key rules:
- Use "When the user's message contains..." framing, NOT "Always..."
- Do not use all-caps section headers like "EVAL NO-CAVEAT" — they trigger unconditional activation
- Never put unconditional behavioral directives at the instruction level — prefer topic-level additionalInstructions
- **Instructions fixes don't fix topic-level problems.** When the greeting/Conversation Starters gate the conversation with a question, instructions changes confuse the model further. Fix the topic, not the instructions. Proven: 15% → 5% regression on Therapy Doc Feedback agent (Jul 4 2026). See `references/therapy-doc-feedback-instruction-regression.md`.
- After changing instructions, always re-run BOTH SR and Conv evals and compare deltas — if Conv drops, the change is too broad

## Workflow: One Agent at a Time

For each Therapy AI Dev agent, complete all steps before starting the next agent.

1. Context pass
   - Read `agent.mcs.yml`, topics, actions, knowledge, and any local README/spec files for that agent.
   - Identify the agent's role in the swarm: hub/orchestrator, dashboard, specialist, compliance, regulatory, meeting support, or synthesis.
   - **Purpose alignment (CRITICAL — do this BEFORE topic-level analysis):** Ask the user (or infer from AGENT.md/agent.mcs.yml description) what the agent's CORE FUNCTION is. Write a one-sentence purpose statement. Then classify every topic as ALIGNED (matches core function), PARTIALLY ALIGNED (could help but needs trimming), MISALIGNED (contradicts the function or is out of scope), or ORPHAN (never reached). Present this classification to the user for confirmation BEFORE deep-diving into individual topic YAML. Getting this wrong wastes the entire audit — Kevin corrected this on TheraDoc (Jun 30 2026) when the audit initially treated a focused post-session documentation assistant as a general-purpose workbench.
   - Confirm expected bot ID against the Therapy AI Dev registry before any live call.
   - **PITFALL: Cross-reference AGENT.md bot IDs against the registry.** The workspace's `AGENT.md` may list a different live bot ID than the task-provided ID or the skill's registry. SNF Command Center V2's user-provided ID is `9f3e370c-a747-f111-bec6-0022480b6bd9` but AGENT.md records the live Therapy Dev bot as `8c9b244f-073a-f111-88b3-000d3a5b95c6` — the bot may have been recreated or migrated between environments. When they differ, surface both to the user as candidates and note which ID the local workspace files actually reference in schema declarations.

2. Discovery
   - **PITFALL: `dump_agent_full.cjs` returns 0 components for Therapy Dev agents.** The script uses auth scoped to Ensign Default (`org3353a370`), not Therapy Dev (`orgbd048f00`). Against Therapy Dev it always returns `topicCount: 0, knowledgeCount: 0` even when the agent is live and published. **Prefer local source audit first** (read topic YAMLs, agent.mcs.yml, connectionreferences.mcs.yml directly from the workspace). Fall back to direct Dataverse API queries (`orgbd048f00.crm.dynamics.com/api/data/v9.2`) for live state instead of relying on the dump script.
- **PITFALL: Never trust subagent self-reports.** A subagent that says \"uploaded successfully\" or \"file written\" may be wrong. QA subagent MUST read actual file content and compare against .bak originals to verify. This was reinforced multiple times in the Therapy AI Dev fleet sweep (Jul 3 2026):
  * **Regulatory Hub V2 QA** — reported OnError.mcs.yml had unremoved boilerplate, but the actual file at the correct path (build_atomic_v3/) was already clean. The QA subagent was checking the wrong root path. **Fix: QA must use the EXACT path from the fix report, not assume the workspace root.**
  * **SNF Dashboard fix agent claimed** 46 files with boilerplate removed — but actually missed 2 (FacilityContextSwitcher and RegulatoryComplianceTracking). QA caught this by spot-checking against the .bak list and counting actual removals. **Fix: QA should independently count .bak files and spot-check against fix report claims. Fix agents sometimes inflate counts — never trust them at face value.**
- **PITFALL: Fix-report documentation inflation.** During the fleet sweep, at least one fix agent claimed 58 .bak files when only 28 were actually created. QA detected this by counting actual .bak files in the workspace. When verifying fixes: count the actual .bak files, don't just trust the report number. If the report claims more than exists, investigate the gap — those missing files may have unapplied fixes.
   - Prefer local source audit first.
   - **Workspace classification first (added 2026-07-03):** Before reading any YAML, classify the workspace as cloned agent, solution archive, or stub/empty. See `references/workspace-investigation-patterns.md`. This prevents false reporting of "0 topics" when the workspace is a solution archive, and prevents attempted push to a disconnected workspace.
   - **Dual-agent workspace detection (added 2026-07-03 — Therapy Report Prep V2):** Scan the workspace recursively for multiple `agent.mcs.yml` files. A main agent with a sub-agent in a nested directory is a dual-agent workspace (e.g. `src/Topics/` for the main agent and `SNF Rehab Agent/` with its own `agent.mcs.yml` and `topics/`). When found, audit both agents separately. Flag if the root `agent.mcs.yml` is empty (0 bytes) while the sub-agent has the actual instructions — this is a workspace configuration defect.
   - **Empty topic file detection (added 2026-07-03):** Check for 0-byte `.mcs.yml` files in the topics directory. These may indicate failed exports, placeholders, or topics deleted but left as stubs. Flag as P0 when referenced by BeginDialog from another topic (creates dead-end routing), otherwise flag as P1.
   - **Check for workspace disconnect signals:** Look for `DO-NOT-APPLY-CHANGES.md` or `conn.json.DISABLED-*` files. If present, the workspace is read-only — use live audit data as source of truth.
   - If live state is needed, query only `https://orgbd048f00.crm.dynamics.com/api/data/v9.2` with `_parentbotid_value eq '<botId>'`.
   - Categorize components: 9 topics/connections, 14 file knowledge, 15 GPT metadata, 16 web/SharePoint knowledge, 19 evaluation data AND trigger phrases. **PITFALL: Do NOT assume all type 19 = trigger phrases.** Type 19 botcomponents with `kind: EvaluationData` or `kind: MultiTurnEvaluationCase` are evaluation test cases — count them separately from actual trigger phrases which are embedded in topic YAML's `triggerQueries:` block. Query a sample of the type 19 `data` field to distinguish. Proven Jul 4 2026: Ensign Default audit initially reported ~5,000 "trigger phrases" per agent — corrected after sampling revealed they were evaluation cases.

3. Audit dimensions
   - Overview: name, description, role clarity, icon metadata if available.
   - Instructions: size, duplicate section headers, corruption, contradictory JSON/prose mandates, unsupported citation manipulation, missing healthcare guardrails.
   - Knowledge: source names/descriptions, duplicate/redundant sources, web browsing fit, configured resources matching instructions.
   - Tools/actions/flows: orphan references, missing flow IDs, **placeholder flow IDs (GUIDs like `11111111-2222-3333-4444-555555555555` or `66666666-7777-8888-9999-000000000000` — these are template placeholders that will crash at runtime — flag as P0)**, **stale action naming (action `.mcs.yml` files in one agent's workspace that hardcode a different agent's name, e.g. `"TheraDoc"` hardcoded in a Clinical Synthesis Lab action — flag as P1)**, action descriptions, safe boundaries, HITL for consequential clinical output.
   - Topics: YAML validity, system-topic skip, trigger phrase count/quality/overlap, EndDialog/clearTopicQueue, SearchAndSummarize settings, unsupported SearchSpecificFiles/SearchAllKnowledgeSources, oversized additionalInstructions, orphan Question nodes, **trailing questions in SendActivity text** (see `references/trailing-question-pattern.md`).
   - **Structured-Intake-Only anti-pattern (added 2026-07-04 — SNF AI Dashboard audit):** Detect agents whose topics form an identity pattern of `Question → Question → ... → SendActivity(placeholder AdaptiveCard with "Automated Handoff Mode" text) → [no EndDialog]` — with no SearchAndSummarizeContent, no InvokeFlowAction, and no EndDialog. This is a "design-phase shell": topics exist as UI mockups that collect structured intake but produce only placeholder output telling the user to do the work manually. Indicators:
     * Every topic ends with a SendActivity saying "stays in structured intake mode until a validated live backend is connected"
     * connectionreferences.mcs.yml is empty (no flows are live-wired)
     * Zero SearchAndSummarizeContent nodes across the entire agent
     * All topic descriptions use identical boilerplate like "Elite clinical intelligence module specialized in [TopicName]"
     * modelDescriptions reference a different agent's name (e.g. "SNF Command Center" on a Dashboard agent)
   - Flag these as **P0 (no EndDialog = context bleeding) and P1 (placeholder output = eval fails, no actual functionality)**. The entire topic architecture needs rework before the agent can pass evaluations.
   - **Routing integrity (added Jun 30 2026):** Trace every BeginDialog reference to confirm the target topic exists. Flag duplicate routers (two topics routing to the same discipline/note-type matrix with different targets). Flag Card topics that collect data via AdaptiveCard but have no SearchAndSummarizeContent, no flow invocation, and no EndDialog — these are data sinks that produce no output.
   - **Connected agent routing utilization (added 2026-07-03 — PCCH V2 audit):** Cross-reference the agent's connected agent declarations (from settings/manifest) against actual `InvokeConnectedAgentTaskAction` blocks in all topic YAML files. Flag connected agents that are declared but never invoked. Found on PCCH V2: 4 connected agents declared (SNF Command Center, SNF AI Dashboard, TheraDoc Workbench, QM Coach V2) with 0 InvokeConnectedAgent calls across all topics. This is report-only — some agents use platform-level orchestration rather than topic-level InvokeConnectedAgent — but the gap should be surfaced so the user can decide if routing is intentionally unwired.
   - **Orphan topic detection (added Jun 30 2026):** For each custom topic, check if it is reachable via (a) trigger phrases (NLU), (b) BeginDialog from another topic, or (c) the router's routing matrix. Topics unreachable by any path are orphans — verify whether they're dead code or should be wired in.
   - **Card-vs-Intake gap (added Jun 30 2026):** When a discipline has both a `*Card` topic (AdaptiveCard data collection) and an `*Intake` topic (Question nodes + SearchAndSummarizeContent), verify the Card topic actually generates output. Pattern: Card topics often collect rich data but lack note generation; Intake topics collect minimal data but generate notes. Route to the one that works.
   - **Duplicate topic representations (pitfall — Clinical Synthesis Lab V2, 2026-07-03):** Some agents have TWO or THREE parallel topic representations for the same logical topic: (1) NLU-triggered authored `.mcs.yml` with trigger phrases and multi-Question workflows, (2) sub-dialog `.topic.yaml` or compiled `SNFRehabSolution/` exports called via `BeginDialog` from a router. These representations often diverge — the authored version may lack EndDialog while the compiled version has it, or the authored version may have a multi-step Question flow while the compiled version uses a simple `InvokePromptAction`. **The NLU-triggered `.mcs.yml` is the authority for agent behavior.** Compiled/solution exports (content.yaml) are secondary and reflect a previous publish state. Always audit both but report based on the NLU-triggered versions.
   - **Topic inventory table format:** After analyzing all topics, emit a structured table in the report:
     ```
     | Topic | Trigger Phrases | EndDialog | clearTopicQueue | Question Nodes | Notes |
     |-------|----------------|-----------|-----------------|----------------|-------|
     ```
     Include system topics flagged as (system), mark EndDialog presence, and note Question counts. This table is the single source of truth for the topic-level state.
   - **Remediation diff format:** Include a compact diff block showing exact before/after for the most impactful fixes (EndDialog, clearTopicQueue, CancelAllDialogs replacement, config changes). Use standard unified diff markers (`+`, `-`).
   - **Hollow topic detection (added 2026-07-03 — POSTette audit):** Topics that match via trigger phrases but produce zero useful output — typically a single `SendActivity` saying "As an AI language model, I cannot provide medical/legal advice" followed by no content, no search, and no EndDialog. These topics consume trigger phrase real estate, intercept user queries, and guarantee eval failure when triggered. Flag as P0. Found on POSTette: 5 topics (P4/P5/P6 across two agent sub-configs).
   - **Duplicate condition detection:** Flag ConditionGroups with empty actions (conditions that check values but do nothing). Flag duplicate conditions (same condition appearing twice in one group).
   - Settings: moderation, authentication/access assumptions, web/code interpreter settings where represented in source.
   - Evaluation readiness: test set coverage, single-response and conversational scenarios, no missing-document eval design errors.

4. Fix priority
   - Security/compliance/HIPAA defects.
   - Environment and settings misalignment.
   - Broken topic/action YAML that blocks validation or publish.
   - Routing/trigger overlap and topic proliferation.
   - Knowledge configuration defects.
   - Instruction compression/corruption cleanup last.

5. Safe local fixes

   **PITFALL: Find the actual working YAML path before fixing.** The workspace root may not contain the agent's live topic files. Some agents have their working YAML at a nested path (e.g., `build_atomic_v3/Chatbots/<schema>/` instead of the workspace root). Always resolve by looking for `agent.mcs.yml` files recursively before attempting fixes. Documented at `references/workspace-investigation-patterns.md`.

   **PITFALL: Never test Dataverse PATCH format on a real component ID.** Use a fake/nonexistent GUID for format tests. Accidentally using a real botcomponent ID with a test payload (`{"value":"test"}`) overwrites the live topic's `data` field with garbage. This happened on Ensign Default Jul 4 2026: PT_Specialist's "Analyze PT Daily Note" was corrupted to 4 chars. Recovered from an earlier API dump. Pattern: always GET+backup before any PATCH attempt, or test against `00000000-0000-0000-0000-000000000000` which will 404 harmlessly.

   **PITFALL: Dataverse PATCH payload uses `{"value": "..."}` not `{"data": "..."}`.** Single-property PATCH to `botcomponents({id})/data` wraps the new content in a `value` key: `{"value": "<yaml_string>"}`. Using `{"data": "<yaml_string>"}` returns 400: "A top-level property with name 'data' was found; property payloads must have a top-level property with name 'value'." HTTP 204 = success. Always verify by re-querying and checking the field.

   **PITFALL: `az rest` is the reliable Dataverse auth path.** Bare `az account get-access-token` tokens lack Dynamics 365 claims and return 401 with `insufficient_claims` / `xms_rp_ipaddr` on Dataverse. `az rest` handles claims challenges internally. Pattern: `az rest --method GET --resource "https://<org>.crm.dynamics.com/" --url "<full_url>"`. For large responses, pipe stdout to file (stderr warnings are cosmetic). **Also: the resource URL requires a trailing slash** — without it, all calls return 401. Verify with a WhoAmI probe first.

   **Systemic bulk EndDialog add pattern (proven Jul 3 2026 across 12 agents):** The #1 fleet-wide P0 is missing EndDialog with clearTopicQueue:true. Fix it systemically in one batch per agent:
   - List all custom topic YAMLs
   - For each, check if `EndDialog` and `clearTopicQueue: true` exist
   - If both missing: append `kind: EndDialog` with `clearTopicQueue: true` after the last action in `beginDialog.actions`
   - If EndDialog exists but lacks clearTopicQueue: add `clearTopicQueue: true` to the existing node
   - Create `.bak` backup of every modified file
   - Validate all YAML with `js-yaml` after each batch
   - This fix resolved 200+ topics across the Therapy AI Dev fleet in one sweep

   **Standard instruction fix pattern (proven across all 12 Therapy AI Dev agents):**
   Every agent needs these 3 instruction block additions to pass evals:
   1. **EVAL NO-CAVEAT STANDARDS CHECK** — 3-4 rules telling the model to produce substantive answers even when the user provides no document text. Do not refuse or ask "please provide the note first." Answer with domain knowledge and label assumptions.
   2. **EVALUATION-SAFE ORCHESTRATION** — 5 rules: respond directly without asking for more info, use `=System.Activity.Text` for search, end with complete answers (no truncation), no follow-up questions during eval, maintain topic boundaries.
   3. **Remove unconditional RESPONSE FORMAT restrictions** — If instructions say "Do not use markdown/emoji" unconditionally, soften to conditional guidance. Unconditional format bans cause 5-10% conversational score drops.

   - Strip BOM and CR corruption only on custom, customizable components; do not patch system topics or inactive/deprovisioned managed agents for cosmetic line-ending cleanup.
   - Remove contradictory instruction text when the intended format is clear from the agent role.
   - Add or normalize `clearTopicQueue: true` on custom-topic `EndDialog` nodes.
   - Remove invalid `SearchAllKnowledgeSources` / `SearchSpecificFiles` patterns when local schema/tests confirm they are unsupported.
   - Keep system topics untouched unless only reading them. System-topic CR/BOM differences are report-only unless they block validation and the user explicitly approves UI repair.

6. Live fixes
   - Back up exact live records first.
   - Treat Copilot Studio UI as source of truth and prefer UI/CDP evidence before and after any live draft repair.
   - Do not assume `content` and `data` have identical server-side semantics. Inspect the live component, normalize local exported topic files to the `kind: AdaptiveDialog` body, and use the supported authenticated path for the current session. See `references/copilot-studio-live-yaml-repair.md` for the Playwright/CDP + Dataverse-origin decision ladder.
   - `content` field PATCH is blocked by a server-side validator for topics with complex YAML (e.g., `InvokeFlowAction`, adaptive expressions, multi-line actions). When the live UI editor shows changed content but the scanner still flags `content` as broken because it reads the old/cached `content`, the fix is to PATCH `data` with the corrected body from the UI-visible source, then update the QA scanner to prefer `data` over `content` for topic parse checks. See `references/copilot-studio-live-yaml-repair.md` section "`data`-field-only repair pattern (Jun 30, 2026)".
   - Do not publish without explicit user approval. Publishing affects shared users.

7. Verification
   - Run local schema/lint/test validation after edits.
   - For `pipeline/scripts/schema-lookup.bundle.js validate`, validate dialog-like source only (`agent.mcs.yml`, `actions/*.mcs.yml`, `topics/*.mcs.yml`) and exclude `settings.mcs.yml`, `connectionreferences.mcs.yml`, knowledge files, scratch/export/log folders; otherwise the validator reports false `No kind property` failures on non-dialog components.
   - If `InvokeAction` appears in topic action lists and schema validation fails, convert to `InvokeFlowAction` only after confirming the node carries an `action:` reference and re-validating that file.
   - When helper/repair scripts are changed and no canonical suite exists, use the ad-hoc tempfile verifier pattern from `copilot-studio-validate` (`references/ad-hoc-verification-after-repair-scripts.md`): syntax-check scripts, run dry-runs without `--apply`, verify Therapy-only scope guards, validate active dialog-like files, clean up the temp verifier, and report as ad-hoc verification rather than suite green. If a fresh verification reminder appears after a prior verifier, rerun a new temp verifier; do not cite stale evidence.
   - For live Dataverse repair scripts, include safety checks for: explicit Therapy AI Dev URL, explicit Ensign Default block guard, no Ensign Default HTTPS target literal, `--apply` required for writes, null/missing component-name-safe filename handling, and a material-change filter that avoids live PATCHes for cosmetic CR/BOM-only normalization.
   - After live `--apply`, immediately rerun the script without `--apply` and require `PATCHED=0`, `PATCH_ERROR=0`, and no remaining `WOULD_PATCH` lines before reporting the safe auto-fix pass complete. Remaining `UNFIXED` lines should be called out as deeper targeted repairs, not hidden as green.
   - When Kevin says the live UI is the source of truth, do not stop at Dataverse/API evidence. Verify both the live Dataverse backing records and at least one representative Copilot Studio UI page/screenshot under Therapy AI Dev. Use `references/live-ui-source-of-truth-verification.md`.
   - For broad fleet QA/checklist/autonomous-loop requests, use `references/3-agent-debug-loop.md` (per-agent subagent loop), `references/fleet-wide-prioritized-queue.md` (parallel analysis + priority queue with systemic fix batch pattern for high-P0 agents), `references/cdp-spa-eval-extraction.md` (extracting eval scores from Copilot Studio UI via CDP when PPAPI detail endpoint returns RouteNotFound), or `references/autonomous-qa-loop-checklist.md` (fleet-wide scanner): create a read-only Therapy-only scanner/checklist first, seed the backlog from live records plus known remaining blockers, require visual UI tab evidence for every agent, then iterate repairs and draft evaluations until each agent exceeds 95% on Single Response and Conversational testing.
   - For local-source-only remediation batches before live/UI repair, use `references/local-safe-repair-batches.md`: prioritize safe `agent.mcs.yml` metadata fixes such as conversation starters, orchestration/routing language, and healthcare/HITL/disclaimer guardrails; validate each file, rerun the read-only scanner, and report pre/post backlog counts without implying live or published behavior changed.
   - Distinguish local source, live draft/source UI, and published-agent behavior. Do not imply published users see a change unless publish was explicitly approved and run.
   - If `manage-agent validate` has `.mcs/conn.json`, run it against Therapy env only.
   - Record fixed issues, remaining manual/UI-only fixes, live UI/source verification evidence, and validation output in a timestamped report.

## Therapy AI Dev Registry

Environment: `https://orgbd048f00.crm.dynamics.com`
Tenant: `03cc92c3-986c-4cf4-ae27-1478cf99d17f`

Core swarm agents (verified live via `pac copilot list` Jun 30 2026):
- SNF Command Center V2 — `9f3e370c-a747-f111-bec6-0022480b6bd9` — Orchestrator Hub
- SNF AI Dashboard V2 — `bd570423-cf47-f111-bec5-70a8a5b1c3a3` — Data Visualization
- TheraDoc Workbench — `e09954e1-4af8-47c6-8ef4-d1d9335bf2e6` — Post-session PT/OT/SLP documentation assistant (click buttons to capture session data with minimal typing, AI generates polished clinical note). Local workspace: `D:/my agents copilot studio/TheraDoc/`
- Pacific Coast Case Historian — `ad635500-cf47-f111-bec5-70a8a5b1c3a3` — Longitudinal Analysis
- Pacific Coast QM Coach V2 — `ea52ad9c-8233-f111-88b3-6045bd09a824` — Quality Measures
  (live name differs from registry: "Pacific Coast QM Coach V2" not "SimpleLTC QM Coach V2")
- Pacific Coast Denial Defense V2 — `6d7815b4-ce47-f111-bec5-70a8a5b1c3a3` — Denial Management
- Therapy Report Prep V2 — `fd1bce12-cf47-f111-bec5-70a8a5b1c3a3` — Report Generation
- Pacific Coast Compliance Analyzer — `19779839-7b6e-4362-925b-8ddf03979f7d` — Compliance Audit
- Pacific-Coast Regulatory Hub V2 — `ea901efc-d043-4023-88a6-8ac4c561a4d5` — Regulatory Reference
- PacCoast Daily + Weekly Medicare Meeting — `ee72fe1a-0882-4dec-9959-ace1fbb74280` — Meeting Support
- Pacific-Coast Clinical Synthesis Lab V2 — `89c7415d-df73-490c-9d78-4829cfbc2f84` — Clinical Synthesis
- POSTette_Compliance_Agent — `03b08692-aa24-4159-986b-cfad8fed6865` — Compliance (NEW, not in original registry)
- CoE Autonomous Agent Builder — `8f33b0e3-5b2e-f111-88b3-00224806baad` — Utility (NEW)
- Meta-Agent Builder — `4e00c251-3941-f111-88b3-70a8a59a9512` — Utility (NEW)
- Copy Therapy Docuementation Feedback Ag — `b0346795-4876-f111-ab0e-70a8a5b1b8cc` — Therapy Documentation Feedback (copy, NEW — discovered Jul 4 2026)

Note: PT_Specialist, OT_Specialist, SLP_Specialist bot IDs from the original clinical guardrails
are NOT visible via `pac copilot list` — they may be managed/imported agents or have been
deprovisioned. Verify before making live API calls against those IDs.

## Ensign Default Registry (audit only when user explicitly directs)

Environment: `https://org3353a370.crm.dynamics.com`
Env ID: `Default-03cc92c3-986c-4cf4-ae27-1478cf99d17f`
Gateway: `https://powervamg.us-il106.gateway.prod.island.powerapps.com`
Tenant: `03cc92c3-986c-4cf4-ae27-1478cf99d17f`

**PITFALL: No local workspaces exist for Ensign Default agents.** All audits on this environment are live-Dataverse-only. Use `az account get-access-token --resource "https://org3353a370.crm.dynamics.com"` for auth, then query `botcomponents` via the Dataverse REST API. Do not attempt `manage-agent.bundle.js push/pull/clone` — there are no `.mcs/conn.json` workspaces for these agents.

**PITFALL: `az account get-access-token` trailing-slash requirement.** Auth succeeds ONLY when the resource URL has a trailing slash: `"https://org3353a370.crm.dynamics.com/"`. Without the trailing slash, the token returns HTTP 401 on every Dataverse API call. Always verify with a `WhoAmI` probe (`GET /api/data/v9.2/WhoAmI`) before running the full audit. Proven Jul 4 2026: `--resource "https://org3353a370.crm.dynamics.com/"` → 200; `--resource "https://org3353a370.crm.dynamics.com"` → 401. This affects ALL Dataverse API calls including botcomponents queries. When audit scripts return empty JSON with `Expecting value: line 1 column 1`, suspect this auth issue first.

Agents (verified live via `pac copilot list` Jul 4 2026, all Published/Active):

| Agent | Bot ID | Instructions ID | Role |
|-------|--------|----------------|------|
| PT_Specialist | `593407f3-539b-490f-84ac-d74e13216c81` | `a6575469-8269-41ae-9e6e-dabd14e8ca63` | PT Documentation Audit |
| OT_Specialist | `73b45e98-af7a-443a-aa12-6d8a05118530` | `28c4402c-2a2b-45d7-888d-e3ef81b2f401` | OT Documentation Audit |
| SLP_Specialist | `6e437a77-a5dc-4984-90eb-4924eab10006` | `9a5e1289-baf3-44be-bb76-ce9d410c91dc` | SLP Documentation Audit |
| Therapy Documentation Audit Agent | `4d0ed0d3-30f6-f011-8406-000d3a37eba2` | `ff00b80a-321b-44be-80a4-40c78072ffe3` | Documentation Audit |
| Therapy Documentation Feedback B | `1c601ace-5255-f111-bec6-000d3a37eba2` | `e6788338-cd4d-4dc2-aa8a-df00642def46` | Therapy Documentation Feedback |
| Therapy_Report_Prep_Assistant | `c030a53a-4839-f111-88b4-000d3a37eba2` | (query via Dataverse) | Report Preparation |

Discovery for Ensign Default:
- Use `pac copilot list --environment "https://org3353a370.crm.dynamics.com"` to list all agents
- Use `manage-agent.bundle.js list-agents --environment-url "https://org3353a370.crm.dynamics.com"` for user-owned agents only
- Query Dataverse directly: `GET /api/data/v9.2/botcomponents?$filter=_parentbotid_value eq '<botId>'` for component inventory
- Use `az account get-access-token --resource "https://org3353a370.crm.dynamics.com"` for bearer tokens (valid ~1 hour, reuse across all calls in a script)
- `pac auth select` is NOT needed — use `--environment` flag directly: `pac copilot publish --bot <id> --environment "https://org3353a370.crm.dynamics.com"`

Audit workflow on Ensign Default:
- Follow the same audit dimensions, severity classification, and fix priority as Therapy AI Dev
- Prefer Dataverse API for all component reads (no local workspace to fall back on)
- For live fixes, PATCH `botcomponent.data` via Dataverse API; `content` field is NOT patchable — use Copilot Studio UI code editor for content fixes
- Publish via `pac copilot publish --bot <id> --environment "https://org3353a370.crm.dynamics.com"`
- Same parallel fleet sweep pattern applies: 3 subagents × 2 agents each for analysis, then priority queue for sequential fix/QA

## New-Experience Agent Recognition (added Jul 4 2026)

Copilot Studio now has two agent experiences: **classic** (botcomponents-queryable via Dataverse) and **new** (UI-driven only).

**How to recognize a new-experience agent:**
- Overview shows "Details" section with Name, Description, Model selector inline
- Topics appear as hyperlinked cards on Overview (not a separate grid)
- Botcomponent type 14/15/16 queries return incomplete/zero results
- Knowledge sources listed with "Ready" status badges
- Model shown as ComboBox (e.g. "Claude Sonnet 4.6")
- URL uses environment GUID: `.../environments/<guid>/bots/<botId>/...`

**Audit implications:**
- Cannot query botcomponents via Dataverse API — must read from Copilot Studio SPA
- Eval scores visible via Evaluation tab + SPA body text
- Fixes must be applied in the UI (instruction editing, topic config, knowledge management)
- cua-driver can drive the SPA but tab clicks may redirect unexpectedly

**Question-First Anti-Pattern (new-experience, Jul 4 2026):** Agents opening with "What type of document would you like reviewed?" + suggested-action buttons guarantee conversational eval failure (<20%) because the grader expects direct answers, not gate questions. All test cases route through this greeting, getting 6-turn conversations failing on completeness. **Discharge-related questions are the only ones that pass** — the agent's knowledge sources may have stronger discharge content or discharge questions may route differently. Fix: **Remove the greeting gate question from the TOPICS / Conversation Starters — NOT the instructions.** 

**PITFALL — Instructions fix for Question-First causes regression (Jul 4 2026):** Do NOT add "evaluation-safe" or "direct-response" blocks to the instructions to fix a topic-level Question-First pattern. The model already has good domain knowledge (proven by the few passing cases). Adding instruction-level directives confuses the routing between greeting topics and instruction guidance, producing LOWER scores (proven: 15% → 5% on Copy Therapy Docuementation Feedback Ag). The fix must be at the TOPIC layer: remove the gate question from Conversation Starters / Greeting topic, let the model answer directly. See `references/therapy-doc-feedback-instruction-regression.md`.

**Example:** Copy Therapy Docuementation Feedback Ag (`b0346795-4876-f111-ab0e-70a8a5b1b8cc`) in Therapy AI Dev — new-experience. SR=68%, Conv=15%.

## Scope Cleanup Workflow (added Jun 30 2026)

When an agent has topics misaligned with its core purpose:

1. **Classify every topic** as ALIGNED / PARTIALLY ALIGNED / MISALIGNED / ORPHAN during the purpose alignment step.
2. **Create a removal manifest** (`REMOVAL_MANIFEST.txt`) listing topics to disable or remove, grouped by reason (out-of-scope, replaced by Cards, shared topics replaced by discipline-specific ones).
3. **Prefer DISABLE over DELETE.** Deactivating a topic via Copilot Studio UI (topic toggle) or Dataverse API PATCH (`statecode: 1, statuscode: 2`) is safer than full deletion — it preserves topic GUIDs, prevents cascading reference breaks in remaining topics (BeginDialog calls, ClosedListEntity menu options, ConditionGroup routing), and avoids publish crashes. Only delete when the user explicitly says to. If a topic was accidentally deleted, its GUID is unrecoverable and all remaining topics referencing it must be manually fixed.
4. **Do NOT delete topic YAML files locally** — the manifest is a guide for live agent cleanup via Copilot Studio UI or Dataverse API. Local files stay until the user explicitly removes them.
5. **Create replacement topics** (Card-based) before marking Intake topics for removal, so the routing matrix has valid targets.
6. **Update the router** to point to new Card topics and remove out-of-scope utility actions.

Example: TheraDoc had 56 custom topics. After scope cleanup: 27 kept (10 core + 17 Cards), 35 marked for removal, 13 system unchanged.

## References

- `references/workspace-investigation-patterns.md` — Classify a local workspace (cloned agent vs solution archive), detect disconnect signals (DO-NOT-APPLY-CHANGES, conn.json.DISABLED), schema-name mismatches, and utility agent pattern.
- `references/2026-07-03-full-fleet-sweep-results.md` — Complete results of the Jul 3 2026 full fleet sweep: P0 deltas per agent, fleet-wide patterns confirmed, pitfalls discovered. Load for cross-agent pattern reference and benchmark data (200+ EndDialogs fixed, 60+ boilerplate blocks cleaned, 12 agents processed).
- `references/solution-export-yaml-extraction.md` — Extract and audit YAML from Power Platform solution export `data` files. Finding topic YAML, GPT instructions, and multi-agent sub-configurations in solution_unpacked/botcomponents/.
- `references/fleet-wide-prioritized-queue.md` — Fleet-wide expansion of the 3-agent loop: analyze ALL agents in parallel first, construct a prioritized queue ordered by P0 count (most critical first), then fix and QA agents work through the queue sequentially. Includes systemic fix batch pattern for high-P0 agents (20+ same-root-cause issues) and specific fix patterns found across Therapy AI Dev (empty ConditionGroups, hardcoded discipline variables, ST vs SLP naming, old template comments, instruction contradictions).
- `references/live-dataverse-repair-safety.md` — safety and verification pattern for live Dataverse YAML repair scripts, including null component names, cosmetic CR/BOM skip logic, and post-apply dry-run checks.
- `references/live-ui-source-of-truth-verification.md` — two-layer verification pattern when the live Copilot Studio UI is the source of truth: Dataverse backing record checks plus browser/CDP UI screenshot evidence, with draft-vs-published wording.
- `references/3-agent-debug-loop.md` — autonomous 3-subagent loop (Analysis → Fix → QA) using delegate_task for per-agent debug cycles targeting >95% SR + Conv. When Kevin says "spin 3 subagents in a loop", use this pattern.
- `references/autonomous-qa-loop-checklist.md` — class-level pattern for creating a read-only Therapy AI Dev fleet checklist/scanner, seeding a backlog from live records, enforcing visual UI evidence across Overview/Settings/Knowledge/Tools/Agents/Topics/Evaluation, and looping repairs/evals until each agent is >95% Single Response and Conversational.
- `references/trailing-question-pattern.md` — SR eval risk from natural-language questions embedded in SendActivity text (distinct from formal `kind: Question` nodes). Discovered on QM Coach V2: 13/13 topics affected.
- `references/ensign-default-live-dataverse-audit.md` — Live-Dataverse-only audit pattern for Ensign Default agents (NO local workspaces). Captures auth trailing-slash gotcha, botcomponent query patterns, Python analysis script template, component type reference, and report output format. Proven Jul 4 2026 on Therapy Documentation Feedback B + Therapy_Report_Prep_Assistant.
- `references/ensign-default-audit-2026-07-04.md` — Full Ensign Default fleet audit results (Jul 4, 2026): 6 agents, 96 topics, 60 P0 issues. Fleet-wide patterns (Escalate 42-trigger copy-paste, ~5k TP components per agent, system topics lacking termination). SLP_Specialist = gold standard (0 P0). Report_Prep_Assistant = worst (45 P0, 33/38 topics unterminated). Priority queue ordering. Audit method: `az rest` Dataverse queries.
- `references/architectural-quick-scan-triage.md` — CLI-based health scan to determine agent fixability in ~30 seconds using `rg -c` counts of Questions, SASC, EndDialog, and SendActivity. Classifies agents as rebuild-needed, systemic-fixable, or clean. Run BEFORE the full audit to avoid wasting deep-dive time on unfixable architectures.
- `references/structured-intake-only-anti-pattern.md` — "design-phase shell" anti-pattern where every topic collects structured intake but produces zero output (no SearchAndSummarizeContent, no EndDialog, placeholder SendActivity). Discovered on SNF AI Dashboard V2. Indicators: zero SearchAndSummarizeContent across the agent, empty connectionreferences.mcs.yml, boilerplate modelDescriptions referencing wrong agent name.
- `references/theradoc-workbench-focused-documentation-audit.md` — TheraDoc Workbench purpose alignment audit: verifying active agent vs legacy names, Card-based post-session workflow, pasted-text vs OCR distinction.
- `references/copilot-studio-live-yaml-repair.md` — Playwright/CDP live YAML repair decision ladder: correct environment ID vs tenant default URLs, multiple Copilot Studio `More` buttons, code-editor click no-op fallback, Dataverse-origin authentication, topic-body normalization from `kind: AdaptiveDialog`, and no-publish verification evidence.
- `references/theradoc-workbench-audit-2026-06-30.md` — TheraDoc Workbench full audit: 56 topics, routing integrity gaps (duplicate routers, Card-vs-Intake data sinks, 12+ orphan topics), missing OCR topic, remediation priority list, knowledge/action inventory.
- `references/theradoc-workbench-card-generation-pattern.md` — Card-based doc generation YAML pattern.
- `references/theradoc-workbench-loop1-findings-2026-07-03.md` — TheraDoc Workbench Loop 1 follow-up audit: confirmed M1/M3 unfixed, discovered RecertificationDischargeCard hardcoded-PT bug, ST/SLP routing gaps, SessionClose flow routing bug, NoteReviewandFinalize empty Global display, and assessed fix-ready=false.
- `references/data-vs-content-staleness.md` — Detect and fix when `botcomponent.data` has correct YAML but `botcomponent.content` is stale (unpublished Dataverse PATCH). Causes 0-5% conversational scores despite appearing fixed. Includes detection query, what causes it, what does NOT fix it (pac publish, PvaPublish API, deactivate/reactivate), and the only working fix (UI code editor save). Case study: Ensign Default PT/OT/TDA Jul 4 2026.

## Output
## TheraDoc Workbench Specifics (2026-06-30)

Bot ID: `e09954e1-4af8-47c6-8ef4-d1d9335bf2e6`
Purpose: Post-session PT/OT/SLP documentation with click-button capture (AdaptiveCards), minimal typing, AI-generated notes.

### Architecture Pattern (Card-based documentation)
The correct flow is: AdaptiveCard (click buttons) → SearchAndSummarizeContent (generate note from card data) → SendActivity (show DRAFT) → BeginDialog → AuditExistingNote → EndDialog with clearTopicQueue: true.

Topics that collect data via AdaptiveCard but have NO generation are broken dead-ends. The original agent had 7 Card topics with no generation — all needed SearchAndSummarizeContent added.

### Key Findings from Full Audit
- 56 custom topics analyzed; 35 were out-of-scope or misaligned (too many free-text questions)
- Clean set: 27 custom + 13 system = 40 topics
- 10 new Card topics created (Progress/Recert/Discharge for PT/OT/SLP + ST Daily)
- NoteIntakeRouter simplified to 2-step flow: Note Type → Discipline → Card
- Out-of-scope topics: CrossDisciplineConflictAuditor, EHRFinalizerGateway, SignificantChangeDetector, GoalBank, SkilledJustification, PlanOfCare, NursingHandoff, DoREmail, etc.
- Misaligned topics: All Intake topics with 10-28 free-text Question nodes (replaced by Card approach)

### Topic Naming Convention
Card topics: `{Discipline}{NoteType}Card.mcs.yml` (e.g., PTDailyNoteCard.mcs.yml)
All Card topics follow identical structure: AdaptiveCardPrompt → SearchAndSummarizeContent → SendActivity → BeginDialog(AuditExistingNote) → EndDialog(clearTopicQueue:true)

### Push Method
manage-agent push fails (LSP binary `vscode-jsonrpc/node` not available). Use CDP batch-patch via Kiro Chrome instead — see copilot-studio-pipeline skill for `cdp_patch_topics.cjs` pattern.

## Output
Create a timestamped markdown/JSON report under the project audit-results folder with:
- Agent-by-agent context summary
- Findings by severity and category
- Fixes applied
- Remaining manual/UI-only fixes
- Validation commands and real outputs
- Environment confirmation: for Therapy AI Dev/Prod, confirm Ensign Default was not touched. For Ensign Default audits (explicit user direction only), confirm no cross-environment contamination.
