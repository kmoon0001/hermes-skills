# Solution Export YAML Extraction

## When to Use This Workflow

The standard workspace-investigation-patterns.md says solution archives cannot provide topic YAML locally. **This is wrong for Power Platform solution exports of Copilot Studio agents.** The `solution_unpacked/botcomponents/` directory contains `data` files that are full YAML — parseable, auditable, and often more complete than the solution's XML metadata.

Use this when the workspace has:
- `solution.zip` + `solution_unpacked/` at root
- `solution_unpacked/botcomponents/` directories with `*.topic.*/data` and `*.gpt.*/data` files
- No `agent.mcs.yml`, `topics/`, or `.mcs/` folder

## Direct ZIP Extraction (No Unpacking Required)

When only the `.zip` file is available (no `solution_unpacked/` directory), extract and analyze topic data directly using Python:

```python
import zipfile, re

z = zipfile.ZipFile('solution.zip')

# 1. Extract GPT instructions (agent behavior settings)
for name in z.namelist():
    if 'gpt' in name.lower() and 'default' in name.lower() and name.endswith('/data'):
        data = z.read(name).decode('utf-8', errors='replace')
        print(f'Instructions ({len(data)} chars):')
        print(data[:500])

# 2. Extract and analyze every topic
results = {}
for name in sorted(z.namelist()):
    if not ('.topic.' in name.lower() and name.endswith('/data')):
        continue
    topic_name = name.split('/')[1]
    data = z.read(name).decode('utf-8', errors='replace')

    results[topic_name] = {
        'EndDialog': 'EndDialog' in data,
        'clearTopicQueue': 'clearTopicQueue' in data,
        'Questions': data.count('kind: Question'),
        'ConditionGroup': 'ConditionGroup' in data,
        'SearchSpecificFiles': 'SearchSpecificFiles' in data,
        'SearchSpecificKnowledgeSources': 'SearchSpecificKnowledgeSources' in data,
        'SearchAndSummarizeContent': 'SearchAndSummarizeContent' in data,
    }

# 3. Extract knowledge file content
for name in sorted(z.namelist()):
    if '.file.' in name.lower() and 'filedata' in name.lower():
        content = z.read(name).decode('utf-8', errors='replace')
        # Read knowledge markdown content

# 4. Read agent metadata
# bots/<schemaName>/bot.xml — agent configuration
```

**Naming conventions inside `.zip`:**
- Topic components: `<PREFIX>.TOPIC.<NAME>` (UPPERCASE with bot prefix, e.g. `CR917_AGENTU92BPC.TOPIC.SINGLENOTECOMPLIANCEAUDIT`)
- GPT instructions: `<PREFIX>.gpt.default/data`
- File knowledge: `<PREFIX>.file.<Name>_<hash>/filedata/<filename>.md`
- Web knowledge: `<PREFIX>.topic.<URL-slug>_<hash>/data`

**Proven on:** Pacific Coast Compliance Analyzer (2026-07-03) — 48+ topics extracted, EndDialog status, Question counts, ConditionGroups, SearchSpecificFiles all analyzable from a single `solution.zip`.

## Finding Agent YAML in an Unpacked Solution Export

If the workspace has `solution_unpacked/botcomponents/`, use shell commands:

| Component Type | Folder Pattern | File to Audit |
|----------------|----------------|---------------|
| Topic | `*.topic.<Name>/data` | YAML dialog body |
| GPT Instructions | `*.gpt.default/data` | YAML instruction body |
| File Knowledge | `*.file.<Name>_<suffix>/filedata/<Name>.pdf` | PDF binary (check metadata via botcomponent.xml) |

### Header Prefixes = Agent Sub-Configurations

The **header prefix** (e.g., `copilots_header_8c921`, `copilots_header_6271a`) identifies which agent sub-configuration a component belongs to. A single solution export can contain **multiple agent sub-configurations** — count unique headers to discover how many agents are bundled.

POSTette Compliance Agent (2026-07-03) had **8 headers**:
- `024e0` — PCA Compliance Analyzer (main)
- `0331e` — Report Generator
- `3f0ed` — Medicare Rules Engine
- `55b3f` — Compliance Auditor
- `6271a` — SLP Specialist
- `70a50` — Data Router
- `8c921` — OT Specialist (most custom topics)
- `13225` — System topics only

### Discovery Command

```bash
# Find all unique headers
ls -d solution_unpacked/botcomponents/*.topic.*/ | sed 's/.*copilots_header_\([0-9a-f]*\)\.topic.*/\1/' | sort -u

# Find all GPT instructions
ls solution_unpacked/botcomponents/*.gpt.*/data

# Find all custom topics (excluding system topics)
ls -d solution_unpacked/botcomponents/*.topic.[A-Z]*/data

# Search across ALL topic data files
grep -l "SearchAndSummarizeContent" solution_unpacked/botcomponents/*.topic.*/data
```

## What You Can Audit

Despite being a solution export, the `data` files contain full YAML and allow:

- **Topic structure**: `kind: OnRecognizedIntent`, `kind: OnActivity`, `kind: OnConversationStart`
- **Trigger phrases**: Parse `triggerQueries` and `intent: {}` (empty = no NLU trigger)
- **SearchAndSummarizeContent**: userInput, additionalInstructions, fileSearchDataSource, knowledgeSources, applyModelKnowledgeSetting
- **EndDialog presence**: Search for `- kind: EndDialog` in topic data files
- **SendActivity only (no EndDialog)**: Topics that end without EndDialog
- **Question nodes**: `kind: Question` in the action list
- **ConditionGroup**: empty conditions, trivial logic errors
- **GPT instructions**: Size (mode ~4000-6000 chars, ceiling ~9000), format mandates (JSON-only), guardrails
- **File knowledge**: List of attached PDFs per agent sub-configuration
- **System topics**: ConversationStart, Fallback, Escalate, OnError, ResetConversation

## What You Cannot Audit

- Live publish state (`content` vs `data` field divergence)
- Connected agent declarations (settings.mcs.yml absent)
- Knowledge source descriptions (in the agent's Knowledge tab, not in export)
- Evaluation results or test sets
- Web/SharePoint knowledge source configuration

## Common Findings from Solution Export Audits

### 1. No EndDialog on Any Topic
The most pervasive issue. `grep -l "EndDialog" solution_unpacked/botcomponents/*.topic.*/data` returns 0 hits for most agents. Every topic ends with `SearchAndSummarizeContent` or `SendActivity` without signaling completion.

**Impact:** P0 — 0% Single Response eval across all topics.

### 2. SearchSpecificFiles + applyModelKnowledgeSetting: false
Search across all topic `data` files:
```bash
grep -l "SearchSpecificFiles\|applyModelKnowledgeSetting: false" solution_unpacked/botcomponents/*.topic.*/data
```

This is the #1 known answer-quality blocker. Topics can only answer from the 8-10 restricted files.

**Impact:** P0 — limited answer scope on affected topics.

### 3. Empty Intent = No Trigger Phrases
Topics with `intent: {}` have no NLU triggers — they can only be reached via `BeginDialog` from another topic or exact NLU match on the component name.

Search: `grep -B3 -A1 "intent: {}" solution_unpacked/botcomponents/*.topic.*/data`

**Impact:** P1 — unreachable via natural language.

### 4. Co-located Agent Configurations
When multiple headers exist, the agent may be a **multi-agent solution** rather than a single agent. Each header prefix identifies a distinct agent role (OT Specialist, SLP Specialist, Rules Engine, etc.).

**Impact:** Report finding. List each sub-configuration's role, topic count, and GPT instruction size.
