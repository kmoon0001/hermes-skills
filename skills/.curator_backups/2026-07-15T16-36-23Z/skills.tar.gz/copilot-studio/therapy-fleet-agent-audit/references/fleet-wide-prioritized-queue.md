# Fleet-Wide Prioritized Queue Pattern

Use this pattern when Kevin asks to analyze ALL Therapy AI Dev agents and fix in priority order using a subagent loop.

## Core principle: Fix/QA are slower than analysis

Since analysis (reading YAML, spotting bugs) is faster than applying fixes and running QA verification, **analyze ALL agents first** in parallel, then have the fix and QA subagents work through a prioritized queue.

## The 3-Subagent Loop

Each agent in the queue goes through three subagents in sequence:

```
Subagent 1 (Analysis) → Subagent 2 (Fix) → Subagent 3 (QA)
         │                      │                    │
    Creates checklist      Applies fixes       Verifies no regressions
    /copilotdebug audit    Backups + diffs     Reads actual file content
    P0/P1/P2 count         YAML validation     Test pane check
```

### Subagent 1 — Analysis
- Full Phase 0 / full-agent-audit per copilot-debug skill
- Read ALL local topic YAMLs + agent.mcs.yml
- Per topic: EndDialog+clearTopicQueue, ConditionGroup+Question, SearchSpecificFiles, trigger phrases
- Check instructions: size (<6000 chars), contradictions, unconditional RESPONSE FORMAT, no-caveat, eval-safe section
- Classify findings as P0 (blocks SR/Conv eval), P1 (routing/logic bugs), P2 (cleanup)
- Output: structured markdown checklist with fix-ready boolean

### Subagent 2 — Fix
- Read the checklist, read each file first, create .bak backup
- Apply P0 fixes first: add missing EndDialog, remove empty ConditionGroups, fix hardcoded variables
- Apply P1 routing/logic fixes
- Apply P2 cleanup (old template comments, instructions)
- Validate YAML with js-yaml after every file change
- Output: before/after diff report

### Subagent 3 — QA
- Verify fixes by READING actual file content (never trust self-reports)
- Compare current vs .bak to ensure ONLY intended changes were made
- Validate ALL topic YAMLs (not just modified ones — regression check)
- Verify EndDialog+clearTopicQueue integrity on all custom topics
- Attempt test pane check via Copilot Studio UI if browser available
- No regressions found → qa-pass: true

## Prioritized Queue Construction

After all parallel analyses return, consolidate into a single queue:

1. Sort agents by P0 count descending (most critical first)
2. Within same P0 count, sort by P1 count descending
3. Within same P1 count, sort by total issues (P0+P1+P2) descending

```json
{
  "queue": [
    {"name": "TheraDoc Workbench", "p0": 7, "p1": 4, "p2": 6},
    {"name": "Agent B",            "p0": 3, "p1": 2, "p2": 5},
    {"name": "Agent C",            "p0": 0, "p1": 1, "p2": 3}
  ]
}
```

The fix subagent works through the queue in order. When it finishes an agent, the QA subagent picks it up. Both run sequentially per agent since Fix depends on Analysis and QA depends on Fix.

## Environment Guard (Hard Rule)

- Therapy AI Agents Dev ONLY: `https://orgbd048f00.crm.dynamics.com` — Env ID: `a944fdf0-0d2e-e14d-8a73-0f5ffae23315`
- **NEVER touch Ensign Default:** `org3353a370.crm.dynamics.com` — blocked at the env level
- **NEVER touch Therapy AI Agents Prod** without explicit user direction

## Live UI Is Source of Truth

When the user says "live Copilot Studio UI is the source of truth":
1. Local YAML files are secondary references, not authoritative
2. Cross-reference with Dataverse API queries when possible
3. Test pane verification via Copilot Studio UI is the final validation gate
4. Draft changes ≠ published changes — state draft-vs-published clearly
5. Publish requires explicit user approval

## Systemic Fix Batch Pattern (High-P0 Agents)

When an agent has **20+ P0 issues** all sharing the same root cause, do NOT fix one topic at a time. Use a systemic batch approach.

### When to Use Systemic Mode

Any agent where >80% of P0 issues share the same root cause. Common candidates from Therapy AI Dev:
- **Missing EndDialog on 95%+ of topics** — bulk-add EndDialog to every custom topic file
- **Missing clearTopicQueue:true on all EndDialogs** — bulk-patch across topic files
- **Old template comments on every topic** — bulk-strip lines 1-12 from all topic files
- **SearchSpecificFiles on every topic** — bulk-remove `fileSearchDataSource` blocks from all files

### Systemic Fix Procedure

1. **Count the pattern** — how many files share the same defect? If >80%, systemic mode is indicated.
2. **Backup ALL files first** — create `.bak` for every topic file before any modification. On 50+ files this takes 2-3 minutes but prevents catastrophic loss.
3. **Apply bulk fix** — for missing EndDialog, append `kind: EndDialog` with `clearTopicQueue: true` as the last action in each topic's `actions:` array. Use the topic filename (sans extension) as the EndDialog id suffix for uniqueness.
4. **Validate in bulk** — run `node -e` with `require('js-yaml')` against ALL modified files in one pass. Pipe output to detect only FAIL lines.
5. **Spot-check 20%** — read 3-5 random files to confirm indentation is correct, the EndDialog slot is right, and no YAML structure broke.

### Verification After Systemic Fix

Systemic fixes are high-risk (one bug in the pattern repeats 50+ times). After applying:

1. **Validate ALL modified files** with js-yaml
2. **Spot-check 20% manually** — random selection, confirm EndDialog indentation, no structure broken
3. **Rerun full analysis scan** — count remaining P0 issues. If systemic fix addressed the dominant pattern but others remain, update the priority queue
4. **Report delta** — "Systemic fix: reduced P0 from N to M across X topics. Pattern: [EndDialog/clearTopicQueue/comments/etc]."

### Example: Therapy Report Prep (~49 P0)

```
1. Count: 48/52 topics missing EndDialog (92%) → systemic mode
2. Backup: 52 .bak files created
3. Bulk fix: Add EndDialog to 48 topic actions arrays
4. Validate: 52/52 pass js-yaml
5. Delta: P0 from 49 → ~2 (remaining P0 from other root causes)
```

## What to Audit Per Agent

| Dimension | What to Check |
|-----------|--------------|
| **EndDialog** | Every custom topic must end with `kind: EndDialog` + `clearTopicQueue: true` unless it's a BeginDialog router |
| **ConditionGroup** | No empty ConditionGroups (conditions with zero actions), no duplicate conditions |
| **SearchSpecificFiles** | Must be absent — removed in prior fixes |
| **SearchSpecificKnowledgeSources** | Must be absent — removed in prior fixes |
| **Trigger Phrases** | 5-10 per NLU topic per MS Learn; avoid overly broad phrases |
| **Instructions** | <6000 chars, no contradictions, no unconditional RESPONSE FORMAT, no citation manipulation, has no-caveat block and eval-safe orchestration |
| **Old Templates** | Remove Platinum Standard comment boilerplate (lines 1-12 in many topic files) |
| **Naming Consistency** | ST vs SLP, discipline variable usage in SearchAndSummarize |
| **Routing** | BeginDialog targets must exist; no duplicate routers; orphans |

## Specific Fix Patterns Found in Therapy AI Dev

### AuditExistingNote — Empty ConditionGroup + Missing EndDialog
Audit sink topics (routed FROM every Card topic) commonly have:
- ConditionGroups with conditions but zero actions (dead code)
- Duplicate conditions (e.g., PT listed twice)
- NO EndDialog — the topic ends with SendActivity, dropping the user silently
Fix: Remove empty ConditionGroup, add EndDialog with clearTopicQueue: true

### RecertificationDischargeCard — Hardcoded Discipline
Card topics that serve multiple disciplines but hardcode one in SearchAndSummarizeContent:
```
userInput: "...Generate a skilled PT Recertification..."  # WRONG — hardcoded PT
```
Fix: Use discipline variable collected from the card's AdaptiveCard: `=Text(Topic.discipline)`

### Old Template Comments
Many topic files still carry 12-line Microsoft Learn "Platinum Standard" comment boilerplate referencing non-existent paths like `src/KnowledgeBase/GLOBAL_CMS_COMPLIANCE.md`. These are YAML comments (start with `#`) and can be safely removed.

### ST vs SLP Naming
Some topics use "ST (Speech Therapy)" while others use "SLP (Speech-Language Pathology)". Standardize on SLP for consistency with Medicare documentation conventions.
