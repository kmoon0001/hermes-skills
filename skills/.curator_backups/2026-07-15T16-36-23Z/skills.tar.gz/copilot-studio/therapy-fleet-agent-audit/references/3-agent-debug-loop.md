# 3-Agent Subagent Debug Loop for Copilot Studio

An orchestrated three-subagent pattern implementing the copilot-debug Phase 1-3 loop using Hermes `delegate_task`. Each loop processes one agent from start to finish before moving to the next.

## When to Use

Use this pattern when Kevin says "spin 3 subagents in a loop" or asks for an autonomous debug loop targeting >95% Single Response and Conversational evaluation scores. It replaces manual sequential execution with parallel subagent delegation.

## The Loop (Per Agent Per Iteration)

```
┌──────────────────────────────────────────────────┐
│                  3-AGENT LOOP                     │
│                                                   │
│  1. ANALYSIS subagent                              │
│     ├─ /copilotdebug / full-agent-audit context    │
│     ├─ Read local YAML + Dataverse live state      │
│     ├─ Identify bugs per checklist categories      │
│     └─ Write priority-ordered fix CHECKLIST.md     │
│                                                   │
│  2. FIX subagent                                   │
│     ├─ Read the CHECKLIST.md from Analysis          │
│     ├─ Apply fixes (local YAML → Dataverse PATCH → │
│     │  → CDP batch-patch → WebBrain)               │
│     └─ Mark each item completed in manifest         │
│                                                   │
│  3. QA subagent                                    │
│     ├─ Verify each fix: content intact, no removal  │
│     ├─ Check no regressions in untouched topics     │
│     ├─ Test in Copilot Studio test pane w/ expected │
│     │  results                                      │
│     └─ Approve or flag for re-iteration             │
│                                                   │
│  → Loop until QA approves (>95% SR + Conv)         │
│  → Move to next agent                              │
└──────────────────────────────────────────────────┘
```

## Subagent Definitions

### Agent 1 — Analysis (Phase 0 + Pattern Analysis)

**Role:** Detective. Gets the full picture, finds every bug, writes a ticket.

**Input:** Agent name, bot ID, environment details

**Steps:**
1. Load skills: `copilot-debug`, `therapy-fleet-agent-audit`, `copilot-studio-pipeline`
2. Run Phase 0 / full-agent-audit:
   - Read agent.mcs.yml, all topic YAMLs, all reference files
   - Query Dataverse live state for botcomponents (_parentbotid_value)
   - Check instruction size, corruption, overlaps
   - Check knowledge sources: naming, descriptions, dedup status
   - Check all topics for: EndDialog + clearTopicQueue:true, SearchSpecificFiles, SearchSpecificKnowledgeSources, ConditionGroup+Question nodes, 800-char limits, missing SendActivity before EndDialog
   - Check trigger phrase quality and overlap
   - Check connected agent routing integrity
3. Pattern-analyze findings: if 80%+ same root cause → one category fix
4. Write `CHECKLIST.md` to the pipeline audit-results folder with:
   - Priority: Security/compliance > YAML validity > routing > knowledge > instructions
   - Each item: file path, exact fix description, category, severity
   - Boolean `fix_ready: true` when all bugs are identified

### Agent 2 — Fix (Phase 1 Remediation)

**Role:** Surgeon. Applies the checklist with minimal side effects.

**Input:** Path to CHECKLIST.md from Analysis

**Steps:**
1. Read CHECKLIST.md, check `fix-ready: true` before proceeding. If `fix-ready: false`, return and re-run analysis.
2. For each item by priority:
   - **Local YAML fix** → create `.bak` backup of the file FIRST, then edit `.mcs.yml` directly, run `topic_lint.cjs`, validate YAML
   - **Dataverse PATCH** → use `az account get-access-token --resource "https://{org}.crm.dynamics.com"` for auth, PATCH `botcomponent.data`
   - **CDP batch-patch** → use Kiro Chrome (port 9223) `cdp_patch_topics.cjs` for YAML-only fixes
   - **WebBrain browser** → for Copilot Studio SPA interactions that need visual canvas or Monaco code editor
3. After each fix, verify by re-reading the live record
4. Write `fix-manifest.md` (`pipeline/audit-results/<agent>-loop<N>-fixes.md`): what changed, per-item status (fixed/skipped/blocked), **backup file paths, YAML validation results, before/after diffs**
5. Include a `fixes-applied: true` boolean when all P0+P1+P2 fixes were successfully applied. If any fix failed or was skipped, set `fixes-applied: false` with reasoning.
6. If local YAML was the source, verify all lint rules pass
7. Remove SearchSpecificFiles AND SearchSpecificKnowledgeSources together (both blocks)

**Priority order:**
- P0: Missing EndDialog / clearTopicQueue:true → context bleeding
- P0: ConditionGroup+Question nodes → SR eval collapse
- P0: **Instruction self-contradictions** — contradictory length guidance ("prioritize completeness" vs "under 800 chars"), unconditional format bans that force plain text when structured formatting helps conversational evals, hard char truncation known to cause "Seems incomplete" eval failures
- P1: SearchSpecificFiles + SearchSpecificKnowledgeSources → KB restriction
- P1: 800-char limits → truncation (same as P0 instruction self-contradiction when combined with completeness mandate)
- P2: Unconditional RESPONSE FORMAT → Conv drops
- P2: No-caveat standards check missing → Question-response on SR
- P2: Missing EVALUATION-SAFE ORCHESTRATION section
- P3: Instructions >6000 chars → compression
- P3: Trigger phrase overlap → routing ambiguity

### Agent 3 — QA (Phase 2 + Phase 3 Verification)

**Role:** Inspector. Verifies every fix, checks for regressions, validates against test pane.

**Input:** Path to CHECKLIST.md and fix-manifest.md

**Steps:**
1. **Content integrity check via .bak comparison:** For every modified file, read the current version AND its .bak counterpart. Diff them to verify ONLY targeted lines changed. Flag any unintentional content removal or truncation.
2. **Full YAML validation:** Validate ALL topic .mcs.yml files with `node -e "try{require('js-yaml').load(require('fs').readFileSync('f','utf8'))}catch(e){console.log('FAIL: f')}"` — not just the modified ones. A regression in an untouched file means the fix subagent contaminated the workspace.
3. **Per-topic structural integrity check:** Re-read every custom topic for:
   - EndDialog + clearTopicQueue:true still present on leaf topic
2. **Regression check:** For non-fixed topics in the same agent, spot-check 3-5 random topics for unintended drift
3. **Instruction check:** Re-read agent.mcs.yml instructions:
   - No contradictory commands introduced
   - No duplicate section headers
   - RESPONSE FORMAT is conditional, not unconditional
   - Size under 6000 chars (patched)
4. **Knowledge check:** Verify no knowledge sources were accidentally removed or renamed
5. **Route integrity check:** All BeginDialog calls point to real topics
6. **Test pane validation** (WebBrain browser):
   - Send 3-5 test messages per fix area
   - Single Response: expected answer appears without Question/ask-back
   - Conversational: multi-turn context preserved, no loop/dead-end
7. **Publish gate check:** If QA passes, note "ready for publish + eval run"
8. Write `qa-report.md`: pass/fail per item, regression check results, test pane screenshots (paths), overall verdict

**QA pass criteria:**
- Fix items: 100% verified content-intact
- No regressions in non-fixed topics
- Test pane: expected responses, no Question nodes firing
- Verdict: APPROVED or RE-ITERATE with specific reasons

## Loop Flow Control

```bash
# Per iteration:
subagent 1: analysis  → writes CHECKLIST.md
        ↓ (sequential)
subagent 2: fix       → writes fix-manifest.md (reads CHECKLIST.md)
        ↓ (sequential)
subagent 3: qa        → writes qa-report.md (reads CHECKLIST.md + fix-manifest.md)
        ↓
if qa verdict = APPROVED → publish → eval → if >95% SR+Conv → NEXT AGENT
if qa verdict = RE-ITERATE → fix items → re-run fix + qa subagents
```

## Fleet-Wide Parallel Analysis (added 2026-07-03)

Since analysis (reading YAML, spotting bugs) is faster than applying fixes and running QA verification, analyze ALL agents in parallel first to build the prioritized queue:

### Pattern

1. **Dispatch N parallel analysis subagents**, each handling 2-4 agents
2. Each analysis subagent runs a Phase 0 / full-agent-audit and counts P0/P1/P2 issues
3. **Consolidate results** into a single prioritized queue:
   - Sort by P0 count descending (most critical → least critical)
   - Within same P0 count, sort by P1 count
   - Within same P1 count, sort by total issues
4. **Fix and QA subagents work through the queue** sequentially, one agent at a time

### Why this works

- Analysis is read-only and parallelizable (reading YAML files has no side effects)
- Fix requires applying changes (sequential per agent, but agent-independent)
- QA requires verifying no regressions (sequential per agent, but agent-independent)
- The queue prevents fix/QA agents from ever being idle while maintaining sequential processing per agent

### Example queue structure

```
Queue (ordered by P0 desc):
  1. TheraDoc Workbench        — 7 P0, 4 P1, 6 P2  ← Fix + QA working here
  2. Agent B                   — 3 P0, 2 P1, 5 P2  ← Next
  3. Agent C                   — 0 P0, 1 P1, 3 P2  ← Last
```

### Overrides

If the user has a specific ordering preference ("start with agent X then move to agent Y"), respect it over the P0-sorted queue. The queue is the default when no explicit ordering is given.

## Per-Agent Processing Rule

**Finish one agent before starting the next.** Kevin has an explicit ordering. Do not jump between agents mid-task. Complete all fix+QA iterations for Agent A before dispatching analysis on Agent B.

## Tool Chain by Priority

When fixing, use this priority order for tool selection:

1. **Dataverse API direct PATCH** — fastest, no browser. Auth: `az account get-access-token --resource "https://{org}.crm.dynamics.com"`
2. **Local YAML edit + topic_lint** — for source-controlled fixes before pushing live
3. **CDP batch-patch via Kiro Chrome** (port 9223) — when Dataverse API fails and `manage-agent push` is broken
4. **WebBrain browser** — for Copilot Studio SPA interactions that need Monaco code editor, visual canvas changes, or instruction editor paste
5. **pac CLI** — `pac copilot publish` only (not for editing)

## WebBrain Browser

When Copilot Studio SPA features block programmatic access (contentEditable instructions editor, canvas drag-drop, Monaco code editor paste), use WebBrain browser as interactive fallback. WebBrain can handle:
- Opening the agent's Overview/Instructions page
- Pasting YAML into Monaco code editor
- Navigating the Evaluation tab
- Running test pane interactions
- Navigating the Topics list to verify topic states

## Microsoft Learn Grounding

Every loop iteration must reference current Microsoft Learn best practices:
- https://learn.microsoft.com/microsoft-copilot-studio/guidance/evaluation-triage-overview
- https://learn.microsoft.com/microsoft-copilot-studio/guidance/evaluation-triage-failure
- https://learn.microsoft.com/microsoft-copilot-studio/guidance/evaluation-triage-pattern
- https://learn.microsoft.com/microsoft-copilot-studio/guidance/evaluation-triage-remediation

## Handoff Artifact Formats

### CHECKLIST.md (Analysis → Fix handoff)
Priority ordered with exact file paths, fix descriptions, and severity.

### fix-manifest.md (Fix → QA handoff)
Table format: #, Item, Status (FIXED/SKIPPED/BLOCKED), Method, Verified.

### qa-report.md (QA output)
Sections: Content Integrity, Regression Check, Instruction Check, Knowledge Check, Route Integrity, Test Pane, Verdict (APPROVED/RE-ITERATE).
