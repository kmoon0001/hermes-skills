# Fleet Sweep Results — Jul 3 2026

## Summary
16 Therapy AI Dev agents analyzed, 12 fixed and QA'd, 6 with draft eval runs completed. Fleet-wide patterns documented below.

## Agents Processed

| # | Agent | Bot ID | Δ P0 | Fix | QA | Eval |
|:-:|-------|--------|:----:|:---:|:--:|:----:|
| — | PC Case Historian V2 | ad635500... | 5→0 | ✅ | ✅ | 42%Conv/89%SR |
| 1 | Compliance Analyzer | 19779839... | ~73→0 | ✅ | ✅ | ran |
| 2 | Therapy Report Prep | fd1bce12... | ~49→~7 | ✅ | ✅ | ran |
| 3 | POSTette Compliance | 03b08692... | 20+→0 | ✅ | ✅ | ran |
| 4 | Regulatory Hub V2 | ea901efc... | 15+→0 | ✅ | ✅ | ran |
| 5 | QM Coach V2 | ea52ad9c... | 12→0 | ✅ | ✅ | ran |
| 6 | Clinical Synthesis Lab V2 | 89c7415d... | 10→0 | ✅ | ✅ | — |
| 7 | TheraDoc Workbench | e09954e1... | 7→0 | ✅ | ✅ | ran |
| 8 | SNF AI Dashboard V2 | bd570423... | Multi | ✅ | ✅ | — |
| 9 | SNF Command Center V2 | 9f3e370c... | Multi | ✅ | ✅ | — |
| 10 | Denial Defense V2 | 6d7815b4... | 4→0 | ✅ | ✅ | — |
| 11 | TDA Audit Agent | 4d0ed0d3... | 3 | ✅ stale | ✅ | — |
| 12 | Therapy Feedback B | 1c601ace... | 1→0 | ✅ | ✅ | — |

## Fleet-Wide Fix Statistics
- 200+ topics received EndDialog + clearTopicQueue: true
- 60+ topic files stripped of boilerplate template comments
- 25+ topics freed from SearchSpecificFiles restrictions
- 12 agents received instruction block updates

## Critical Finding: Unconditional EVAL Blocks Kill Conv Scores
Applied to ALL 12 agents simultaneously. PCCH post-fix:
- SR: 83% to 89% (+6pp, marginal)
- Conv: 65% to 42% (-23pp, regression)

Root cause: Unconditional "respond directly, don't ask follow-up questions" instructions broke multi-turn conversational flows. All 12 agents need their instruction blocks changed to conditional MS Learn-aligned format.

## Key PPAPI Eval Limitations Discovered
- Token expires ~15 min, not 1 hour as documented
- Detail endpoint returns 404 RouteNotFound
- SPA page text extraction via CDP Runtime.evaluate is the fallback
- Active-run limit per agent: SR and Conv must be sequential
- New runs show as "Automated Test Triggered by API" in SPA grid
