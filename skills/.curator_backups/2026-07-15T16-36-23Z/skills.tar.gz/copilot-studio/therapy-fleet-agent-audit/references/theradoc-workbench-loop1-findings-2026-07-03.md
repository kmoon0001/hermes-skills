# TheraDoc Workbench — Loop 1 Audit Findings (Jul 3, 2026)

**Agent:** TheraDoc Workbench (`e09954e1-4af8-47c6-8ef4-d1d9335bf2e6`)
**Env:** Therapy AI Agents Dev (`orgbd048f00.crm.dynamics.com`)
**Local workspace:** `D:/my agents copilot studio/TheraDoc/`

## Summary

Follow-up audit after the Jun 30 scope cleanup. Confirmed that:
- All 17 Card topics have the correct generation pattern (AdaptiveCard → SearchAndSummarizeContent → SendActivity → BeginDialog(AuditExistingNote) → EndDialog with clearTopicQueue:true) ✅
- 10 new Card topics (Progress/Recert/Discharge for PT/OT/SLP + ST Daily) are clean with no old template comments ✅
- **fix-ready: false** — 7 topics missing EndDialog and 3 routing bugs block eval readiness

## M1 — AuditExistingNote: Still Unfixed

**File:** `D:/my agents copilot studio/TheraDoc/topics/AuditExistingNote.mcs.yml`

- ❌ **No EndDialog** — topic ends with SendActivity, no `kind: EndDialog` anywhere. Every Card topic routes here via BeginDialog then expects to return control — without an EndDialog the topic queue stacks and the parent topic's EndDialog may not execute cleanly.
- ❌ **Empty ConditionGroup** (lines 40-54): `conditionGroup_4WLBs7` has 4 conditions (PT, OT, SLP, **PT-duplicate**) with ZERO actions. No audit logic fires. The topic collects incomingDiscipline then does nothing with it.
- **Impact:** This is the compliance audit sink for ALL 17 Card topics. Currently it's a no-op.

## M3 — ParseBrainDump: Still Unfixed

**File:** `D:/my agents copilot studio/TheraDoc/topics/ParseBrainDump.mcs.yml`

- ❌ **No EndDialog** — ends with SendActivity of `{Topic.Parseddata}`
- ❌ **String interpolation issue** — line 51: `"{Topic.Parseddata}**DRAFT - CLINICAL REVIEW REQUIRED**...` has a bare double-quote `"` before the expression, creating an unescaped YAML/expression parsing hazard. Should use proper Concatenate wrapping.

## New Finding: RecertificationDischargeCard Hardcodes PT

**File:** `D:/my agents copilot studio/TheraDoc/topics/RecertificationDischargeCard.mcs.yml`

- The AdaptiveCard collects `discipline` (PT/OT/SLP) and `noteType` (Recertification/Discharge Summary) from the user as separate fields.
- **SearchAndSummarizeContent at line 169 hardcodes `"Generate a skilled PT Recertification..."`** — ignores the actual discipline and noteType.
- **IncomingDiscipline passed to AuditExistingNote is hardcoded `"PT"`** — OT/SLP users get wrong audit routing.
- **Fix:** Replace hardcoded `"PT"` and `"Recertification"` with `Text(Topic.discipline)` and `Text(Topic.noteType)`.

## New Finding: STDailyNoteCard Routes to ST — No Handler

**File:** `D:/my agents copilot studio/TheraDoc/topics/STDailyNoteCard.mcs.yml`

- Routes to AuditExistingNote with `incomingDiscipline: =\"ST\"`.
- AuditExistingNote's ConditionGroup only has conditions for PT, OT, SLP — **no ST handler**.
- ST falls through to the empty ConditionGroup's else (which doesn't exist) — effectively a no-op.
- **Options:** Add an ST condition to AuditExistingNote, or route to "SLP" since ST is speech therapy (same discipline).

## New Finding: SessionClose Uses ST, Routes Everything Through PT Flow

**File:** `D:/my agents copilot studio/TheraDoc/topics/SessionClose.mcs.yml`

- **Uses `ST` not `SLP`** in discipline selection (line 51: `ST (Speech Therapy)`). All other topics use `SLP`.
- **ALL disciplines route to `TheraDoc-PTGenerateNote` flow** (line 365). OT sessions generate PT notes, ST sessions generate PT notes.
- ❌ **No EndDialog** — ends with BeginDialog to AuditExistingNote, no EndDialog.
- Old template comments present.

## New Finding: NoteReviewandFinalize Empty Global Variable

**File:** `D:/my agents copilot studio/TheraDoc/topics/NoteReviewandFinalize.mcs.yml`

- Line 30: `value: '""'` — sets `Global.GeneratedNote` to empty string.
- Line 33-35: Immediately displays `{Global.GeneratedNote}` — shows nothing.
- ❌ **No EndDialog** — falls off after SendActivities in both branches.

## New Finding: RedoReviseNote No EndDialog

**File:** `D:/my agents copilot studio/TheraDoc/topics/RedoReviseNote.mcs.yml`

- ❌ **No EndDialog** — ends with SendActivity of note content.
- Calls `TheraDoc-PTGenerateNote` flow regardless of discipline context.

## Old Template Comments Still Present in 14 Topics

The Microsoft Learn Platinum Standard boilerplate (lines 1-12 referencing non-existent `src/KnowledgeBase/GLOBAL_CMS_COMPLIANCE.md`) was found in:

1. AuditExistingNote.mcs.yml
2. ParseBrainDump.mcs.yml
3. SessionClose.mcs.yml
4. StartOver.mcs.yml
5. MasterPatientContext.mcs.yml
6. PTDailyNoteCard.mcs.yml
7. OTDailyNoteCard.mcs.yml
8. SLPDailyNoteCard.mcs.yml
9. PTEvaluationCard.mcs.yml
10. OTEvaluationCard.mcs.yml
11. SLPEvaluationCard.mcs.yml
12. RecertificationDischargeCard.mcs.yml
13. RedoReviseNote.mcs.yml
14. ErrorTimeoutRecovery.mcs.yml
15. ConversationStart.mcs.yml (system — report only)

These lines reference paths like `src/KnowledgeBase/GLOBAL_CMS_COMPLIANCE.md` which do not exist in the agent. They're stale template artifacts from initial topic creation.

## Instruction Audit (agent.mcs.yml)

| Check | Status | Note |
|-------|--------|------|
| Size (5,875) | ✅ PASS | Under 6,000 threshold |
| Duplicate headers | ✅ PASS | None found |
| Contradictory JSON/prose | ✅ PASS | No "STRICT JSON ONLY" |
| Unconditional RESPONSE FORMAT | ✅ PASS | responseInstructions are behavioral, not a rigid format mandate |
| Old template comments in instructions | ✅ PASS | Instructions field itself is clean |
| NO-CAVEAT STANDARDS CHECK | ❌ MISSING | No eval-safe fallback behavior block for no-note scenarios |
| EVALUATION-SAFE ORCHESTRATION | ❌ MISSING | No dedicated section for how the agent should behave in eval context |
| HITL / guardrails | ✅ PASS | Has Strict HITL Gate, Zero-PHI Policy, Button-First UI |

## Default/Empty inputType/outputType

All 17 Card topics have `inputType: {}` and `outputType: {}` at the bottom. This is common for topics that are BeginDialog-routed (not standalone NLU-triggered) — no defect.

## Knowledge & Connected Agents

- 6 knowledge sources declared in manifest (all file knowledge)
- 4 connected agents declared but 0 `InvokeConnectedAgentTaskAction` calls found in any topic YAML — report-only (platform routing may handle this transparently)
- No SearchSpecificFiles or SearchSpecificKnowledgeSources blocks found in any topic ✅

## 35 Topics Still on Filesystem Marked for Removal

Per `REMOVAL_MANIFEST.txt`, 35 topics should be disabled from the live agent. All are still present on the local filesystem. No action has been taken to disable them live.

## Fix-Ready Assessment

**fix-ready: false**

Blockers:
1. AuditExistingNote — no EndDialog + empty ConditionGroup with duplicate PT condition (blocker for ALL Card audit routing)
2. ParseBrainDump — no EndDialog + string interpolation bug
3. NoteReviewandFinalize — no EndDialog + empty Global.GeneratedNote display
4. RedoReviseNote — no EndDialog
5. RecertificationDischargeCard — hardcoded PT discipline, generates wrong content for OT/SLP
6. STDailyNoteCard — routes "ST" to AuditExistingNote with no ST handler condition
7. SessionClose — uses ST not SLP, routes everything via PT, no EndDialog
