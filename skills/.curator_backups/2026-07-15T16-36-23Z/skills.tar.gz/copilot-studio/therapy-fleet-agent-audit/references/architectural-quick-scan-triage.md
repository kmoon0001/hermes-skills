# Architectural Quick-Scan Triage

Determine an agent's fixability in ~30 seconds using CLI counts before any topic-by-topic audit.

## The Quick Scan

```bash
# From the agent's topics directory
echo "Topics:    $(ls *.mcs.yml 2>/dev/null | wc -l)"
echo "Questions: $(rg -c 'kind: Question' *.mcs.yml 2>/dev/null | grep -c ':')"
echo "SASC:      $(rg -c 'SearchAndSummarizeContent' *.mcs.yml 2>/dev/null | grep -c ':')"
echo "EndDialog: $(rg -c 'kind: EndDialog' *.mcs.yml 2>/dev/null | grep -c ':')"
echo "SendActiv: $(rg -c 'kind: SendActivity' *.mcs.yml 2>/dev/null | grep -c ':')"
echo "BeginDia:  $(rg -c 'kind: BeginDialog' *.mcs.yml 2>/dev/null | grep -c ':')"
echo "CondGroup: $(rg -c 'ConditionGroup' *.mcs.yml 2>/dev/null | grep -c ':')"
```

## Decision Matrix

| Questions | SASC | EndDialog | Interpretation | Action |
|:---------:|:----:|:---------:|:---------------|:-------|
| ≈ topics | **≈ 0** | ≈ 0 | **Structured-Intake-Only** — every topic is a menu/collector with no knowledge retrieval | 🛑 Rebuild needed. If SASC and EndDialog are both near-zero, the agent produces zero useful output. See `structured-intake-only-anti-pattern.md` |
| >> SASC | **≈ 0** | ≈ 0 | **Question-Collector Pattern** — topics ask questions but can't answer from KB | 🛑 Same as above — agent produces placeholder output only |
| > 0 | **> 0, < topics** | << topics | **Fixable with systemic work** — some topics have SASC but most missing EndDialog | ⚠️ Good candidate for systemic EndDialog batch + SASC audit |
| > 0 | **≈ topics** | ≈ topics | **Mostly clean** — topics have both knowledge retrieval and proper termination | ✅ Quick spot-fix: check for SearchSpecificFiles, trigger overlaps, instruction health |
| ≈ 0 | ≈ 0 | ≈ topics | **Router-only agent** — BeginDialogs to other agents, no standalone topics | ✅ Router agents need instruction audit only |
| ≈ 0 | **≈ topics** | ≈ topics | **Healthy** — clean architecture with knowledge retrieval | ✅ Minor polish only |

## When to Use Systemic Batches

If the quick scan shows **≥80% of topics share the same defect pattern**, use systemic bulk fix (see `fleet-wide-prioritized-queue.md`):

| Scan Signal | Systemic Fix | Proven On |
|:------------|:-------------|:-----------|
| EndDialog ≈ 0 across all custom topics | Bulk-add EndDialog + clearTopicQueue:true to every topic | Compliance Analyzer, Report Prep |
| Questions ≈ topics AND SASC ≈ 0 | Full architectural rework needed (not fixable by batch) | SNF Dashboard V2 |
| SearchSpecificFiles on every topic | Bulk-remove fileSearchDataSource blocks | Feedback B (6 topics) |
| Old template comments on every file | Bulk-strip boilerplate comment blocks (lines 1-12) | Therapy Report Prep |

## Example: SNF Dashboard V2 (July 3, 2026)

```
Topics:    49
Questions:  3 per topic avg (= topics, collector pattern)
SASC:       0   ← zero knowledge retrieval
EndDialog:  ... (only on some, but SASC=0 means they're empty EndDialogs)
SendActiv:  blank placeholder text
```

**Verdict**: Rebuild needed. Every topic is a dead-end data collector. The agent was designed as a UI menu system for Power Automate flows that were never connected. No amount of topic-level fixing can create answers where no answer infrastructure exists.

## Example: Therapy Report Prep (July 3, 2026)

```
Topics:     72
Questions:  13
SASC:       13  ← some topics have knowledge retrieval
EndDialog:  4   ← only 4/72 topics terminate properly
```

**Verdict**: Fixable with systemic batch. ~68 topics need EndDialog added (systemic), ~13 have proper SASC flows, remaining P0 from other root causes are minor.

## Example: Pacific Coast Case Historian V2 (June 26, 2026)

```
Topics:     35 (custom)
Questions:  11 (after ConditionGroup+Question removal)
SASC:       ~22
EndDialog:  35 (after fix)
```

**Verdict**: Mostly clean after fixes. Remaining issues are SearchSpecificFiles, SearchSpecificKnowledgeSources, and instruction-level fixes.

## Why This Matters

Without a quick health scan, a deep-dive audit on a rebuild-needed agent wastes 20+ minutes on detailed topic-by-topic analysis that yields no fixable issues. The scan tells you upfront:
1. Whether the agent is worth fixing at the topic level
2. Which systemic batch pattern applies (if any)
3. Whether to escalate to the user as a "needs full rebuild" case

Run this scan **before** starting Phase 0 of the full audit workflow. It takes one terminal command and saves hours of wasted analysis.
