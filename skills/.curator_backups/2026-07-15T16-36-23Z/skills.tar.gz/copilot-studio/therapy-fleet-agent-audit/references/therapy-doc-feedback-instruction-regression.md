# Therapy Doc Feedback — Instruction Fix Regression (Jul 4 2026)

## Agent

- **Name:** Copy Therapy Docuementation Feedback Ag
- **Bot ID:** `b0346795-4876-f111-ab0e-70a8a5b1b8cc`
- **Environment:** Therapy AI Agents Dev (`orgbd048f00`)
- **Type:** New-experience (Claude Sonnet 4.6)
- **Score:** SR=68%, Conv=15%

## Eval Pattern

20 conversational test cases. 3 pass, 17 fail. ALL 3 passes are discharge-related:
- "Can you audit my discharge summary and provide feedback on documentation strengths and weaknesses?" — PASS
- "Audit my documentation for discharge planning and caregiver training requirements." — PASS
- "Review my discharge summary for progress, plateau, and maintenance justification." — PASS

ALL 17 failures show 6 total messages — the agent opens with a gate question ("What type of document would you like reviewed?"), the test responds, the agent asks follow-up instead of answering.

## Failed Fix: Instructions

Added `# EVALUATION-SAFE DIRECT RESPONSE` section to instructions with:
- "respond directly and completely without asking follow-up questions"
- "When no documentation text: give a direct, substantive answer"
- "Do NOT ask 'What type of document?'"

**Result: Score dropped from 15% → 5% (-10pp regression).**

## Root Cause Analysis

The Question-First pattern was in the **Greeting topic / Conversation Starters**, NOT in the instructions. The agent's instructions already had strong domain knowledge (proven by the 3 discharge passes). Adding instruction-level directives to bypass the topic-level gate confused the model — it tried to reconcile conflicting signals from the greeting topic ("ask what document type") and the instructions ("answer directly, don't ask").

## Correct Fix Path

1. Fix the **Greeting topic / Conversation Starters** — remove the "What type of document would you like reviewed?" gate question
2. Replace Conversation Starters with direct action prompts: "Audit a progress note", "Check discharge compliance", etc.
3. Leave the instructions alone — they were adequate (the 3 discharge passes prove the instructions have good domain coverage)

## Lessons

- **When ALL conversational failures show the same turn count (e.g., 6), the gate is in the TOPICS, not the instructions.**
- **If some document types pass consistently, the instructions already have good knowledge for those types — the blocker is the topic-level routing, not the instruction-level guidance.**
- **Instructions fixes for topic-level problems cause regression** — the model gets conflicting signals from topics vs instructions.
- **Fix the LAYER where the problem lives:** topics control conversation flow, instructions control response content.
