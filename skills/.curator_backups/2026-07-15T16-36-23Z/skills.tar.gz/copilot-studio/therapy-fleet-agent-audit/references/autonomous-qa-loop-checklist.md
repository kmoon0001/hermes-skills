# Autonomous QA Loop Checklist — Therapy AI Dev Fleet

> **Updated 2026-07-03:** Full 4-phase fleet sweep proven on Therapy AI Dev. Parallel analysis → priority queue (worst-first) → systemic bulk fixes → QA → CDP evals with score loop. See below for the pattern.

## Fleet Sweep Pattern (4-Phase Loop)

Phase 0 — Parallel Analysis: dispatch parallel subagents to analyze ALL agents simultaneously. Each reads local topics + agent.mcs.yml, counts P0/P1 issues, creates individual checklists.

Phase 0.5 — Priority Queue: consolidate all checklists into a single priority queue ordered by P0 count descending (most bugs first). This drives fix + QA pipeline.

Phase 1 — Systemic Bulk Fix (worst-first): fix agents from the top of the queue. Apply systemic patterns (add EndDialog+clearTopicQueue to ALL topics, strip boilerplate, add eval instruction blocks) rather than one-off per-topic fixes. Create .bak backups and validate YAML.

Phase 2 — QA Verification: verify actual file contents vs .bak originals. Run js-yaml on ALL .mcs.yml files. Spot-check EndDialog+clearTopicQueue. Check agent.mcs.yml has eval sections. Check for regressions.

Phase 3 — CDP Eval (score loop): capture PPAPI token via CDP WebSocket. Start draft eval runs (SR then Conv, sequential per agent, parallel across agents). Poll API for completion. Read scores from SPA via CDP Runtime.evaluate. If below 95%, identify root cause pattern and loop back to Phase 1.

Parallelism rules: max 3 concurrent delegate_task subagents. Analysis batches run in parallel; fix+QA runs sequentially per agent but parallel across agents. Eval runs parallel across agents but SR+Conv sequential per agent.

## Core principle

The live Microsoft Copilot Studio UI is the source of truth. Dataverse/API records are a machine-readable backing layer, not sufficient by themselves. A fix is not complete until both layers are checked:

1. Live Dataverse/source record re-read succeeds and validates.
2. Representative live Copilot Studio UI page is opened under Therapy AI Agents Dev and screenshot/state evidence confirms the expected agent/topic/settings page.
3. Draft-vs-published status is stated clearly. Do not imply published users see draft changes unless publish was explicitly approved and completed.

## Loop mechanism

Create or run a read-only scanner/checklist generator before broad remediation. The tested project script pattern was:

```bash
cd "D:/my agents copilot studio"
node scratch/therapy-fleet-autonomous-qa-loop.cjs --scan
```

Expected behavior:
- Hard-code/guard Therapy AI Dev only: `https://orgbd048f00.crm.dynamics.com`.
- Explicitly block Ensign Default: `org3353a370.crm.dynamics.com`.
- Do not include an apply/patch mode in the checklist scanner.
- Read live bot/components from Dataverse and generate:
  - `CHECKLIST.md`
  - `qa-loop-report.json`
  - `qa-loop-config.json`
- Include the current list of known remaining live YAML blockers from latest live repair summaries.
- Include live UI URLs for each agent tab so browser QA can proceed agent-by-agent.

## Required checklist gates

At minimum, include gates for:

1. Scope and baseline freeze: Therapy AI Dev only, publish timestamp, live snapshot.
2. Live UI visual proof: Overview, Settings, Knowledge, Tools, connected Agents, Topics, Activity/Evaluation, Analytics/Channels as relevant.
3. Overview: name, icon/identity, description, role, published/draft status, owner/environment.
4. Instructions/compliance: role-specific, complete, HIPAA/PHI, HITL, CMS/Medicare, NIST/FDA/CFR/OMG/regulatory references where applicable, no unsupported tool promises.
5. Suggested prompts: at least 10 strong conversation starters mapped to core workflows and safety boundaries.
6. Generative orchestration: enabled/used where supported; names/descriptions of topics/tools/knowledge/connected agents are distinct and routing-safe.
7. Knowledge sources: each source has a clear name, detailed description, valid auth/link, official-source marker where appropriate, and maps to the agent role.
8. Tools/actions/flows: clear names/descriptions/config/auth, HITL boundaries, no orphan flow/action references.
9. Connected agents/handoffs: swarm routing is clear, no circular/ambiguous handoffs, orchestrator knows when to hand off.
10. Topics: live topics parse, complete logic, end nodes, no orphan branches, no invalid Search/Invoke patterns, coverage fits the agent purpose.
11. Settings/security: auth, moderation, channels, web/code interpreter, DLP/privacy posture.
12. Local/live consistency: reconcile local source with live draft, but live UI remains final source of truth.
13. Single Response eval: draft eval >95% for each agent.
14. Conversational eval: draft eval >95% for each agent.
15. Publish gate: explicit user approval before publish, then post-publish smoke/chat tests.

## Microsoft Learn grounding to cite in the checklist

Use current Microsoft Learn docs as source of truth. In the session that produced this pattern, these Learn pages grounded the checklist:

- `advanced-generative-actions`: generative orchestration can choose topics, tools, knowledge, and connected agents; clear names/descriptions matter for routing.
- `add-tools-custom-agent`: tool descriptions should say what the tool does and when it should be used.
- `knowledge-copilot-studio`: knowledge-source names/descriptions affect source selection, especially with many sources.
- `knowledge-add-sharepoint`: SharePoint knowledge sources need detailed descriptions; renamed sites/folders can break links and permissions.

## QA Verification Rule

**Never trust fix subagent self-reports.** QA must verify by reading actual file content, not just the fix report. Proven pitfall (Jul 3 2026): SNF Dashboard fix agent claimed "2 files already clean" for FacilityContextSwitcher and RegulatoryComplianceTracking, but both still had full 15-line boilerplate blocks. The fix agent didn't actually modify them.

QA procedure:
1. Read the fix report to know what was *supposed* to change
2. Read the actual current file content
3. Diff against .bak originals
4. Run independent validation (js-yaml on ALL files, not just modified ones)
5. Spot-check 5 random unmodified files for regressions

When the scanner script is changed and no canonical suite exists, run an ad-hoc temp verifier under `C:/Users/kevin/AppData/Local/Temp` with prefix `hermes-verify-`.

Verifier should check:
- `node --check scratch/therapy-fleet-autonomous-qa-loop.cjs` passes.
- Static guards: Therapy AI Dev URL, tenant, Ensign Default block, live UI source-of-truth wording.
- Required tabs are in the script: overview, settings, knowledge, tools, connectedAgents, topics, activity/evaluation, analytics/channels.
- 95% Single Response and Conversational thresholds exist.
- Microsoft Learn grounding links exist.
- Publish requires explicit approval.
- Scanner has no apply/patch mode.
- Fresh `--scan` exits 0 and produces valid report shape: 14 agents, checklist gates, backlog items, known remaining live YAML blockers, config flags.
- Delete the temp verifier and report as ad-hoc verification, not canonical suite green.

## Reporting language

Be direct and operational. Kevin asked for autonomy, not a long explanation. Report:
- path to generated checklist/report/config,
- number of agents/components/backlog items,
- known critical blockers carried forward,
- whether ad-hoc verification passed,
- next operational step: repair critical live blockers, visually verify UI, then eval loop to >95% SR/Conv.
