# Pacific-Coast Clinical Synthesis Lab V2 Audit (2026-07-03)

**Bot ID:** `89c7415d-df73-490c-9d78-4829cfbc2f84`
**Schema:** `pcca_agent39xn69`
**Role:** Clinical Synthesis — unified clinical synthesis hub for longitudinal case histories and session progress reports. Specialist in SBAR and Admission Prep.

## Key Findings

| Severity | Count |
|----------|-------|
| **P0** | **10** |
| **P1** | **14** |

## Architecture

Two-tier agent structure:

- **Root GPT** (`agent.mcs.yml`): `GptComponentMetadata`, `useModelKnowledge: true`, `contentModeration: High`
- **Sub-agent GPT** (`SNF Rehab Agent/agent.mcs.yml`): Named "Therapy_Report_Prep_Assistant", `useModelKnowledge: false`, `contentModeration: Medium`
- **20 NLU-triggered topics** in `SNF Rehab Agent/topics/*.mcs.yml`
- **8 sub-dialog topics** in `src/Topics/*.topic.yaml` (called via BeginDialog from router)
- **5 actions** with 2 using placeholder flow IDs

## P0 Findings

### 1. Missing EndDialog on NLU-Triggered Topics (7 topics)
EvalAnalysis, DischargeAnalysis, ProgressAnalysis, RecertAnalysis, ClassifyAndRouteRehabRecord, ManualIntakeFallback, Escalate all lack EndDialog. Greeting uses CancelAllDialogs instead.

### 2. Missing EndDialog on Sub-Dialog Topics (5 topics)
ClassifyAndRouteRehabRecord (success path), CaseHistoryAnalysis, ComplianceAuditor (success path), SBAR_Narrative_Engine, SwarmWorkerGate, GlobalSecurityGate (normal path).

### 3. Missing clearTopicQueue (23/23 EndDialog instances)
Only the Search conversational-boosting topic has `clearTopicQueue: true`. All other EndDialog instances across every topic omit it.

### 4. Placeholder Flow IDs
Two actions use placeholder GUIDs:
- `SynthesisLab-SBARGenerateNote`: `11111111-2222-3333-4444-555555555555`
- `SynthesisLab-EmailSBARReport`: `66666666-7777-8888-9999-000000000000`

## P1 Findings

### ConditionGroup + Question Pattern (SR Eval Blockers)
7 topics have multi-Question flows (3-4 questions each) before the terminal action. These will fail Single Response eval.

### Sub-Agent Config Issues
- `useModelKnowledge: false` on the sub-agent (root has `true`)
- `contentModeration: Medium` on sub-agent (root has `High`)

### Other Findings
- "I need support" trigger on Escalate is too broad
- SuggestedActions topic is empty (no actions)
- 3 duplicate/misnamed CrossAgentAuditLog actions with hardcoded "TheraDoc" source name
- Comment-only "STRICT JSON ONLY" in topic YAML headers not actually enforced

## Clean Checks
- No `SearchSpecificFiles` / `SearchSpecificKnowledgeSources` / `fileSearchDataSource`
- Trigger phrase quality good (4-8 per topic)
- No instruction corruption, no ghost components
- Web browsing explicitly disabled

## Remediation Priority
1. Replace placeholder flow IDs → real Power Automate flow IDs
2. Add EndDialog + clearTopicQueue to all NLU-triggered and sub-dialog topics
3. Fix Greeting: CancelAllDialogs → EndDialog + clearTopicQueue
4. Populate or remove SuggestedActions
5. Remove duplicate/misnamed CrossAgentAuditLog actions
6. Narrow Escalate trigger phrases
7. Decide on useModelKnowledge: false (confirm intentional or re-enable)
8. Align contentModeration to High on sub-agent
