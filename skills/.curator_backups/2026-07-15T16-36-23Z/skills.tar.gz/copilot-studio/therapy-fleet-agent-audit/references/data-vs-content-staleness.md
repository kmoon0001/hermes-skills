# Data vs Content Staleness Detection

Detect and fix when a Dataverse PATCH wrote correct YAML to `data` but `content` was never regenerated — the agent runs on stale compiled YAML and scores 0-5%.

## Detection Query

```python
import subprocess, json, urllib.request

ORG_URL = "https://org3353a370.crm.dynamics.com/"
r = subprocess.run(
    ["az", "account", "get-access-token",
     "--resource", "https://org3353a370.crm.dynamics.com/",
     "--query", "accessToken", "-o", "tsv"],
    capture_output=True, text=True
)
token = r.stdout.strip()

component_id = "959540fc-bce6-4a04-a152-bc955567f849"  # Fallback topic
url = f"{ORG_URL}api/data/v9.2/botcomponents({component_id})?$select=data,content"
req = urllib.request.Request(url)
req.add_header("Authorization", f"Bearer {token}")
req.add_header("Accept", "application/json")
req.add_header("OData-MaxVersion", "4.0")

resp = urllib.request.urlopen(req, timeout=30)
comp = json.loads(resp.read())

data_ok = "SearchAndSummarizeContent" in (comp.get("data") or "")
content_ok = "SearchAndSummarizeContent" in (comp.get("content") or "")
content_stale = "FallbackCount" in (comp.get("content") or "")

if data_ok and not content_ok:
    print("STALE: data has fix but content does not — needs publish")
elif data_ok and content_ok:
    print("OK: both data and content have the fix")
elif not data_ok:
    print("NOT FIXED: data field needs patching first")
```

## What Causes It

1. Dataverse PATCH writes correct YAML to `botcomponent.data`
2. Agent is not published after PATCH
3. `content` field (compiled YAML) remains unchanged
4. Agent runs on `content` — the old broken YAML
5. Evaluation scores 0-5% conversational because the running agent has no `SearchAndSummarizeContent`

## What Does NOT Fix It

- `pac copilot publish` — succeeds but does NOT compile `content` for OnUnknownIntent/Fallback system topics
- `PvaPublish` API — returns 200 with empty `PublishedBotContentId`
- Deactivate → Reactivate → Publish cycle — does not trigger recompilation
- Direct `content` PATCH — platform rejects with "Unexpected character encountered while parsing value: k" 

## What Fixes It

Only the Copilot Studio UI code editor save compiles `content` for system OnUnknownIntent topics:
1. Open agent → Topics → Fallback/Conversational Boosting
2. Open code editor (⋮ menu)
3. Select All → Delete → Paste correct YAML
4. Save (Ctrl+S)
5. Publish from UI

## Case Study: Ensign Default PT/OT/TDA (Jul 4 2026)

- All 3 agents had identical component IDs to previously patched records (no deletion/recreation)
- `data` field: correct fix-pattern YAML (SearchAndSummarizeContent, Topic.Answer, ConditionGroup)
- `content` field: old broken YAML (FallbackCount < 3, static SendActivity, no SearchAndSummarizeContent)
- `pac copilot publish` returned "Published successfully" but did not regenerate `content`
- `PvaPublish` API returned empty `PublishedBotContentId`
- Deactivate/reactivate + publish had no effect
- Root cause: unpublished Dataverse PATCH — the `data` fix was applied via API but never published
- SLP_Specialist had compiled `content` (SASC present) → scored 85% conversational
- PT/OT/TDA had stale `content` → scored 0-5% conversational
- Fix: publish from Copilot Studio UI (UI code editor save + UI publish)

## Prevention

After every Dataverse PATCH on topic `data`:
1. Publish the agent
2. Wait 90 seconds
3. Query `$select=data,content` for every patched topic
4. Verify `SearchAndSummarizeContent` appears in BOTH fields
5. If only `data` has it → publish from UI, not CLI
