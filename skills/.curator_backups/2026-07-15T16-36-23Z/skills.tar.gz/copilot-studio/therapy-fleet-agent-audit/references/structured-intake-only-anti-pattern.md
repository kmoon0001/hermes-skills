# Structured-Intake-Only Anti-Pattern

## What It Is

An agent where **every topic follows the pattern**: `Question → Question → ... → SendActivity(placeholder output) → [no EndDialog]` — with zero SearchAndSummarizeContent, zero InvokeFlowAction, and zero EndDialog. These agents are "design-phase shells": the topic architecture was built as a UI mockup showing what an end-to-end flow would look like, but no backend or knowledge retrieval was ever connected.

## Discovery

Discovered on **SNF AI Dashboard V2** (Bot ID: `bd570423-cf47-f111-bec5-70a8a5b1c3a3`) during the July 3, 2026 Therapy Dev fleet sweep.

## Indicators

| Indicator | Pattern | Severity |
|-----------|---------|----------|
| **Every topic ends with a SendActivity saying "stays in structured intake mode until a validated live backend is connected"** | Placeholder output text | P0 — agent produces zero useful work |
| **connectionreferences.mcs.yml is empty** | No flows are live-wired | P0 — no backend actions exist |
| **Zero SearchAndSummarizeContent nodes across the entire agent** | No knowledge retrieval at all | P0 — agent cannot answer from KB |
| **All topic descriptions use identical boilerplate** | `"Elite clinical intelligence module specialized in [TopicName]"` copied verbatim across every topic | P1 — indicates template-based creation without customization |
| **modelDescriptions reference a different agent's name** | e.g. Dashboard topics say "SNF Command Center" | P1 — copy-paste from different agent |
| **No EndDialog on any topic** | Dialog stack never cleaned | P0 — context bleeding |
| **Topic names match a legitimate workflow** (PatientRiskStratification, QualityMeasurePerformance, etc.) but **produce placeholder output only** | Topic names suggest capability that does not exist | P0 — false routing promises |

## Why It's Harmful

1. **Eval scores will be near-zero.** Every topic fires Question nodes that ask for structured input, then outputs a placeholder. Single Response eval expects a final answer — Question nodes score as Abandonment.
2. **Context bleeding.** No EndDialog means every topic stays on the dialog stack. After 2-3 interactions the stack overflows and the agent produces garbage or crashes.
3. **User frustration.** The agent sounds capable (\"Patient Risk Stratification\", \"Quality Measure Performance\") but produces no useful output. Users will perceive it as broken.
4. **False routing matches.** NLU triggers fire on these topic names, intercepting queries from other agents that could actually answer.

## When to Suspect This Pattern

Run these checks on any agent where local source audit shows:
- Every topic follows `Question → ConditionGroup → Question → ... → SendActivity` without SearchAndSummarizeContent
- SendActivity text contains phrases like \"backend\", \"validation mode\", \"under development\", \"automated handoff mode\", or \"not yet connected\"
- connectionreferences.mcs.yml has zero entries despite topics referencing flow actions
- Zero `kind: SearchAndSummarizeContent` nodes across all topic files

## What to Report

When you find this pattern, report it as:

**P0: No EndDialog on ANY custom topic (N topics affected)** — every topic lacks topic termination. This will cause context bleeding and dialog stack overflow in conversational evals.

**P0: Zero knowledge retrieval across the entire agent** — no SearchAndSummarizeContent nodes exist. The agent cannot answer from configured knowledge sources. It only collects structured intake and outputs placeholder text.

**P0: Hollow topic execution (N topics)** — topics with legitimate-sounding names produce only placeholder output. Every triggered topic will fail SR eval with no useful response generated.

**P1: boilerplate modelDescriptions** — all topics use identical template text referencing the wrong agent name instead of topic-specific descriptions.

**P1: Empty connection references** — N Power Automate flows are declared but none have live connection references. All InvokeFlowAction calls will fail at runtime.

## Recommended Action

This agent needs **architectural rework**, not targeted fixes. The minimal viable remediation:

1. Add EndDialog with clearTopicQueue:true to every custom topic (bulk)
2. Add SearchAndSummarizeContent to topics that should answer from KB
3. Either wire up the Power Automate flows or remove InvokeFlowAction references
4. Replace placeholder SendActivity text with actual response content
5. Remove boilerplate modelDescriptions (replace with topic-specific descriptions)

If the agent is genuinely not yet implemented (design-phase-only), advise the user to disable it from the active agent set rather than trying to patch it into eval-readiness for >95% scores. It would take less time to rebuild than to fix the current structure.
