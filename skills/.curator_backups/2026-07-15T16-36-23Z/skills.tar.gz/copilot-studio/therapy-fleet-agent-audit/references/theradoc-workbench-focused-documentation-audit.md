# TheraDoc Workbench focused documentation audit lessons

Use this reference when auditing or repairing Therapy AI Agents documentation assistants, especially TheraDoc/TheraDoc Workbench.

## Correct framing

Do not treat this class of agent as a broad clinical utility hub. For TheraDoc Workbench, the intended product shape is:

1. Therapist finishes a PT/OT/SLP treatment session.
2. User selects discipline + note type.
3. AdaptiveCard / closed-list buttons capture the session with minimal typing.
4. Agent generates a polished draft note.
5. Therapist reviews and personalizes before EHR entry.
6. Optional audit/compliance check runs on the draft.

If the user corrects the framing toward “click buttons, minimal typing, PT/OT/SLP documentation assistance,” immediately re-audit with this lens before making more changes.

## Audit checklist

- Confirm the active live agent, not just a similarly named legacy/managed/deprovisioned agent.
- Check local `.mcs/conn.json`, but do not blindly trust it; compare with `pac copilot list` output when available.
- Confirm entry points (`Greeting`, fallback/ambiguous menu, router) do not route into old free-text or out-of-scope workflows.
- Required main routes for the focused PT/OT/SLP version:
  - PT/OT/SLP x Daily Note
  - PT/OT/SLP x Evaluation
  - PT/OT/SLP x Progress Note
  - PT/OT/SLP x Recertification
  - PT/OT/SLP x Discharge
- Each card route should include:
  - `AdaptiveCardPrompt`
  - `SearchAndSummarizeContent` or approved generation action
  - display draft to clinician
  - audit/review route (`AuditExistingNote` or equivalent)
  - `EndDialog` with `clearTopicQueue: true`
- Run schema validation across all topic YAML after edits.

## Out-of-scope signals

For a focused post-session documentation assistant, flag/remove or archive topics that are not directly part of note capture, note generation, note review, or document processing. Examples:

- Cross-discipline conflict analysis
- EHR finalizer/submission workflow
- significant-change detector
- goal bank generator
- standalone skilled-justification builder
- plan-of-care generator
- nursing handoff
- DOR/leadership email
- regulatory transition manager
- duplicate legacy routers
- static guidance/help topics that do not participate in the flow

## Free-text intake pitfall

Legacy `*Intake` topics may be schema-valid but still product-wrong because they ask many free-text questions. For this class of agent, prefer replacing them with AdaptiveCard topics using choices, toggles, numeric fields, and only optional text boxes for personalization.

## ST vs SLP naming pitfall

If the user specifies PT/OT/SLP, treat `ST*` topics as potential legacy/remnant content unless the user explicitly wants Speech Therapy labeled as ST. Main routing should not silently include ST when scope is PT/OT/SLP.

## Document/OCR pitfall

A pasted-document processing topic is not the same as true binary OCR. If the user asks whether large-document OCR is wired, distinguish:

- pasted/scanned text processing topic: accepts text and summarizes/extracts
- true OCR action: connector/action for PDFs/images, e.g. a large-document processor action

Report honestly which is wired.
