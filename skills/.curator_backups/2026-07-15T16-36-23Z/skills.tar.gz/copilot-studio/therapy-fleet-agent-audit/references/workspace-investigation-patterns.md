# Workspace Investigation Patterns

How to quickly classify a local Copilot Studio workspace and detect signals that affect your audit approach.

## Workspace Classification

When you first enter a workspace directory, classify it:

### 1. Cloned Agent Workspace (manage-agent clone / pac copilot pull)

**Signals:**
- Has `agent.mcs.yml` at root
- Has `topics/` directory with `.mcs.yml` files
- Has `.mcs/conn.json` (may be disabled — see below)
- Has `settings.mcs.yml`, `knowledge/`, `actions/` subdirectories
- Contains GPT instructions in a component YAML or a separate `gpt/` file

**What you can do:** Full local audit — read topic YAMLs, instructions, knowledge config. Lint and validate.

### 2. Solution Archive (Power Platform export .zip + unpacked XML)

**Signals:**
- Has a `.zip` file (the solution package)
- Has `solution_unpacked/` directory
- Has `solution_unpacked/Other/Solution.xml`
- Contents organized by `botcomponents/`, `Workflows/`, `Assets/`
- **No** `agent.mcs.yml`, `topics/`, or `.mcs/` folder
- Bot component XML files reference a schema name that may differ from the workspace folder name

**What you can do:** Moderate — read workflow JSONs, entity definitions, attached knowledge file metadata. Can also audit topic YAML from `data` files under `botcomponents/*.topic.*/data` and GPT instructions from `botcomponents/*.gpt.*/data`. These `data` files are full YAML dialog bodies, not XML metadata.

**IMPORTANT — Multiple agent sub-configurations:** A single solution export can bundle multiple agents. Each unique header prefix in the `botcomponents/` folder names identifies a distinct agent sub-configuration. Example from POSTette Compliance Agent (2026-07-03): 8 headers (`024e0`, `0331e`, `3f0ed`, `55b3f`, `6271a`, `70a50`, `8c921`, `13225`) — each representing a different agent role (OT Specialist, SLP Specialist, Rules Engine, etc.). Always count unique headers before reporting agent scope.

**See `references/solution-export-yaml-extraction.md`** for the extraction workflow and common findings.

#### Solution ZIP Topic Extraction Methodology (proven 2026-07-03 on Pacific Coast Compliance Analyzer)

**Step 1 — Extract GPT instructions:**
```python
import zipfile
z = zipfile.ZipFile('solution.zip')
for name in z.namelist():
    if 'gpt' in name.lower() and 'default' in name.lower() and name.endswith('/data'):
        data = z.read(name).decode('utf-8', errors='replace')
        # Parse YAML — it's the agent's instructions and capabilities
```

**Step 2 — List all topics:**
```python
import zipfile
z = zipfile.ZipFile('solution.zip')
for name in sorted(z.namelist()):
    if '.TOPIC.' in name.upper() and name.endswith('/data'):
        topic_name = name.split('/')[1]  # e.g. CR917_AGENTU92BPC.TOPIC.SINGLENOTECOMPLIANCEAUDIT
        data = z.read(name).decode('utf-8', errors='replace')
        # data contains the topic YAML — query for EndDialog, Questions, ConditionGroups, etc.
```

**Step 3 — Analyze every topic for audit signals:**
```python
results = {}
for name in sorted(z.namelist()):
    if name.endswith('/data') and '.TOPIC.' in name.upper():
        data = z.read(name).decode('utf-8', errors='replace')
        results[topic_name] = {
            'EndDialog': 'EndDialog' in data,
            'clearTopicQueue': 'clearTopicQueue' in data,
            'Questions': data.count('kind: Question'),
            'ConditionGroup': 'ConditionGroup' in data,
            'SearchSpecificFiles': 'SearchSpecificFiles' in data,
            'SearchSpecificKnowledgeSources': 'SearchSpecificKnowledgeSources' in data,
            'SearchAndSummarizeContent': 'SearchAndSummarizeContent' in data,
        }
```

**Step 4 — Extract knowledge file content:**
```python
for name in sorted(z.namelist()):
    if '.file.' in name.lower() and 'filedata' in name:
        # knowledge markdown files — read the file content
```

**Step 5 — Read bot.xml for agent metadata:**
- `bots/<schemaName>/bot.xml` — agent configuration

**Naming conventions in solution exports:**
- Topic component names use UPPERCASE with bot prefix (e.g., `CR917_AGENTU92BPC.TOPIC.SINGLENOTECOMPLIANCEAUDIT`)
- GPT instructions at: `botcomponents/<prefix>.gpt.default/data`
- File knowledge at: `botcomponents/<prefix>.file.<Name>_<hash>/filedata/<filename>.md`
- Web knowledge at: `botcomponents/<prefix>.topic.<URL-slug>_<hash>/data`

### 3. Stub/Empty Workspace

**Signals:**
- Empty directories or directories with only `.qodo/` or IDE metadata
- No topic files, no agent.mcs.yml, no solution artifacts

**What you can do:** Nothing locally. Must clone from live environment.

## Disconnected Workspace Signals

**DO NOT PUSH or APPLY CHANGES** when you see these:

| Signal | What It Means |
|--------|---------------|
| `DO-NOT-APPLY-CHANGES.md` | Explicit user warning — the workspace is stale and was overwriting live state |
| `conn.json.DISABLED-<date>` | The `conn.json` was renamed to prevent accidental push — workspace cannot reach the live environment |
| `conn.json.DISABLED-*` (any variant) | Same intent — prevents the Copilot Studio VS Code extension from applying changes |
| Last modified date on files > 30 days before latest publish date | Workspace is stale — live agent has diverged significantly |

**Action:** Read-only analysis only. Use live audit data (API dumps, eval results) as the source of truth. If changes are needed, the user must re-clone or re-sync first.

## Schema Name vs Display Name Mismatch

The `schemaName` in the solution solution.xml or botcomponent XML files may reference a **different agent** than the workspace folder name implies.

Example from 2026-07-03: `Meta-Agent Builder/` workspace contained solution components with schema `cr917_simpleLtcQmClinicalCoachingCopilot` — which is the SimpleLTC QM Clinical Coaching Copilot, not Meta-Agent Builder. The solution (`HealthcareAgentsFoundation`) is a shared foundation layer, not the agent's own topic set.

## Registry Agents Without Local Workspaces

Some agents listed in the Therapy AI Dev Registry may:
- Have no local workspace directory at all
- Have a workspace that is only a solution archive (not a cloned agent)
- Have been deprovisioned or renamed in the live environment

Always verify workspace contents before reporting topic/instruction counts. If the workspace is a solution archive, note it in the audit as "no local topic YAML available — solution archive only" rather than reporting 0 topics/instructions.

## Utility Agents Pattern

Utility agents (CoE Autonomous Agent Builder, Meta-Agent Builder) in the registry may be:
- Solution exporters that bundle shared foundation components (workflows, entities, knowledge files used by multiple agents)
- Not individual Copilot Studio agents with their own topics/instructions

Treat utility agents differently from therapy documentation agents — their workspace may be a shared solution rather than an agent-specific clone. Do not assume a utility agent has its own topic set or instructions until you verify.
