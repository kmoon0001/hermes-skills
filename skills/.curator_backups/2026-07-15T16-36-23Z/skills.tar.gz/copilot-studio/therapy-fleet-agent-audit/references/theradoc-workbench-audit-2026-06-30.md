# TheraDoc Workbench Audit Findings — Jun 30, 2026

## Agent Identity
- **Bot ID:** `e09954e1-4af8-47c6-8ef4-d1d9335bf2e6`
- **Schema:** `pcca_theradocworkbench`
- **Local workspace:** `D:/my agents copilot studio/TheraDoc/`
- **Purpose (corrected Jun 30):** Post-session PT/OT/SLP documentation assistant — click buttons (AdaptiveCards) to capture session data with minimal typing, AI generates polished clinical note, therapist reviews and personalizes.
- **56 custom topics → 27 after scope cleanup, 13 system topics, 9 actions, 18 knowledge sources**

## Corrected Purpose Statement

Kevin corrected the initial audit framing (Jun 30 2026). The agent is NOT a general-purpose documentation workbench. It is specifically:
- **Post-session** — therapist documents AFTER completing a treatment session
- **Click buttons** — AdaptiveCards with ChoiceSets, not free-text Question nodes
- **Minimal typing** — only free text for things that truly need it (clinical observations)
- **AI generates the note** — therapist reviews and personalizes
- **PT/OT/SLP only** — not nursing, not compliance analysis, not EHR submission

This means: CrossDisciplineConflictAuditor, EHRFinalizerGateway, SignificantChangeDetector, GoalBankGenerator, SkilledJustificationBuilder, PlanOfCareGeneration, NursingHandoff, DoRSUMMARYEMAIL, DocumentationGuidance, ComplianceHelp, FormatPreference, PartAPartBTransitionManager are OUT OF SCOPE.

## Scope Cleanup (Completed Jun 30 2026)

### Topics Removed (35 marked for removal)
See `REMOVAL_MANIFEST.txt` in TheraDoc workspace.

Groups:
- **14 out-of-scope** (analysis, compliance, regulatory, utility)
- **17 replaced by Card topics** (Intake topics with 10-28 free-text questions)
- **4 shared topics** (replaced by discipline-specific Cards)

### Topics Kept (27 custom)
**Core orchestration (10):**
NoteIntakeRouter, MasterPatientContext, AmbiguousRequestDisambiguation, AuditExistingNote, NoteReviewandFinalize, ParseBrainDump, RedoReviseNote, SessionClose, StartOver, ErrorTimeoutRecovery

**Fixed Cards (7 — added generation):**
PTDailyNoteCard, OTDailyNoteCard, SLPDailyNoteCard, PTEvaluationCard, OTEvaluationCard, SLPEvaluationCard, RecertificationDischargeCard

**New Cards (10 — created):**
PTProgressNoteCard, PTRecertCard, PTDischargeCard, OTProgressNoteCard, OTRecertCard, OTDischargeCard, SLPProgressNoteCard, SLPRecertCard, SLPDischargeCard, STDailyNoteCard

### NoteIntakeRouter Updated
- Simplified to 2-step flow: Note Type → Discipline → Route to Card
- Removed utility actions (FinalizeEHR, ConflictAudit, AuditNote, LoadPatient)
- All 9 discipline/note-type combos route to proper Card topics

## HIGH Findings (Original — All Addressed)

### H1. Duplicate Routing — NoteIntakeRouter vs GenerateNoteOrchestration
- **Status:** RESOLVED — GenerateNoteOrchestration marked for removal

### H2. Card Topics Are Data Sinks (No Note Generation)
- **Status:** RESOLVED — Added SearchAndSummarizeContent + AuditExistingNote + EndDialog to all 7 existing Card topics

### H3. Orphan Discipline-Specific Topics
- **Status:** RESOLVED — Replaced with new Card topics, orphans marked for removal

### H4. Missing OCR/Document Upload Topic
- **Status:** PENDING — OCR topic scaffold not yet created

### H5. SLPProgressNoteIntake DUPLICATE QUESTION SETS
- **Status:** RESOLVED — SLPProgressNoteIntake marked for removal, replaced by SLPProgressNoteCard

### H6. SLPRecertificationIntake VARIABLE ORDER BUG
- **Status:** RESOLVED — SLPRecertificationIntake marked for removal, replaced by SLPRecertCard

### H7. OT/ST Daily Note Intakes Call PT-Named Flow
- **Status:** RESOLVED — OTDailyNoteIntake and STDailyNoteIntake marked for removal

### H8. RecertificationDischargeCard is a DEAD-END
- **Status:** RESOLVED — Added generation to RecertificationDischargeCard

## MEDIUM Findings

### M1. AuditExistingNote — Empty ConditionGroup
- **Status:** NOT YET FIXED — needs live UI cleanup

### M2. EHRFinalizerGateway — Out of Scope
- **Status:** Marked for removal

### M3. ParseBrainDump — String Interpolation Issue
- **Status:** NOT YET FIXED

### M4. No clearTopicQueue: true on EndDialog Nodes
- **Status:** RESOLVED — All new/fixed Card topics have clearTopicQueue: true

### M5. CrossDisciplineConflictAuditor — Out of Scope
- **Status:** Marked for removal

## Topic Coverage Matrix (After Cleanup)

| Note Type | PT | OT | SLP | ST |
|-----------|-----|-----|------|-----|
| Daily Note | Card | Card | Card | Card |
| Evaluation | Card | Card | Card | — |
| Progress Note | Card | Card | Card | — |
| Recertification | Card | Card | Card | — |
| Discharge | Card | Card | Card | — |

All Card topics follow the pattern: AdaptiveCard → SearchAndSummarizeContent → SendActivity → AuditExistingNote → EndDialog(clearTopicQueue:true)

## Remaining Work
1. Create OCR topic (DocumentUploadAndOCR)
2. Fix AuditExistingNote empty ConditionGroup (live UI)
3. Fix ParseBrainDump string interpolation
4. Push local changes to live agent
5. Remove 35 out-of-scope topics from live agent
6. Create ST Evaluation, Progress, Recertification, Discharge Cards if needed
