# Trailing-Question Pattern — SR Eval Risk

**Discovered:** 2026-07-03 — QM Coach V2 audit
**Fleet prevalence:** All 13 QM Coach V2 custom topics
**Distinct from:** `kind: Question` / `kind: AdaptiveCardPrompt` nodes (which the existing ConditionGroup+Question recipe addresses)

## The Pattern

A topic's `SendActivity` ends with a natural-language follow-up question embedded in the activity text — NOT a formal `kind: Question` node:

```yaml
- kind: SendActivity
  id: answer
  activity: |
    Here is the escalation matrix...

    Would you like to start an escalation for a specific concern?
```

All 13 QM Coach V2 topics follow this exact pattern:

| Topic | Trailing Text |
|-------|--------------|
| escalate_qm_concern | "Would you like to start an escalation for a specific concern?" |
| qm_driver_analysis | "Which driver category would you like to analyze?" |
| qm_action_plan | "Which quality measure needs an action plan?" |
| clinical_intake_handoff | "Would you like to start routing a specific intake?" |
| qm_email_generator | "Would you like me to generate a draft email template?" |
| facility_trend_reporter | "Would you like to analyze trends for specific measures?" |
| qm_severity_classification | "Do you have a specific concern to classify?" |
| hitl_approval | "Would you like to submit a concern for HITL review?" |
| workflow_menu | "Which workflow to start?" |
| accountability_matrix | "What QM action needs accountability mapping?" |
| coaching_corner | "Which QM measure needs coaching?" |
| escalation_matrix | "Do you need to escalate a specific concern?" |
| qm_data_upload_decline_detection | "What facility, reporting period, and QM export should I analyze?" |

## Why It Matters

In **Single Response** evaluation mode, each test case is one-shot. The grader sends a query and expects a definitive answer back. A trailing question — even a text-only one — is treated as **abandonment/non-response** by strict graders because:

1. The bot asked for more input instead of providing the answer.
2. The grader cannot (and should not) simulate a follow-up response.
3. The bot's final turn content reads like a question, not an answer.

This is **not** the same as the known `kind: Question` node issue (which kills SR evals via interactive content routing). A trailing question in plain text is subtler — it passes schema validation, doesn't trigger linter rules, and looks conversational. But the eval grader doesn't care about the schema — it cares about whether the final message is an answer or a question.

## Detection During Audit

1. For every custom topic with `SendActivity` as the terminal action before `EndDialog`, inspect the `activity:` text.
2. Look for sentences ending in `?` — especially transactional questions:
   - "Would you like...?"
   - "Which [X] would you like...?"
   - "Do you have a specific [Y] to...?"
   - "What [data] should I...?"
3. Flag them for SR eval risk even though they are not formal Question nodes.

## Remediation

Two options depending on design intent:

### Option A: Remove trailing question (for SR-focused topics)

Delete the final question sentence from the activity text. The topic provides the information directly and ends definitively:

```yaml
activity: |
  To escalate a QM concern:
  
  Level 1 — Staff Level (0-24 hours): ...
  Level 2 — Management (24-48 hours): ...
  
  Document the issue with specific findings, classify severity, and notify appropriate parties within timeframes.
```

### Option B: Replace trailing question with an offer (for conversational topics)

If the topic is meant to be interactive in Conversational eval but needs to pass SR, separate the two paths:

```yaml
- kind: SendActivity
  activity: |
    Here is the escalation matrix...
    
    If you have a specific concern to escalate, tell me the details and I will walk you through the process.
```

"Tell me the details" is an offer/instruction, not a question — it's more likely to be graded as a valid response.

## Relation to Existing Patterns

| Pattern | Documented? | Detection |
|---------|------------|-----------|
| `kind: Question` node | Yes (Copilot Studio Pipeline skill) | YAML structural — easy to regex |
| `kind: AdaptiveCardPrompt` | Yes (Copilot Studio Pipeline skill) | YAML structural — easy to regex |
| **Trailing question in SendActivity text** | **This file** | Content inspection — requires reading activity text |

The trailing-question pattern is harder to detect automatically but equally damaging to SR scores. Add it to every audit checklist alongside the structural checks.
