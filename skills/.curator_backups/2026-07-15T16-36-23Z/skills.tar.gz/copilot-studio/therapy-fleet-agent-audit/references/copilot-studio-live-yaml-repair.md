# Copilot Studio live YAML repair via Playwright/CDP

Use this when local Copilot Studio topic YAML parses cleanly but the live draft topic in Copilot Studio/Dataverse has broken YAML and needs source-of-truth UI evidence.

## Decision ladder

1. Confirm scope before any edit.
   - Read the audit/report config for `envId`, `tenantId`, `envUrl`, and `botId`.
   - Copilot Studio URLs use the environment ID, not always `Default-<tenantId>`.
   - A `Default-<tenantId>` URL can open the wrong environment and show "link is broken" even when the bot/component IDs are valid.

2. Prefer deterministic Playwright/CDP for UI evidence.
   - Launch or attach to Edge/Chrome with CDP.
   - Navigate to the exact Copilot Studio environment/bot/topic URL.
   - Capture screenshots before editing.
   - Verify the top bar environment label, agent name, topic name, and that Publish was not invoked.

3. Use the topic editor UI when it responds.
   - The topic canvas can contain multiple `More` buttons.
   - The topic-toolbar `More` is usually the larger visible button near the topic title; the test-pane `More` opens test options only.
   - Before clicking `Open code editor`, inspect menuitem bounding boxes/text so you do not click the test pane menu.
   - If `Open code editor` is visible but clicking it creates no console/network activity, do not loop on clicks. Switch to an authenticated source repair path.

4. For Dataverse reads/writes, use the supported authenticated path for the current session.
   - Browser-session `fetch(..., credentials:'include')` from the Dataverse origin is preferred for UI-authenticated repairs.
   - Browser-session fetch from the Copilot Studio origin may be blocked by CORS for Dataverse API calls.
   - If using browser-session fetch, navigate/sign in to the Dataverse origin (`https://<org>.crm.dynamics.com`) first so same-origin authenticated fetches can be made. If Microsoft prompts for password/verification, stop and have the user enter it directly in the browser.
   - Direct bearer-token reads are useful for inspection; do not assume direct bearer PATCH has the same server-side semantics as the Copilot Studio UI.

5. Normalize local exported topic files before using as live topic body.
   - Local `.mcs.yml` exports can include `mcs.metadata` and comments that validate locally but are not the topic body Copilot Studio expects in live `content`.
   - Extract from the first line matching `^kind: AdaptiveDialog$` through EOF.
   - Parse with `js-yaml` and require `kind: AdaptiveDialog` plus `beginDialog` before any write.

6. Never publish as part of repair verification.
   - Save draft/source only.
   - Re-read live component content after the write.
   - Re-run the scanner and preserve a repair summary with before/after versions and screenshots.

## Minimal normalization snippet

```js
function normalizeTopicBody(txt) {
  txt = txt.replace(/^\uFEFF/, '').replace(/\r\n/g, '\n');
  const idx = txt.search(/^kind:\s*AdaptiveDialog\s*$/m);
  if (idx < 0) throw new Error('no kind: AdaptiveDialog line found');
  return txt.slice(idx).trimStart();
}
```

## Evidence checklist

- Screenshot: signed-in Copilot Studio home or target page.
- Screenshot: correct environment label (for Therapy fleet, `Therapy AI Agents Dev`).
- Screenshot: agent/topic editor page before repair.
- JSON/text capture: current URL, document title, visible page text, button/menu inventory.
- Before backup: live component record including name, content/data, modifiedon/versionnumber.
- After verification: re-read record, parse content, compare normalized content, rerun scanner.
