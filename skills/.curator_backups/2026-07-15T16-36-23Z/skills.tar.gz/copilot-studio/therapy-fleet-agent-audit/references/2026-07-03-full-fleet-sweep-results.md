# Therapy AI Dev Fleet Sweep — Jul 3, 2026

Full analysis → fix → QA pass of all Therapy AI Agents Dev agents with local workspace YAMLs.

## Environment

- **Org:** `https://orgbd048f00.crm.dynamics.com`
- **Env ID:** `a944fdf0-0d2e-e14d-8a73-0f5ffae23315`
- **Tenant:** `03cc92c3-986c-4cf4-ae27-1478cf99d17f`

## Results by Agent (Ordered by Original P0 Count)

| # | Agent | Bot ID | P0 Orig | P1 Orig | P0→ | Fixes | QA |
|:-:|-------|--------|:-------:|:-------:|:---:|:-----:|:--:|
| 1 | **Compliance Analyzer** | `19779839-7b6e-4362-925b-8ddf03979f7d` | ~73 | 4 | ~0 | EndDialog on 44/44 topics, eval sections added, boilerplate stripped | ✅ |
| 2 | **Therapy Report Prep V2** | `fd1bce12-cf47-f111-bec5-70a8a5b1c3a3` | ~49 | 5 | ~7 | EndDialog on 20 topics, root agent.mcs.yml created (was empty), 2 corrupted files fixed | ✅ |
| 3 | **POSTette Compliance** | `03b08692-aa24-4159-986b-cfad8fed6865` | 20+ | 9 | ~0 | EndDialog on 25 topics, 10 SearchSpecificFiles removed, 5 hollow topics fixed, 5 OnActivity→OnRecognizedIntent, 8 GPT configs updated | ✅ |
| 4 | **Regulatory Hub V2** | `ea901efc-d043-4023-88a6-8ac4c561a4d5` | 15+ | 8 | ~0 | EndDialog on 21 topics, 2 EndConversation replaced, 3 boilerplate blocks removed, "Button-First UX"→"Flexible Input UX" instruction fix | ✅ |
| 5 | **QM Coach V2** | `ea52ad9c-8233-f111-88b3-6045bd09a824` | 12 | 4 | ~0 | clearTopicQueue:true on 12 EndDialogs, 14/14 YAML valid | 🟡 QA |
| 6 | **Clinical Synthesis V2** | `89c7415d-df73-490c-9d78-4829cfbc2f84` | 10 | 14 | ~0 | EndDialog on 14 topics, CancelAllDialogs→EndDialog, 18 boilerplate blocks, useModelKnowledge:true, contentModeration:High | ✅ |
| 7 | **TheraDoc Workbench** | `e09954e1-4af8-47c6-8ef4-d1d9335bf2e6` | 7 | 4 | ~0 | EndDialog on 5 topics, empty ConditionGroup removed, string interpolation fix, Recertification card discipline fix, ST→SLP routing fix, 14 boilerplate blocks | ✅ |
| 8 | **SNF AI Dashboard V2** | `bd570423-cf47-f111-bec5-70a8a5b1c3a3` | Multi | — | ~0 | EndDialog on 47/49 topics (2 system exempt), 46 boilerplate blocks removed, eval sections added | ✅ |
| 9 | **SNF Command Center V2** | `9f3e370c-a747-f111-bec6-0022480b6bd9` | Multi | — | ~0 | EndDialog on 5 custom topics, 14 boilerplate blocks, removed "ACTIVE WORD DOCUMENT" contradiction, fixed unconditional RESPONSE FORMAT | 🟡 QA |
| 10 | **Denial Defense V2** | `6d7815b4-ce47-f111-bec5-70a8a5b1c3a3` | 4 | 5 | ~0 | EndDialog + clearTopicQueue on 2 topics, Question nodes removed, eval sections added, boilerplate cleaned | ✅ |
| 11 | **TDA Audit Agent** | (from workspace) | 3 | 4 | 3 | eval sections added to agent.mcs.yml. Workspace stale/disconnected — topic fixes not possible (stubs only) | 🟡 QA |
| 12 | **Therapy Feedback B** | `1c601ace-5255-f111-bec6-000d3a37eba2` | 1 | 8 | ~0 | 800-char cap already removed, SearchSpecificFiles already removed from 6 topics, eval sections added | 🟡 QA |
| — | **PC Case Historian V2** | `ad635500-cf47-f111-bec5-70a8a5b1c3a3` | 5 | 0 | ~0 | Fixed in earlier session (Jun 26). Loop 1: contradiction fixes, no-caveat block, eval-safe section added | ✅ |

## Report-Only Agents (no local workspace YAMLs)
- CoE Autonomous Agent Builder (`8f33b0e3-...`) — solution archive only
- Meta-Agent Builder (`4e00c251-...`) — solution archive only
- PacCoast Medicare Meeting (`ee72fe1a-...`) — empty workspace (AGENT.md only)

## Fleet-Wide Patterns Confirmed

### #1 P0 Across All Agents: Missing EndDialog + clearTopicQueue
- 200+ topics across 12 agents had no EndDialog (or had EndDialog without clearTopicQueue)
- Single systemic fix resolved the majority of P0 issues fleet-wide
- **Bulk fix pattern:** add `kind: EndDialog` with `clearTopicQueue: true` after the last action in `beginDialog.actions` for every custom topic
- Always create `.bak` backup first. Validate all YAML with js-yaml after.

### #2 P0 Across All Agents: No Evaluation-Safe Instruction Sections
Every agent needed:
1. `EVAL NO-CAVEAT STANDARDS CHECK` — prevent refusal when no document text provided
2. `EVALUATION-SAFE ORCHESTRATION` — direct answers, no follow-up questions, complete responses
3. Conditional (not unconditional) RESPONSE FORMAT guidance

### Common P1 Patterns
- Empty ConditionGroups (conditions with zero actions)
- Hardcoded discipline variables in search strings
- Old Platinum Standard comment boilerplate (12-line blocks at top of topic files)
- Broad/overlapping trigger phrases
- Instructions over 6000-char ceiling

## Key Pitfalls Discovered

1. **Working YAML may be at nested path**: Compliance Analyzer's actual YAML was at `build_atomic_v3/Chatbots/<schema>/` not workspace root
2. **Dual-agent workspaces**: Therapy Report Prep had root agent.mcs.yml (empty) + SNF Rehab Agent/ sub-agent with actual instructions
3. **Duplicate topic representations**: Clinical Synthesis Lab had 3 representations of the same topic (authored .mcs.yml, sub-dialog .topic.yaml, compiled solution export)
4. **dump_agent_full.cjs returns 0 for Therapy Dev**: Script auth is scoped to Ensign Default, not Therapy Dev. Prefer local source audit.
5. **Never trust subagent self-reports**: QA subagent must read actual file content and compare against .bak originals
6. **ST vs SLP naming**: Several agents used "ST (Speech Therapy)" instead of "SLP (Speech-Language Pathology)"
7. **Hollow topics**: Topics that match via triggers but produce only "cannot provide advice" refusals — these guarantee eval failure
8. **Structured-intake-only anti-pattern**: Agents where every topic collects intake but produces nothing (no SearchAndSummarizeContent, placeholder SendActivity only)
