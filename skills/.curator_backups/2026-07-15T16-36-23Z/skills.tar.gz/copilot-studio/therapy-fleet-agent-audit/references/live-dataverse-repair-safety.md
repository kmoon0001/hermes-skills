# Live Dataverse repair script safety notes

Use these notes when repairing Copilot Studio live component YAML in Therapy AI Dev.

## Scope and write guards

- Hard-code or otherwise assert the allowed environment before any live call: `https://orgbd048f00.crm.dynamics.com`.
- Include an explicit blocked-environment guard for Ensign Default: `org3353a370.crm.dynamics.com`.
- Do not keep `https://org3353a370.crm.dynamics.com` as a live target literal in the script.
- Require an explicit `--apply` flag for any PATCH. Default mode must be DRY-RUN.

## Component-data quirks

- Dataverse component names may be null or missing. Build backup filenames from a safe fallback chain such as `name || schemaname || botcomponentid || 'unnamed-component'` and sanitize/truncate the result.
- Prefer patching only the `data` field for YAML body repairs; back up before and after text under a timestamped audit-results folder.

## Avoid noisy live PATCHes

Do not live PATCH cosmetic CR/BOM-only normalization by itself. It creates churn and can explode into hundreds of low-value updates.

Use a material-change filter and only PATCH changes that actually repair behavior, parsing, or routing, for example:
- scalar-to-block fixes for malformed `text`, `prompt`, or `activity` fields,
- invalid control-character cleanup that blocks parsing,
- `clearTopicQueue: true` insertion when needed,
- indentation/quote/card-content repairs that make YAML parse.

## Post-apply verification

After `--apply`:
1. Run the live repair script again without `--apply`.
2. Confirm live read/auth succeeds (`components read=` appears).
3. Confirm `PATCHED` count is 0 in dry-run.
4. Confirm `PATCH_ERROR` count is 0.
5. Confirm no `WOULD_PATCH` lines remain for the script's safe auto-fix class.
6. Report remaining `UNFIXED` lines separately as deeper targeted repairs or local-to-live replacement candidates.

This is ad-hoc verification, not canonical suite green.