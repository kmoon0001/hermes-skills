# Ensign Default Fleet Audit — 2026-07-04

Environment: `org3353a370.crm.dynamics.com` | Tenant: `03cc92c3` | GW: `powervamg.us-il106`

## Fleet at a Glance

| Agent | Bot ID | Topics | P0 | P1 | State |
|-------|--------|--------|----|----|-------|
| SLP_Specialist | 6e437a77-a5dc-4984-90eb-4924eab10006 | 7 | 0 | 0 | ✅ Clean |
| PT_Specialist | 593407f3-539b-490f-84ac-d74e13216c81 | 11 | 2 | 2 | ⚠️ Minor |
| OT_Specialist | 73b45e98-af7a-443a-aa12-6d8a05118530 | 12 | 1 | 6 | ⚠️ Minor |
| Feedback B | 1c601ace-5255-f111-bec6-000d3a37eba2 | 13 | 6 | 2 | ⚠️ Moderate |
| TDA | 4d0ed0d3-30f6-f011-8406-000d3a37eba2 | 15 | 6 | 2 | ⚠️ Moderate |
| Report_Prep | c030a53a-4839-f111-88b4-000d3a37eba2 | 38 | 45 | 4 | 🔴 Critical |
| **TOTAL** | | **96** | **60** | **16** | |

All agents Published/Active. No local workspaces exist — live Dataverse audit only.

## Fleet-Wide Patterns

### Escalate topic: 42 triggers on every agent that has it
PT, OT, TDA, and Feedback B all have an Escalate topic with exactly 42 trigger phrases. MS Learn recommends 5-10. Copy-paste artifact.

### ~5,000 trigger phrase components per specialist
PT (4,980), OT (4,986), SLP (4,976), TDA (4,979) each have ~5,000 trigger phrase component records. Most are AI-generated near-duplicates. Report_Prep has 638; Feedback B has 0 standalone.

### System topics commonly lack termination
Sign in lacks EndDialog on PT, OT, TDA, Feedback B. Multiple Topics Matched lacks on PT, TDA, Feedback B. End of Conversation lacks on TDA only.

### SLP_Specialist is the gold standard
All 7 topics have EndDialog+clearTopicQueue:true. Every custom topic has exactly 5 varied trigger phrases. 16 knowledge sources (8 web + 8 file).

### Report_Prep_Assistant is systemic failure
33/38 topics lack dialog termination. 13 topics with zero trigger phrases. 3 duplicate topic records (EvalAnalysis, ClassifyAndRouteRehabRecord, ProgressAnalysis). Public web search (cms.gov, ecfr.gov) on 3 topics contradicts instructions saying "use only approved knowledge."

## Audit Method

Query via `az rest` (handles claims challenges that raw `az account get-access-token` doesn't):
```bash
az rest --method GET \
  --resource "https://org3353a370.crm.dynamics.com/" \
  --url "https://org3353a370.crm.dynamics.com/api/data/v9.2/botcomponents?\$filter=_parentbotid_value eq {botId}&\$select=name,componenttype,data,statecode,statuscode,componentstate"
```

Component types parsed: 9=topics, 14=file knowledge, 15=instructions, 16=web knowledge, 19=trigger phrases.

MS Learn grounding: evaluation triage framework (overview, failure triage, remediation mapping, pattern analysis), agent instructions best practices, trigger phrase best practices (5-10 per topic).
