# Local safe repair batches for Therapy AI Dev fleet audit

Use this reference when the user asks to continue fleet QA/remediation but explicitly says not to publish, or when the safest next step is local-source cleanup before live/UI repair.

## When to choose a local-only batch

Choose local-only repairs first when backlog contains high/medium issues in local `agent.mcs.yml` metadata that are safe to validate without Dataverse writes:
- missing or weak `conversationStarters`
- missing Microsoft Learn-aligned orchestration/routing language
- missing healthcare/HITL/disclaimer/regulatory guardrails in `instructions`
- empty or truncated local instruction bodies

Do not use local-only edits to claim that live Copilot Studio draft or published behavior changed. Local-source repair only prepares source for a later push/UI/live repair path.

## Microsoft Learn-aligned local metadata pattern

For each edited `agent.mcs.yml`, verify these elements:
- `kind: GptComponentMetadata`
- `displayName` present
- clear role and scope in `instructions`
- generative-orchestration language that treats topic/tool/knowledge/connected-agent names and descriptions as routing signals
- human-in-the-loop clinician review before EHR, care-plan, billing, denial, resident/family, or operational action
- PHI/HIPAA least-necessary handling
- therapy/regulatory grounding when relevant: CMS Chapter 15, Jimmo, MDS 3.0/Section GG, PDPM, APTA, AOTA, ASHA
- safety/privacy terminology when relevant: NIST, FDA clinical-decision-support boundaries, CFR, OMG/CMS interoperability
- explicit disclaimer text, e.g. `All outputs are DRAFT - CLINICAL REVIEW REQUIRED`
- at least 10 workflow-specific `conversationStarters` with short, complete, safe prompts

## Verification sequence

After each batch:
1. Parse the edited YAML with `js-yaml` or equivalent.
2. Count `conversationStarters` and check guardrail keywords programmatically.
3. Run `pipeline/scripts/schema-lookup.bundle.js validate <agent.mcs.yml>` on every edited metadata file.
4. Run `node --check scratch/therapy-fleet-autonomous-qa-loop.cjs` if the scanner was modified.
5. Rerun the read-only scanner: `node scratch/therapy-fleet-autonomous-qa-loop.cjs --scan`.
6. Report pre/post backlog counts, remaining critical/high issues, and exact scanner output directory.

## Reporting language

Be explicit:
- `NOT PUBLISHED. No publish command was run.`
- `Local source only` unless a live Dataverse/UI repair actually succeeded and was verified.
- If a live PATCH attempt failed before any material change, do not describe it as a fix; only mention successful local edits and verified scanner results.

## Prioritization note

Critical live YAML parse blockers remain highest overall priority, but they require the live/UI repair workflow: backup exact live records, make minimal draft/data repair, reread records, verify Copilot Studio UI evidence, and only then consider publish after explicit user approval.
