# Ensign Default Live-Dataverse Audit Pattern

**Proven:** Jul 4 2026 — Therapy Documentation Feedback B + Therapy_Report_Prep_Assistant

## Overview

When auditing agents on Ensign Default (`org3353a370`), there are NO local workspaces. The entire audit runs live against the Dataverse API. This reference captures the specific auth gotchas, query patterns, and analysis approach for this environment.

## Auth Pattern (CRITICAL)

```bash
# Correct (trailing slash REQUIRED):
TOKEN=$(az account get-access-token --resource "https://org3353a370.crm.dynamics.com/" --query accessToken -o tsv)

# Wrong — returns 401 on ALL calls:
TOKEN=$(az account get-access-token --resource "https://org3353a370.crm.dynamics.com" --query accessToken -o tsv)
```

**Always verify** with a WhoAmI probe before running the full audit:
```bash
curl -s -w "\nHTTP:%{http_code}" -H "Authorization: Bearer $TOKEN" \
  "https://org3353a370.crm.dynamics.com/api/data/v9.2/WhoAmI"
```

Expected: HTTP 200 with JSON user data. If 401, double-check the trailing slash.

## Botcomponent Query Pattern

```bash
# Save full component dump
curl -s -H "Authorization: Bearer $TOKEN" -H "Accept: application/json" \
  "https://org3353a370.crm.dynamics.com/api/data/v9.2/botcomponents?\$filter=_parentbotid_value%20eq%20'<botId>'&\$select=name,componenttype,data,content,statecode,statuscode,componentstate" \
  > agent_botcomponents.json

# Verify component count
python3 -c "import json; d=json.load(open('agent_botcomponents.json')); print(len(d['value']),'components')"
```

## Component Type Reference

| Type | Name | What to analyze |
|------|------|----------------|
| 9 | Topic / AdaptiveDialog | EndDialog, clearTopicQueue, trigger phrases, Question nodes, SearchAndSummarizeContent |
| 14 | File Knowledge | Uploaded PDFs, Dataverse files |
| 15 | GptComponentMetadata / Instructions | Size, guardrails, model hint, web browsing/code interpreter settings |
| 16 | Web / SharePoint Knowledge | Public sites, SharePoint sources, FederatedStructuredSearchSource |
| 19 | Trigger Phrase / EvaluationData | Count, source (Generated/Imported/Manual), deduplication |

## Analysis Dimensions (Live-Dataverse-Only)

### Instructions (type 15)
- Size check: >6,000 chars is oversized (costs context window)
- Guardrails: count explicit numbered rules; fewer than 5 is a gap
- Model hint: Sonnet46 vs GPT5Chat — determines reasoning style
- Web browsing: should be `false` for clinical agents with configured knowledge
- Sections: Role, Objective, Context, Sources, Guardrails, Output Format — each missing section is a P1

### Topics (type 9)
For each topic:
1. **Termination check (P0):** Must have `EndDialog`+`clearTopicQueue`, `CancelAllDialogs`, or `EndConversation`. Exception: `OnConversationStart` topics are entry points that don't need termination.
2. **Trigger phrases (P0/P1):** Zero triggers on an `OnRecognizedIntent` topic = P0 (unreachable). <5 triggers = P1 (MS Learn minimum). >30 triggers = flag (bloats NLU, increases false matches).
3. **Node inventory:** Question nodes (may fail SR eval if multiple), SearchAndSummarizeContent (uses knowledge), SendActivity (has output).
4. **Public data sources:** `publicDataSource` in a SearchAndSummarizeContent node means live web search, bypassing configured knowledge. Flag as P1 if it contradicts instruction-level "use only approved knowledge" guardrails.
5. **Duplicate topics:** Two components with the same name (one populated, one empty) = orphaned stale record. Flag as P1 for cleanup.

### Knowledge (types 14, 16)
- FederatedStructuredSearchSource vs PublicSiteSearchSource — the former uses SharePoint/configured knowledge; the latter hits public web
- PDF-named sources using FederatedStructuredSearchSource may be misconfigured — verify they actually resolve
- Check that instructions reference the configured knowledge sources by name

### Trigger Phrase Components (type 19)
- Total count > 100 = excessive. Deduplicate AI-generated near-duplicates.
- Source breakdown (Generated vs Manual vs Imported): high Generated count signals unreviewed AI output.

## Python Analysis Script Pattern

For a direct Python analysis after JSON download:

```python
import json, re

with open('agent_botcomponents.json') as f:
    data = json.load(f)

# Categorize by type
types = {9: 'Topic', 14: 'FileKnowledge', 15: 'Instructions', 16: 'WebKnowledge', 19: 'TriggerPhrase'}
cats = {}
for c in data['value']:
    t = types.get(c['componenttype'], f"Unknown({c['componenttype']})")
    cats.setdefault(t, []).append(c)

# Analyze each topic
for c in cats.get('Topic', []):
    d = c.get('data') or ''
    has_end_dialog = 'EndDialog' in d
    has_clear_topic = 'clearTopicQueue' in d
    has_cancel_all = 'CancelAllDialogs' in d
    has_end_conv = 'EndConversation' in d

    # Count triggers
    triggers = []
    in_triggers = False
    for line in d.split('\n'):
        if 'triggerQueries:' in line:
            in_triggers = True; continue
        if in_triggers:
            s = line.strip()
            if s.startswith('- '): triggers.append(s[2:])
            elif s and not s.startswith(' '): in_triggers = False

    severity = 'OK'
    issues = []
    if not (has_end_dialog or has_cancel_all or has_end_conv):
        if 'OnConversationStart' not in d:
            issues.append('P0: No termination')
            severity = 'P0'
    if 'OnRecognizedIntent' in d and len(triggers) == 0:
        issues.append('P0: Zero triggers')
        severity = 'P0'
    elif 0 < len(triggers) < 5:
        issues.append('P1: <5 triggers')

    print(f"[{severity}] {c['name']}: triggers={len(triggers)}, EndDialog={has_end_dialog}")
    for i in issues:
        print(f"  {i}")
```

## Report Output Format

Every audit report should follow this structure:

1. **Executive Summary** — comparison table across all audited agents
2. **Per-Agent Sections:**
   - Component inventory (type counts)
   - Instructions analysis (size, sections, guardrails, model, capabilities)
   - Topic inventory (table: name, triggers, termination, issues)
   - Knowledge sources (names and types)
   - Trigger phrase stats (total, source breakdown)
   - Top 5 issues ranked by severity
3. **MS Learn Compliance Assessment** — table comparing each agent against key standards
4. **Remediation Priority** — P0 first, P1 second, Medium third

## Known Ensign Default Failure Modes

1. **Empty JSON on botcomponents query** → Wrong auth token (missing trailing slash). Verify with WhoAmI.
2. **Agent has 0 components in dump_agent_full.cjs** → Script targets wrong org. Use direct `curl` queries instead.
3. **Instructions component has no data field** → Check `content` field as fallback (rare).
4. **Topic data field is null** → Handle with `data = c.get('data') or ''` in Python.
5. **Duplicate topic names with one empty** → Orphaned stale record from failed export/reimport. Flag but don't count twice.
