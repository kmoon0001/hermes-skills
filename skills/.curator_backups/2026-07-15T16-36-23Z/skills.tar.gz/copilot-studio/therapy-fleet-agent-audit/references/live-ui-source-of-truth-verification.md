# Live UI source-of-truth verification for Therapy AI Dev

Use this when Kevin says the live Copilot Studio UI is the source of truth, or after Dataverse/API repairs must be proven visible in Copilot Studio.

## Principle

For Copilot Studio agents, a successful Dataverse PATCH is necessary but not always sufficient. Verify both layers:

1. **Live Dataverse backing record** — proves the draft source record has the expected `data` field.
2. **Copilot Studio live UI** — proves the same Therapy AI Dev draft is visible in the web app, under the correct environment/agent/topic.

Do not claim "live UI verified" from Dataverse alone. Phrase Dataverse-only evidence as "live Dataverse backing record verified" until a browser/CDP screenshot confirms the UI.

## Therapy AI Dev guardrails

- Allowed org URL: `https://orgbd048f00.crm.dynamics.com`
- Allowed tenant: `03cc92c3-986c-4cf4-ae27-1478cf99d17f`
- Do not touch Ensign Default / `org3353a370.crm.dynamics.com`.
- Published users may not see draft/source UI changes until publish. If UI shows an older `Published <date>` marker, explicitly distinguish: "draft/source UI has the change; published agent was not updated."

## Verification pattern

### 1. Re-read live backing records

For every patched component, query `botcomponents` directly in Therapy AI Dev and verify:

- correct `_parentbotid_value`,
- expected `name`,
- record found exactly once,
- `data` parses as YAML,
- expected repair pattern is present,
- `modifiedon` is after the apply run.

Examples of repair-specific assertions:

- Greeting/topic send activity repair: `text: |` present.
- `EndDialog` queue repair: `clearTopicQueue: true` present.
- multiple-topics prompt repair: `prompt: |` present.

Save a JSON report under `scratch/audit-results/live-ui-source-verify-<timestamp>/`.

### 2. Open Copilot Studio UI under Therapy AI Dev

Open a real browser/CDP session to a representative patched component URL:

```text
https://copilotstudio.microsoft.com/environments/<environmentId>/bots/<botId>/adaptive/<botcomponentId>
```

Confirm page text/screenshot shows:

- Copilot Studio, not Microsoft sign-in,
- environment: `Therapy AI Agents Dev`,
- expected agent name,
- expected topic/component name,
- no visible error banners/toasts.

Save screenshot and page-state JSON under `scratch/audit-results/live-ui-visual-verify-<timestamp>/`.

### 3. Handle sign-in/MFA without overstating verification

If the browser lands on Microsoft sign-in/account picker, click the listed Ensign account and wait for Microsoft Authenticator approval. If approval is not completed, report "UI verification blocked at Microsoft sign-in/MFA" rather than claiming UI verification.

Once MFA completes, re-check `location.href`, `document.title`, and visible body text before screenshotting.

### 4. Report exact scope

Use wording like:

```text
Live UI verified:
- Environment: Therapy AI Agents Dev
- Agent: <agent>
- Topic/component: <topic>
- Screenshot: <path>
- No visible error banners/toasts.

Live Dataverse backing records verified for N/N patched components.
Draft/source UI has the change. Published agent was not updated unless publish was explicitly run.
```

## Pitfalls

- The test pane can show published or cached behavior. Use it as extra signal, not the sole proof of source YAML changes.
- The topic designer may render the visual nodes rather than Monaco YAML; that is still valid UI evidence if the correct topic opens without errors.
- Direct Dataverse auth can work while browser auth is expired. Treat these separately.
- A screenshot of Microsoft sign-in/account picker is not Copilot Studio UI evidence.