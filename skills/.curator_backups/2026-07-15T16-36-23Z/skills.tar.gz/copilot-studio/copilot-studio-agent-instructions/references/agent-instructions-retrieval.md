# Retrieving and Restoring Agent Instructions

This guide explains how to extract the original instructions (componenttype 15) from a deployed Copilot Studio agent and restore them if needed.

## Overview

Each Copilot Studio agent has a corresponding Bot Component record in Dataverse. The agent's instructions are stored in the `data` field of the component where `componenttype` equals 15 (metadata/instructions). This value includes YAML frontmatter and the actual instructions text.

To safely view or modify these instructions, you need to:
1. Access the live agent data via the browser's authenticated session (using Chrome DevTools Protocol)
2. Extract the current `data` value from the componenttype 15 record
3. Optionally modify it and send it back via a PATCH request

## Prerequisites

- Google Chrome with remote debugging enabled on port 9223
- Access to the target Power Platform environment
- Authentication established (via Azure CLI or prior Copilot Studio CLI session)

## Steps

### 1. Enable Chrome Remote Debugging

```bash
start chrome --remote-debugging-port=9223 --user-data-dir="%LOCALAPPDATA%\Google\Chrome\User Data" "https://your-environment.crm.dynamics.com/"
```

Keep this Chrome instance open.

### 2. Dump Live Agent Components

Run:
```bash
node "D:/my agents copilot studio/pipeline/scripts/dump_live_components.cjs"
```

This creates JSON files in `D:/my agents copilot studio/pipeline/live_agent_dump/` for each agent (OT, PT, SLP, TDA).

### 3. Extract Instructions

For a specific agent (e.g., TDA), locate the component with `componenttype`: 15 in the corresponding `_components_response.json` file. The `data` field contains the full instructions.

Example extraction (Node.js):
```bash
node -e "
const fs = require('fs');
const file = 'D:/my agents copilot studio/pipeline/live_agent_dump/TDA_components_response.json';
const json = JSON.parse(fs.readFileSync(file, 'utf8'));
const comp = json.value.find(c => c.componenttype === 15);
if (comp) {
  console.log(comp.data);
}
"
```

### 4. Backup and Modify (Optional)

Before changing instructions, back up the current `data` value. To restore later, simply re-PATCH this backed-up value.

To modify and apply:
- Edit the `data` field (e.g., add evaluation-safe orchestration guidelines)
- Use a PATCH script (like `apply_tda_eval_fix.cjs`) to send the update via the browser's authenticated session

### 5. Restore Original Instructions

To revert to the original instructions:
1. Retrieve the backed-up `data` value (from Step 4)
2. Send it via PATCH to the same component using a script like `restore_tda_original.js`

## Automation Helper Scripts

- `dump_live_components.cjs` – Dumps components for all therapy agents
- `apply_tda_eval_fix.cjs` – Example: patches TDA instructions with evaluation-safe rules
- `restore_tda_original.js` – Example: restores TDA instructions from a backup file

## Important Notes

- The `data` field includes YAML frontmatter (e.g., `kind: GptComponentMetadata`) — preserve the entire value.
- Always verify the Chrome debugging session is active before running scripts.
- If you see `connect ECONNREFUSED 127.0.0.1:9223`, restart Chrome with the remote debugging flag.
- This process works for any agent (OT, PT, SLP, TDA) by changing the target file or identifier.