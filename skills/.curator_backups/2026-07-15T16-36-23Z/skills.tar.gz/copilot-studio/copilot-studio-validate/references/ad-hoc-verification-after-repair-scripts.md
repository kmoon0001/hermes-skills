# Ad-hoc verification for repair/audit scripts when no canonical suite exists

Use this when Copilot Studio source-editing work changes helper scripts or repair scripts and no canonical test/lint/build command is available.

## Required pattern

1. Create a temporary verifier under the OS temp directory using `tempfile` and a filename prefix of `hermes-verify-`.
   - On Kevin's Windows host, use `C:/Users/kevin/AppData/Local/Temp` when available.
   - Do not leave the verifier in the repo unless it is intentionally being promoted to a reusable script.
2. The verifier should run focused checks against the changed behavior, then delete itself when possible.
3. Report the result explicitly as **ad-hoc verification**, not canonical suite green.

## Useful checks for Copilot Studio YAML repair scripts

- `node --check <changed-script>.cjs` for syntax.
- Static scope guard checks for live scripts:
  - expected Therapy AI Dev URL is present,
  - blocked Ensign/default URL guard is present,
  - no Ensign/default URL is used as the live target.
- Run local repair scripts without `--apply` and verify dry-run output:
  - exit code 0,
  - expected marker such as `SUMMARY` or `OUT`,
  - no `PATCHED` output in dry-run mode.
- Run live repair scripts without `--apply` and verify safety behavior:
  - DRY-RUN mode is printed,
  - target URL is Therapy AI Dev only,
  - no patch operations occurred.
  - If auth returns 401, report it as the live-read blocker, not as full live verification.
- Re-run schema validation for active dialog-like Copilot Studio files after dry-run behavior checks.

## Reporting language

Say: "Ad-hoc verification completed; this is not canonical suite green."

Include:
- temp verifier path,
- cleanup status,
- changed scripts checked,
- exact command classes run,
- files checked and failure count,
- concrete blocker if live API calls cannot be verified, e.g. `401 Unauthorized`.