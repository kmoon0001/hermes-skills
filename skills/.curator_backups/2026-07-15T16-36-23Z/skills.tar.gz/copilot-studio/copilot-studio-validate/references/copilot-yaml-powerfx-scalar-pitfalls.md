# Copilot Studio YAML + Power Fx scalar pitfalls

Session-derived root cause pattern: publish/validation failures can come from YAML parse errors introduced while trying to repair Power Fx expressions. The visible Copilot error may say "empty node", "blank condition", or publish may fail silently, while the real issue is that a YAML scalar containing `:`, `{}`, or embedded quotes was left bare.

## Failure examples

### Bare activity text with colon
```yaml
activity: Using your saved OCR Job ID: {Topic.async_job_id}. Checking status now...
```
PyYAML error:
```text
mapping values are not allowed here
line ..., column ...: activity: Using your saved OCR Job ID: ...
```
Fix:
```yaml
activity: 'Using your saved OCR Job ID: {Topic.async_job_id}. Checking status now...'
```

### Bare Power Fx object literal
```yaml
file: ={ contentBytes: First(System.Activity.Attachments).Content, name: First(System.Activity.Attachments).Name }
```
PyYAML error:
```text
mapping values are not allowed here
line ..., column ...: file: ={ contentBytes: ...
```
Fix:
```yaml
file: '={ contentBytes: First(System.Activity.Attachments).Content, name: First(System.Activity.Attachments).Name }'
```

### One-line condition with `in`
Prefer a quoted scalar and force text context:
```yaml
condition: '="Status: Completed" in Text(Topic.ocr_payload)'
```
Do not convert this to `|-` unless it is genuinely multi-line.

## Repair discipline
1. Back up exact live `data` before editing.
2. Patch only the intended `data` field.
3. Re-query live `data` after PATCH.
4. Run YAML parse on the exact live `data` string.
5. Inspect parsed scalar values to ensure formulas still start with `=` and did not gain leading newlines.
6. Then run schema/LSP validation or publish diagnostics.

## Important nuance
Do not treat every quoted `"=..."` as a bug. Copilot Studio YAML commonly needs quoted scalars for formulas containing YAML syntax characters. The bug is not quoting itself; the bug is whether the YAML parser and Copilot formula/schema parser receive the intended string value.
