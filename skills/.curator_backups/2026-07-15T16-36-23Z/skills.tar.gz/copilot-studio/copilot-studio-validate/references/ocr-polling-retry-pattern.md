# OCR Polling Retry Pattern for Copilot Studio Topics

When a topic uses InvokeFlowAction for async OCR + SearchAndSummarizeContent audit, the OCR check must poll until the job completes. Two patterns exist — use the sentinel pattern for new work.

## Sentinel Pattern (Discharge Summary — reference design)

```yaml
    - kind: InvokeFlowAction
      id: invokeFlow_check_async_ocr_status
      # ... (check async_job_id via flow)

    - kind: SetVariable
      id: setVariable_ocr_payload
      variable: Topic.ocr_payload
      value: =Topic.job_json

    - kind: ConditionGroup
      id: conditionGroup_ocr_completed
      conditions:
        - id: condition_ocr_completed
          condition: '="Status: Completed" in Topic.ocr_payload'
          actions:
            - kind: SearchAndSummarizeContent   # Generate audit report
            - kind: SendActivity                # Display results

      elseActions:
        - kind: SendActivity
          id: sendActivity_processing_status
          activity: |-
            The OCR audit job is not complete yet.
            Job ID: {Topic.async_job_id}
            Current status response: {Topic.ocr_payload}
            Use "check OCR job status" with this Job ID to retrieve the completed report.

        - kind: SetVariable
          id: setVariable_retry_count
          variable: Topic.retry_count_num
          value: =If(Value(Text(Topic.'retry_count_num')) + 1 >= 10, Blank(), Value(Text(Topic.'retry_count_num')) + 1)

        - kind: ConditionGroup
          id: conditionGroup_retry_limit
          conditions:
            - id: conditionItem_retry_exit
              condition: =IsBlank(Topic.retry_count_num)

        - kind: GotoAction
          id: goto_retry_ocr_check
          actionId: invokeFlow_check_async_ocr_status

    - kind: EndDialog
      id: endDialog_done
      clearTopicQueue: true
```

**How it works:**
- `retry_count_num` increments each loop. At 10, the formula returns `Blank()`
- `IsBlank(Topic.retry_count_num)` fires when retries exhausted → silent exit
- `GotoAction` loops back to the OCR check
- The 5-second delay is handled in the Power Automate flow itself, not in the topic

## Counter Pattern (Progress Report — alternative)

```yaml
        - kind: SetVariable
          id: init_retry
          variable: Topic.RetryCount
          value: =0

        ...
        
        # In elseActions:
        - id: condition_retry_limit
          condition: =Topic.RetryCount < 10
          actions:
            - kind: SetVariable
              id: increment_retry
              variable: Topic.RetryCount
              value: =Topic.RetryCount + 1
            - kind: SendActivity
              activity: The OCR audit is still processing (attempt {Topic.RetryCount} of 10). Checking again...
            - kind: GotoAction
              id: goto_retry_check
              actionId: invokeFlow_check_async_ocr_status
```

## Dead Pattern (DO NOT USE)

```yaml
          condition: =Topic.RetryCount < 0   # NEVER true — dead code!
```

This was present in Eval/Assessment + POC and Episode of Care topics. The condition `RetryCount < 0` can never fire, so the loop never retries.

## Verification Checklist

When patching a topic with the retry pattern, verify via Dataverse API:

```
retry_count_num  — ✓  (or RetryCount with proper < 10)
IsBlank          — ✓  (or equivalent exit condition)
GotoAction       — ✓
actionId points to check_async_ocr — ✓
>= 10 or < 10    — ✓  (retry limit)
```

## Topics That Should Have This Pattern

- Discharge Summary (reference — has it)
- Progress Report Review (has RetryCount < 10 variant)
- Evaluation/Assessment + Plan of Care
- Treatment Encounter Note Review
- Recertification/UPOC Review
- Episode of Care
