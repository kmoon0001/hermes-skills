# Global Pre-Commit Hook for Copilot Studio Topic Quality

A reusable `pre-commit` hook that enforces topic YAML quality standards across all Copilot Studio agent repos in a single installation.

## Installation

```bash
# 1. Create a hooks directory
mkdir -p ~/.hermes_hooks

# 2. Place the pre-commit script there (see template below)
# 3. Make it executable
chmod +x ~/.hermes_hooks/pre-commit

# 4. Set git global hooks path
git config --global core.hooksPath "C:/Users/kevin/.hermes_hooks"
```

This applies to **every** Git repository on the machine — no per-repo setup needed.

## What the Hook Checks

| Check | Blocks? | Pattern |
|---|---|---|
| Missing `knowledgeSources:` block | ✅ Block | `^knowledgeSources:` missing from any topic YAML |
| Raw record output (no `.Text.Content`) | ✅ Block | `Topic.*(AuditReport|audit_report)}` without `.Text.Content` |
| `in` operator without `Text()` wrapper | ✅ Block | `in Topic.` without `Text(Topic.` |
| Dead retry (`RetryCount < 0`) | ✅ Block | `RetryCount < 0` (always-false condition) |

## Template

```bash
#!/usr/bin/env bash
# Global pre‑commit hook for all Copilot Studio agents.
REPO_ROOT="$(git rev-parse --show-toplevel)"
block=0

find "$REPO_ROOT" -type f -name "*.yml" -print0 | while IFS= read -r -d '' file; do
    # missing knowledgeSources
    if ! grep -q '^knowledgeSources:' "$file"; then
        echo "❌ BLOCK: MISSING knowledgeSources in: $file"
        block=$((block+1))
    fi
    # raw record output (no .Text.Content)
    if grep -qE 'Topic\.[A-Za-z0-9_]+(AuditReport|audit_report)\}' "$file"; then
        echo "❌ BLOCK: RAW RECORD output (missing .Text.Content) in: $file"
        block=$((block+1))
    fi
    # `in` operator without Text() wrapper
    if grep -qE 'in Topic\.' "$file" && ! grep -qE 'in Text\(Topic\.' "$file"; then
        echo "❌ BLOCK: Missing Text() wrapper on `in` operator in: $file"
        block=$((block+1))
    fi
    # dead retry: RetryCount < 0
    if grep -q 'RetryCount < 0' "$file"; then
        echo "❌ BLOCK: Dead retry (RetryCount < 0) in: $file"
        block=$((block+1))
    fi
done

if [ $block -ne 0 ]; then
    echo "❌ Commit blocked due to $block error(s)."
    exit 1
fi

echo "✅ All checks passed."
exit 0
```

## Verification

Test the hook by staging a broken topic YAML and attempting a commit:

```bash
git add -A
git commit -m "test"   # Should block with descriptive output
```

To bypass the hook temporarily (e.g., committing a known-WIP branch):

```bash
git commit --no-verify -m "message"
```
