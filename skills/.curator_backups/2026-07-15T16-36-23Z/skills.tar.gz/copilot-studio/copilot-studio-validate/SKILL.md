---
name: copilot-studio-validate
description: "Validate Copilot Studio agent YAML files — schema validation (local) and LSP-based validation (environment-aware). Use before publishing or after editing."
version: 1.1.0
author: Copilot Studio Pipeline
license: MIT
platforms: [windows, linux, macos]
metadata:
  hermes:
    tags: [copilot-studio, validation, yaml, schema, lsp]
    homepage: https://learn.microsoft.com/microsoft-copilot-studio/
---

# Validate Agent YAML

Validate Copilot Studio agent YAML files using two complementary methods.

## Method 1: Schema Validation (local, no auth needed)
```bash
node "D:/my agents copilot studio/pipeline/scripts/schema-lookup.bundle.js" validate <path-to-yml-file>
```
Checks structural correctness: action kinds, property placement, required fields.

## Method 2: LSP-based Validation (needs .mcs/conn.json)
```bash
node "D:/my agents copilot studio/pipeline/scripts/manage-agent.bundle.js" validate --workspace <path-to-agent-folder> --tenant-id <tenantId> --environment-id <envId> --environment-url <envUrl> --agent-mgmt-url <mgmtUrl>
```
Checks: YAML structure, Power Fx expressions, schema validation, cross-file references, environment-specific checks.
Connection details come from .mcs/conn.json.

## Workflow
1. Locate agent workspace (directory containing .mcs/conn.json)
2. Run schema validation first (fast, local)
3. Run LSP validation if conn.json exists (comprehensive)
4. Parse JSON output:
   - valid: true -> all files pass (may have warnings)
   - valid: false + summary.errors > 0 -> report as FAIL
   - summary.warnings > 0 -> report as WARN
5. If `pac copilot publish` fails after local validation passes, query the bot row's `synchronizationstatus.lastFinishedPublishOperation.diagnosticDetails` before guessing.
6. If the system requires fresh verification after edits and there is no canonical test/lint/build command, create a focused temporary verifier under the OS temp directory using `tempfile` with a `hermes-verify-` filename prefix.
7. Report findings:
```
Validation Results for: <agent-name>
[PASS] <filename> — no issues
[FAIL] <filename> — <error message> (line X)
[WARN] <filename> — <warning message> (line X)
Summary: X files checked, Y errors, Z warnings
```

## Quick YAML Parse Check (js-yaml)

```bash
node -e "const y = require('js-yaml'), fs = require('fs'); \
  process.exitCode = fs.readdirSync('topics').filter(f => f.endsWith('.mcs.yml')).every(f => { \
    try { y.load(fs.readFileSync('topics/'+f,'utf8')); return true; } \
    catch(e) { console.log('INVALID: '+f+': '+e.message); return false; } \
  }) ? 0 : 1"
```

**Alternative — PyYAML (Python):** When Node.js is not available:
```python
import yaml, os, sys
errors = []
for f in os.listdir('topics'):
    if not f.endswith('.mcs.yml') or f.endswith('.bak'):
        continue
    path = os.path.join('topics', f)
    with open(path, 'rb') as fh:
        content = fh.read()
    if not content.strip():
        continue
    try:
        yaml.safe_load(content)
    except yaml.YAMLError as e:
        errors.append(f"{f}: {e}")
if errors:
    for e in errors:
        print(f"FAIL: {e}")
    sys.exit(1)
else:
    print("ALL PASS")
```

## OCR Polling Retry Pattern

See `references/ocr-polling-retry-pattern.md` for the retry/poll pattern used in document audit topics. When fixing OCR polling issues:

1. Identify the working reference topic first
2. Check for dead code (`RetryCount < 0`) — root cause in 2/6 topics
3. Apply changes one topic at a time, publish + verify after each
4. Verify via Dataverse API before proceeding to next topic
5. QA matrix at the end — all topics should match on key elements: retry var, IsBlank/GotoAction limit, flow reference

## Methodical Incremental Approach

When making changes across multiple similar topics:

1. Identify the reference topic (the one that works correctly)
2. Identify all topics that differ from the reference
3. Fix one topic at a time — publish + verify after EACH
4. Use a QA matrix to confirm all topics match before declaring done
5. Never batch-patch unless you can roll back each independently

## For Additional Context on Errors
```bash
node "D:/my agents copilot studio/pipeline/scripts/schema-lookup.bundle.js" resolve <kind>
```

## Pitfalls
- `Can't find top-level schema for kind: Foo` is a SCHEMA error, not YAML
- Multi-line Power Fx with colons needs `|-` block scalar
- One-line `condition:` with `in` operator needs quoted string, NOT block scalar
- `RetryCount < 0` is dead code — the loop never fires
- Always verify persisted Dataverse data after API PATCH, not just the publish status

## References
- `references/ocr-polling-retry-pattern.md` — Full OCR polling retry pattern with sentinel and counter variants
- `references/ad-hoc-verification-after-repair-scripts.md` — Ad-hoc verification patterns
- `references/copilot-yaml-powerfx-scalar-pitfalls.md` — YAML scalar quoting
- `references/pre-commit-hook-pattern.md` — Pre-commit hook
