# KB Source Naming Conventions (MS Learn Best Practices)

## File Naming
- Pattern: `{Org}_{ContentDescription}_{Version}.pdf`
- Remove `.pdf` from the display name when uploading to Copilot Studio
- Use underscores between segments
- Content description should match the scope of the source

Examples:
- `CMS_Advance_Care_Planning_MLN909289.pdf` → Display: "Advance Care Planning Documentation Requirements (CMS)"
- `CMS_Hospital_Discharge_Planning_QSO_23_16.pdf` → Display: "Hospital Discharge to PAC Requirements (CMS)"
- `SBAR_Communication_Toolkit_AHRQ.pdf` → Display: "SBAR Communication Framework (AHRQ)"
- `APTA_PT_Examination_Documentation.pdf` → Display: "PT Examination & Evaluation Documentation Standards (APTA)"

## Descriptions (MS Learn Format)
Each KB must have a unique 1-2 sentence description that:
- States the authoritative source (CMS, AHRQ, APTA, AOTA, ASHA)
- Describes what the document covers
- Notes the version or effective date if applicable

Examples:
- "CMS Medicare Learning Network booklet covering advance care planning (ACP) billing, coding, and documentation requirements for CPT codes 99497 and 99498."
- "AHRQ SBAR communication framework for structured clinical handoffs during care transitions. Endorsed by the Joint Commission and CMS."
- "AOTA OT SNF Evaluation Checklist and Quality Measures (2026) covering occupational profile, MDS Section GG scoring, and SNF quality measures per the OT Practice Framework 4th Edition."

## Official Designation
Mark as "Official" for any source from:
- CMS (Centers for Medicare & Medicaid Services)
- AHRQ (Agency for Healthcare Research and Quality)
- APTA (American Physical Therapy Association)
- AOTA (American Occupational Therapy Association)
- ASHA (American Speech-Language-Hearing Association)
- HHS (Department of Health and Human Services)
- Medicare.gov

## Source Discovery Workflow
When eval results show groundedness=No failures:
1. Classify the failing case topic (e.g., "advance care planning", "SBAR handoff")
2. Search authoritative sites: CMS.gov, AHRQ.gov, APTA.org, AOTA.org, ASHA.org
3. Prefer PDF downloads from official .gov or .org domains
4. If no standalone PDF exists, create from web content (cite source URL)
5. Follow naming convention above
6. Upload to agent Knowledge tab
7. Write MS Learn-format description
8. Mark as Official
9. Re-run eval
