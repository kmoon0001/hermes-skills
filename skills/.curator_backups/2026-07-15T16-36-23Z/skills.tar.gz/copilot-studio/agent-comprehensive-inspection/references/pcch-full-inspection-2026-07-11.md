# Pacific Coast Case Historian V2 — Full Inspection (2026-07-11)

## What Was Done
Ran the full 12-domain agent-comprehensive-inspection protocol on PCCH V2 live agent via Dataverse API queries (instructions + all 26 topic components). Produced structured pass/fail report per domain.

## Key Discoveries

### 1. TaskDialog Exemption Pattern
Connected agent topics (`SNF AI Dashboard V2`, `TheraDoc Workbench`, `SimpleLTC QM Coach V2`, `SNF Command Center V2`) use `kind: TaskDialog` with `InvokeConnectedAgentTaskAction` — NOT `kind: AdaptiveDialog`. These:
- Have NO EndDialog (by design — routing is the action)
- Have NO SearchAndSummarizeContent
- Have NO trigger phrases
- Are NOT caught by OnRecognizedIntent checks

**Lesson:** Filter these out when counting "custom AdaptiveDialog topics." They must be detected by checking `kind:` at root level.

### 2. YAML Corruption: Unquoted Colon in Fallback Activity
The Fallback topic's `activity:` field contained:
```yaml
activity: I can help review acute hospital records for case history synthesis. Paste clinical documents or describe what you need: SBAR handoff, MDS 3.0 mapping...
```
The colon after "need:" caused YAML to interpret it as a new mapping key. Fix is to wrap the string in double quotes:
```yaml
activity: "I can help review acute hospital records... what you need: SBAR handoff..."
```

**Detection:** `grep 'activity:.*:'` on the Dataverse data field — any `activity:` value that contains a colon and is not quoted.

### 3. responseCaptureType Gap Detection
Missing `responseCaptureType: FullResponse` on 5/13 SSC topics. `applyModelKnowledgeSetting: true` does NOT imply `responseCaptureType` is set — they're independent fields. Detection:
```bash
# For each topic with SearchAndSummarizeContent, check both:
grep -c 'responseCaptureType' topic_data
grep -c 'applyModelKnowledgeSetting' topic_data
```

### 4. Live-vs-Local Topic Name Divergence
| Local .mcs.yml | Live Dataverse Name |
|----------------|-------------------|
| `PTClinicalAnalysis.mcs.yml` | PT Acute Record Extraction |
| `OTClinicalAnalysis.mcs.yml` | OT Acute Record Extraction |
| `SLPClinicalAnalysis.mcs.yml` | SLP Acute Record Extraction |
| `NursingClinicalAnalysis.mcs.yml` | Nursing Acute Record Extraction |
| `StartOver.mcs.yml` | Session Reset - New Case |
| *Not in local* | Case Start and Intent Router |

Live has topics NOT in local (`Case Start and Intent Router`, `Session Reset - New Case`) and the connected agents appear as topics.

### 5. Dataverse Query Pattern for Live Inspection
```bash
BOT_ID="ad635500-cf47-f111-bec5-70a8a5b1c3a3"
ORG="https://orgbd048f00.crm.dynamics.com"

# Instructions
az rest --resource "$ORG/" --method GET \
  --url "$ORG/api/data/v9.2/botcomponents?\$filter=_parentbotid_value eq $BOT_ID and componenttype eq 15&\$select=botcomponentid,name,data"

# All topics
az rest --resource "$ORG/" --method GET \
  --url "$ORG/api/data/v9.2/botcomponents?\$filter=_parentbotid_value eq $BOT_ID and componenttype eq 9&\$select=botcomponentid,componenttype,name,data,statecode&\$top=50" \
  2>/dev/null > topics.json
```

**PITFALL:** `az rest` outputs a cp1252 encoding warning to stdout. Redirect stderr separately: `2>/dev/null > output.json`.

### 6. YAML Cleanup for Dataverse Data
Dataverse returns CRLF (`\r\n`) in YAML data fields. When double-CRLF (`\r\r\n`) appears, clean before YAML parsing:
```python
clean = raw_data.replace('\r\r\n', '\n').replace('\r\n', '\n')
```

### 7. Trigger Queries Location
In `kind: OnRecognizedIntent` topics, trigger phrases are in `beginDialog.intent.triggerQueries`, NOT in `beginDialog.triggerQueries`. The parser must check both locations:
```python
intent = beginDialog.get('intent', {})
triggers = intent.get('triggerQueries', [])
if not triggers:
    triggers = beginDialog.get('triggerQueries', [])
```

## Inspection Results Summary
See `C:/Users/kevin/pcch_inspection_report.md` for the full structured report.
