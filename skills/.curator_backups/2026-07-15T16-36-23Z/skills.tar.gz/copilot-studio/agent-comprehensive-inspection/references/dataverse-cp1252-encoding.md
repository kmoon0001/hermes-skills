# Dataverse API — cp1252 Encoding Handling (Windows)

## The Problem
`az rest --url "https://org.crm.dynamics.com/api/data/v9.2/..." -o json` returns data that Python's default `json.load(sys.stdin)` cannot parse because stdout on Windows powershell/git-bash encodes as cp1252, not UTF-8.

## Symptoms
```
UnicodeDecodeError: 'utf-8' codec can't decode byte 0x97 in position 377: invalid start byte
```

## Fixes

### Fix A: Save to file first (preferred)
```bash
az rest --resource "https://org.crm.dynamics.com/" --method GET \
  --url "https://org.crm.dynamics.com/api/data/v9.2/botcomponents?...\$(filter=..." \
  -o json > C:/Users/kevin/Desktop/out.json
```
Then read with Python:
```python
import json
with open('C:/Users/kevin/Desktop/out.json', encoding='utf-8', errors='replace') as f:
    data = json.load(f)
```

### Fix B: Python with urllib directly (best for scripting)
```python
import json, urllib.request

token = subprocess.check_output(
    ['az.cmd', 'account', 'get-access-token', '--resource', 'https://org.crm.dynamics.com/', 
     '--query', 'accessToken', '-o', 'tsv'],
    shell=True, text=True, stderr=subprocess.DEVNULL
).strip()

org = "https://orgbd048f00.crm.dynamics.com"

def dv_get(url_suffix):
    url = f"{org}/api/data/v9.2/{url_suffix}"
    req = urllib.request.Request(url)
    req.add_header("Authorization", f"Bearer {token}")
    req.add_header("Accept", "application/json")
    with urllib.request.urlopen(req, timeout=30) as resp:
        raw = resp.read()
        # Try UTF-8 first, fall back to cp1252
        for enc in ['utf-8', 'cp1252', 'latin-1']:
            try:
                return json.loads(raw.decode(enc))
            except:
                continue
    return json.loads(raw.decode('latin-1'))  # Last resort
```

### Fix C: Inline Python pipe (only works for pure ASCII data)
```bash
az rest ... -o json | python3 -c "import json,sys; d=json.load(sys.stdin); print(d)"
```

## Affected Scenarios
- Listing botcomponents with `\$select=name,data` when data contains clinical text with em-dashes, smart quotes, or special characters
- Reading instruction component (componenttype=15) data
- Reading topic (componenttype=9) data with non-ASCII content
