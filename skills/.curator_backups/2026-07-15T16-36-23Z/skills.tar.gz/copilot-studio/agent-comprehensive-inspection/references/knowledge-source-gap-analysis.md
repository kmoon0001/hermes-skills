# Knowledge Source Gap Analysis & Download Workflow

Used when: eval failures show groundedness=No on specific topics, and the fix requires adding authoritative KB content.

## Step 1: Identify Gaps from Eval Failures

From eval detail output (graderMetrics.properties):
```
groundedness=No → agent answer not supported by knowledge sources
abstention=Yes  → agent refused — possible KB gap causing "no info" response
```

Classify each failing case by what KB content is missing:
- SBAR handoff format standards → need AHRQ/CMS SBAR documentation
- Discharge summary requirements → need CMS discharge planning guidelines
- Advance care planning doc → need CMS ACP billing/coding standards
- Nursing notes extraction → need MDS 3.0 / nursing standards
- SLP documentation → need ASHA documentation standards
- PT/OT evaluation → need APTA/AOTA practice guidelines

## Step 2: Search Authoritative Sources

Priority order for therapy compliance agents:
1. **CMS (.gov)** — regulations, coverage, billing, MDS, QSO memos
   - Search: `site:cms.gov <topic> PDF`
   - MLN products: `site:cms.gov MLN <topic>`
   - QSO memos: `site:cms.gov QSO <topic>`
2. **AHRQ (.ahrq.gov)** — TeamSTEPPS, patient safety, SBAR, care transitions
3. **APTA (.apta.org)** — PT documentation standards, examination guidelines
4. **AOTA (.aota.org)** — OT evaluation checklists, MDS Section GG guidance
5. **ASHA (.asha.org)** — SLP documentation, swallowing, communication
6. **Medicare.gov** — beneficiary-facing coverage info
7. **42 CFR Part 483** — regulatory text via eCFR.gov

## Step 3: Download Strategy

### Direct PDFs (best — upload as-is to Copilot Studio)
```bash
# CMS MLN products (reliable direct PDFs)
curl -sL -o "CMS_Topic_Name.pdf" "https://www.cms.gov/files/document/mln-<doc-id>.pdf"

# CMS QSO memos
curl -sL -o "CMS_QSO_Topic.pdf" "https://www.cms.gov/files/document/qso-YY-NN-hospitals.pdf"

# AHRQ site pages (use web_extract, save as text)
curl -sL "https://www.ahrq.gov/<path>" -o page.html
# Or use web_extract tool then write cleaned text to file
```

### Blocked Downloads (WAF, authentication, no direct PDF)
When a site returns a small HTML stub (212-919 bytes = Incapsula/Cloudflare block):
- Use `web_extract` to pull the page content
- Create a clean PDF from the text using Python fpdf2
- Name the file with the org prefix and source URL in the file header

### URL Discovery Pattern
```bash
# Find official CMS PDFs
google: "site:cms.gov <topic> PDF" 
# MLN products have predictable URLs:
https://www.cms.gov/files/document/mln-<slug>.pdf

# For downloadable resources, check AOTA:
# Go to aota.org → search → look for PDF links
# Note: AOTA uses Incapsula WAF — direct curl fails
# Workaround: web_extract the page, create PDF from text
```

## Step 4: Name Files Correctly

Format: `{SourceOrg}_{ContentDescription}_{VersionIfKnown}.{ext}`

Good examples:
```
CMS_Advance_Care_Planning_MLN909289.pdf
CMS_Hospital_Discharge_Planning_QSO_23_16.pdf
CMS_Medical_Record_Documentation_Compliance_MLN909160.pdf
SBAR_Communication_Toolkit_AHRQ.pdf
APTA_PT_Examination_Documentation.pdf
AOTA_OT_SNF_Evaluation_Checklist.pdf
```

Bad examples:
```
Doc1.pdf
untitled.pdf
document.pdf
KB_source_1.pdf
```

## Step 5: Upload & Mark Official

In Copilot Studio:
1. Go to agent → Knowledge tab → Add knowledge → Upload files
2. Give each KB a clear description: "CMS MLN Advance Care Planning — billing, coding, and documentation requirements for ACP services"  
3. Mark as "Official" where applicable (CMS, regulatory sources)
4. Order most specific KBs first

## Step 6: Verify

After upload, re-run eval:
```python
# Conv eval (faster — 20 cases, ~3-5 min)
# SR eval (100 cases, ~8-12 min)
# Check if groundedness=No failures decreased
```

If groundedness failures still present:
- The KB content may not cover the specific test case expectations
- Check that the SearchAndSummarizeContent query matches the KB content
- Add more granular KBs for the specific sub-topic
