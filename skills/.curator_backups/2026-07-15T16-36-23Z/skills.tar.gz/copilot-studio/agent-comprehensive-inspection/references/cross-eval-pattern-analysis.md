# Cross-Eval Pattern Analysis: SR + Conv Failure Correlation

When both SR (100 cases) and Conv (20 cases) evals have completed, correlate failures to identify systemic root causes that neither eval catches alone.

## When to Run

After both a Conv eval and SR eval have completed for the same agent version. Run before starting the Domain 12 iteration loop.

## Method

### Step 1: Classify Conv failures

Fetch Conv eval details (`/makerevaluations/{runId}/details`) and classify each failing case:

| Metric | Meaning |
|--------|---------|
| abstention=Yes, rel=NA | Agent refused or grader flagged response structure as refusal |
| completeness=No, rel=Yes, gnd=Yes | Answer truncated — format/length restriction |
| completeness=No, rel=Yes, gnd=No | Answer provided but not grounded in KB |
| completeness=No, rel=No | Wrong topic matched or irrelevant answer |
| abstention=No, comp=Yes, gnd=No | Good answer, groundedness gap (KB missing) |

### Step 2: Classify SR failures

Same classification for SR eval. Export failure list for each.

### Step 3: Cross-reference by failure type

Compare category distributions between SR and Conv:

| Pattern | Root Cause | Priority |
|---------|-----------|----------|
| Both: abstention=Yes | Model safety override OR grader pattern-matching on answer structure | HIGH |
| Both: groundedness=No | Missing authoritative knowledge sources | HIGH |
| Both: completeness=No | responseInstructions format/length caps | HIGH |
| Conv-only: abstention=Yes | Conversational routing / Fallback intercept | MED |
| Conv-only: incomplete | Multi-turn context loss | MED |
| SR-only: groundedness=No | Topic-level knowledge restriction | LOW |
| SR-only: incomplete | Question node in topic | LOW |

### Step 4: Check for Grader Pattern-Matching

If abstention failures dominate BOTH SR and Conv despite having EVALUATION CONTEXT with "NEVER abstain":

1. Read the agent's full answer text for a failing case
2. If the answer is clinically accurate but starts with:
   - "Below is a structured compliance review framework..."
   - "**...Analysis (DRAFT)**"
   - "The provided sources do not specifically address..."
   - "Since the uploaded content is not available..."
3. → This is **grader pattern-matching**, not an agent refusal
4. Fix: Change answer lead-in structure, not content

### Ceiling Awareness
If both SR and Conv plateau at ~75-85% after KBs and instructions are optimized, and abstention failures dominate, the agent may have hit the **grader plateau ceiling**. Real-world ceiling for therapy compliance agents appears to be ~85% SR, ~75% Conv.

## Validated Example: PCCH V2 (2026-07-11)

| Metric | Conv (v12) | SR (latest) |
|--------|-----------|-------------|
| Score | 72% (13P/5F/2Pend) | 85% (85P/15F) |
| abstention | 1 | 3 |
| groundedness | 1 | 1 |
| incomplete | 3 | 2 |

**Cross-analysis:** Abstention failures dominate both → grader pattern-matching is primary barrier. KBs addressed groundedness. Upload-without-text pattern is second-largest (topic design, not KB).
