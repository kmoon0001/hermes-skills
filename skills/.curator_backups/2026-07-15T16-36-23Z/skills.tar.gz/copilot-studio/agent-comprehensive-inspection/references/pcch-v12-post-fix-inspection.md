# PCCH V2 — Post-Fix Inspection (2026-07-11, Updated)

## What Changed Since Previous Inspection (2026-07-11 Round 2)
All 8 prior fixes applied + 7 new KB sources added. Verifying everything stuck.

## Key Discoveries

### 1. KB Storage as componenttype=14 (Plugin)
Knowledge sources in this schema version are stored as `componenttype=14` (Plugin), **NOT** componenttype=11. Query:
```python
filt = f"_parentbotid_value eq '{BOT_ID}' and componenttype eq 14"
url = f"{ORG}/api/data/v9.2/botcomponents?$filter={quote(filt)}&$select=botcomponentid,name,data&$top=50"
```
Returns all KB sources with their names and (potentially empty) data fields.

### 2. KB Data Field May Be Empty for Some Types
Three of the new KBs had `data: (empty)` in Dataverse:
- CMS Advance Care Planning Documentation and Billing (Official) — empty data
- CMS Hospital Discharge Planning to Post-Acute Care (Official) — empty data
- CMS Medical Record Documentation Compliance (Official) — empty data

This is NOT corruption — these are likely public URL or SharePoint-based KBs where the actual content lives externally. The name, description, and "Official" flag are what matter for routing. File-attachment KBs (`kind: FileAttachmentComponentMetadata`) should have non-empty data.

### 3. Connected Agents All Deactivated
All 4 connected agent TaskDialog topics had `statecode=1` (inactive):
- SNF AI Dashboard V2
- TheraDoc Workbench
- SimpleLTC QM Coach V2
- SNF Command Center V2

**Impact:** Agent-to-agent routing is completely disabled. This may be intentional (simplifying PCCH to a standalone agent) or unintentional (missed during a publish cycle). Flag for user confirmation.

### 4. Case Start and Intent Router Deactivated
The router topic (with its Question node for "What type of output do you need?") was also deactivated (statecode=1). This means topics respond directly to NLU intent without an explicit disambiguation step.

### 5. All 3 Prior Blockers Resolved
| Blocker | Before | After |
|---------|--------|-------|
| Fallback YAML broken | `activity: ... need: SBAR handoff` — YAML parse error | `activity: ... need - SBAR handoff` — valid YAML |
| Missing responseCaptureType | 5/13 SSC topics missing FullResponse | All 16 SSC topics have FullResponse |
| KB coverage gaps | Missing discharge, ACP, AOTA, APTA, SBAR, billing, documentation | 7 new Official KBs added (total: 18) |

### 6. 146 Conversation Starters
The agent has 146 conversation starters stored as componenttype=19 entries in Dataverse — far more than the 10 in the instructions `conversationStarters:` block. Query:
```python
filt = f"_parentbotid_value eq '{BOT_ID}' and componenttype eq 19"
url = f"{ORG}/api/data/v9.2/botcomponents?$filter={quote(filt)}&$select=botcomponentid,name"
```

### 7. Topic Count Breakdown (Live Dataverse, 26 total)
- 15 active custom AdaptiveDialog topics (all OnRecognizedIntent, all with EndDialog+clearTopicQueue)
- 5 system topics (Reset Conversation, End of Conversation, Conversation Start, Conversational boosting, Multiple Topics Matched)
- 4 deactivated TaskDialog connected agent topics
- 1 deactivated custom topic (Case Start and Intent Router)
- 1 deactivated system topic (Sign in)

## Dataverse Query Patterns Used

### Instructions (componenttype=15)
```bash
az rest --resource "$ORG/" --method GET \
  --url "$ORG/api/data/v9.2/botcomponents?\$filter=_parentbotid_value eq $BOT_ID and componenttype eq 15&\$select=botcomponentid,name,data" \
  -o json 2>/dev/null > instructions.json
```

### All Topics (componenttype=9)
```bash
az rest --resource "$ORG/" --method GET \
  --url "$ORG/api/data/v9.2/botcomponents?\$filter=_parentbotid_value eq $BOT_ID and componenttype eq 9&\$select=botcomponentid,componenttype,name,data,statecode,schemaname&\$top=50" \
  -o json 2>/dev/null > topics.json
```

### All KBs (componenttype=14)
```bash
az rest --resource "$ORG/" --method GET \
  --url "$ORG/api/data/v9.2/botcomponents?\$filter=_parentbotid_value eq $BOT_ID and componenttype eq 14&\$select=botcomponentid,name,data&\$top=50" \
  -o json 2>/dev/null > plugins.json
```

### All Components (for type discovery)
```bash
az rest --resource "$ORG/" --method GET \
  --url "$ORG/api/data/v9.2/botcomponents?\$filter=_parentbotid_value eq $BOT_ID&\$select=botcomponentid,componenttype,name&\$top=200" \
  -o json 2>/dev/null | python3 -c "import json,sys; d=json.load(sys.stdin); types={}; [exec('types[c[\"componenttype\"]]=types.get(c[\"componenttype\"],0)+1') for c in d['value']]; [print(f'Type {t}: {n}') for t,n in sorted(types.items())]"
```

## YAML Parser for Dataverse Data
```python
import yaml
clean = raw_data.replace('\r\r\n', '\n').replace('\r\n', '\n')
parsed = yaml.safe_load(clean)
```
CRLF handling is critical — the Dataverse `data` field uses `\r\n`, and double-CRLF (`\r\r\n`) can appear. Always strip both.

## Statecode Meaning
- `statecode=0` = Active (topic fires normally)
- `statecode=1` = Inactive/Deactivated (topic does NOT fire, even with valid YAML and trigger phrases)
