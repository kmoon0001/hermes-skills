# Authoritative Knowledge Source Acquisition

## When to Use
When an agent needs KB content to fix groundedness failures. Domain-specific PDFs from authoritative sources (CMS, AHRQ, APTA, AOTA) uploaded as knowledge sources can push eval scores past the ~80% plateau caused by KB gaps.

## Source Discovery URLs

### CMS Medicare Learning Network (MLN)
- MLN products page: https://www.cms.gov/Outreach-and-Education/Medicare-Learning-Network-MLN/MLNProducts
- MLN search: https://www.cms.gov/medicare/learning-network/search
- Direct PDFs known to work:
  - Advance Care Planning: https://www.cms.gov/files/document/mln-advanced-care-planning.pdf
  - Medical Record Documentation Compliance: https://www.cms.gov/files/mln909160-complying-with-medical-record-documentation-requirements.pdf
  - SNF Billing Reference: https://www.cms.gov/Outreach-and-Education/Medicare-Learning-Network-MLN/MLNProducts/Downloads/SNFSpellIllnesschrtTextOnly.pdf

### CMS Quality/Safety Oversight (QSO) Memos
- Hospital discharge requirements: https://www.cms.gov/files/document/qso-23-16-hospitals.pdf
- Updated guidance: https://www.cms.gov/files/document/qso-25-24-hospitals-original-release-date-2025-09-05.pdf
- General memo page: https://www.cms.gov/medicare/health-safety-standards/quality-safety-oversight-general-information/policy-memos-states-and-cms-locations

### CMS MDS 3.0 RAI Manual
- Main page: https://www.cms.gov/medicare/quality/nursing-home-improvement/resident-assessment-instrument-manual
- Current manual PDF (v1.20.1, ~33MB, 1000+ pages): https://www.cms.gov/files/document/final-mds-3-0-rai-manual-v1-20-1-october-2025.pdf-1
- Chapter 3 (assessment coding) is the most relevant section for therapy agents

### AHRQ SBAR
- No standalone PDF available. The SBAR tool is embedded in the TeamSTEPPS curriculum:
  - https://www.ahrq.gov/teamstepps-program/curriculum/communication/tools/sbar.html
  - Long-term care example: https://www.ahrq.gov/patient-safety/settings/long-term-care/resource/facilities/ltc/mod2ap.html
  - Workaround: extract text content via web_extract and create a text/PDF file

### APTA Documentation Standards
- No standalone PDF. Key pages:
  - Initial examination/evaluation: https://www.apta.org/your-practice/documentation/defensible-documentation/elements-within-the-patientclient-management-model/initial-examination
  - Documentation overview: https://www.apta.org/your-practice/documentation
  - PT in SNF: https://www.apta.org/your-practice/practice-models-and-settings/skilled-nursing-facility
  - Note: APTA site uses React rendering — web_extract may get truncated. Save full page text via browser snapshot or curl + parse.

### AOTA OT Evaluation Checklist
- Official PDF (AOTA site blocks direct download with Incapsula WAF): https://www.aota.org/-/media/corporate/files/practice/practice-essentials/quality/snf-eval-checklist-2026.pdf
  - curl with default User-Agent returns 212-byte Incapsula block page
  - Workaround: extract PDF text content from search results or create from published web content
- Practice page: https://www.aota.org/practice/practice-settings/skilled-nursing-facilities
- Documentation: https://www.aota.org/practice/practice-essentials/documentation

### Medicare Coverage Pages
- Advance care planning: https://www.medicare.gov/coverage/advance-care-planning
- General Medicare coverage: https://www.medicare.gov/coverage

### 42 CFR Regulations (eCFR)
- Part 483 (SNF requirements): https://www.ecfr.gov/current/title-42/chapter-IV/subchapter-G/part-483
- Part 482.43 (hospital discharge planning): https://www.ecfr.gov/current/title-42/chapter-IV/subchapter-G/part-482/subpart-C/section-482.43

## Download Pattern

### For CMS PDFs (directly downloadable):
```bash
curl -sL -o "CMS_Document_Name.pdf" "https://www.cms.gov/files/document/actual-slug.pdf"
```
- CMS uses `/files/document/` or `/files/` paths
- PDFs are generally accessible without auth
- Size varies from 200KB (MLN booklets) to 33MB (MDS manual)

### For AHRQ/APTA/AOTA (no direct PDF):
```python
# Option 1: Extract text via web_extract, save as .txt (works for Copilot Studio knowledge sources)
# Option 2: Create PDF from text using fpdf2
from fpdf import FPDF
pdf = FPDF()
pdf.add_page()
pdf.set_font("Courier", size=8)
for line in text_content.split('\n'):
    pdf.cell(0, 4, line.encode('latin-1', errors='replace').decode('latin-1'), new_x="LMARGIN", new_y="NEXT")
pdf.output("filename.pdf")
```

## KB Upload Requirements for Copilot Studio
- File format: .pdf or .txt (both work as knowledge sources)
- Max file size: 5MB per MS Learn (for eval test sets)
- For the MDS manual (33MB): split into chapters or upload only relevant sections
- Naming: must be descriptive — "CMS_MDS_3.0_RAI_Manual_v1.20.1_2025.pdf" not "document1.pdf"
- Description: must state content scope — helps AI routing select correct source

## PCCH V2 Session Reference (Jul 11, 2026)
- Source folder: `D:/my agents copilot studio/Pacific Coast Case Historian/knowledge-sources/`
- 7 files, 37MB total
- Conv improved from 78% → 88% partial after instruction fixes; plateau at groundedness failures caused by missing KB
- KB gaps identified: SBAR format, discharge synthesis, advance care planning, nursing record extraction
