# ClosedListEntity Entity Reference Format

## The Problem

When a Question node with a ClosedListEntity asks the user to pick from a list, the selected value is stored as a structured reference, not a plain string. Comparing with a string literal does NOT work because the runtime value is an entity reference.

## The Entity Reference Path

Correct comparison format (two valid forms depending on where you're writing):

### Format 1: Bare Inline — Copilot Studio UI Editor Only

```
condition: =Topic.Var = '<schema-prefix>.topic.<TopicName>.main.<QuestionNodeId>'.'<ItemId>'
```

**No wrapping quotes.** The YAML value starts immediately after `condition: `. This is the ONLY format the Copilot Studio YAML editor accepts when pasting raw YAML. Wrapping in single/double quotes causes `UnexpectedToken` errors.

### Format 2: Single-Quoted YAML — Dataverse API PATCH Only

```yaml
condition: '=Topic.Var = ''<schema-prefix>.topic.<TopicName>.main.<QuestionNodeId>''.''<ItemId>'''
```

When writing via Dataverse PATCH, wrap in YAML single quotes with doubled inner quotes. This prevents backslash compounding. Do NOT paste this format into the UI editor.

### Components

| Part | Example | Description |
|------|---------|-------------|
| schema-prefix | `cr917_CopyTherapyDocuementationFeedbackAg` | Bot schema prefix (per bot, from Dataverse) |
| TopicName | `DocumentUploadIntake` | Schema name of the topic |
| QuestionNodeId | `question_document_type` | The `id:` of the Question node |
| ItemId | `Progress Report` | The `id:` from ClosedListEntity items |

### Full Example (Editor format)

```yaml
- kind: ConditionGroup
  conditions:
    - id: route_progress
      condition: =Topic.DocumentTypeSelection = 'cr917_CopyTherapyDocuementationFeedbackAg.topic.DocumentUploadIntake.main.question_document_type'.'Progress Report'
      actions:
        - kind: SendActivity
          activity: Routing to Progress Report.
        - kind: EndDialog
```

## Finding Your Bot's Schema Prefix

The schema prefix is visible in Dataverse error messages or the `name` field of botcomponents:

```
$filter = [System.Uri]::EscapeDataString("_parentbotid_value eq '<bot-id>'")
$url = "https://<org>.crm.dynamics.com/api/data/v9.2/botcomponents?`$filter=$filter&`$select=name&`$top=1"
$result = Invoke-RestMethod -Uri $url -Headers @{Authorization = "Bearer $token"}
$result.value[0].name -replace '\\..*$'
```

## PITFALL: Entity Reference Changes on Topic Rebuild

The path is tied to the topic's schema name and Question node `id:`. Renaming either breaks existing conditions. Rebuilding a topic in the UI may generate a different schema path.

## Item IDs vs Display Names

Conditions compare against the `id:` field, NOT `displayName:`. These are often the same:

```yaml
items:
  - id: recert_upoc           # What condition compares against
    displayName: Recertification or Updated Plan of Care  # What user sees
```

## Common Errors

| Error | Cause | Fix |
|-------|-------|-----|
| `UnexpectedToken, token: 'Encounter Note' (UnquotedValue)` | Pasted single-quoted YAML into UI editor. The editor expects bare inline format. | Use Format 1 — no wrapping quotes around the condition value |
| `Unexpected character in expression '\'` | Backslash escaping compounded via API PATCH with double-quoted YAML | Use Format 2 — single-quoted YAML via API, or edit in UI |
| `Incompatible type` | Variable type mismatch in comparison | Wrap string variables in `Text()` |

## Verified Working Example

From Medicare Part B Compliance Agent, Document Upload Intake (July 2026):

```yaml
condition: =Topic.DocumentTypeSelection = 'cr917_CopyTherapyDocuementationFeedbackAg.topic.DocumentUploadIntake.main.question_document_type'.'Progress Report'
```

The item `id:` in the ClosedListEntity for this condition is `Progress Report`.
