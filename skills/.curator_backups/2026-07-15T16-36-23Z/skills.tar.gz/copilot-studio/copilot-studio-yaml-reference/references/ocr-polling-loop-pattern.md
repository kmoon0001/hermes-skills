# OCR Polling Loop Pattern (retry_count_num)

## Problem
An InvokeFlowAction calls an async OCR check status flow. The OCR may not be ready on first poll. The topic needs to retry N times with a controlled exit.

## Pattern
Insert these nodes between the InvokeFlowAction (check status) and the completed/not-completed ConditionGroup:

```yaml
# After the InvokeFlowAction that checks OCR status:
# The condition checks for "Status: Completed" in the payload

- kind: ConditionGroup
  id: conditionGroup_poll_completed
  conditions:
    - id: condition_poll_completed
      condition: '="Status: Completed" in Text(Topic.ocr_payload)'
      actions:
        - kind: SearchAndSummarizeContent
          id: search_generate_report
          variable: Topic.audit_report
          # ... audit prompt ...
        - kind: SendActivity
          id: sendActivity_report
          activity: |-
            Audit Complete:
            {Topic.audit_report}
        - kind: EndDialog
          id: endDialog_completed

  elseActions:
    - kind: ConditionGroup
      id: conditionGroup_poll_again
      conditions:
        - condition: =Topic.OCRpoll < 3     # Max 3 retries
          actions:
            - kind: SendActivity
              activity: Still processing (check {Topic.OCRpoll}/3).
            - kind: GotoAction
              actionId: invokeFlow_check_async_ocr_status
      elseActions:
        - kind: SendActivity
          activity: Document still processing after 3 checks.
        - kind: EndDialog
```

## Retry Count Sentinel Pattern (10 attempts)
For topics that need more retries, use the sentinel formula:

```yaml
- kind: SetVariable
  id: setVariable_retry_count
  variable: Topic.retry_count_num
  value: =If(Value(Text(Topic.'retry_count_num')) + 1 >= 10, Blank(), Value(Text(Topic.'retry_count_num')) + 1)

- kind: ConditionGroup
  conditions:
    - id: conditionItem_retry_exit
      condition: =IsBlank(Topic.retry_count_num)
      # NO actions — when IsBlank (attempt 10+), execution stops here
      # When not blank (<10), falls through to GotoAction

- kind: GotoAction
  actionId: invokeFlow_check_async_ocr_status
```

## Key Details
- `Topic.OCRpoll` must be initialized to `0` before the first poll
- The `GotoAction` target (`actionId`) must exist earlier in the actions list
- For the sentinel pattern, `retry_count_num` is NOT initialized — the formula handles `Blank()` as the first call by treating `Value(Text(Blank()))` as 0
- Exit path at 10 retries: the IsBlank condition matches (no actions) → flow ends naturally

## Single-Quoted YAML (Preferred)

The condition in the examples above uses single-quoted YAML `'...'` to avoid backslash escaping issues. Do NOT use double-quoted `"..."` for conditions with Power Fx string literals — backslashes compound across JSON → YAML → Power Fx layers. Always wrap string variables in `Text()` for the `in` operator.
