# Async OCR Check Job Status — Power Automate Flow

## Purpose

Replaces the legacy synchronous OCR status check with a Dataverse query. Instead of calling an external OCR service that might return "Processing" indefinitely, this flow queries the **Notes (annotations)** table for a record whose `subject` matches the job ID.

## Flow Structure

```
When Copilot Studio calls a flow (trigger)
    ↓
List rows (Microsoft Dataverse)
    ↓
Respond status (Power Virtual Agents)
```

## List rows Configuration

| Parameter | Value |
|-----------|-------|
| Table name | `Notes (annotations)` |
| Filter rows | `subject eq '@{triggerBody()?['job_id']}'` |
| Row count | `1` |
| Sort by | `createdon desc` |

## Respond status Outputs

| Output | Expression |
|--------|------------|
| `found` | `not(empty(outputs('List_rows')?['body/value']))` |
| `job_id` | `@{triggerBody()?['job_id']}` |
| `job_json` | `if(empty(outputs('List_rows')?['body/value']), 'Status: Processing', concat('Status: Completed \| ', first(outputs('List_rows')?['body/value'])?['notetext']))` |
| `processing_status` | `if(empty(outputs('List_rows')?['body/value']), 'Processing', 'Completed')` |
| `message` | `if(empty(outputs('List_rows')?['body/value']), 'Still Processing', first(outputs('List_rows')?['body/value'])?['notetext'])` |
| `document_type` | `Unknown` |

## Topic Condition

The `job_json` output contains `"Status: Completed | ..."` when a note is found. The topic's condition checks for this substring:

```yaml
condition: '="Status: Completed" in Text(Topic.ocr_payload)'
```

## Why This Works

1. The OCR Submit flow writes the completed OCR text to a Dataverse Note (annotation) record with `subject = job_id`
2. The Check flow queries Notes for that job_id
3. If found → returns `Status: Completed | <OCR text>` in `job_json`
4. The topic's `ConditionGroup` detects "Status: Completed" and proceeds to generate the audit report
5. If not found → returns `Status: Processing` → topic retries (up to configured limit)

## Flow ID

`27c65bc3-277a-f111-ab0e-7ced8d6f2fba` (Medicare Part B Compliance Agent environment)

## Validated

Medicare Part B Compliance Agent, July 2026. Applied to 7 documentation review topics.
