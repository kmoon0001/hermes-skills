# Document Upload Intake Pre-Check Pattern

## Problem

When a user says "I want to upload a treatment encounter note" or "How do I upload an episode of care for review", the Document Upload Intake topic fires and asks "What type of therapy document did you want reviewed?" — even though the user already specified the type. In single-response (SR) evals this costs 1 point per fail; in multi-turn (Conv) evals it can cost 3-4 points because every turn re-asks.

The root cause: the topic has a single `Question` node with a `ClosedListEntity`. It ALWAYS asks, regardless of whether the user's query already contains the answer.

## Fix: Add a Pre-Check ConditionGroup Before the Question

Insert a `ConditionGroup` BEFORE the `Question` node. Each condition checks `System.Activity.Text` for document type keywords. If matched, it sets `Topic.DocumentTypeSelection` and uses `GotoAction` to jump directly to the routing ConditionGroup — skipping the question entirely.

```yaml
actions:
  # --- NEW: Pre-check for document type in user's query ---
  - kind: ConditionGroup
    id: precheck_doc_type
    conditions:
      - id: check_eval_pre
        condition: ="evaluation" in Lower(System.Activity.Text) || "plan of care" in Lower(System.Activity.Text) || "assessment" in Lower(System.Activity.Text)
        actions:
          - kind: SetVariable
            id: setvar_eval_pre
            variable: Topic.DocumentTypeSelection
            value: ='<schema-prefix>.topic.<TopicName>.main.<QuestionNodeId>'.'Evaluation and Plan of Care'
          - kind: GotoAction
            id: goto_route_pre
            actionId: conditionGroup_route

      - id: check_treatment_pre
        condition: ="treatment" in Lower(System.Activity.Text) && "encounter" in Lower(System.Activity.Text)
        actions:
          - kind: SetVariable
            id: setvar_treatment_pre
            variable: Topic.DocumentTypeSelection
            value: ='<schema-prefix>.topic.<TopicName>.main.<QuestionNodeId>'.'Treatment Encounter Note'
          - kind: GotoAction
            id: goto_treatment_pre
            actionId: conditionGroup_route

      - id: check_progress_pre
        condition: ="progress report" in Lower(System.Activity.Text)
        actions:
          - kind: SetVariable
            id: setvar_progress_pre
            variable: Topic.DocumentTypeSelection
            value: ='<schema-prefix>.topic.<TopicName>.main.<QuestionNodeId>'.'Progress Report'
          - kind: GotoAction
            id: goto_progress_pre
            actionId: conditionGroup_route

      - id: check_recert_pre
        condition: ="recert" in Lower(System.Activity.Text) || "recertification" in Lower(System.Activity.Text) || "upoc" in Lower(System.Activity.Text)
        actions:
          - kind: SetVariable
            id: setvar_recert_pre
            variable: Topic.DocumentTypeSelection
            value: ='<schema-prefix>.topic.<TopicName>.main.<QuestionNodeId>'.'Recertification or UPOC'
          - kind: GotoAction
            id: goto_recert_pre
            actionId: conditionGroup_route

      - id: check_discharge_pre
        condition: ="discharge summary" in Lower(System.Activity.Text) || "discharge" in Lower(System.Activity.Text)
        actions:
          - kind: SetVariable
            id: setvar_discharge_pre
            variable: Topic.DocumentTypeSelection
            value: ='<schema-prefix>.topic.<TopicName>.main.<QuestionNodeId>'.'Discharge Summary'
          - kind: GotoAction
            id: goto_discharge_pre
            actionId: conditionGroup_route

      - id: check_episode_pre
        condition: ="episode of care" in Lower(System.Activity.Text) || ("episode" in Lower(System.Activity.Text) && "care" in Lower(System.Activity.Text))
        actions:
          - kind: SetVariable
            id: setvar_episode_pre
            variable: Topic.DocumentTypeSelection
            value: ='<schema-prefix>.topic.<TopicName>.main.<QuestionNodeId>'.'Episode of Care'
          - kind: GotoAction
            id: goto_episode_pre
            actionId: conditionGroup_route
    # elseActions: (implicit — fall through to the existing Question node)

  # --- EXISTING: Question node (only reached when no type was detected) ---
  - kind: Question
    id: question_document_type
    # ... unchanged ...
```

## CRITICAL: Conditions MUST return Boolean

Each `condition:` MUST be a pure Boolean expression. Do NOT use the `If(condition, Value, Blank())` pattern — that returns the Value (e.g. EmbeddedOptionSet), not true/false, and the publish validator rejects it with `IncorrectTypeError`.

**Wrong:** `condition: |=If("eval" in Lower(System.Activity.Text), 'schema'.'Eval', Blank())`
**Right:** `condition: ="eval" in Lower(System.Activity.Text)`

Set the variable separately via `SetVariable` in the actions block.

## Keyword Selection Guidelines

- **Be specific to avoid false positives:** `"progress report"` not just `"progress"` (which would match "progress note" queries that should route differently)
- **Use `&&` for multi-word types:** `"treatment" && "encounter"` prevents "treatment plan" from matching
- **Use `||` for synonyms:** `"recert" || "recertification" || "upoc"` covers variant spellings
- **Always use `Lower(System.Activity.Text)`** for case-insensitive matching
- **Order by specificity:** Put the most specific/highest-volume types first (evaluation, treatment), least specific last (discharge, episode)

## Verification

After PATCHing:
1. Read back the topic's `data` field and confirm conditions are `condition: ="text" in Lower(...)` — NOT `condition: |-`
2. Publish via `pac copilot publish` and check for `IncorrectTypeError` diagnostics
3. In the test canvas, type "I want to upload a treatment encounter note" — should skip the question and route directly

## Known Limitations

- The pre-check only fires on the FIRST turn of the Document Upload Intake topic. If the topic was already in a Question loop (e.g. from a previous conversation turn), this won't help.
- Only detects types explicitly listed. "Progress note" won't match `"progress report"` — add synonyms if needed.
- `System.Activity.Text` contains the FULL user utterance. If the user says "review this treatment encounter note for compliance", both "treatment" and "encounter" are present and the pre-check will match.

## Source

Applied to Medicare Part B Compliance Agent (bot `b0346795`), Document Upload Intake topic (`66fc5c98-ff7a-f111-ab0e-000d3a59ae1f`), July 14 2026. Initial PATCH with `If()` conditions failed publish with `IncorrectTypeError`; resolved by switching to bare Boolean conditions.
