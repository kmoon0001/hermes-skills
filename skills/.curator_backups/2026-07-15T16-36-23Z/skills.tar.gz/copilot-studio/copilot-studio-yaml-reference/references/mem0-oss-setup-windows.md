# Mem0 OSS Setup on Windows

## Stack
- **LLM:** DeepSeek (via api.deepseek.com/v1) — or any OpenAI-compatible provider
- **Embedder:** OpenAI-compatible via OpenRouter (`text-embedding-3-small`)
- **Vector Store:** Qdrant local (embedded, file-backed)
- **API Key:** Supply via `MEM0_API_KEY` in `~/.hermes/.env` (or `OPENAI_API_KEY` / `OPENAI_BASE_URL`)

## Config file (`~/.hermes/profiles/<profile>/mem0.json`)
```json
{
  "mode": "oss",
  "user_id": "<username>",
  "agent_id": "<profile-name>",
  "llm": {
    "provider": "openai",
    "config": {
      "model": "deepseek-chat"
    }
  },
  "embedder": {
    "provider": "openai",
    "config": {
      "model": "text-embedding-3-small"
    }
  },
  "vector_store": {
    "provider": "qdrant",
    "config": {
      "path": "C:\\Users\\<user>\\.hermes\\profiles\\<profile>\\mem0_store",
      "on_disk": true
    }
  }
}
```

## Activation
```bash
pip install mem0ai qdrant-client
hermes config set memory.provider mem0
echo "MEM0_API_KEY=sk-or-..." >> ~/.hermes/.env    # OpenRouter key (handles both LLM+embeddings)
```

## Env Var Requirements
Mem0 OSS with `openai` provider reads:
- `OPENAI_API_KEY` — fallback (set by Hermes for the active provider)
- `MEM0_API_KEY` — explicit (override, recommended for clarity)
- `OPENAI_BASE_URL` — NOT supported in mem0.json config; use env var instead

## Embedders
- `openai` with `text-embedding-3-small` — works via OpenRouter
- `ollama` with `nomic-embed-text` — local, no API key, requires Ollama running
- DeepSeek does NOT have an embeddings endpoint — cannot use DeepSeek for embeddings
