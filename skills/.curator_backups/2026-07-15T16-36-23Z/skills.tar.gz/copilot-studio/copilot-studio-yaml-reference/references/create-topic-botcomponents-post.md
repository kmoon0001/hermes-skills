# Create a NEW topic via Dataverse botcomponents POST

`copilot-studio-yaml-reference` documents editing existing topics via `PATCH /botcomponents({id})`.
This file covers the **CREATE** path — adding a brand-new topic to a live agent. PATCH cannot
create; you must POST a new `botcomponent` of `componenttype 9` (AdaptiveDialog topic) and bind it
to the bot.

## Why POST (not PATCH)

- PATCH requires an existing `botcomponentid`. To ADD a topic you do not yet have an ID for.
- POST to the `botcomponents` collection creates one and returns the new ID in the `OData-EntityId`
  response header.

## Critical gotchas (all validated 2026-07-12, Pacific Coast Case Historian)

| Mistake | Error | Fix |
|---------|-------|-----|
| Set `_parentbotid_value` directly in the body | `0x80060888` "CRM do not support direct update of Entity Reference properties, Use Navigation properties instead." | Use the **navigation property**: body key `parentbotid@odata.bind` with value `'/bots(<BOTID>)'` |
| `schemaname` without a customization prefix | `0x800608ad` "must start with a valid customization prefix" | Prefix with the agent's existing solution prefix, e.g. `auto_agent_XRF5I.<Name>` (find the prefix from any existing topic's `schemaname`) |
| `componenttype` sent as a string `"9"` or omitted | validation/rejected | Send as **integer** `9` |
| Expecting HTTP 201 Created | you'll think it failed | Dataverse returns **HTTP 204** on success; the new id is in the `OData-EntityId` response header, NOT in a JSON body |

## Working Python (copy-paste; agent-specific IDs at top)

```python
import json, urllib.request, subprocess, os

ORG = "orgbd048f00"                                   # your Dynamics org subdomain
BOT = "ad635500-cf47-f111-bec5-70a8a5b1c3a3"          # target agent bot id
YAML_PATH = r"C:/.../topics/My_New_Topic.mcs.yml"     # the .mcs.yml to create

# az is NOT on the bare MSYS PATH - call it by full path with PATH injected
AZ = r"C:/Program Files/Microsoft SDKs/Azure/CLI2/wbin/az.cmd"
AZP = r"C:/Program Files/Microsoft SDKs/Azure/CLI2/wbin"
env = dict(os.environ); env["PATH"] = AZP + ";" + env.get("PATH", "")
token = subprocess.run(
    [AZ, "account", "get-access-token", "--resource", f"https://{ORG}.crm.dynamics.com",
     "--query", "accessToken", "-o", "tsv"],
    capture_output=True, text=True, env=env, shell=True).stdout.strip()

data = open(YAML_PATH, encoding="utf-8").read()

body = {
    "name": "My New Topic",                       # display name
    "schemaname": "auto_agent_XRF5I.MyNewTopic",  # MUST have customization prefix
    "componenttype": 9,                            # int, not str
    "data": data,                                  # raw YAML string
    "parentbotid@odata.bind": f"/bots({BOT})",     # navigation property, NOT _parentbotid_value
}
req = urllib.request.Request(
    f"https://{ORG}.crm.dynamics.com/api/data/v9.2/botcomponents",
    data=json.dumps(body).encode(), method="POST")
for h, v in {"Authorization": f"Bearer {token}", "Content-Type": "application/json",
             "OData-MaxVersion": "4.0", "OData-Version": "4.0", "Accept": "application/json"}.items():
    req.add_header(h, v)
resp = urllib.request.urlopen(req, timeout=120)
print("status", resp.status)                       # 204 on success
new_id = resp.headers.get("OData-EntityId", "").split("(")[-1].rstrip(")")
print("new botcomponentid:", new_id)
```

## Verify it landed (and is under the right agent)

```python
req = urllib.request.Request(
    f"https://{ORG}.crm.dynamics.com/api/data/v9.2/botcomponents({new_id})?$select=name,schemaname,data")
req.add_header("Authorization", f"Bearer {token}")
back = json.loads(urllib.request.urlopen(req, timeout=120).read())
assert "triggerQueries" in back["data"]        # or whatever key you expect
```

## Post-create notes

- The new topic is live in DRAFT (no publish needed for a DRAFT eval run).
- It is **additive** - nothing else changes. Safe under the additive-only rule.
- Re-PATCH the same `botcomponentid` later to upgrade the topic (edit flow).
- Topic count should increase by 1 (e.g. 25 -> 26) after a successful POST.
- Sibling agents in the SAME Dynamics org share the `botcomponents` collection. To study a
  high-scoring sibling's topics (logic-mining, NOT copy), list `componenttype eq 9` filtered by
  `_parentbotid_value eq '<SIBLING_BOTID>'` and read each `data` field.
