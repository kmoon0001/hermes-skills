# Preferred Auth Path — Decision Tree (2026-06-22)

This doc is the **decision procedure** for getting a working bearer token against the Power Platform / Dataverse APIs. The pipeline's `auth_helper.cjs` implements it. **Use this doc, not scripts/sniff-bearer-from-cdp.cjs**, when you need a token for *anything* (deployment, eval API, Dataverse CRUD). CDP-sniffing is a documented fallback only when the chain AND browser-popup both break.

## Why this doc exists

Before 2026-06-22 the team's default was the CDP-sniff pattern in the older `evaluation-rest-api` skill: launch Playwright on `ws://127.0.0.1:9223`, attach a CDP session, wait for Authorization: Bearer headers to fire on Copilot Studio SPA traffic, capture the token, reuse it for one read-only eval API call.

That worked but had two big problems:
1. **Read-only by scope.** The CDP-captured token is scoped to whatever page the user was on when the network event fired. Dataverse calls (`org*.crm.dynamics.com`) need a separate token, captured separately.
2. **Browser attached, no headless.** If the captured session expires mid-job, you have to refresh the browser, manually log back in (`headless: false`), then re-snapshot. Fragile and slow on this box.

The 2026-06-22 session shipped a strictly better path: **default to the existing `az login` session** via `@azure/identity` `DefaultAzureCredential`. Zero browser. Works for Dataverse *and* Power Platform. Same code path works for read AND write (within the user's existing RBAC). Falls back to `InteractiveBrowserCredential` if the az chain is dead.

## Decision Procedure (in order — try each before asking the user)

### 1. Default: use the existing az-login chain

Kevin has `az login` running on this machine already (verified: `az account show --query user.name -o tsv` returns `123713644@ensignservices.net` on tenant `03cc92c3-986c-4cf4-ae27-1478cf99d17f`). Reuse it via @azure/identity:

```javascript
const { DefaultAzureCredential } = require('@azure/identity');
const creds = new DefaultAzureCredential({ additionallyAllowedTenants: ['*'] });
const token = await creds.getToken('https://orgbd048f00.crm.dynamics.com/.default');
// token.token is the bearer, token.expiresOnTimestamp is Unix ms
```

Verified scope names:
- `https://api.powerplatform.com/.default`
- `https://orgbd048f00.crm.dynamics.com/.default`

Same chain likely works for ANY `*.powerplatform.com` and any Dataverse org URL you replace the host with. Add scopes as you discover them.

**If this works, stop. Don't fall through to (2) or (3).**

### 2. Chain is dead: open an interactive browser popup

Pass `{ allowInteractive: true }`. The helper opens `login.microsoftonline.com` in your default browser. You click "Sign In" — that's it. MSAL handles the rest. No password touches our code, not even briefly.

This is the **interactive signal we offer the user, not a managed password**. The browser exposes it to login.live.com in the click flow; we never read it.

Implementation in `auth_helper.cjs`:
```javascript
new InteractiveBrowserCredential({
  clientId: '04b07795-8ddb-461a-bbee-02f9e1d7f644',  // Microsoft's public "Azure CLI" client id
  tenantId: 'common',
  loginStyle: 'popup',
  redirectUri: 'http://localhost:8400',
});
```

That `clientId` is whitelisted specifically for the popup flow. Don't substitute any other — it won't work and you'll waste 2 minutes debugging.

### 3. Browser popup declined or unavailable: ask the user, frame as a request

This is the fall-back of last resort. If we get here, both automated paths failed. We surface the situation, ask the user to choose. **Always offer "skip this run" as a no-cost alternative.** Never demand.

### 4. Last-resort fallback: legacy CDP-sniff (rare)

This is the OLD default in `evaluation-rest-api/SKILL.md`. We keep it in our back pocket because it works even when az login is dead AND browser popups are blocked (corporate locks, captive portals). But it has all the same drawbacks the original had: read-only by scope, browser-attached.

Only attempt this if (1) AND (2) AND (3) all fail AND the user is fine with the limitations. Document why you reached for it.

If you ever find yourself reaching for (4) without exhausting (1)-(3), stop — you're taking the long road.

## Anti-patterns

**Never:**
- Print the bearer token to logs (it lasts ~1 hour, treat like an API key).
- Cache a token to disk with `chmod 666` or near the user's Desktop. Use `pipeline/.token_cache.json` with `mode: 0o600`.
- Pass the bearer token as a query string. Always `Authorization: Bearer` header.
- Use `process.env.AZURE_*_KEY` to inject secrets at runtime. The chain reads env *automatically* if those are set, but the right path is `az login` — never seed env vars manually.
- Try the `--tenant organizations` or `--tenant common` parameter chain — leave tenant detection to `@azure/identity`.

**Avoid:**
- Reaching for App Registration + client secret unless the workspace actually has admin-only endpoints AND the chain is exhausted. Most Power Platform workflows don't.
- Asking for the password in chat — even with a "trust me" wrapper.
- Building your own bearer-mint function when `auth_helper.cjs` already covers it.

## Spamless chain detection

Sometimes the chain returns `CredentialGetTokenError: ...` but the next call works. `@azure/identity` does internal retries, but if you see the error intermittently, just retry once silently — don't punish the user with the error.

If you want, you can probe at startup:
```javascript
const a = require('./auth_helper.cjs');
await a.probe([
  a.KNOWN_SCOPES.powerplatform,
  a.KNOWN_SCOPES.dataverse('https://orgbd048f00.crm.dynamics.com'),
]);
if (!a.lastProbeOk()) {
  console.log('auth chain not live — run `az login` or pass allowInteractive');
  // do not exit; let the calling code fall through to ask
}
```

## Implementation notes

- `pipeline/auth_helper.cjs` is the SINGLE source. Don't add a second token-mint function. If a future need isn't covered there, extend it in place.
- The chain tolerates `*,` in `additionallyAllowedTenants` (means any tenant) — keep that.
- Cache TTL: we re-mint a token if it's within 60 seconds of `expiresOnTimestamp`. Set that conservatively to avoid the case where a job starts and the token expires mid-request.
- The pipeline runs `eval_bot.cjs` via `pac copilot publish` last — ensure the token cache is in `pipeline/.token_cache.json` and NOT in `/tmp` (those get wiped).
