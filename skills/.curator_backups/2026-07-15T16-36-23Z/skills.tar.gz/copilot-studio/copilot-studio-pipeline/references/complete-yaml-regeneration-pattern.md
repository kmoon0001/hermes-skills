# Complete YAML Regeneration Pattern

## When to Use

When patching multiple Copilot Studio topics via the Dataverse API where you need to update structural fields (flow bindings, AI Builder model IDs, descriptions, trigger queries) across a batch of topics. Use this instead of regex substitution on existing YAML.

## Why

Regex substitution on YAML `data` fields is fragile:
- The YAML is a single long string with multi-line block scalars and nested structure
- A regex that matches one section boundary can overlap another
- The result is silently duplicated content that still parses as valid YAML but has multiple copies of every node
- Detection requires manual counting of node IDs

## Pattern

Write a PowerShell script with:

1. A `New-CleanYaml()` function that takes all parameters (name, componentName, displayName, triggers, description, modelId) and returns a complete YAML string using a here-string

2. Query all component IDs in one batch call

3. Iterate and PATCH each one with the full YAML

### Template function

```powershell
function New-CleanYaml {
    param($Name, $CompName, $DisplayName, $Triggers, $Desc, $ModelId = "guid-here")
    
    $qs = ($Triggers | ForEach-Object { "      - $_" }) -join "`n"
        
    return @"
kind: AdaptiveDialog
modelDescription: "$Desc"
mcs.metadata:
  componentName: $CompName
  description: |-
    $Desc
beginDialog:
  kind: OnRecognizedIntent
  id: main
  intent:
    displayName: $Name
    triggerQueries:
$qs

  actions:
    - kind: Question
      id: ask_for_document
      interruptionPolicy:
        allowInterruption: true
      variable: init:Topic.TopicUploadedDoc
      prompt: Please upload the $DisplayName document for review.
      entity: FilePrebuiltEntity
      valueType:
        kind: FileType

    - kind: ConditionGroup
      id: check_file_uploaded
      conditions:
        - id: file_is_valid
          condition: =!IsBlank(Topic.TopicUploadedDoc)
          actions:
            - kind: InvokeAIBuilderModelAction
              id: invokeAIBuilderModelAction
              input:
                binding:
                  Document_20input: =Topic.TopicUploadedDoc
              output:
                binding:
                  predictionOutput: Global.GlobalAuditResultstext
              aIModelId: $ModelId

            - kind: SendActivity
              id: send_audit_results
              activity: "=Global.GlobalAuditResultstext"

      elseActions:
        - kind: SendActivity
          id: send_error_message
          activity: It looks like you didn't upload a valid file.

    - kind: EndDialog
      id: end-topic
      clearTopicQueue: true
"@
}
```

### Batch PATCH loop

```powershell
$token = Get-Token
$filter = [System.Uri]::EscapeDataString("_parentbotid_value eq '$BOT_ID' and componenttype eq 9")
$select = [System.Uri]::EscapeDataString("botcomponentid,schemaname")
$url = "$ORG/api/data/v9.2/botcomponents?`$filter=$filter&`$select=$select&`$top=50"
$result = Invoke-RestMethod -Uri $url -Headers @{Authorization = "Bearer $token"; Accept = "application/json"; "OData-Version" = "4.0"; "OData-MaxVersion" = "4.0"}
$compMap = @{}
foreach ($c in $result.value) { $compMap[$c.schemaname] = $c.botcomponentid }

foreach ($t in $topics) {
    $cid = $compMap[$t.Sn]
    if (-not $cid) { continue }
    
    $yaml = New-CleanYaml -Name $t.Name -CompName $t.CompName -DisplayName $t.Disp -Triggers $t.Triggers -Desc $t.Desc -ModelId $t.Model
    
    $token = Get-Token
    $patchUrl = "$ORG/api/data/v9.2/botcomponents($cid)"
    $headers = @{Authorization = "Bearer $token"; Accept = "application/json"; "Content-Type" = "application/json"; "OData-Version" = "4.0"; "OData-MaxVersion" = "4.0"}
    $body = @{ data = $yaml }
    Invoke-RestMethod -Uri $patchUrl -Method Patch -Headers $headers -Body ($body | ConvertTo-Json -Depth 100 -Compress) | Out-Null
}
```

## Validated

Jul 2026 — 6 topics in Therapy Documentation Feedback B bot (b0346795). Applied clean YAML 3 times as we iterated on the correct pipeline (with flow → without flow → with blob variable). No corruption in any of the 18 total PATCH operations because each was a complete replacement.
