# HITL Confirmation Patterns

All agents in this pipeline interact with real patients. Per MS Learn validation guidelines: "For consequential actions, the agent must provide confirmation prompts aligned with user-initiated actions, using clear language that explicitly seeks the user's permission." (Must fix)

## When to Use Each Node Type (per MS Learn)

| Scenario | Node Type | Why |
|----------|-----------|-----|
| Agent takes action (write to EHR, generate report, send to patient) | **Adaptive Card** with Confirm/Cancel buttons | MS Learn: "A confirmation of the completion of the action must be shared by the agent in the form of a card." Must fix. |
| Displaying information to user (no action taken) | **Message** node (can contain Adaptive Card for rich display) | MS Learn: "Use Message and Question nodes to present the user with a non-interactive card that displays information." |
| Need free-text input from user | **Question** node | But prefer closed-list choices (buttons/options) over free-text where domain is bounded. |
| Multi-choice input | **Adaptive Card** with buttons | Prevents random free-text input. Each submit action must have unique `actionSubmitId` to avoid stale-click issues. |

## Adaptive Card Best Practices (from MS Learn)

1. **Unique submit identifiers** — every `Action.Submit` must include a unique `actionSubmitId` in the `data` payload. Prevents earlier card submissions from interfering with later cards.
2. **Schema version** — use 1.6 for Bot Framework Web Chat, 1.5 for Teams/Omnichannel.
3. **Must have submit button** — if the card is interactive (user submits data), it must have at least one `Action.Submit`. If it's display-only, put it in a Message node instead.
4. **Closed-list over free-text** — use buttons/options wherever the domain is bounded. This minimizes random user input.

## Confirmation Prompt Template (from MS Learn validation guidelines)

| Pass example | Fail example |
|---|---|
| "Do you want to allow searching for tickets?" | "Do you want to proceed?" (doesn't indicate what the function does) |
| "Do you want to proceed with creating a new order?" | "Searches tickets" (doesn't seek permission) |

Key rule: the confirmation must explicitly describe what the agent is about to do AND seek the user's permission.

## Topic Lint Integration (R8)

The linter warns (not errors) when a topic has `SearchAndSummarizeContent` + `EndDialog` but no `AdaptiveCard`. This is a soft check — many topics legitimately use Message nodes for non-interactive responses. The warning is a reminder to consider whether the topic's response needs HITL confirmation before being sent to a patient.
