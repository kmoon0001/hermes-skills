# Batch Topic Attribute Patching (Without YAML)

## Why

Individual topic attributes like `modelDescription` and `triggerQueries` can be PATCHed directly via the Dataverse API or PPAPI without touching local YAML files. This is useful for:

- **Broadening modelDescriptions** — changing "Use ONLY when the user provides a document" to also handle general CMS questions
- **Adding trigger phrases** — bulk-adding CMS requirement triggers across N audit topics
- **Quick wins** — applying a pattern (e.g., "add citation requirement" to all audit topic modelDescriptions) in one batch pass

No YAML parsing, no linting, no local file edits. Just a focused PATCH on the specific field.

## When NOT to use

- Structural changes (removing Question nodes, adding EndDialog, changing routing logic) — these require YAML edits to the `data` field
- Knowledge source changes — use the Knowledge tab UI
- No local sync needed — but remember to pull live→local afterward so local YAML reflects changes

## Batch Pattern (Python)

```python
import json, urllib.request, os, pathlib

token = pathlib.Path(os.path.expandvars(r'%USERPROFILE%\.copilot-studio-cli\test-agent-token.txt')).read_text().strip()
base_url = "https://api.powerplatform.com/copilotstudio"
env_id = "<environment-guid>"
api_ver = "2024-12-01"

# The PPAPI /botcomponents endpoint handles topic component data
# PATCH /environments/{envId}/bots/{botId}/botcomponents/{componentId}?api-version={apiVer}
# Body: {"data": {"modelDescription": "...", "triggerQueries": [...]}}

# For modelDescription + triggerQueries together in one batch script:
updates = [
    {"componentId": "...", "modelDescription": "new desc", "triggers": ["q1", "q2", "q3"]},
    ...
]
for u in updates:
    body = {
        "data": {
            "modelDescription": u["modelDescription"],
            "triggerQueries": u["triggers"]
        }
    }
    req = urllib.request.Request(
        f"{base_url}/environments/{env_id}/bots/{bot_id}/botcomponents/{u['componentId']}?api-version={api_ver}",
        method="PATCH",
        data=json.dumps(body).encode(),
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        print(f"  {u['componentId']}: HTTP {resp.status}")
```

## Validated Jul 1 2026

Therapy Documentation Feedback Agent (Prod) — batch script updated 6 modelDescriptions and added 18 trigger phrases across all 6 audit topics in a single pass. All returned HTTP 204.

## Pitfalls

- **Component ID vs Display Name**: The `componentId` is the schema name (e.g., `cr53f_TherapyDocumentationFeedbackB.topic.DischargeReportReview`), NOT the display name. Get it from the Dataverse `botcomponents` query or from the local `.mcs.yml` file's `componentName` field.
- **Token expiry**: The CDP-captured token lasts ~1 hour. For batch operations, capture token first, then run the full batch within that window. Do not re-capture per-request.
- **No YAML sync**: After batch patching, pull live topics down to local (e.g., `manage-agent.bundle.js pull`) so local files reflect the changes. Otherwise, the next YAML push will overwrite the PPAPI changes.
- **`data` field shape**: The `data` field of a botcomponent is the OBI authoring format. PATCHing only the specific attributes you want to change is safe — the platform merges with existing data. You do NOT need to send the full topic YAML for a partial update.
