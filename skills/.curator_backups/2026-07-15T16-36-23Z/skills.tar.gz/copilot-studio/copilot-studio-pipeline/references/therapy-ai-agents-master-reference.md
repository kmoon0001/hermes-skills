# Therapy AI Agents Dev — Master Reference

Everything we learned, built, and fixed on QM Coach V2, organized for reuse on every future agent in this environment.

---

## 1. Pipeline Overview

The pipeline is at `D:/my agents copilot studio/pipeline/`. It works on ANY agent — just create a config file.

### Files

| File | Purpose |
|------|---------|
| `auth_helper.cjs` | Auth chain (az login → DefaultAzureCredential → browser fallback) |
| `topic_lint.cjs` | Lint rules R1-R7, R9-R13 (structural checks on topic YAML) |
| `test_topics.cjs` | Automated test suite (YAML syntax, structure, lint, knowledge, triggers) |
| `publish_pipeline.cjs` | 6-stage pipeline: Auth → Lint → Test → Empty-check → Publish → Eval |
| `eval_bot.cjs` | Eval capture (tries REST API, falls back to "unavailable" row) |
| `routing_matrix.json` | Per-topic trigger phrases and expected response shape |
| `eval_history.jsonl` | Append-only run history |
| `agents/<name>.json` | Per-agent config (bot ID, env ID, org URL, topic path) |

### Adding a New Agent

1. Create `agents/<agent-name>.json`:
```json
{
  "name": "Agent Display Name",
  "botId": "BOT_ID_FROM_COPILOT_STUDIO",
  "environmentId": "ENV_ID",
  "orgUrl": "https://ORG.crm.dynamics.com",
  "topicPath": "D:/my agents copilot studio/topic_templates/",
  "skillName": "copilot-studio-<agent-name>"
}
```

2. Run: `node publish_pipeline.cjs <agent-name>`

3. The pipeline reads the config, uses the correct bot/env/topic path automatically.

---

## 2. Lint Rules (R1-R13)

Each rule maps to a known Copilot Studio failure mode. Run `node topic_lint.cjs <dir>` to check.

| Rule | Check | Severity | What Breaks |
|------|-------|----------|-------------|
| R1 | No periods in topic display names | ERROR | Solution export fails |
| R2 | No OnUnknownIntent in custom topics | ERROR | Overrides platform fallback, breaks publish |
| R3 | Non-empty beginDialog.actions | ERROR | Empty AdaptiveDialog crashes publish |
| R4 | No orphan Question nodes | ERROR | SR collapses 95→12% |
| R5 | Trigger overlap < 60% Jaccard | WARNING | Routing drift, eval variance |
| R6 | Topic ends with EndDialog | WARNING | Topic doesn't terminate cleanly |
| R7 | ≥ 3 trigger phrases | WARNING | Low NLU confidence |
| R9 | clearTopicQueue: true on EndDialog | ERROR | Topic stacking (PT conv 55→40%) |
| R10 | allowLatencyMessage: false | WARNING | Misleads AI grader |
| R11 | No SearchSpecificFiles | ERROR | Restricts search, groundedness failures |
| R12 | No SearchAllKnowledgeSources | ERROR | Invalid field, runtime errors |
| R13 | No applyModelKnowledgeSetting: false | WARNING | Knowledge gaps, score collapse |

### What We Removed

**R8 (HITL confirmation)** — removed because it fired on informational topics that search knowledge and display results. HITL confirmation is a design choice (Adaptive Card for actions, Message for information), not a structural error. The linter should catch things that break publish or degrade eval, not suggest design improvements.

---

## 3. Test Suite

Run `node test_topics.cjs --agent <name>` before every publish.

### What It Tests

| Suite | What It Checks |
|-------|----------------|
| yaml-syntax | YAML parses without error |
| structure | beginDialog, triggers, actions all present |
| lint | R1-R13 rules pass |
| knowledge | No SearchSpecificFiles, no SearchAllKnowledgeSources |
| triggers | Minimum 3 trigger phrases, no duplicates within topic |

### What It Skips

- **Aggregate files** — `consolidated`, `fine_tuned`, `all_topics`, `backup`, `archive` (source control snapshots, not active topics)
- **System topics** — `beginDialog.kind === 'OnUnknownIntent'` (built-in platform topics, not custom)

### Exit Codes

- `0` = all tests pass (safe to publish)
- `1` = one or more tests failed (must fix before publish)

---

## 4. Topic Authoring Rules (MS Learn + Kiro)

### Structural Rules

- `botcomponent` table `componenttype` = 9 (Topic V2). Older payloads used 0.
- `schemaname` field is REQUIRED on create. Pattern: `qm_coach_<topic_name>` (lowercase, alphanumerics/underscores).
- `parentbotid` uses OData-bound syntax: `'parentbotid@odata.bind': '/bots(BOT_ID)'`.
- Source of truth = local YAML file. Never edit topics only in Dataverse. Round-trip via `pac copilot pull` first.

### Topic Configuration Rules

| Rule | Source | Impact |
|------|--------|--------|
| `clearTopicQueue: true` on EndDialog | Kiro, validated PT | Topic stacking 55→40% |
| `allowLatencyMessage: false` on all topics | Kiro, validated SLP | Misleads grader, "irrelevant" failures |
| No `SearchSpecificFiles` in topics | Kiro, validated OT vs SLP | Restricts search, groundedness failures |
| No `knowledgeSources: kind: SearchAllKnowledgeSources` | Kiro | Invalid field, runtime errors |
| `applyModelKnowledgeSetting: true` or omit | Kiro | False causes knowledge gaps |
| `additionalInstructions` ≤ 4 bullet points | Kiro | Verbose = truncation (5-15% regression) |
| Prefer `webBrowsing: false` with file-only knowledge | Kiro | Web causes variable-length responses |
| No explicit citation requirements | Kiro | Over-focuses on citing at expense of completeness |
| No PHI in any payload/log/API response | Kiro | Use `record_id` pointers |
| Never mix "NOT JSON" and "Return exactly one valid JSON" | Kiro | Model confusion |

### Connected Agent Rules

- Every `InvokeConnectedAgentTaskAction` must have correct `botSchemaName` — verify against actual bot before publishing.
- Never copy-paste connected agent topics without updating `botSchemaName`.
- Detection: query `bots` entity for all specialists, cross-reference against topic YAML.

---

## 5. Anti-Corruption Checklist

Run before ANY patch to botcomponent data field. Prevents duplicated instructions, mid-word splices, BOM corruption.

### Pre-Patch Detection

| Check | How | Fail Action |
|-------|-----|-------------|
| Section header count | Key phrases appear exactly 1x | STOP — content duplicated |
| Agent identity count | Agent title appears exactly 1x | STOP — content duplicated |
| Total char length | See expected sizes below | WARN — likely duplicated |
| Mid-word splices | No word fragments before capitalized block | STOP — cursor paste |
| BOM characters | No \uFEFF | Strip before patching |
| YAML structure | Only one `kind:` at root | STOP — multiple components merged |
| Smashed words | No concatenation without spaces | STOP — partial paste |

### Expected Instruction Sizes

| Agent | Healthy Range |
|-------|---------------|
| PT_Specialist | 3,000-5,500 chars |
| OT_Specialist | 3,000-5,500 chars |
| SLP_Specialist | 1,800-3,000 chars |
| TDA | 4,000-7,000 chars |
| QM Coach V2 | 2,000-6,000 chars |

### Write Pattern

Always full replacement, never append. Always write from source-controlled YAML.

---

## 6. HITL Patterns (MS Learn)

### When to Use Each Node Type

| Scenario | Node Type | Why |
|----------|-----------|-----|
| Agent takes action (write to EHR, send to patient) | **Adaptive Card** with Confirm/Cancel | MS Learn: confirmation required for consequential actions |
| Displaying information (no action) | **Message** node | MS Learn: use for non-interactive display |
| Need free-text input | **Question** node | Prefer closed-list choices where domain is bounded |
| Multi-choice input | **Adaptive Card** with buttons | Minimizes random user input |

### Adaptive Card Rules

1. Every `Action.Submit` must have unique `actionSubmitId` — prevents stale-click issues
2. Schema version: 1.6 for Web Chat, 1.5 for Teams/Omnichannel
3. Interactive cards need at least one `Action.Submit`
4. Use buttons/options wherever domain is bounded

### Confirmation Prompt Rules

Must explicitly describe what the agent is about to do AND seek permission:
- PASS: "Do you want to proceed with creating a new order?"
- FAIL: "Do you want to proceed?" (doesn't say what)

---

## 7. Eval Patterns

### Eval Failure Diagnosis Workflow

When eval scores are low, follow this path in order:

1. **Query GPT components** (`componenttype eq 15`):
   ```
   botcomponents?$filter=_parentbotid_value eq BOT_ID and componenttype eq 15&$select=name,data
   ```
   Note: use `_parentbotid_value`, NOT `botid` (field doesn't exist on botcomponent).

2. **Check GPT instruction size** — if >6000 chars, the model produces longer responses that truncate in eval channel. Compress by removing inline knowledge source list and consolidating overlapping sections.

3. **Check topic additionalInstructions** — if >4 bullets or >200 chars, compress. Kiro guardrail: verbose instructions cause 5-15% regression. Format guidance belongs at topic level; behavioral guidance belongs at GPT level.

4. **Check for ghost components** — 0-char empty entries next to the real component. Delete them.

5. **Check for duplication** — agent name or section headers appearing >1x. Run anti-corruption checklist.

6. **PATCH via Dataverse API**, publish, re-test.

### Known Failure Modes

| Pattern | Symptom | Fix |
|---------|---------|-----|
| Response truncation | "Seems incomplete" + "Knowledge sources not cited" | Length constraint ≤800 chars, cite inline, turn off webBrowsing |
| Instruction conflict | One score improves, another regresses | Consolidate, prioritize, simplify. Highest-priority first. |
| Non-deterministic variance | ±10-20% between runs | Run 3x per iteration. File-only knowledge = more consistent. |
| Eval setup issues | Test cases missing data | Fix the test, not the agent |
| webBrowsing regression | Score drops when toggling | SLP REQUIRES webBrowsing:true (ASHA content has no PDF equivalent) |
| Connected agent routing | "Error" status in eval | Verify botSchemaName matches actual bot |
| GPT instruction corruption | Inconsistent behavior, oversized instructions | Run anti-corruption checklist, rewrite from source YAML |

### Eval Endpoint Status

- `api.powerplatform.com/copilotstudio/.../makerevaluation/...` returns 404 on our tenant (regional rollout, public preview)
- eval_bot.cjs tags such rows `source=unavailable`
- When endpoint becomes available, eval_bot.cjs will use it automatically

---

## 8. Auth Chain

### Decision Procedure

1. **Default:** `az login` → DefaultAzureCredential → MSAL token cache
2. **On failure:** interactive browser popup (`allowInteractive: true`)
3. **On decline:** ask framed as request, offer "skip this run"
4. **Skip:** app registration client secrets unless tenant requires it

### Usage

```javascript
const { getBearerToken, probe, KNOWN_SCOPES } = require('./auth_helper.cjs');
const token = await getBearerToken('https://orgbd048f00.crm.dynamics.com/.default');
```

### Verified Scopes

- `https://api.powerplatform.com/.default`
- `https://orgbd048f00.crm.dynamics.com/.default` (replace host for other orgs)

---

## 9. Debugging

All scripts use Node.js `console.log/error/warn`.

```bash
# Pipe to log file
node publish_pipeline.cjs <agent> 2>&1 | tee pipeline.log
```

### When Things Break

| Symptom | Check |
|---------|-------|
| Auth failures | `probe()` output — tells which scope failed |
| YAML parse errors | `topic_lint.cjs` shows line number |
| Publish failures | `eval_history.jsonl` for last successful run |
| Token issues | `az account show` and `pac auth list` |
| Publish error "UnknownElementError" | Orphaned action component — DELETE via API |
| Publish error "Component data malformed" | Stale synchronizationstatus — scrub or re-import |

---

## 10. QM Coach V2 Specifics

### IDs

| Field | Value |
|-------|-------|
| Bot ID | `ea52ad9c-8233-f111-88b3-6045bd09a824` |
| Environment | `a944fdf0-0d2e-e14d-8a73-0f5ffae23315` |
| Dataverse org | `https://orgbd048f00.crm.dynamics.com` |
| Tenant | `03cc92c3-986c-4cf4-ae27-1478cf99d17f` |

### Topics (15 custom + 1 system)

| Topic | Triggers | Notes |
|-------|----------|-------|
| coaching_corner | 5 | 2-3 sentences, must-contain coaching |
| DoR_Summary_fixed | 6 | Bullet format, DRAFT output |
| accountability_matrix | 5 | RACI format |
| qm_severity_classification | 5 | 4-level table |
| qm_email_generator | 5 | Email format, rewritten to avoid R5 overlap |
| facility_trend_reporter | 5 | Summary + top 3 recommendations |
| workflow_menu | 5 | Bullet list of options |
| escalate_qm_concern | 5 | Structured with urgency level |
| escalation_matrix | 5 | Escalation paths |
| qm_action_plan | 5 | Action plan format |
| qm_driver_analysis | 5 | Root cause analysis |
| qm_data_upload_decline_detection | 7 | Data upload patterns |
| clinical_intake_handoff | 5 | Handoff routing |
| Resident_Outlier_Analysis_fixed | 6 | Outlier analysis, DRAFT output |
| hitl_approval | 5 | HITL approval flow |
| conversational_boosting | system | OnUnknownIntent — not custom |

### Run Sequence

```bash
# Full pipeline
node publish_pipeline.cjs qm_coach_v2

# Individual steps
node topic_lint.cjs D:/my agents copilot studio/topic_templates/
node test_topics.cjs --agent qm_coach_v2
node eval_bot.cjs
```

---

## 11. FAQ

**Q: Why do we exclude consolidated/fine_tuned files from linting and testing?**
A: These are `pac copilot pull` export artifacts — source control snapshots that bundle all topics into one file. They contain empty sub-entries that trigger false failures. The actual topics are the individual YAML files.

**Q: Why do we skip OnUnknownIntent topics?**
A: These are system topics (built-in platform topics like Conversational Boosting). They have OnUnknownIntent as their trigger by design — it's not a custom topic mistake. MS Learn: "System topics support essential behaviors... You can't delete system topics."

**Q: Why was R8 (HITL) removed from the linter?**
A: It fired on informational topics (DoR Summary, Resident Outlier) that search knowledge and display results. These don't take actions — they just generate text for the user to read. Per MS Learn, Adaptive Card confirmation is for actions (write to EHR, send to patient), not for displaying information. The linter should catch structural errors, not suggest design improvements.

**Q: How do I add a new agent to the pipeline?**
A: Create `agents/<agent-name>.json` with botId, environmentId, orgUrl, topicPath. Then run `node publish_pipeline.cjs <agent-name>`.

**Q: What if the eval endpoint returns 404?**
A: It's a Microsoft regional rollout issue. eval_bot.cjs handles it gracefully by tagging the row as `source=unavailable`. The pipeline still gates on prior-run averages. Re-test each session — the endpoint may become available.

**Q: How do I fix a publish failure?**
A: Check the error message against the publish failure triage table in `references/common-pitfalls.md`. Most common: orphaned action component (DELETE via API), stale synchronizationstatus (scrub or re-import), or empty AdaptiveDialog (add actions).

**Q: How do I fix eval failures (low scores)?**
A: Follow this diagnosis path:
1. Query GPT components: `botcomponents?$filter=_parentbotid_value eq BOT_ID and componenttype eq 15&$select=name,data`
2. Check size — if >6000 chars, compress. Remove inline knowledge source list (model already has access). Consolidate overlapping sections.
3. Check topic `additionalInstructions` — if >4 bullets or >200 chars, compress. Detailed format guidance at topic level; behavioral guidance at GPT level.
4. Check for ghost components (0 chars) — delete them.
5. Check for duplication — "RESPONSE LENGTH" or agent name appearing >1x in instructions.
6. PATCH via Dataverse API, publish, re-test.

**Q: Why does SLP require webBrowsing:true?**
A: ASHA clinical practice content (fluency, voice, cognitive-linguistic, AAC) exists only as web pages — no downloadable PDFs available. Setting webBrowsing:false caused 95→88% regression even with topic fixes. Validated three times. This is a permanent architectural difference between SLP and PT/OT.

**Q: What's the difference between topic_lint.cjs and test_topics.cjs?**
A: topic_lint.cjs checks structural rules (R1-R13) that map to known failure modes. test_topics.cjs checks everything the linter doesn't: YAML syntax, topic structure, knowledge source config, trigger quality. The linter is faster and catches publishing blockers. The test suite is comprehensive and catches design issues.
