# CDP Batch Topic Patching

When `manage-agent push` fails and Dataverse API needs browser auth, use Chrome DevTools Protocol with Kiro Chrome's cached MSAL tokens.

## Quick Start

```bash
# 1. Launch Chrome with Kiro profile (background)
"/c/Program Files/Google/Chrome/Application/chrome.exe" \
  --remote-debugging-port=9223 \
  --user-data-dir="C:\Users\kevin\AppData\Local\Programs\Kiro\.playwright-auth" \
  --no-first-run --no-default-browser-check --disable-extensions about:blank

# 2. Verify CDP is running
curl -s http://127.0.0.1:9223/json/version | grep Browser

# 3. Run batch patch (patches all local .mcs.yml to matching live topics)
cd "D:/my agents copilot studio/pipeline"
NODE_PATH=$(npm root -g) node cdp_patch_topics.cjs patch-all

# 4. Create new topics
NODE_PATH=$(npm root -g) node cdp_patch_topics.cjs create TopicName1 TopicName2

# 5. Delete out-of-scope topics
NODE_PATH=$(npm root -g) node cdp_patch_topics.cjs delete TopicName1 TopicName2
```

## How It Works

1. Connects to Chrome via WebSocket on port 9223
2. Navigates to Dataverse org (`https://orgbd048f00.crm.dynamics.com/main.aspx`) to trigger auth
3. Uses `fetch()` from browser context (same-origin, authenticated) to PATCH `botcomponents.data` field
4. Matches local `.mcs.yml` filenames to live topic `name` field
5. Rate-limits at 500ms between calls

## Auth Requirements

- Kiro Chrome profile must have valid MSAL tokens for the Dataverse org
- If script reports "Not authenticated", user must log in via the Chrome window
- Auth expires after ~1 hour; re-login needed for new sessions

## Limitations

- Only patches `data` field (authoring YAML), not `content` (runtime YAML)
- Publishing still required after patching (`pac copilot publish`)
- New topics need `schemaname` and `parentbotid@odata.bind` set correctly
- Cannot create topics that require flow connections (those need UI setup)
