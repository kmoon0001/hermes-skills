# Content vs Data Fields on botcomponent (Jun 22, 2026)

## The Problem

MS Learn lists both `Content` and `Data` as writable columns on the `botcomponent` entity:
- `Content`: "The content or metadata of the Bot Component that defines its structure and properties." Type: Memo, MaxLength: 1048576
- `Data`: "The content of the Bot Component in OBI format." Type: Memo, MaxLength: 1048576

Both have `IsValidForUpdate: True` in the entity metadata.

## What Actually Works

| Field | PATCH via API | Notes |
|-------|--------------|-------|
| `data` | ✅ Works | YAML in OBI format. This is the authoring source. |
| `content` | ❌ 400 error | "Unexpected character encountered while parsing value: k" — server-side plugin rejects writes. |
| `name` | ✅ Works | Topic display name. |
| `statecode` | ✅ Works | 0=Active, 1=Inactive. |
| `description` | ✅ Works | Searchable text. |

## The content Error

```
PATCH /api/data/v9.2/botcomponents({id})
Body: { "content": "kind: AdaptiveDialog\r\n..." }

Response: 400
{
  "error": {
    "code": "0x80040265",
    "message": "{
      \"statuscode\": 500,
      \"statusdescription\": \"Internal Server Error\",
      \"errors\": [{
        \"code\": 10000,
        \"message\": \"Unexpected character encountered while parsing value: k. Path '', line 0, position 0.\"
      }]
    }"
  }
}
```

The `k` is the first character of `kind: AdaptiveDialog`. The platform's internal parser tries to parse the YAML as JSON and fails.

## What This Means for Topic Fixes

1. **`data` field CAN be updated via API** — this is what we've been doing successfully for empty-content topics (copying data to content).
2. **`content` field CANNOT be updated via API** — must be done through the Copilot Studio UI code editor.
3. **`pac copilot publish` does NOT sync `content` from `data`** — the two fields stay out of sync after publish.
4. **The live agent uses `content`**, not `data` — so updating `data` alone doesn't fix the live behavior.

## Correct Workflow for Topic Fixes

1. Identify topics with issues (Question nodes, stale content, etc.)
2. Build fixed YAML
3. Guide user to paste YAML into Copilot Studio UI code editor
4. User saves
5. Publish via `pac copilot publish`

The API can be used for:
- Reading topics (GET)
- Activating/deactivating topics (PATCH statecode)
- Updating topic names (PATCH name)
- Updating descriptions (PATCH description)
- Creating new topics (POST with content + data + schemaname + OData bind)
- Deleting topics (DELETE)

But NOT for updating the `content` field of existing topics.

## Verified Environment

- Default env: `https://org3353a370.crm.dynamics.com`
- Dev env: `https://orgbd048f00.crm.dynamics.com`
- Auth: `InteractiveBrowserCredential` with `clientId: 04b07795-8ddb-461a-bbee-02f9e1bf7b46`
- Token audience: `https://{org}.crm.dynamics.com/user_impersonation`
