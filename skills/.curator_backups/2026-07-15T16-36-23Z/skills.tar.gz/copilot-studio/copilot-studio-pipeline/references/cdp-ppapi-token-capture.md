# CDP WebSocket Token Capture for PPAPI

Reliable method to capture fresh PPAPI Bearer tokens from an authenticated Edge browser session.

## Prerequisites
- Edge running with remote debugging: `--remote-debugging-port=9223 --user-data-dir=C:\Users\kevin\AppData\Local\Microsoft\Edge\User Data`
- User signed into Copilot Studio in Edge

## Script
`D:/my agents copilot studio/pipeline/scripts/cdp_simple.cjs`

## How It Works
1. Connects to Edge via CDP WebSocket (port 9223)
2. Finds or creates a tab pointing to the evaluation page
3. Enables `Fetch.requestPaused` to intercept all network requests
4. Reloads the page
5. Captures the `Authorization: Bearer ...` header from any request to `powerplatform.com` or `makerevaluation`
6. Saves token to `%USERPROFILE%\.copilot-studio-cli\test-agent-token.txt`

## Key Implementation Details
- Use `Fetch.requestPaused` event (not `Network.requestWillBeSent`) because the Fetch domain gives access to request headers
- Must `Fetch.continueRequest` for every paused request to avoid blocking the page
- Search for tab by URL pattern (evaluation page), not hardcoded ID (tab IDs change on navigation)
- If no eval tab, create one via `Target.createTarget` on the browser-level WebSocket endpoint
- Token expires in ~1 hour; re-capture as needed

## Exit Codes
- 0: Token captured successfully
- 1: Failed (timeout, no tab found, auth error)
- 2: Created new tab, retry needed after page loads
