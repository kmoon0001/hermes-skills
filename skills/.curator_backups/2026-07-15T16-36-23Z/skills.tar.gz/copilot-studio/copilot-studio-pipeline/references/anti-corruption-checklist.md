# Anti-Corruption Checklist (Adopted from Kiro — Run Before EVERY Patch)

These rules prevent the mid-word splices, duplicated instruction blocks, and BOM corruption that destroyed two evals in prior sessions.

Source: Kiro's `text-corruption-prevention.md` steering (2026-06-22).

## Pre-Patch Detection

| Check | How | Fail Action |
|-------|-----|-------------|
| Section header count | Key phrases (e.g. "RESPONSE LENGTH") appear exactly 1x | STOP — content duplicated |
| Agent identity count | Agent title phrase appears exactly 1x | STOP — content duplicated |
| Total char length | GPT instructions should be 2000-6000 chars (not 8000-10000) | WARN — likely duplicated |
| Mid-word splices | No word fragments immediately before a capitalized block start | STOP — cursor-position paste |
| BOM characters | No \uFEFF anywhere in content | Strip before patching |
| YAML structure | Only one `kind:` declaration at root level | STOP — multiple components merged |
| Smashed words | No concatenation without spaces at paragraph boundaries | STOP — partial paste overlap |

## Required Write Pattern

```javascript
// In Node.js scripts — ALWAYS full replacement, never append
// CRITICAL: Only the `data` field is patchable via API.
// The `content` field is NOT patchable (server-side plugin rejects YAML).
// To update content, edit the topic in Copilot Studio UI and save.
const fullContent = `kind: GptComponentMetadata\ndisplayName: AgentName\ninstructions: |-\n  [FULL CLEAN INSTRUCTIONS - SINGLE VERSION]`;

// PATCH data field only (replaces everything)
// Expect 204 on success. Publishing does NOT sync data → content.
await fetch(`${orgUrl}/api/data/v9.2/botcomponents(${id})`, {
  method: 'PATCH',
  headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json; charset=utf-8' },
  body: JSON.stringify({ data: fullContent })
});
```

## Post-Patch Verification

```javascript
// Verify no duplication after patch
const comp = await fetch(`${orgUrl}/api/data/v9.2/botcomponents(${id})?$select=data`, { headers });
const { data } = await comp.json();
const dupes = (data.match(/RESPONSE LENGTH/g) || []).length;
if (dupes > 1) throw new Error(`CORRUPTION DETECTED: ${dupes} duplicates`);
```

## Expected Sizes (Clean, Non-Duplicated)

| Agent | GPT Instructions | Healthy Range |
|-------|-----------------|---------------|
| PT_Specialist | ~4,900 chars | 3,000-5,500 |
| OT_Specialist | ~4,900 chars | 3,000-5,500 |
| SLP_Specialist | ~2,200 chars | 1,800-3,000 |
| TDA | ~6,100 chars | 4,000-7,000 |
| QM Coach V2 | ~3,000-5,000 chars | 2,000-6,000 |

If any agent's GPT instructions exceed the upper range, it's likely corrupted — run the detection checklist.

## What NOT to Do

- Never append to existing GPT instructions — always full replacement
- Never paste into the Copilot Studio UI instructions textbox without Select All → Delete first
- Never use partial string replacement on the `data` field (e.g., `-replace` on a substring)
- Never trust the current live content — always write from source-controlled YAML
- Never list knowledge sources inline in GPT instructions — the model already has access to configured sources. Listing them wastes instruction budget.

## How to Check Live GPT Instructions

Query Dataverse for GPT components (componenttype=15):

```javascript
const url = `${orgUrl}/api/data/v9.2/botcomponents?$filter=_parentbotid_value eq '${botId}' and componenttype eq 15&$select=name,data`;
// Check: size, duplicate headers, ghost components (0 chars), BOM characters
```
