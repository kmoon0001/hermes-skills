# Notepad Delivery Workflow (User Preference, 2026-07-11)

## When to Use

When providing YAML topic code for the user to paste into the Copilot Studio code editor. The user has explicitly stated: **"if you give me code, always pull up on notepad"** — do NOT deliver code only inline in chat; always open a Notepad window with the file.

## Workflow

1. **Write YAML to disk** — save to `D:\my agents copilot studio\pipeline\patches\<topic-name>.yaml`
2. **Open in Notepad** — `start notepad "D:\my agents copilot studio\pipeline\patches\<topic-name>.yaml"`
3. **Tell the user** the file is open and ready to copy-paste into the code editor

## Why Not Chat Code Blocks

- The user finds inline YAML blocks in chat harder to copy correctly
- The Copilot Studio code editor has specific YAML parsing quirks (bare inline conditions, no single quotes) — having the file open in Notepad lets them verify the exact format
- Avoids the API↔UI sync problem where API PATCHes get overwritten by the UI cache
- The paste-into-code-editor workflow keeps the UI as the single source of truth

## File Location Convention

All paste-ready YAML files: `D:\my agents copilot studio\pipeline\patches\<TopicName>.yaml`

Open all files at once: `start notepad "D:\...\patches\Topic1.yaml"` (repeat per file)
