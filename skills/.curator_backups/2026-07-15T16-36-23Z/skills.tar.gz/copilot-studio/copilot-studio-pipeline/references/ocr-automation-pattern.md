# OCR Automation Pattern — Remove User-Typed "Check OCR Status"

## Problem (Feedback B, Jul 2026)

After document upload, the agent told users to **type** "check OCR job status" to proceed. This made the agent feel broken — users had to manually poll instead of the agent monitoring automatically.

## Fix Pattern

### 1. "Large Document OCR Extraction" — auto-poll after submit

Instead of: submit → tell user "check OCR status" → wait for user to type

Do: submit → auto-poll up to 3× → if still processing, save Job ID and tell user they can ask later

**Key YAML changes:**
```
# After InvokeFlowAction (submit), add:
- kind: SetVariable
  id: setVariable_poll_init
  variable: Topic.ocr_poll_count
  value: "0"

- kind: GotoAction
  id: goto_poll_start
  actionId: invokeFlow_check_status   # loops back to poll

# Polling loop target:
- kind: InvokeFlowAction
  id: invokeFlow_check_status
  # ...call flowId: 27c65bc3-277a-f111-ab0e-7ced8d6f2fba...

- kind: ConditionGroup
  id: conditionGroup_ocr_completed
  conditions:
    - condition: ="Status: Completed" in Topic.ocr_payload
      # → SearchAndSummarizeContent + SendActivity + EndDialog
  elseActions:
    - condition: =Topic.ocr_poll_count < 3
      # → SendActivity "still processing (check N/3)..." → GotoAction poll again
    - else:
        # → SendActivity "still processing after multiple checks"
        # → EndDialog (save Job ID for later)
```

### 2. "Check Async OCR Job Status" — use saved Job ID automatically

Instead of: always prompting user to type the Job ID

Do: check if `System.Var.TherapyDocFeedbackAgent.async_job_id` is set → if yes, use it silently

**Key YAML changes:**
```
- kind: ConditionGroup
  id: conditionGroup_use_saved_id
  conditions:
    - condition: =!IsBlank(System.Var.TherapyDocFeedbackAgent.async_job_id)
      actions:
        - SetVariable: Topic.async_job_id = System.Var.TherapyDocFeedbackAgent.async_job_id
        - SendActivity: "Using your saved OCR Job ID: {Topic.async_job_id}. Checking..."
  elseActions:
    - Question: "Please enter the OCR Job ID."   # only if no saved ID
```

## Validated

- Agent: Therapy Documentation Feedback B (`b0346795`)
- Topics: `Large Document OCR Extraction`, `Check Async OCR Job Status`
- Result: User no longer needs to type "check OCR job status" — agent polls automatically, saves Job ID, and reuses it on subsequent requests.

## Pitfalls

1. **GotoAction looping** — make sure there's a poll limit (≤3) and an `EndDialog` after the limit, otherwise the topic never ends.
2. **Job ID persistence** — save to `System.Var.<agent>.async_job_id` so it survives across topics.
3. **InvokeFlowAction flowId** — must match the actual Power Automate flow for checking OCR status. Verify the GUID before copying this pattern.
