# OCR Polling Retry Architecture Pattern

## Problem

Copilot Studio topics that use Power Automate flows for async OCR extraction need to poll for completion. Without proper retry logic, three failure modes occur:

1. **Dead condition** (`Topic.RetryCount < 0`) — the condition never evaluates to true, so the retry loop never fires
2. **No retry at all** — one-shot OCR check only, if still processing the user gets a static "not complete yet" message
3. **No exit sentinel** — infinite loop that burns quota

## Reference Pattern (Discharge Summary, verified working)

```
setVariable_ocr_payload     → capture job_json
conditionGroup_ocr_completed
  ├─ "Status: Completed"    → SearchAndSummarizeContent (audit)
  │                          → SendActivity (results)
  └─ elseActions:
       → SendActivity        "not complete yet, Job ID: {…}"
       → SetVariable         retry_count_num = If(Value(Text(Topic.'retry_count_num')) + 1 >= 10, Blank(), …)
       → ConditionGroup      IsBlank(Topic.retry_count_num)  ← silent exit at 10
       → GotoAction          → invokeFlow_check_async_ocr_status (loop)
EndDialog
```

### Key sentinel formula

```
=If(Value(Text(Topic.'retry_count_num')) + 1 >= 10, Blank(), Value(Text(Topic.'retry_count_num')) + 1)
```

- Increments on every poll attempt
- Returns `Blank()` at attempt 10 → `IsBlank` condition fires → silent exit
- Topic variable name: `retry_count_num` (consistent across all patched topics)

## Topics Verified With This Pattern

| Topic | Status |
|-------|--------|
| Discharge Summary | ✅ Reference — had pattern from authoring |
| Eval/Assessment + Plan of Care | ✅ Patched from dead `RetryCount < 0` |
| Treatment Encounter Note Review | ✅ Patched from no retry logic |
| Recertification/UPOC Review | ✅ Patched from no retry logic |
| Episode of Care | ✅ Patched from dead `RetryCount < 0` |
| Progress Report Review | ✅ Had `RetryCount < 10` (different var name, works) |

## Patch Procedure

1. GET current `data` field via Dataverse API
2. Find the `elseActions:` block after `conditionGroup_ocr_completed`
3. Replace the entire block with the pattern above
4. PATCH `botcomponents({id})/data` with `{"value": new_yaml}`
5. `pac copilot publish --bot <id> --environment "<orgUrl>"`
6. Verify via re-querying `data` field

## Pitfalls

- **The `RetryCount < 0` bug** — this was present in Eval/Assessment + Plan of Care and Episode of Care. It appears to be a Copilot Studio canvas default: when you add a retry condition through the UI and don't configure it, it generates `RetryCount < 0` which can NEVER be true (RetryCount starts at 0, 0 < 0 is false).
- **Progress Report uses `RetryCount` not `retry_count_num`** — different variable name, same logic. If harmonizing, verify the `>=` comparison and `IsBlank` exit both reference the same variable.
- **The 5-second delay in Power Automate** — the Copilot Studio YAML doesn't contain the delay; it's embedded in the Power Automate flow itself. The YAML only handles the polling loop.
- **10 retries at ~5s each = ~50s max** — if OCR takes longer, the user gets the "use check OCR job status" message.

## ConvStart Rule (2026-07-10)

**Do NOT activate ConversationStart via Dataverse PATCH on a reorganized bot.** The baseline Conv score (45%) was achieved with ConvStart in **statecode=1 (inactive)**. Activating it caused Conv regression to 10-15% because the menu question's ClosedListEntity routing conditions reference topic names that no longer exist after reorganization. The menu asks "what document type" then tries to BeginDialog to topic IDs that were deleted — the agent falls through to the `elseActions/SearchAndSummarizeContent` branch which is less structured than having the NLU route naturally through individual topic triggers.

**Best practice for reorganized bots:** Leave ConvStart deactivated. The `OnConversationStart` system trigger is a single-speaker gate that forces every incoming message through its menu — if the menu's child topic references are stale, it's better to disable it entirely and let `OnRecognizedIntent` topic matching handle routing naturally.
