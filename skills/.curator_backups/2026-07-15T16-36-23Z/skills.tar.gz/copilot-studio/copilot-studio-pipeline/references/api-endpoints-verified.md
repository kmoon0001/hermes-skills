# API Endpoints — Verified Status

Last updated: 2026-06-22 (this session)
Verified against bot `ea52ad9c-8233-f111-88b3-6045bd09a824` / env `a944fdf0-0d2e-e14d-8a73-0f5ffae23315` / org `orgbd048f00.crm.dynamics.com`.

## Status legend

- ✓ WORKING — confirmed live, returns expected shape
- ⚠ UNAVAILABLE — auth chain live but endpoint returns 404 RouteNotFound (likely public preview, regional rollout)
- ✗ DENIED — token minted but permission denied (need different role)
- ? UNTESTED — referenced in MS Learn docs but no probe in this session

---

## Power Platform REST API (api.powerplatform.com)

Auth: bearer token from auth_helper.cjs (chain: az login → AzureCliCredential).
Verified scopes in cache: `https://api.powerplatform.com/.default`.

| Endpoint | Method | Status | Notes |
| -------- | ------ | ------ | ----- |
| `/copilotstudio/environments/{envId}/bots/{botId}/api/makerevaluation/testsets?api-version=2024-10-01` | GET | ⚠ UNAVAILABLE | Gateway rewrites URL with `/{tenant-id}/` prefix; 404 RouteNotFound. Public preview — not yet in our tenant region. Last checked: 2026-06-22. Re-test per session. |
| `/copilotstudio/environments/{envId}/bots/{botId}/api/makerevaluation/testsets/{id}/run?api-version=2024-10-01` | POST | ⚠ UNAVAILABLE | Same as above — doesn't reach the route once gateway rewrites URL. |
| `/copilotstudio/environments/{envId}/bots/{botId}/api/makerevaluation/testruns/{runId}?api-version=2024-10-01` | GET | ⚠ UNAVAILABLE | Same as above. |
| `/copilotstudio/bots/makerenvironments?api-version=2024-10-01` | GET | ⚠ UNAVAILABLE | 404. |
| `/copilotstudio/environments?api-version=2024-10-01` | GET | ⚠ UNAVAILABLE | 404. |
| `/` (root) | GET | ✓ (docs page) | Returns Microsoft Learn HTML — confirms the host DNS but not API endpoints. |

## Dataverse Web API (orgbd048f00.crm.dynamics.com/api/data/v9.2)

Auth: bearer for scope `https://orgbd048f00.crm.dynamics.com/.default`.

| Endpoint | Method | Status | Notes |
| -------- | ------ | ------ | ----- |
| `/WhoAmI` | GET | ✓ WORKING | Returns UserId + BusinessUnitId — confirmed auth chain live for our user. |
| `/EntityDefinitions` | GET | ✓ WORKING | 6.5 MB metadata doc; lists all entity definitions. Search for tables by SchemaName substring. |
| `/botcomponents?$filter=...&$select=...` (topic CRUD) | GET/POST/PATCH | ? UNTESTED last session, prior sessions ✓ | We used it across the prior session. componenttype=9, schemaname required, parentbotid uses OData-bound syntax `'parentbotid@odata.bind': '/bots(BOT_ID)'`. |
| `/botcomponents({id})` | DELETE/GET/PATCH | ? UNTESTED last session, prior sessions ✓ | Empty topics must be deleted via API (publish-killer if not). |
| `/bots({botId})` | PATCH | ✓ WORKING (twice this session) | PAC CLI publishes via this — last successful: 6/22/2026 12:31:18 AM. |
| `/msdyn_evalresults?$top=N` | GET | ✗ DENIED | Token works, but lacks `prvReadmsdyn_evalresult` privilege. Need AI Builder Author or Evaluator role. |
| `/msdyn_aievaluationruns?$top=N` | GET | ✓ WORKING (returns 0 rows) | Tenant has no AI Builder runs. Not used for Copilot Studio results. |
| `/msdyn_aitestruns?$top=N` | GET | ✓ WORKING (returns 0 rows) | Same. |
| `/msdyn_aitestrunbatches?$top=N` | GET | ✓ WORKING (returns 0 rows) | Same. |
| `/msdyn_aitestcases?$top=N` | GET | ✓ WORKING (returns 0 rows) | Same. |

Where Copilot Studio eval results actually live: not in Dataverse tables that we can read. They live in the api.powerplatform.com REST endpoint at `api.powerplatform.com/copilotstudio/.../makerevaluation/...` and at `copilotstudio.microsoft.com` UI storage. Until the regional rollout lands, our eval_bot captures `source=unavailable` and gates on prior-run averages.

---

## PAC CLI

Verified: `C:/Users/kevin/.dotnet/tools/pac.exe` v2.7.4+g06bb2eb (.NET 10.0.9).

| Command | Status | Notes |
| ------- | ------ | ----- |
| `pac auth list` | ✓ WORKING | Returns 3 profiles: #1 UNIVERSAL OS-auth (defunct/replaced), #2 User TDAFix Therapy AI Agents Dev, #3 User OTFix (same env). Use #2. |
| `pac copilot list --environment X` | ✓ WORKING | Returns 15 bots in env a944fdf0. Confirms auth-chain live. |
| `pac copilot publish --bot X --environment Y` | ✓ WORKING | Last successful: ea52ad9c-8233-f111-88b3-6045bd09a824 [6/22/2026 12:31:18 AM]. |
| `pac copilot status --bot X` | ? UNTESTED this session | Documented in MS Learn. |

## Azure CLI

`C:/Program Files/Microsoft SDKs/Azure/CLI2/wbin/az`

| Command | Status | Notes |
| ------- | ------ | ----- |
| `az account show --query user.name -o tsv` | ✓ WORKING | Returns `123713644@ensignservices.net` |
| Tenant ID | ✓ KNOWN | `03cc92c3-986c-4cf4-ae27-1478cf99d17f` |
| Default subscription | ✓ KNOWN | `Azure subscription 1` (`ee15f208-b7ca-4eb2-9ff1-e0948e1decde`) |

## Chromium / Chrome CDP

| Endpoint | Status | Notes |
| -------- | ------ | ----- |
| `ws://127.0.0.1:9223` (DevTools) | ? UNTESTED this session, prior sessions ✓ | Used for SPA navigation. SPA eval pages unreliable via CDP — kept landing on Overview. |
| Chrome temp profile `--user-data-dir=$TEMP/chrome-cdp-profile` | ? UNTESTED this session | Prior sessions worked but lacked auth cookies — fresh login required. |

---

## Things NOT to do

- Don't try `api.powerplatform.com/admin/...` paths unless we explicitly need admin endpoints. They likely need higher roles.
- Don't try `login.microsoftonline.com/{tenant}/oauth2/v2.0/token` with `grant_type=password` from inside scripts. The legacy flow is documented but PAC/az already give us working tokens — no reason to add password-handling code.
- Don't create a new App Registration unless user explicitly opts into Power Platform admin flow. Default path: az-login chain → interactive browser fallback.
- Don't store bearer tokens in environment variables between sessions. Use `auth_helper.cjs`'s `pipeline/.token_cache.json` (per-machine).
