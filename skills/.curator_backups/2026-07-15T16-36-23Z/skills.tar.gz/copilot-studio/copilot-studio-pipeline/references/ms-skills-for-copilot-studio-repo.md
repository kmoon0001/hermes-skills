# Microsoft's skills-for-copilot-studio Repo

**Repo**: https://github.com/microsoft/skills-for-copilot-studio
**Cloned to**: C:\Users\kevin\skills-for-copilot-studio
**Purpose**: Plugin for Claude Code / GitHub Copilot CLI / VS Code — authoring, testing, troubleshooting Copilot Studio agents via YAML files.

## What It Provides

### Bundled Scripts (scripts/*.bundle.js)
| Script | Purpose | Replaces/Enhances |
|--------|---------|-------------------|
| `schema-lookup.bundle.js` | Schema queries + YAML validation against 884KB JSON schema | Our manual YAML validation |
| `manage-agent.bundle.js` | push/pull/clone/publish/validate/list-agents/list-envs via LSP binary | Our `pac copilot publish` + Dataverse API PATCH |
| `eval-api.bundle.js` | Power Platform Evaluation API — test DRAFT agents without publishing | Our `eval_bot.cjs` |
| `chat-with-agent.bundle.js` | Detect auth mode (DirectLine vs M365) | — |
| `directline-chat.bundle.js` | DirectLine v3 chat for testing | — |
| `connector-lookup.bundle.js` | Connector operations lookup (inputs/outputs) | — |

### Schema Lookup Commands
```bash
node schema-lookup.bundle.js kinds                    # List all valid kind values
node schema-lookup.bundle.js lookup SendActivity      # Look up definition
node schema-lookup.bundle.js resolve AdaptiveDialog   # Resolve $ref chains
node schema-lookup.bundle.js search <keyword>         # Search definitions
node schema-lookup.bundle.js summary Question         # Compact overview
node schema-lookup.bundle.js validate <file.yml>      # Validate YAML file
```

### Manage Agent Commands
```bash
node manage-agent.bundle.js clone --workspace . --tenant-id <id> --url <copilot-studio-url>
node manage-agent.bundle.js pull --workspace <path> --tenant-id <id> --environment-id <id> --environment-url <url> --agent-mgmt-url <url>
node manage-agent.bundle.js push --workspace <path> ...  # Auto-validates before push
node manage-agent.bundle.js validate --workspace <path> ...
node manage-agent.bundle.js publish --workspace <path> --tenant-id <id> --environment-url <url>
node manage-agent.bundle.js list-agents --tenant-id <id> --environment-url <url>
node manage-agent.bundle.js list-envs --tenant-id <id>
```
- Push auto-validates all .mcs.yml files before pushing
- Must pull before push (ConcurrencyVersionMismatch otherwise)
- Publish uses Dataverse PvaPublish bound action directly

### Eval API Commands (DRAFT testing — no publish needed!)
```bash
node eval-api.bundle.js list-testsets --workspace <path> --client-id <id>
node eval-api.bundle.js start-run --workspace <path> --client-id <id> --testset-id <id> --run-name "name"
node eval-api.bundle.js get-run --workspace <path> --client-id <id> --run-id <id>
node eval-api.bundle.js get-results --workspace <path> --client-id <id> --run-id <id>
```

### Auth Flows
1. **Interactive browser** (push/pull/clone) — VS Code 1p client, tokens cached 90 days in OS credential store
2. **Device code flow** (chat/test tokens) — needs Azure App Registration with `CopilotStudio.Copilots.Invoke` permission

### Templates (17 YAML templates in templates/)
Topics: greeting, fallback, search-topic, question-topic, auth-topic, error-handler, disambiguation, conversation-init, custom-knowledge-source, remove-citations, arithmeticsum
Actions: connector-action, mcp-action
Knowledge: public-website, sharepoint
Variables: global-variable
Agents: agent, child-agent
All use `_REPLACE` placeholders for unique IDs.

### Patterns Library (14 patterns in patterns/)
- jit-glossary, jit-user-context, dynamic-topic-redirect
- prevent-child-agent-responses, date-context, orchestrator-variables
- prevent-tool-call-leaks, channel-aware-behavior, rai-error-handling
- line-breaks-in-messages, knowledge-hold-message
- deterministic-mcp-calls, chain-of-thought-logging
- conversation-history-variable, teams-production-hardening

### Skills (28 SKILL.md files in skills/)
Key skills that encode Copilot Studio YAML authoring knowledge:
- `new-topic` — topic creation with template matching + mandatory schema verification
- `add-node` — adding nodes (SendActivity, Question, ConditionGroup, etc.)
- `edit-agent` — agent.mcs.yml and settings.mcs.yml editing
- `edit-triggers` — trigger phrases + modelDescription
- `validate` — LSP-based validation
- `lookup-schema` — schema exploration
- `manage-agent` — push/pull/clone/publish via LSP binary
- `add-action` — connector actions (guide pattern — UI must create connection first)
- `add-knowledge` — knowledge sources
- `add-generative-answers` — SearchAndSummarizeContent patterns
- `run-eval` — PP Evaluation API for draft testing
- `int-reference` — FULL reference tables (triggers, actions, vars, entities, Power Fx)

### Reference Connectors (reference/connectors/)
- shared_sharepointonline.yml, shared_office365.yml
- shared_office365users.yml, shared_visualstudioteamservices.yml

## Key Insights for Our Pipeline

### 1. Schema Validation Prevents Hallucination
NEVER write a `kind:` value without verifying it exists via schema-lookup. The #1 source of errors is hallucinated kind values.

### 2. Eval on Draft (No Publish Needed)
eval-api.bundle.js can test DRAFT agents. This is critical for autonomous iteration loops — edit → validate → eval on draft → fix → repeat.

### 3. Generative Orchestration Changes YAML Patterns
When `GenerativeActionsEnabled: true`:
- Use `AutomaticTaskInput` instead of Question nodes
- Use topic outputs instead of SendActivity for final results
- `modelDescription` > trigger phrases for routing
- `inputs` and `outputType` go at AdaptiveDialog root level, NOT inside beginDialog

### 4. MCP Actions Have Different YAML Structure
MCP: `InvokeExternalAgentTaskAction` + `ModelContextProtocolMetadata`
Connector: `InvokeConnectorTaskAction` + `operationId`
Do not mix these.

### 5. LSP Binary vs pac CLI
- `manage-agent.bundle.js` uses the VS Code extension's LanguageServerHost binary (same protocol as the extension)
- `pac copilot publish` uses its own auth and protocol
- LSP binary handles push/pull/clone/publish/validate in one tool
- pac CLI only handles publish

### 6. How to Extend
- Schema lookup: standalone, just needs the JSON schema file
- Manage agent: needs VS Code Copilot Studio extension installed (provides LSP binary)
- Eval API: needs Azure App Registration with Dataverse permissions

## Extracted Hermes Skills (2026-06-25)

16 Hermes skills created from the repo's SKILL.md files, all in `copilot-studio` category:

### Authoring
- `copilot-studio-author-topic` — create new topics from templates
- `copilot-studio-add-node` — add/modify nodes (Question, SendActivity, etc.)
- `copilot-studio-edit-agent` — edit instructions, model, settings
- `copilot-studio-edit-triggers` — trigger phrases + modelDescription
- `copilot-studio-add-knowledge` — knowledge sources (web, SharePoint, custom API)
- `copilot-studio-add-action` — connector actions guide + MCP actions
- `copilot-studio-add-adaptive-card` — AdaptiveCardPrompt nodes
- `copilot-studio-add-global-variable` — GlobalVariableComponent
- `copilot-studio-add-other-agents` — child agents + connected agents
- `copilot-studio-add-generative-answers` — SearchAndSummarizeContent patterns

### Reference + Patterns
- `copilot-studio-yaml-reference` — complete YAML reference (triggers, actions, vars, Power Fx, entities)
- `copilot-studio-patterns` — 15-pattern library index

### Management + Testing
- `copilot-studio-manage-agent` — push/pull/clone/publish via LSP binary
- `copilot-studio-validate` — two-layer validation (schema + LSP)
- `copilot-studio-run-eval` — eval on DRAFT (no publish needed)
- `copilot-studio-chat-test` — point-test via DirectLine or M365 SDK

### Autonomous Workflows
- `copilot-studio-autonomous-builder` — full edit→validate→push→publish→test loop
- `copilot-studio-eval-loop` — eval failures→auto-fix→re-test until passing
