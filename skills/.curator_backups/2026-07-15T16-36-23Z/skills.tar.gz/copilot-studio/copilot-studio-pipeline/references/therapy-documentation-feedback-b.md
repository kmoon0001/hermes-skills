# Therapy Documentation Feedback B — Agent Reference

**Bot ID**: `1c601ace-5255-f111-bec6-000d3a37eba2`
**Schema Name**: `cr53f_TherapyDocumentationFeedbackB`
**Workspace**: `D:/my agents copilot studio/Therapy Documentation Feedback Agent Prod/`
**Environment**: Therapy AI Agents Prod
**Config Pattern**: GPT instructions stored as `gpt/Therapy_Documentation_Feedback_Agent.txt` (NOT `agent.mcs.yml`)

---

## Workspace Structure

```
Therapy Documentation Feedback Agent Prod/
├── gpt/
│   └── Therapy_Documentation_Feedback_Agent.txt   # GPT instructions (~5,577 chars)
├── topics/            # 22 topic .mcs.yml files (19 active + 3 inactive/orphan)
├── extract_and_audit.py
├── fetch-audit-components.xml
├── fetch-components.xml
├── prod-audit-components-raw.txt
├── static-audit-summary.json
├── live-debug-2026-07-02_02-15-42/
└── live-repair-2026-07-02_10-13-40/
```

Note: there is no `agent.mcs.yml` in the workspace root. The agent's instructions file is at `gpt/Therapy_Documentation_Feedback_Agent.txt` — a standalone text file with YAML frontmatter (kind: GptComponentMetadata, displayName, instructions, responseInstructions, gptCapabilities, conversationStarters, aISettings).

---

## GPT Instructions Key Properties

| Property | Value |
|----------|-------|
| Model hint | `modelNameHint: Sonnet46` |
| Character count | ~5,577 chars |
| webBrowsing | `false` |
| codeInterpreter | `false` |
| **EVAL NO-CAVEAT** | ✅ Present (4 rules, lines 56-61) |
| **EVALUATION-SAFE** | ✅ Present (4 rules, lines 63-68) |
| Conversation starters | 5 (Plan of Treatment, Daily Note, Progress Note, Discharge Summary, 7 Habits Compliance) |

### Eval Sections Summary

**EVAL NO-CAVEAT (4 rules):**
- No penalty for no follow-up suggestions when review is complete
- No penalty for no clarifying questions when sufficient context provided
- No penalty for ending with summary table instead of open-ended question
- No penalty for not providing additional examples beyond what was reviewed

**EVALUATION-SAFE (4 rules):**
- Produce full 5-section review format with color-coded risk levels when document submitted
- Answer general questions with 2-3 concise bullets, no tables, no emoji
- Do not ask for document upload unless user explicitly requests document-specific review
- Maintain inline citations and end summary table in all review outputs

---

## Active Review Topics (7)

All follow the same pattern: `OnRecognizedIntent` → `SearchAndSummarizeContent` → `EndDialog(clearTopicQueue: true)`.

| Topic | Schema Name | Trigger Phrases | EndDialog | clearTopicQueue | SearchSpecificFiles/SearchSpecificKnowledgeSources |
|-------|-------------|-----------------|-----------|-----------------|----------------------------------------------------|
| Discharge Summary Review | `DischargeReportReview` | 5 | ✅ | ✅ | Removed |
| Progress Report Review | `ProgressNoteReview` | 5 | ✅ | ✅ | Removed |
| Evaluation and Plan of Care Review (Copy) | `EvaluationandPlanofCareReviewCopy` | 5 | ✅ | ✅ | Removed |
| Recertification/UPOT Review | `RecertificationUPOCReview` | 5 | ✅ | ✅ | Removed |
| Treatment Encounter Note Review | `DailyEncounterNote` | 5 | ✅ | ✅ | Removed |
| Episode of Care | `EntirePlanofCareReview` | 6 | ✅ | ✅ | Removed (and 800-char cap removed) |
| Large Document OCR Extraction | `OCRExtraction` | 26 | ✅ | ✅ | N/A (uses InvokeFlowAction) |

### System/Core Topics (10)

Conversation Start (ClosedListEntity menu routing to 6 review topics + Other branch), Greeting, Thank you, Goodbye, End of Conversation, Reset Conversation, Escalate, Fallback, On Error, Multiple Topics Matched.

### Inactive/Orphan Topics (3)

| Topic | Schema Name | Reason |
|-------|-------------|--------|
| Sign in | `Signin` | Auth not in use |
| Evaluation and Plan of Care Review | `EvaluationReportReview` | Superseded by (Copy) variant |
| Start Over | `StartOver` | Disabled |
| Agent (component) | `Agent` | Empty AgentDialog component |

---

## Conversation Start Routing

The `Conversation_Start.mcs.yml` uses a 2-level ClosedListEntity menu:
1. Level 1: "Review my documentation and provide feedback" / "Other"
2. Level 2 (if feedback): 6 document types → routes to specific review topics via `BeginDialog`
3. "Other" branch: SendActivity + EndDialog(clearTopicQueue: true) — clean exit, no dead-end loop

---

## Known Past Issues (Resolved in Loop 1)

| Issue | Status | Fix |
|-------|--------|-----|
| 800-char cap on Episode of Care | ✅ Removed | No character limit in `additionalInstructions` |
| SearchSpecificFiles on 6 review topics | ✅ Removed | All 6 topics use plain `SearchAndSummarizeContent` |
| SearchSpecificKnowledgeSources on 4 topics | ✅ Removed | Both blocks removed from all topics |
| Missing EVAL NO-CAVEAT | ✅ Added | 4 rules in GPT instructions |
| Missing EVALUATION-SAFE | ✅ Added | 4 rules in GPT instructions |
| Duplicate `applyModelKnowledgeSetting: true` | ✅ Fixed | Recertification_UPOT_Review and Treatment_Encounter_Note_Review — each now has single instance |

---

## Evaluation Considerations

- Single Response eval: all 7 review topics answer directly via `userInput: =System.Activity.Text` — no Question nodes that would cause abandonment
- Conversational eval: Conversation Start routes cleanly; "Other" branch exits cleanly
- No-caveat rules prevent the agent from asking for documents when the user provides sufficient context
- 5-section review format (Goals → Progress → Discharge/Transition Plan → Assessment → Justification) with color-coded risk levels and inline citations
- No connected agents — operates standalone

---

## Related Skills

- `copilot-studio-pipeline` — universal pipeline for build/lint/deploy/eval
- `copilot-studio-topic-yaml-fixes` — fix patterns for 800-char caps, SearchSpecificFiles, EndDialog
