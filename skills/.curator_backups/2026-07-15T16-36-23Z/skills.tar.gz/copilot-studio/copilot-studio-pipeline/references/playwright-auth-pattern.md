# Playwright Testing Against Copilot Studio

## The Problem
Headless Playwright cannot complete Microsoft OAuth. When navigating to `copilotstudio.microsoft.com/environments/...`, the browser redirects to `login.microsoftonline.com` and stops at the Sign-in form. Tests that check page content (like "Published" status) fail because the page shows a login form, not Copilot Studio.

## Solution: storageState (Recommended)
Run Playwright in headed mode ONCE to capture auth cookies, then reuse in headless runs.

### Step 1: Capture auth state (run once, manually)
```bash
npx playwright codegen --save-storage=tests/auth.json https://copilotstudio.microsoft.com
```
This opens a headed browser. Sign in with your Microsoft account. The cookies are saved to `tests/auth.json`.

### Step 2: Use storageState in tests
```ts
// In playwright.config.ts
export default defineConfig({
  use: {
    storageState: 'tests/auth.json',
  },
});
```

Or per-test:
```ts
test.use({ storageState: 'tests/auth.json' });
```

### Step 3: Run headless as usual
```bash
npx playwright test
```
The browser reuses saved cookies — no login prompt.

## Token Expiry
- Auth cookies typically last ~90 days
- If tests start failing with login redirects, re-run Step 1
- Add a check in CI: if `auth.json` is older than 80 days, flag for refresh

## Alternative: Dataverse API (No Browser) — PREFERRED

**This is the preferred approach.** Browser-based tests are brittle with Microsoft OAuth. The Dataverse API is faster (4.7s vs 2.6min), more reliable, and needs no browser.

### Key insight: `az login` GET tokens DO work for Dataverse
Despite earlier notes that `az login` tokens return 401 on Dataverse, `az account get-access-token --resource https://<org>.crm.dynamics.com/` returns a valid token for GET operations against the bots table. The 401 issue may be specific to PATCH operations or different resource audiences.

### Complete working test file

```ts
import { test, expect } from '@playwright/test';

const AGENTS = [
  { name: 'SNF AI Dashboard V2', id: 'bd570423-cf47-f111-bec5-70a8a5b1c3a3' },
  { name: 'TheraDoc Workbench', id: 'e09954e1-4af8-47c6-8ef4-d1d9335bf2e6' },
  { name: 'Pacific Coast Case Historian', id: 'ad635500-cf47-f111-bec5-70a8a5b1c3a3' },
  { name: 'SimpleLTC QM Coach V2', id: 'ea52ad9c-8233-f111-88b3-6045bd09a824' },
];
const ORG_URL = 'https://orgbd048f00.crm.dynamics.com';

async function getToken(): Promise<string | null> {
  if (process.env.DATAVERSE_TOKEN) return process.env.DATAVERSE_TOKEN;
  try {
    const { execSync } = require('child_process');
    const token = execSync(
      `az account get-access-token --resource ${ORG_URL}/ --query accessToken -o tsv`,
      { timeout: 30000, encoding: 'utf-8' }
    ).trim();
    if (token && token.length > 100) return token;
  } catch {}
  return null;
}

test.describe('Fleet Smoke: Dataverse API', () => {
  let token: string | null = null;
  test.beforeAll(async () => { token = await getToken(); });

  for (const agent of AGENTS) {
    test(`${agent.name} is published and active`, async ({ request }) => {
      if (!token) { test.skip(true, 'No token'); return; }
      const resp = await request.get(
        `${ORG_URL}/api/data/v9.2/bots(${agent.id})?$select=synchronizationstatus,name`,
        { headers: { Authorization: *** ${token}`, Accept: 'application/json' } }
      );
      expect(resp.ok()).toBeTruthy();
      const data = await resp.json();
      const sync = JSON.parse(data.synchronizationstatus);
      expect(sync.lastFinishedPublishOperation?.status).toBe('Succeeded');
      // Accept both Synchronized and Synchronizing (mid-sync is still valid)
      expect(['Synchronized', 'Synchronizing'].includes(
        sync.currentSynchronizationState?.state
      )).toBeTruthy();
    });
  }
});
```

### Pitfalls discovered (2026-06-25)

1. **Agent names in Dataverse may differ from manifest.** "Pacific Coast Case Historian V2" in the manifest is "Pacific Coast Case Historian" in Dataverse. Don't hardcode expected names — verify against API.

2. **Sync state can be "Synchronizing" (mid-sync).** Don't assert `toBe('Synchronized')` — accept both. Channel list is empty during sync, so only check channels when fully synchronized.

3. **`npm run test` must be configured.** The system verification gate checks `npm run test`, not `npx playwright test`. Update package.json scripts to: `"test": "npx playwright test tests/agent-smoke.spec.ts"`. If the script is the default placeholder (`echo "Error: no test specified" && exit 1`), verification fails even if tests pass via npx.

4. **synchronizationstatus is a JSON string inside JSON.** Must `JSON.parse()` it twice — the API returns it as a stringified JSON object.

### API response structure

```json
{
  "name": "SNF AI Dashboard V2",
  "synchronizationstatus": "{\"lastFinishedPublishOperation\":{\"status\":\"Succeeded\"},\"currentSynchronizationState\":{\"state\":\"Synchronized\",\"channels\":[{\"channelName\":\"MsTeams\"},{\"channelName\":\"Microsoft365Copilot\"}]}}"
}
```

## Test Results Location
- Screenshots on failure: `test-results/<test-name>/test-failed-1.png`
- Traces: `test-results/<test-name>/trace.zip`
- View trace: `npx playwright show-trace test-results/<test-name>/trace.zip`
