# Static Agent Audit via pac org fetch (Extract-Template Crash Fallback)

When `pac copilot extract-template` crashes with `System.ArgumentException` in PAC CLI v2.7.4 (loads components successfully then crashes), use `pac org fetch` with a custom FetchXML to extract ALL component YAML for static audit. This is slower than extract-template but reliable.

## Prerequisites

```bash
# Switch to the target environment
pac auth create --environment <environment-guid-from-pac-env-list>
# Verify
pac auth list
pac copilot list  # confirm you see the target bot
```

## Step 1: Write FetchXML

Create a file like `fetch-audit-components.xml`:

```xml
<fetch>
  <entity name="botcomponent">
    <attribute name="botcomponentid" />
    <attribute name="name" />
    <attribute name="componenttype" />
    <attribute name="schemaname" />
    <attribute name="statecode" />
    <attribute name="statuscode" />
    <attribute name="data" />
    <filter>
      <condition attribute="_parentbotid_value" operator="eq" value="<bot-guid>" />
    </filter>
  </entity>
</fetch>
```

Get `<bot-guid>` from `pac copilot list` "Copilot ID" column.

## Step 2: Fetch and Parse

```bash
# Fetch all components with data field
pac org fetch --environment <org-url> --xmlFile fetch-audit-components.xml > components-raw.txt

# Parse with Python to extract per-component YAML
python extract_and_audit.py
```

## Step 3: Python Extraction Script

The raw PAC output uses a tabular format where `data` field content spans multiple lines. Parse by matching the component ID regex at line start:

```python
import re, pathlib, yaml

raw = pathlib.Path('components-raw.txt').read_text(errors='replace')
row_re = re.compile(r'^([0-9a-f-]{36})\s+(Active|Inactive)\s+(.+?)\s+(\S+)\s+(.+?)\s+(Active|Inactive)\s*(.*)$')

components = []
cur = None
for line in raw.splitlines():
    m = row_re.match(line)
    if m:
        if cur: components.append(cur)
        cur = {'id': m.group(1), 'state': m.group(2), 'componenttype': m.group(3).strip(),
               'schemaname': m.group(4), 'name': m.group(5).strip(), 'status': m.group(6), 'data': m.group(7)}
    elif cur:
        cur['data'] += '\n' + line
if cur: components.append(cur)

# Save topics as .mcs.yml files
for c in components:
    if c['componenttype'].startswith('Topic'):
        safe = re.sub(r'[^A-Za-z0-9._ -]+', '_', c['name']).strip()[:120]
        pathlib.Path('topics').mkdir(exist_ok=True)
        (pathlib.Path('topics') / f'{safe}.mcs.yml').write_text(c['data'], encoding='utf-8')
```

## Step 4: Run Static Audit

Validate all extracted YAMLs:
- Check `schema_errors` by attempting `yaml.safe_load()` on each
- Count active/inactive topics
- Detect patterns: 800-char limits, JSON-only instructions, latency messages, trigger phrase counts
- Classify topics: ALIGNED (review/OCR), CORE/SYSTEM (Greeting/Fallback), INACTIVE/ORPHAN, NEEDS_REVIEW

## Output

Write `static-audit-summary.json` with:
- Component counts (topics, GPTs, knowledge sources)
- Schema validation results
- Findings by severity (HIGH, MEDIUM, LOW, INFO)
- Topic classification map
- Unresolved dialog references

## Limitations

- PAC output format is fragile — the regex may miss edge cases (double-line component names, etc.)
- Knowledge source `data` field may contain binary content (base64 PDFs) — skip those
- Does NOT produce the proper `.mcs.yml` header that `extract-template` adds (no `bot.mcs.yml`, `agent.mcs.yml`, etc.)
- Use only when `extract-template` crashes; for normal use, prefer `extract-template`
