# Copilot Studio Taxonomy Rules

Validated across multiple therapy agents (PT/OT/SLP/QM). Applies to ALL Copilot Studio agents.

Sources: Kiro `agent-guardrails.md`, MS Learn docs.

## Rules

| Rule | Source | Impact |
|------|--------|--------|
| `clearTopicQueue: true` on EndDialog | Kiro guardrails, validated PT | Topic stacking without it drops conv scores 55→40% |
| Disable `allowLatencyMessage` on all topics | Kiro guardrails, validated SLP | Misleads AI grader, causes "irrelevant" failures |
| No `SearchSpecificFiles` in topics | Kiro guardrails, validated OT vs SLP | Restricts search, causes "didn't cite knowledge sources" |
| No `knowledgeSources: kind: SearchAllKnowledgeSources` | Kiro guardrails | Not a valid field, causes runtime errors |
| No `applyModelKnowledgeSetting: false` | Kiro guardrails | Always `true` or omit to inherit bot default |
| `additionalInstructions` ≤ 4 bullet points | Kiro guardrails | Verbose instructions cause response truncation (5-15% regression) |
| Prefer `webBrowsing: false` with file-only knowledge | Kiro guardrails | Web browsing causes variable-length responses that truncate in eval channel |
| No periods in topic display names | MS Learn docs | Export will fail |
| No `OnUnknownIntent` as `beginDialog.kind` | MS Learn docs | Overrides system fallback, breaks publish |
| Every custom topic with `SearchAndSummarizeContent` MUST end with `EndDialog` with `clearTopicQueue: true` | Kiro guardrails | Conversation context stacks without explicit termination |
| Use `userInput: =System.Activity.Text` not Question nodes for orchestration topics | Kiro guardrails | Question nodes re-ask for input incorrectly (caused 95→12% SR drop) |
| No explicit citation requirements in `additionalInstructions` | Kiro guardrails | Over-focuses on citing at expense of completeness |
| No PHI in any inter-agent payload, log, or API response | Kiro guardrails | Use `record_id` pointers instead |
| Never mix "NOT JSON" and "Return exactly one valid JSON" in same `additionalInstructions` | Kiro guardrails | Causes model confusion — pick one output format |
| Every `InvokeConnectedAgentTaskAction` must have correct `botSchemaName` | Kiro guardrails, validated TDA | Wrong schema name → "Error" results in eval (PT/OT routing to SLP) |

## Expected Instruction Sizes

| Agent | GPT Instructions | Healthy Range |
|-------|-----------------|---------------|
| PT_Specialist | ~4,900 chars | 3,000-5,500 |
| OT_Specialist | ~4,900 chars | 3,000-5,500 |
| SLP_Specialist | ~2,200 chars | 1,800-3,000 |
| TDA | ~6,100 chars | 4,000-7,000 |
| QM Coach V2 | ~3,000-5,000 chars | 2,000-6,000 |

If instructions exceed upper range → likely corruption → run anti-corruption checklist.

## Lint Rule Mapping

Each rule maps to a topic_lint.cjs rule:

| Rule | Lint Rule | Severity |
|------|-----------|----------|
| clearTopicQueue: true on EndDialog | R9 | ERROR |
| allowLatencyMessage: false | R10 | WARNING |
| No SearchSpecificFiles | R11 | ERROR |
| No SearchAllKnowledgeSources | R12 | ERROR |
| No applyModelKnowledgeSetting: false | R13 | WARNING |
| No periods in topic names | R1 | ERROR |
| No OnUnknownIntent | R2 | ERROR |
| Non-empty actions | R3 | ERROR |
| No orphan Question nodes | R4 | ERROR |
| Trigger overlap < 60% Jaccard | R5 | WARNING |
| EndDialog termination | R6 | WARNING |
| ≥ 3 trigger phrases | R7 | WARNING |
