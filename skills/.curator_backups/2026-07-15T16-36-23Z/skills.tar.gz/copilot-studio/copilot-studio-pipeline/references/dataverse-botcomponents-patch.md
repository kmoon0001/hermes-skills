# Dataverse BotComponent PATCH Pattern

Patch live Copilot Studio topic YAML via the Dataverse Web API. Use when `pac copilot extract-template` crashes (v2.7.4 bug) or for surgical fixes without navigating the Copilot Studio UI.

## Prerequisites

- `az` CLI installed and logged in (`az login`)
- PAC CLI authenticated to target environment (`pac auth create --environment https://{org}.crm.dynamics.com`)
- Known botcomponent IDs (from `pac org fetch` or Dataverse query)

## Auth

PPAPI token (captured via CDP) ≠ Dataverse token. Get a Dataverse token:

```bash
az account get-access-token --resource "https://{org}.crm.dynamics.com" | python3 -c "import sys,json; print(json.load(sys.stdin)['accessToken'])" > ~/.copilot-studio-cli/dv-token.txt
```

Save and reuse across all API calls in the script. Token expires ~1 hour.

## Read Live Topic YAML

### Via PAC CLI (FetchXML)

```xml
<fetch version="1.0" output-format="xml-platform" mapping="logical">
  <entity name="botcomponent">
    <attribute name="botcomponentid"/>
    <attribute name="name"/>
    <attribute name="data"/>
    <filter type="and">
      <condition attribute="botcomponentid" operator="eq" value="{component-guid}"/>
    </filter>
  </entity>
</fetch>
```
```bash
pac org fetch --environment https://{org}.crm.dynamics.com/ --xmlFile fetch.xml
```

> **PITFALL**: `botcomponent` queries with `_parentbotid_value` can crash PAC v2.7.4 with stack overflow. Use direct `botcomponentid` filter for reliable results.

### Via Dataverse Web API (Python)

```python
import json, urllib.request

token = open(r'%USERPROFILE%\.copilot-studio-cli\dv-token.txt').read().strip()
base = "https://{org}.crm.dynamics.com/api/data/v9.2"

url = f"{base}/botcomponents({comp_id})?$select=data"
req = urllib.request.Request(url)
req.add_header("Authorization", f"Bearer {token}")
req.add_header("Accept", "application/json")

with urllib.request.urlopen(req) as resp:
    d = json.loads(resp.read())

yaml_content = d.get('data', '')
```

## PATCH Topic YAML

```python
new_yaml = yaml_content.replace('old block', 'new block')

patch_data = json.dumps({"data": new_yaml}).encode()
req = urllib.request.Request(
    f"{base}/botcomponents({comp_id})",
    data=patch_data,
    method='PATCH'
)
req.add_header("Authorization", f"Bearer {token}")
req.add_header("Content-Type", "application/json")
req.add_header("If-Match", "*")

with urllib.request.urlopen(req) as resp:
    print(f"PATCH: HTTP {resp.status}")  # 204 = success
```

## Verify and Publish

```python
# Verify
vreq = urllib.request.Request(url)
vreq.add_header("Authorization", f"Bearer {token}")
vreq.add_header("Accept", "application/json")
with urllib.request.urlopen(vreq) as vresp:
    updated = json.loads(vresp.read())
assert 'SearchSpecificKnowledgeSources' not in updated.get('data', '')

# Publish
# pac copilot publish --environment https://{org}.crm.dynamics.com/ --bot {bot-id}
```

## SearchSpecificKnowledgeSources Removal

Most common PATCH: remove both KB-restricting blocks from audit topics.

```python
import re

def remove_knowledge_sources(yaml_text):
    """Remove the SearchSpecificKnowledgeSources block from YAML."""
    lines = yaml_text.split('\n')
    result = []
    in_block = False
    for line in lines:
        stripped = line.lstrip()
        if stripped.startswith('knowledgeSources:'):
            next_meaningful = [l for l in lines[lines.index(line)+1:] if l.strip()]
            if next_meaningful and 'SearchSpecificKnowledgeSources' in next_meaningful[0]:
                in_block = True
                continue
        if in_block:
            ind = len(line) - len(stripped) if stripped else 8
            if not stripped:
                continue
            if ind <= 6:  # exit indent level
                in_block = False
                result.append(line)
            continue
        result.append(line)
    return '\n'.join(result)
```

## Data vs Content Nuance

The earlier claim "PATCH `data` doesn't sync to `content`" is only true when `content` has **broken YAML** (missing properties, bad indentation). When both `data` and `content` contain valid YAML:

1. PATCH `botcomponent.data` updates the authoring YAML
2. `pac copilot publish` compiles `data` → syncs to `content` → publishes
3. Publish succeeds if the YAML is valid

The failure scenario: `content` has broken YAML from a previous bad edit → patching `data` alone doesn't fix it → publish fails. In that case, the ONLY fix is editing the topic in the Copilot Studio UI code editor.

## Syncing Local YAML After Live Edits

After patching live topics via API, local YAML files are STALE. Pull live YAML back:

```python
import json, urllib.request, pathlib, os

token = open(r'%USERPROFILE%\.copilot-studio-cli\dv-token.txt').read().strip()
base_url = "https://{org}.crm.dynamics.com/api/data/v9.2"
topic_ids = {"{component-id}": "Topic_Name"}  # from pac org fetch
topics_dir = "D:/path/to/topics"

for comp_id, filename in topic_ids.items():
    url = f"{base_url}/botcomponents({comp_id})?$select=data"
    req = urllib.request.Request(url)
    req.add_header("Authorization", f"Bearer {token}")
    req.add_header("Accept", "application/json")
    with urllib.request.urlopen(req) as resp:
        d = json.loads(resp.read())
    yaml = d.get('data', '')
    filepath = os.path.join(topics_dir, f"{filename}.mcs.yml")
    with open(filepath, 'w', newline='\r\n') as f:
        f.write(yaml)
        f.write('\n')
    print(f"  {filename}: {len(yaml)} chars")
```

## 800-Char Cap Removal from AgentDialog (validated 2026-07-04)

AgentDialog topics (componenttype 9, `kind: AgentDialog`) can have response-length caps embedded in `settings.instructions` as a managed-property string. These look like:

```yaml
settings:
  instructions: |
    ... Keep responses under 800 characters for general questions. ...
```

**⚠️ These caps are NOT in `additionalInstructions`** — they're in the topic-level `settings.instructions` string. This is the third location where response cap constraints live (alongside GPT instructions `responseInstructions` and `additionalInstructions` on SearchAndSummarizeContent nodes).

**Fix**: Read the live `data` field, remove the "Keep responses under N characters" sentence in-place, PATCH the full `data` string back.

For Conversational boosting topics (`kind: AdaptiveDialog`, `kind: OnUnknownIntent`), the cap lives in `additionalInstructions`:
```yaml
additionalInstructions: |-
  ...
  - Keep response under 800 characters total. ...
```

Replace with a relaxed version:
```yaml
additionalInstructions: |-
  ...
  - Keep responses under 600 characters for simple questions. Full-length audit responses allowed when document text is provided. ...
```

**Detection**: Search for `800` in the `data` field of every component. Hits in `settings.instructions`, `additionalInstructions`, and GPT-level `responseInstructions` all need different fix patterns.

## Publish

After PATCH, publish for changes to take effect:
```bash
pac copilot publish --environment https://{org}.crm.dynamics.com/ --bot {bot-id}
```

### Cross-Environment Publish Bypass (validated 2026-07-04)

When the pac auth profile doesn't include the target environment (e.g., TDA on Ensign Default `org3353a370` but active pac auth points to Therapy AI Dev `orgbd048f00`), you do NOT need to create a new auth profile. Use `--environment <orgUrl>` directly:

```bash
pac copilot publish --bot "4d0ed0d3-30f6-f011-8406-000d3a37eba2" --environment "https://org3353a370.crm.dynamics.com"
```

This works because pac uses the user's existing auth session and overrides the environment scope. No interactive browser login required.

**PITFALL**: Requires existing `az login` session with permissions on the target environment. 401 = re-auth needed, not a `pac auth create` issue.

## Conversation Start — Fix Dead-End "Other" Branch

Topics with `OnConversationStart` + `ClosedListEntity` often have an "Other" branch that loops:
```yaml
- kind: SendActivity
  activity: I'm sorry, no other options...
- kind: GotoAction
  actionId: {menu-question-id}
```

**Fix**: Replace with clean exit so NLU routes the next message:
```yaml
- kind: SendActivity
  activity: Please describe what you need help with...
- kind: EndDialog
  clearTopicQueue: true
```

## Pitfalls

- **Token mismatch**: PPAPI token ≠ Dataverse token. Wrong token → 401.
- **`_parentbotid_value` crashes PAC v2.7.4**: Use direct `botcomponentid` filter or `<link-entity>` instead.
- **SearchSpecificFiles removal is NOT enough**: Must also remove `knowledgeSources: SearchSpecificKnowledgeSources`.
- **Publish can false-report failure**: PAC v2.7.4 prints "Failed to publish" but log shows success. Check pac-log.txt.
- **Always verify after PATCH**: 204 does not mean the YAML is valid — re-fetch and check.
- **Local YAML gets stale**: Pull live after every live edit cycle.
