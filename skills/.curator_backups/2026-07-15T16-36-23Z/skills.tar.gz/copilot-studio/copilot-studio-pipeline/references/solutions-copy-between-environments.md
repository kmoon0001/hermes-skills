# Solutions-Based Copy Between Environments

**Source:** MS Learn — `authoring-solutions-overview`, `authoring-solutions-import-export`, troubleshooting: `agents-solution-mapping`
**Date researched:** 2026-06-27
**Status:** Official Microsoft method — confirmed as the recommended approach

## When to Use

Use the solutions method when you need to copy agents between Power Platform environments (e.g., default → dev, dev → staging, staging → production). This is the ONLY Microsoft-supported method for cross-environment agent copies.

Alternatives:
- `manage-agent.bundle.js clone` + push to different env — works but is not the official ALM path
- Manual rebuild — lossy, error-prone, doesn't preserve all metadata

## Step-by-Step (from MS Learn)

### Prerequisites
- **System Customizer** security role (minimum) in both source and target environments
- Target environment must have Dataverse enabled
- Familiarity with Power Apps solution concepts

### Step 1: Create a Custom Solution
1. In Copilot Studio, click three dots (…) on sidebar → **Solutions**
2. Click **New solution** → follow Power Apps wizard (name, publisher, version)
3. Solution opens automatically. If not, return to solution list and select it.

### Step 2: Add Agents to Solution
1. Open the custom solution
2. Click **Add existing** → **Agent** → **Agent**
3. Select the agents you want to copy (e.g., TDA, SLP, PT, OT)
4. Click **Add**

### Step 3: Add Required Objects (CRITICAL)
1. In the solution, find your agent under **Agents**
2. Click three dots (⋮) → **Advanced** → **Add required objects**
3. This captures topics, knowledge sources, connectors, and dependencies
4. **Repeat for EACH agent** — skipping this is the #1 cause of missing components after import

### Step 4: Export the Solution
1. Select the solution → **Export solution**
2. Follow the Power Apps export wizard (Before you export → Next → Export)
3. Saves a `.zip` file to Downloads

### Step 5: Import into Target Environment
1. Switch Copilot Studio to the target environment (environment switcher in top bar)
2. Go to **Solutions** → **Import solution**
3. Upload the `.zip` file
4. Follow the import wizard
5. If import fails, click **Download log file** for the XML error details

### Step 6: Post-Import
1. Open each imported agent
2. **Reconfigure authentication** if the agent uses OAuth/API keys
3. **Publish** the agent (required before sharing)
4. Icon may take up to 24 hours to appear everywhere

## What Transfers vs What Doesn't

| Transfers | Does NOT Transfer |
|-----------|-------------------|
| Agent instructions (main prompt) | Conversation ID |
| Topics (if added via "Add required objects") | CDS Bot ID |
| Agent configuration/settings | Environment ID |
| Knowledge sources (usually) | Topic-level/node-level comments |
| Connectors and connection references | Agent icon (may be empty) |
| Environment variables | Channel details (may be empty) |

**Note on knowledge sources:** They MIGHT NOT transfer if stored as separate Dataverse tables or resources, depending on how they were created/linked. Verify after import.

## Pitfalls (from MS Learn + troubleshooting docs)

### New components don't auto-sync
After initial import, if you add new topics/tools/knowledge to the SOURCE agent, they do NOT appear in the imported version. To sync:
1. Re-open source solution → agent → three dots (⋮) → Advanced → **Add required objects**
2. Re-export the solution
3. Re-import into target (upgrade)

**Prevention:** Create agents directly in a solution context. In Copilot Studio agent settings, under Advanced settings, select the desired solution before creating the agent.

### Can't export solutions with periods in topic names
MS Learn: "You can't export a solution that contains an agent with periods (.) in the name of any of its topics." Rename any topics with dots before exporting.

### Don't manually edit components in the solution
Warning from MS Learn: "Don't remove unmanaged agent components, such as agent topics, directly from the solution unless you also remove the agent from the solution. Removing or changing an agent's components directly from the solution causes the export and import to fail."

### Large agents need classic export
"If your agent has a large number of components (for example, more than 250 topics or more than 100 entities), see Export using the classic experience."

### Managed solutions can't be re-exported
"When you create a solution, it's unmanaged by default. If you change it to a managed solution, you can't export it. You need to create a new solution." Always keep solutions unmanaged for the export workflow.

### Custom connectors need separate import order
If agents use custom connectors, import the custom connectors FIRST, then import the agent solution with connection references.

### Environment variables need explicit addition
If the agent uses environment variables, add them explicitly: Add existing → More → Environment variable → select required ones → Add.

## Source URLs
- https://learn.microsoft.com/en-us/microsoft-copilot-studio/authoring-solutions-overview
- https://learn.microsoft.com/en-us/microsoft-copilot-studio/authoring-solutions-import-export
- https://learn.microsoft.com/en-us/troubleshoot/power-platform/copilot-studio/lifecycle-management/agents-solution-mapping
- https://learn.microsoft.com/en-us/microsoft-copilot-studio/environments-first-run-experience
