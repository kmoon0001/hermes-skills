# OCR / File-Upload Topic Diagnostic Pattern

Recurring defects found in Copilot Studio topics that handle file uploads via Power Automate flows.

## Common Defects Checklist

When auditing an OCR/file-upload topic, check for these three issues:

### 1. Duplicate Flow Calls
The same Power Automate flow (`flowId`) is called multiple times in the same topic. 
- **Look for**: Multiple `InvokeFlowAction` nodes with identical `flowId`
- **Fix**: Keep only ONE call — either inside the ConditionGroup (attachment vs. text branches) or after it, not both
- **Verified case**: Therapy Documentation Feedback Agent OCR topic had 3 calls to flow `c71672f2`

### 2. Wrong Variable Mapping for Attachments
In the attachment branch of a ConditionGroup, `file_content` is mapped to `Topic.UploadedText` (the text variable from a Question node) instead of the actual file attachment.
- **Look for**: `condition: =!IsEmpty(System.Activity.Attachments)` + `file_content: =Topic.UploadedText`
- **Fix**: Change to `file_content: =System.Activity.Attachments` and `file_name: =First(System.Activity.Attachments).Name`
- **Why**: When a user uploads a file, `Topic.UploadedText` is empty (user didn't type anything). The file data lives in `System.Activity.Attachments`

### 3. Missing EndDialog
The topic has no `kind: EndDialog` node at the end of the action list.
- **Look for**: Last action is a `SendActivity` or `InvokeFlowAction`, not `EndDialog`
- **Fix**: Add `kind: EndDialog` with `clearTopicQueue: true`

## Corrected Pattern

```yaml
actions:
  - kind: Question
    variable: init:Topic.UploadedText
    prompt: Paste text or upload a file...
    entity: StringPrebuiltEntity

  - kind: ConditionGroup
    conditions:
      - condition: =!IsEmpty(System.Activity.Attachments)
        actions:
          - kind: InvokeFlowAction
            input:
              binding:
                file_content: =System.Activity.Attachments       # ← FIXED
                file_name: =First(System.Activity.Attachments).Name
            output:
              binding:
                extracted_text: Topic.extracted_text
                processing_status: Topic.processing_status
            flowId: <flow-guid>
    elseActions:
      - kind: InvokeFlowAction
        input:
          binding:
            file_content: =Topic.UploadedText                    # ← CORRECT for paste
            file_name: PastedText.txt
        output:
          binding:
            extracted_text: Topic.extracted_text
            processing_status: Topic.processing_status
        flowId: <flow-guid>                                      # ← SAME flow, one call per branch

  - kind: SendActivity
    activity: Processing your document...

  - kind: EndDialog                                               # ← ADDED
    clearTopicQueue: true
```
