# Topic Audit Workflow — 3-Question Diagnostic

Standard pre-publish or post-regression audit for any Copilot Studio agent. Covers the three most common causes of eval failures and runtime errors.

## When to Run
- After cloning/importing an agent from another environment
- Before publishing a batch of topic fixes
- When eval scores drop unexpectedly (SR, conversational, or end-to-end)
- After any batch YAML patch operation

## The 3 Questions

### Q1: Do all generative nodes have knowledge grounded in them?
**Check:** Every `SearchAndSummarizeContent` node must NOT have:
- `SearchSpecificKnowledgeSources` (restricts KB to a subset)
- `SearchSpecificFiles` (restricts file search to specific uploads)

**Why:** Restricted KB/files means the topic can only search a subset of knowledge. If the user asks something outside that subset, the agent returns "I don't know" or hallucinates.

**Fix:** Remove both `fileSearchDataSource` and `knowledgeSources` blocks from the YAML. The topic then uses ALL assigned knowledge sources.

### Q2: Do all topics have `description` and `modelDescription`?
**Check:**
- `description` = Dataverse top-level field (`t.get('description')`) — shows in Copilot Studio topic list
- `modelDescription` = YAML top-level field (`modelDescription: ...` inside `data`) — passed to the LLM as topic context

**Why:** Missing `description` breaks topic discovery in the Copilot Studio UI. Missing `modelDescription` means the LLM doesn't know when to trigger the topic.

**Fix:** PATCH `description` via Dataverse API (`botcomponent` entity). Add `modelDescription` to the `data` YAML (top-level field, same level as `kind: AdaptiveDialog`).

### Q3: Are all inputs required and properly set up?
**Check for each `SearchAndSummarizeContent` node:**
- `variable: Topic.Answer` (or similar) — captures the search result
- `userInput: =System.Activity.Text` (or similar) — passes user input to the search
- `SendActivity` node AFTER the SASC node, with `activity: =Topic.Answer.Text` (or similar) — surfaces the result to the user
- `EndDialog` with `clearTopicQueue: true` — clean exit

**Why:** Missing `SendActivity` → eval framework sees no text response → `unsupportedactivity.notextresponse`. Missing `EndDialog` → conversation hangs or falls through to wrong topic.

## Audit Script

The reusable audit script is at:
`D:/my agents copilot studio/pipeline/scripts/audit_topic_metadata.py`

(If not present, the script from session 2026-07-08 can be reproduced — it queries all `componenttype eq 9` botcomponents, parses YAML for `modelDescription`/`SearchAndSummarizeContent`, and reports issues.)

## Common Issues Found Across Agents

| Issue | Seen In | Fix |
|---|---|---|
| `SearchSpecificFiles` blocking grounding | Feedback B (6 topics) | Remove `fileSearchDataSource` block from YAML |
| Missing `modelDescription` | Feedback B (`Sign in` topic) | Add YAML top-level `modelDescription:` field |
| Missing `description` | Feedback B (`Check Async OCR Job Status`) | PATCH Dataverse `description` field |
| Deactivated topic still referenced | Feedback B (`Greeting` → `ConversationStart`) | Remove `BeginDialog` redirect to deactivated topic |

## Query Pattern (Dataverse REST)

Preferred over Python `subprocess.run(['az',...])` (which fails on Windows PATH issues):

```bash
az rest --method GET \
  --resource "https://{org}.crm.dynamics.com/" \
  --url "https://{org}.crm.dynamics.com/api/data/v9.2/botcomponents?\$filter=_parentbotid_value eq '{bot_id}' and componenttype eq 9&\$select=botcomponentid,name,description,data" \
  > /tmp/topics.json 2>&1
```

Then parse `/tmp/topics.json` with Python (`json.loads()` with `encoding='utf-8-sig'` fallback).
