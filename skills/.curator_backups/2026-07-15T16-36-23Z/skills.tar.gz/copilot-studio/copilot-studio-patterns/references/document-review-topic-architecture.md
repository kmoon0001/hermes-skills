# Document Review Topic Architecture Comparison (Therapy AI Dev - Feedback B)

Six document review topics in the agent, each with OCR submit + async polling. Two have working retry logic, four need updates.

## Status Matrix

| Topic | Retry Logic | Counter Approach | Condition | Bug |\n|-------|-------------|-----------------|-----------|-----|\n| Discharge Summary | ✅ Working | Sentinel blank-out (`retry_count_num >= 10 -> Blank()`) | `IsBlank(Topic.retry_count_num)` | None |\n| Progress Report Review | ✅ Working | `RetryCount < 10` | `=Topic.RetryCount < 10` | None |\n| Eval/Assessment + Plan of Care | ✅ Fixed 2026-07-10 | Sentinel blank-out (`retry_count_num >= 10 -> Blank()`) | `IsBlank(Topic.retry_count_num)` | Was `RetryCount < 0` (dead code) |\n| Treatment Encounter Note Review | ✅ Fixed 2026-07-10 | Sentinel blank-out (`retry_count_num >= 10 -> Blank()`) | `IsBlank(Topic.retry_count_num)` | No retry at all |\n| Recertification/UPOC Review | ✅ Fixed 2026-07-10 | Sentinel blank-out (`retry_count_num >= 10 -> Blank()`) | `IsBlank(Topic.retry_count_num)` | No retry at all |\n| Episode of Care | ✅ Fixed 2026-07-10 | Sentinel blank-out (`retry_count_num >= 10 -> Blank()`) | `IsBlank(Topic.retry_count_num)` | Was `RetryCount < 0` (dead code) |

## Discharge Summary Reference Architecture (Working)

The Discharge Summary topic uses the sentinel blank-out approach:

1. Initialize `retry_count_num = 0`
2. Submit async OCR via InvokeFlowAction
3. Poll via InvokeFlowAction check_async_ocr_status
4. Set `ocr_payload = job_json`
5. Condition: "Status: Completed" in ocr_payload -> success route (SearchAndSummarizeContent generative audit)
6. Else: SendActivity "not complete" message
7. Increment: `=If(Value(Text(Topic.'retry_count_num')) + 1 >= 10, Blank(), Value(Text(Topic.'retry_count_num')) + 1)`
8. Condition: `=IsBlank(Topic.retry_count_num)` -> timeout exit (SendActivity + EndDialog)
9. Else (retry_count_num not blank): GotoAction loop back to OCR check
10. Power Automate flow has 5-second delay to prevent tight polling loop

## Document Upload Intake Simplification (2026-07-10)

The Document Upload Intake topic originally routed to 7 BeginDialog child topics (EvaluationAssessmentandPlanOfCare, TreatmentEncounterNoteReview, ProgressReportReview, RecertificationUPOTReview, DischargeSummary, EpisodeofCare, LargeDocumentOCRExtraction). All 7 were deleted during agent reorganization — the BeginDialog references were **stale** and caused silent routing failures.

**Fix applied:** Replaced each condition's BeginDialog with SendActivity (direct upload request for that document type) + EndDialog. The intake now just asks "What type of document?" and tells the user what to upload — letting the specific document topics handle the actual upload handling.

**Trigger phrase overlap:** The intake had 42 triggers including phrases like "review this progress note" that overlapped with specific doc topics, causing the intake to fire instead of the topic. **Fix:** removed 29 overlapping triggers, kept only 13 generic ones (upload/file/review my document).

**Key insight:** A catch-all intake topic should ONLY have triggers for vague/unsure utterances. Everything else should route to specific topics directly. The menu question handles the routing for users who aren't sure what they have.

## Method: Applying Changes Safely

All 6 doc topics and the Document Upload Intake were modified via Dataverse API PATCH. The safety approach:
1. One topic at a time — PATCH, verify data integrity, publish (or attempt publish)
2. Each patch isolated to the `elseActions` block only (retry pattern) or trigger list (intake)
3. Verify by re-reading the Dataverse data and checking for retry_count_num, IsBlank exit, GotoAction loop
4. QA check: compare retry sections across all 6 topics for consistency

## Errors Fixed (Check OCR Status Topic)

The Check OCR Status topic's condition `condition_poll_completed` had a YAML escaping error caused by Dataverse JSON serialization. The `\"` in `=\"Status: Completed\" in Topic.ocr_payload` got doubly-escaped, resulting in a runtime `contentValidationError` with `'Unexpected characters' (\)`.

**Fix:** Rewrote the condition to match the exact format used by Discharge Summary and Progress Report Review (which worked correctly). Verified by comparing `repr()` of the condition line byte-for-byte.

All 4 broken topics were updated to match the Discharge Summary's sentinel blank-out pattern. Change was isolated to the `elseActions` block after the OCR "Status: Completed" check fails:

1. Replaced the existing SendActivity "not complete" message (kept it)
2. Added `SetVariable retry_count_num` with sentinel formula: `=If(Value(Text(Topic.'retry_count_num')) + 1 >= 10, Blank(), Value(Text(Topic.'retry_count_num')) + 1)`
3. Added `ConditionGroup` checking `=IsBlank(Topic.retry_count_num)` — empty actions block stops execution at 10 attempts
4. Added `GotoAction` with `actionId: invokeFlow_check_async_ocr_status` to loop back

**Method:** One topic at a time, publish after each, verify publish and data integrity. All 4 published successfully.

## Common Elements Across All 6 Topics

All six share:
- File upload Question with document type-specific prompt
- ConditionGroup checking `!IsBlank(Topic.{DocVar})`
- GotoAction back to upload question if no file
- InvokeFlowAction `submit_async_ocr` with extraction_goal specific to document type
- InvokeFlowAction `check_async_ocr_status` with job_id binding
- ConditionGroup checking "Status: Completed" in Topic.ocr_payload
- SearchAndSummarizeContent generative audit with document-type-specific audit instructions
- SendActivity for audit report output
- EndDialog with or without clearTopicQueue
