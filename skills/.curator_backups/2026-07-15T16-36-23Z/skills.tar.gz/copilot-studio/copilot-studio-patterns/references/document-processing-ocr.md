# Document Processing with OCR + AI Builder

Pattern for processing clinical documents (PDFs, scanned images, large multi-page) through OCR/PDF text extraction before sending to an AI Builder Prompty model for audit.

## The Problem

Most clinical document processing topics upload a raw file → AI Builder Prompty model. This fails when:

- **PDFs** — the Prompty model receives raw binary, can't extract text
- **Scanned images** — same problem, no OCR
- **Large documents** — EoC files can be 100+ pages, exceeds the model's context
- **Mixed formats** — .docx, .pdf, .png all arrive as file entities, the model can't handle all

## Architecture

```
User uploads file
  → Topic collects file via Question(FilePrebuiltEntity)
  → [OCR STEP] InvokeFlowAction or 2nd InvokeAIBuilderModelAction for text extraction
  → [AUDIT STEP] InvokeAIBuilderModelAction with Prompty model
  → SendActivity with audit results
```

### Two OCR Paths

**Path A: Power Automate Flow (InvokeFlowAction)**
- Create a flow in make.powerautomate.com that accepts a file input
- Uses "Extract text from PDF" (AI Builder PDF extraction) or "Convert file to text" connector
- Handles chunking for 100+ page documents
- Returns extracted text output
- Wire into topic: `InvokeFlowAction` with flow ID

**Path B: AI Builder Prompty model (InvokeAIBuilderModelAction)**
- Create a separate Prompty model in Copilot Studio configured for text extraction
- Takes file input → extracts text → returns cleaned text
- Wire in before the audit Prompty call
- Simpler but less control over chunking

## Topic YAML Structure (Path A)

```yaml
- kind: Question
  variable: "init:Topic.uploaded_file"
  prompt: "Upload the document..."
  entity: FilePrebuiltEntity

- kind: ConditionGroup
  conditions:
  - condition: "=!IsBlank(Topic.uploaded_file)"
  elseActions:
  - kind: GotoAction
    actionId: question_upload

- kind: InvokeFlowAction
  id: invokeFlow_ocr
  input:
    binding:
      uploadedFile: "=Topic.uploaded_file"
  output:
    binding:
      extractedText: "ocr_output"
  flowId: "<ocr-flow-guid>"

- kind: SetVariable
  id: setVar_extracted
  variable: "Topic.extracted_text"
  value: "=Topic.ocr_output"

- kind: InvokeAIBuilderModelAction
  id: invokeAI_audit
  input:
    binding:
      doc_text: "=Topic.extracted_text"
  output:
    binding:
      predictionOutput: "audit_result"
  aIModelId: "<prompty-model-guid>"

- kind: SendActivity
  activity: "{Topic.audit_result.text}"

- kind: EndDialog
```

## Common Pitfalls

- **All 6 doc topics write to `Global.feedback_system_instructions`** — this is the SAME global variable. If two topics run close together, they stomp each other's instructions. Use Topic-scoped variables instead.
- **FilePrebuiltEntity gives raw binary** — the AI Builder Prompty model receives the file bytes, not text. Always extract text first.
- **No OCR flow in environment** — check `Workflow` entity (category=5) in Dataverse first. If none, build one in Power Automate.
- **AI Builder model ID** — the Prompty model for audit is stored in botcomponents (componenttype=15, schemaname contains `.gpt.default`). The same model ID is reused across topics via different input bindings.
- **Large docs** — Power Automate flows can chunk via loops. AI Builder Prompty models have fixed context windows. Flow is preferred for 100+ page documents.

## Related Topics

- Large Document OCR Extraction (dedicated OCR topic in the agent)
- Individual doc audit topics (Evaluation, Progress Report, Discharge, Treatment Encounter, Recertification, Episode of Care)

## When to Use

Any Copilot Studio agent that:
- Accepts clinical document uploads
- Processes PDFs or scanned images
- Needs compliance/clinical audit
- Has documents exceeding single-turn context limits
