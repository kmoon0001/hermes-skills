# Card → Generation → Audit Pattern

## Problem
Clinical documentation agents need therapists to capture session data quickly (click buttons, not type) and generate polished, compliant notes from that structured data.

## Solution
1. **AdaptiveCard** collects structured data via ChoiceSets (click buttons), Numbers, Dates, and minimal free text
2. **SearchAndSummarizeContent** generates a clinical note from the card data using a Concatenate prompt
3. **SendActivity** shows the DRAFT with review instructions
4. **BeginDialog → AuditExistingNote** runs compliance review
5. **EndDialog with clearTopicQueue: true** prevents topic stacking

## YAML Template

```yaml
kind: AdaptiveDialog
beginDialog:
  kind: OnRecognizedIntent
  id: main
  intent: {}
  actions:
    - kind: AdaptiveCardPrompt
      id: card1
      card: |
        {
          "type": "AdaptiveCard",
          "version": "1.5",
          "body": [
            { "type": "Input.ChoiceSet", "id": "taskType", "choices": [...] },
            { "type": "Input.ChoiceSet", "id": "assistLevel", "choices": [...] },
            { "type": "Input.Number", "id": "painScale" },
            { "type": "Input.Text", "id": "responseToTreatment", "isMultiline": true }
          ],
          "actions": [{ "type": "Action.Submit", "title": "Generate Note" }]
        }
      output:
        binding:
          taskType: Topic.taskType
          assistLevel: Topic.assistLevel
          painScale: Topic.painScale
          responseToTreatment: Topic.responseToTreatment
      outputType:
        properties:
          taskType: String
          assistLevel: String
          painScale: Number
          responseToTreatment: String

    # Generate note from card data
    - kind: SearchAndSummarizeContent
      id: genNote
      userInput: "=Concatenate(\\"Generate a skilled DISCIPLINE NOTE_TYPE. SECTIONS - 1. Header 2. Diagnosis 3. Subjective 4. Objective 5. Assessment 6. Plan 7. Signature. Use only provided data. Task \\", Text(Topic.taskType), \\" Assist \\", Text(Topic.assistLevel), \\" Pain \\", Text(Topic.painScale), \\" Response \\", Text(Topic.responseToTreatment), \\".\\")"

    - kind: SendActivity
      id: showDraft
      activity: |-
        DRAFT - CLINICAL REVIEW REQUIRED

        {Topic.Answer}

        Review before EHR entry.

    - kind: BeginDialog
      id: audit
      input:
        binding:
          incomingDiscipline: ="PT"
          incomingDocumentType: ="Daily Note"
      dialog: pcca_theradocworkbench.topic.AuditExistingNote

    - kind: EndDialog
      id: done
      clearTopicQueue: true

inputType: {}
outputType: {}
```

## YAML Quoting Rules

The `userInput` for SearchAndSummarizeContent with Concatenate MUST use double-quoted string with escaped inner quotes:

```yaml
userInput: "=Concatenate(\\"text\\", Text(Topic.var), \\"more text\\")"
```

NOT unquoted (breaks on colons/braces in YAML):
```yaml
userInput: =Concatenate("text", Text(Topic.var), "more text")
```

## Key Variables

The generated note is stored in `Topic.Answer` (SearchAndSummarizeContent default output). Use `{Topic.Answer}` in SendActivity to display it.

## References
- See `therapy-fleet-agent-audit/references/theradoc-workbench-card-generation-pattern.md` for the full TheraDoc-specific implementation with all 7 Card topics.
