# Action Execution Order in Copilot Studio Topics

## How Actions Execute

Copilot Studio topics execute actions sequentially from top to bottom in the YAML `actions:` list. The execution order determines what the user sees and what the eval grader evaluates.

### Typical Topic Structure

```yaml
actions:
    - kind: SendActivity          # 1. Fires FIRST — user sees this immediately
      id: ot_sr_guardrail_answer
      activity: |
        Generic compliance answer...

    - kind: SearchAndSummarizeContent  # 2. Runs AFTER — writes to Topic.Answer
      id: search_ot_general
      variable: Topic.Answer
      userInput: =System.Activity.Text

    - kind: EndDialog             # 3. Ends the topic
```

## Critical Behaviors

### 1. SendActivity fires before SearchAndSummarizeContent

The guardrail `SendActivity` sends text to the user immediately. Then `SearchAndSummarizeContent` runs and writes its result to `Topic.Answer`. The user may see **both** responses. The eval grader evaluates the text it captures — typically the last visible response.

### 2. SearchAndSummarizeContent WITHOUT a SendActivity causes execution failures

If you remove the guardrail `SendActivity` and leave only `SearchAndSummarizeContent`:

```yaml
actions:
    - kind: SearchAndSummarizeContent  # Writes to Topic.Answer
      variable: Topic.Answer
    - kind: EndDialog                  # Topic ends
```

The eval framework reports `unsupportedactivity.notextresponse` — it can't capture `Topic.Answer` as a text response without an explicit `SendActivity`. This is NOT a grader failure; it's an execution error that prevents evaluation entirely.

**Fix**: Add a `SendActivity` that sends the variable:
```yaml
actions:
    - kind: SearchAndSummarizeContent
      variable: Topic.Answer
    - kind: SendActivity
      id: send_topic_answer
      activity: =Topic.Answer
    - kind: EndDialog
```

### 3. Guardrail ceiling at ~85%

A static `SendActivity` guardrail that returns the same text for ALL questions works well for generic compliance questions but hits a ceiling because:

- "Can you check if my [document] includes [X]?" questions fail — the agent can't access user documents
- The grader marks generic checklists as incomplete for document-check questions
- Making the answer longer/verbose makes it worse (drops to ~78%)

**To push past 85%**: Improve topic routing (trigger phrases, modelDescription) so questions reach the right topic instead of falling to the guardrail. Don't make the guardrail text longer.

## YAML Editing Pattern

Use **line-based string manipulation**, not regex, for editing Copilot Studio YAML:

```javascript
function removeBlock(yaml, targetId) {
  let s = yaml.replace(/\r/g, '');
  const lines = s.split('\n');
  
  // Find the target line
  let start = -1;
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].trim() === `id: ${targetId}`) {
      start = i - 1; // back to "- kind:"
      break;
    }
  }
  if (start < 0) return s;
  
  // Find block end: next "- kind:" at same indent, or top-level key
  let end = start + 1;
  while (end < lines.length) {
    if (lines[end].match(/^\s{4}- kind:/) && end > start) break;
    if (lines[end].match(/^inputType:|^outputType:/)) break;
    end++;
  }
  
  lines.splice(start, end - start);
  return lines.join('\n').replace(/\n\n\n+/g, '\n\n');
}
```

**Why not regex**: The YAML uses `activity: |` (literal block scalar) not `activity: |-`. Regex patterns like `activity: \|\n(?:        .*\n)*?\n` fail because:
- Indentation varies between topics
- The `|` vs `|-` distinction matters
- Content lines may be empty or have trailing spaces

## Eval Impact

When testing action order changes:
- **Adding guardrail**: Expect score to stabilize (same answer for all questions)
- **Removing guardrail**: Check for `ExecutionFailed` in eval details, not just pass/fail
- **Adding SendActivity for Topic.Answer**: May improve scores if SearchAndSummarizeContent generates better answers than the guardrail

Use the details endpoint to distinguish grader failures from execution errors:
```javascript
const states = {};
cases.forEach(c => {
  const s = c.executionState;
  states[s] = (states[s] || 0) + 1;
});
// Expected: { Evaluated: 100 } or { Evaluated: N, ExecutionFailed: M }
```
