# Inline Quoted Evidence Pattern for Document-Review Topics

## Problem
The model outputs citation-only findings ("Medicare Benefit Policy Manual Chapter 15 Section 220") without quoting the exact flagged passage from the source document. The user only sees the regulation, not the text that triggered the flag.

## Root Cause
`SearchAndSummarizeContent` prompts in document-review topics only instruct "provide inline citations" — the model interprets this as citing the regulation standard, NOT echoing the flagged source text. No instruction anywhere tells the model to reproduce the verbatim passage in the output.

## Fix Architecture (two layers)

### Layer 1: Instructions Component (global G4a guardrail)
Add a guardrail that forces all document-review responses to include the verbatim quote:

```
G4a. Inline Quoted Evidence (MANDATORY for document reviews): For every finding on a submitted
document, you MUST quote the EXACT flagged passage from the user's documentation inline,
immediately followed by its regulation citation. Format: > "[exact verbatim phrase from the note]"
— [Regulation citation]. The quote must be the literal text as written in the submitted note
(not a paraphrase). If the phrase is missing entirely, write > "[Not documented in submitted note]"
— [Regulation citation]. Always pair the quotation and the citation inline so the reader sees
the flagged text next to the rule it violates.
```

PATCH to `botcomponents({instructions_component_id})` with `{"data": "<full yaml>"}` via Dataverse API.

### Layer 2: Topic-Level Prompt (in SearchAndSummarizeContent)

Every document-review topic's `SearchAndSummarizeContent.userInput` must embed a "MANDATORY INLINE QUOTE RULE" tailored to the document type, AND the `additionalInstructions` must require verbatim quotations.

**userInput rule** (inject before `CONSTRAINTS:`):
```
MANDATORY INLINE QUOTE RULE: For EVERY finding, you MUST embed the EXACT verbatim phrase from
the submitted {DocType} that triggered the finding, inside quotation marks, immediately followed
by its regulation citation. Example: > "{generic vague phrase}" — Medicare Benefit Policy Manual
Chapter 15 Section 220 (describes deficiency). If a required element is absent, write
> "[Not documented in submitted note]" — [Regulation citation]. Do NOT paraphrase the flagged text;
quote it word-for-word from the OCR payload.
```

**additionalInstructions rule** (replaces the plain "inline citations" version):
```
additionalInstructions: "Provide specific, source-grounded audit findings with inline citations
AND inline verbatim quotations of the exact flagged text from the submitted document. For each
finding, quote the literal phrase (or state [Not documented]) then the regulation citation, inline.
Report what is present, what is missing, and what CMS requires. If OCR data is missing, state that
clearly. Keep responses concise (under 900 characters). Never output raw citation tokens or
metadata (cite:1, Citation-1, etc.). Reference sources by natural document name only."
```

⚠ YAML GOTCHA: The internal colon in "For each finding: quote..." causes YAML to read it as a mapping key if the value is unquoted. **Always double-quote the `additionalInstructions` value.**

## Per-Document-Type Examples

| Doc Type | Example Flagged Phrase | Example Deficiency |
|----------|----------------------|-------------------|
| Progress Report | "Patient is making good progress" | Lacks objective measurable gains (§220) |
| Treatment Encounter | "Patient seen for routine treatment session" | Lacks skilled justification (§220) |
| Evaluation/A&P | "Patient requires continued therapy" | Lacks objective functional deficits (§230) |
| Discharge Summary | "Patient discharged to home at prior level" | Lacks discharge goals/care-continuity plan (§220) |
| Recertification/UPOT | "Patient continues to make progress" | Lacks revised goals/frequency (§220) |
| Episode of Care | "Therapy provided as scheduled" | Lacks skilled justification across timeline |

## YAML Structure Variations

When inserting the MANDATORY INLINE QUOTE RULE, the structure of `SearchAndSummarizeContent.userInput` varies:

### A. Multi-line Concatenate (Treatment Encounter, Evaluation, Discharge, Episode)
CONSTRAINTS is on its own indented line within the `|-` block scalar. Insert rule before `CONSTRAINTS:` as a new paragraph.

```
                Human Review Advisory: Mandatory flag...

                CONSTRAINTS: If information is missing...
```
Insert: `\n\n                MANDATORY INLINE QUOTE RULE: ...\n\n                CONSTRAINTS:`

### B. Single-line Concatenate (Progress Report, Recert, Text Paste)
CONSTRAINTS is in the middle of a one-line appended string. Insert rule as inline text after `review. ` and before `CONSTRAINTS:`.

```
...Flag missing elements that require clinician review. CONSTRAINTS: If information is missing...
```
Replace: `review. CONSTRAINTS:` → `review. MANDATORY INLINE QUOTE RULE: ... CONSTRAINTS:`

## Episode of Care: Per-Document + Whole-Episode

The Episode of Care topic requires an additional structure block beyond the quote rule:

```
DOCUMENT-BY-DOCUMENT AND WHOLE-EPISODE ANALYSIS: You MUST structure the output in TWO parts.
PART A — PER-DOCUMENT REVIEW: Analyze EACH document in the episode SEPARATELY. For every document
(Evaluation, Treatment Encounters, Progress Reports, Recertification/UPOT, Discharge Summary),
provide: (a) document type and date, (b) individual compliance findings with inline verbatim
quotations and citations, (c) individual risk level.
PART B — WHOLE EPISODE OF CARE: Synthesize ALL documents into one longitudinal analysis —
continuity of care, consistency of the clinical narrative from Evaluation through Discharge,
longitudinal progress, skilled-necessity across the full timeline, and episode-level denial risk.
PART B must reference how individual documents combine, not merely restate them.
```

Also relax the 900-character cap on `additionalInstructions` for EOC since per-doc + whole-episode analysis inherently exceeds that limit. Either raise it or let the model produce longer output.

## Dataverse PATCH Verification

After PATCHing `botcomponents({id})` with the updated `data` field:

1. **VERIFY via GET** immediately:
   ```
   GET /botcomponents({id})?$select=data
   ```
   Confirm the response `data` contains the inserted rule text. The `$select` field must be `data` (not `content`, not `body`).

2. **PUBLISH** and verify `bot.publishedon` timestamp updates:
   ```
   GET /bots({bot_id})?$select=publishedon
   ```

3. **Caution**: Some topic components may not exist as standalone `botcomponents` records (e.g., deleted topics, new-experience topics). If GET returns "Does Not Exist", the topic cannot be PATCHed via Dataverse API — use Copilot Studio UI or VS Code extension instead.

4. **YAML round-trip gotcha**: The `modelDisplayName` top-level field is non-standard and causes "Invalid bot component" errors on PATCH (HTTP 400). Strip it before sending: `re.sub(r'^modelDisplayName:.*\n?\n?', '', data, count=1, flags=re.MULTILINE)`.

## Testing

Upload a sample document and verify the output includes a line like:
```
> "Patient tolerated treatment well and is making progress" — Medicare Benefit Policy Manual Chapter 15 Section 220 (lacks objective measurable progress).
```

If the output shows only the citation without the quote, the topic-level `additionalInstructions` or userInput is still using the old citation-only variant.
