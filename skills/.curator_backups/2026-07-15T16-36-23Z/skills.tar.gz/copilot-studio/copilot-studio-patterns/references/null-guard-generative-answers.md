# Null Guard for Generative Answers Output

## When to Use

Any topic that outputs the result of a `SearchAndSummarizeContent` or `AnswerQuestionWithAI` node to the user. If the generative AI node fails silently (empty response, content-filter block, timeout), `.Text.Content` resolves to blank — the user sees nothing.

## Pattern

Wrap the final `SendActivity` in a `ConditionGroup` that checks `IsBlank`:

```yaml
            - kind: ConditionGroup
              id: conditionGroup_report_available
              conditions:
                - id: condition_report_has_content
                  condition: '=!IsBlank(Topic.ProgressReportAuditReport.Text.Content)'
                  actions:
                    - kind: SendActivity
                      id: sendActivity_audit_report
                      activity: "{Topic.ProgressReportAuditReport.Text.Content}"

              elseActions:
                - kind: SendActivity
                  id: sendActivity_fallback
                  activity: "The audit could not be completed. The result was empty. Please try again."
```

## Pitfalls

- The variable name varies by topic (e.g. `EvaluationAuditReport`, `discharge_summary_audit_report`, `completed_ocr_audit_report`). Use the actual variable from the `SearchAndSummarizeContent` node's `variable:` property.
- Always use `.Text.Content` — not the bare variable — inside both the `IsBlank` check and the output `activity:`. The bare variable is a record, not a string.
- The `condition` string must be single-quoted (`'...'`) to avoid YAML parsing issues with the `!` in `!IsBlank`.
- The `elseActions` fallback message should be generic enough to cover any failure mode but specific enough to tell the user what to do next.

## Related Patterns

- **Prevent Tool Call Leaks** (copilot-studio-patterns) — using `.Text.Content` to avoid raw record metadata
- [Auto-Poll Async Job Status](references/auto-poll-async.md) — polling pattern that feeds into the null-guarded output
