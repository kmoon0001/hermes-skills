# Auto-Poll Async Job Status Pattern

Eliminates manual "check status" user typing by polling an async job automatically after submission.

## When to Use
- Topic submits an async job (OCR, document processing, Power Automate flow)
- User currently has to type a separate command to check status
- Perceived as "manual" or "broken" by users

## YAML Pattern

```yaml
# ── After InvokeFlowAction submit ──────────────────────────
- kind: SetVariable
  id: setVariable_poll_count
  variable: Topic.poll_count
  value: "0"

- kind: GotoAction
  id: goto_first_poll
  actionId: action_poll_status

- kind: InvokeFlowAction
  id: action_poll_status
  input:
    binding:
      job_id: =Topic.async_job_id
  output:
    binding:
      found: Topic.poll_found
      job_id: Topic.poll_job_id
      job_json: Topic.ocr_payload
  flowId: <your-flow-id>

- kind: SetVariable
  id: setVariable_poll_increment
  variable: Topic.poll_count
  value: "=Topic.poll_count + 1"

- kind: ConditionGroup
  id: conditionGroup_poll_completed
  conditions:
    - id: condition_poll_completed
      condition: ="Status: Completed" in Topic.ocr_payload
      actions:
        - kind: SendActivity
          id: sendActivity_completed
          activity: "Job complete. Report: {Topic.report}"
        - kind: EndDialog
          id: endDialog_completed

  elseActions:
    - kind: ConditionGroup
      id: conditionGroup_poll_again
      conditions:
        - id: condition_poll_continue
          condition: =Topic.poll_count < 3
          actions:
            - kind: SendActivity
              id: sendActivity_poll_status
              activity: |
                Document still processing (check {Topic.poll_count}/3).
                Checking again now...
            - kind: GotoAction
              id: goto_poll_again
              actionId: action_poll_status

      elseActions:
        - kind: SendActivity
          id: sendActivity_poll_timeout
          activity: |
            Still processing after multiple automatic checks.
            Job ID: {Topic.async_job_id}
            Say "check OCR job status" to retry.
        - kind: EndDialog
          id: endDialog_timeout
```

## Two Counter Approaches

### Approach A: poll_count < N (simpler, recommended for new topics)
Initialize counter to "0", increment each poll, exit when poll_count >= N. Shown above. 3 retries recommended.

### Approach B: Sentinel blank-out (used by Discharge Summary in Therapy AI Dev)
Uses Power Fx sentinel formula that blanks the counter after N attempts, then checks IsBlank:

```yaml
# Initialize
- kind: SetVariable
  id: setVariable_init_retry
  variable: Topic.retry_count_num
  value: "0"

# After OCR check fails and message sent, increment:
- kind: SetVariable
  id: setVariable_increment_retry
  variable: Topic.retry_count_num
  value: "=If(Value(Text(Topic.'retry_count_num')) + 1 >= 10, Blank(), Value(Text(Topic.'retry_count_num')) + 1)"

# Exit condition:
- kind: ConditionGroup
  id: conditionGroup_retry_exit
  conditions:
    - id: condition_retry_maxed
      condition: "=IsBlank(Topic.retry_count_num)"
      actions:
        - kind: SendActivity
          id: sendActivity_timeout
          activity: OCR still processing after 10 attempts. Say "check status" to retry.
        - kind: EndDialog
          id: endDialog_timeout

# Loop back to OCR check (else branch of the IsBlank condition):
- kind: GotoAction
  id: goto_retry_check
  actionId: invokeFlow_check_async_ocr_status
```

**Key difference:** Approach A exits the loop inside the elseActions of the completed-check. Approach B exits via IsBlank check -- the sentinel formula naturally blanks at 10, and the IsBlank condition handles the exit. Cleaner for high-retry scenarios.

**⚠️ Sentinel Exit Mechanism (non-obvious behavior):** In Approach B's actual implementation (Discharge Summary), the `ConditionGroup` with condition `=IsBlank(Topic.retry_count_num)` has **no `actions:` block**. When the condition is TRUE (10 attempts reached, retry_count_num is blank), Copilot Studio enters the matched condition but finds no actions to execute — execution **stops at the ConditionGroup** and does NOT fall through to the `GotoAction` sibling. This effectively exits the loop. When the condition is FALSE (<10 attempts, retry_count_num has a numeric value), the condition doesn't match, so execution falls through to the next sibling (`GotoAction`), which loops back to the OCR check.

This is a valid pattern but fragile — if someone later adds actions to the IsBlank condition (e.g., a timeout message), the ConditionGroup will execute those actions and then **fall through to GotoAction**, breaking the exit. If you need a timeout message with Approach B, add it in an `elseActions:` block on the GotoAction node, or use Approach A instead.

## Companion: "Check Status" Topic

The separate "check status" topic should also use the saved Job ID automatically:

```yaml
- kind: ConditionGroup
  id: conditionGroup_use_saved
  conditions:
    - id: condition_has_saved
      condition: =!IsBlank(System.Var.AgentName.async_job_id)
      actions:
        - kind: SetVariable
          id: setVariable_use_saved
          variable: Topic.async_job_id
          value: "=System.Var.AgentName.async_job_id"
        - kind: SendActivity
          id: sendActivity_using_saved
          activity: Using your saved Job ID: {Topic.async_job_id}. Checking...
  elseActions:
    - kind: Question
      id: question_job_id
      variable: init:Topic.async_job_id
      prompt: Please enter the OCR Job ID.
```

## Pitfalls

1. **Counter must be initialized BEFORE the first GotoAction** -- otherwise the first poll has no counter value.
2. **GotoAction target (actionId) must be the id of a node AFTER the GotoAction in YAML order** -- can't target a node before itself.
3. **Condition expressions need = prefix** -- ="Status: Completed" in Topic.ocr_payload works; without =, Copilot Studio treats it as a string literal.
4. **RetryCount < 0 is always false -- dead code trap.** condition: =Topic.RetryCount < 0 is never true since RetryCount starts at 0 and only increments. Found in Evaluation/Assessment and Episode of Care topics -- the retry loop can never fire. Fix: condition: =Topic.RetryCount < 3 (or use sentinel approach above).
5. **Text() wrapper needed for `in` operator** -- "Status: Completed" in Text(Topic.ocr_payload) not bare Topic.ocr_payload in some Copilot Studio versions.
6. **Save Job ID to global variable for Check Status topic** -- after timeout, set System.Var.AgentName.job_id = Topic.async_job_id so the separate topic can use it without re-prompting.
7. **Stale BeginDialog references to non-existent topics break topic routing.** When topics are deleted or renamed (e.g., agent reorganized from routing topics to individual NLU topics), any BeginDialog referencing the old topic name silently fails. The conversation falls to Fallback/OnUnknownIntent, producing generic answers instead of proper routing. This caused Conv eval scores to drop from 30% to 10%. Fix: replace BeginDialog with SendActivity + EndDialog for direct upload requests, or update the dialog reference to the correct existing topic name. Verify BeginDialog targets exist before publishing.
