---
name: copilot-studio-patterns
description: "Pattern library index for Copilot Studio agent design — 16 proven patterns for JIT context, routing, hardening, observability, and more."
---

# Copilot Studio Pattern Library

Pattern library for Copilot Studio agent design. Patterns are recommendations, not requirements.

## Pattern Index

### JIT Glossary (patterns/jit-glossary.md)
Loads customer-specific acronyms into global variable on first message so orchestrator can expand them before searching knowledge.
When: glossary/acronym list needed, knowledge search quality poor due to abbreviations.

### JIT User Context (patterns/jit-user-context.md)
Loads current user's M365 profile (country, department) into global variables for personalized answers.
When: country/department/role-aware answers needed, agent needs M365 Users connector.

### Dynamic Topic Redirect (patterns/dynamic-topic-redirect.md)
Uses Switch expression inside BeginDialog to route to different topics based on variable.
When: route to one of several topics based on variable, replace nested ConditionGroup nodes.

### Prevent Child Agent Responses (patterns/prevent-child-agent-responses.md)
Stops child agents from messaging users directly by instructing them to use output variables.
When: child agent should return data without messaging user, parent controls all responses.

### Auto-Poll Async Job Status (patterns/auto-poll-async.md)
Polls an async job status automatically (up to N tries) after submission, instead of making the user type a command to check. Uses SetVariable counter + GotoAction loop + nested ConditionGroup.
When: topic submits an async job (OCR, document processing, Power Automate flow), user currently has to type a separate command to check status, perceived as "manual" or "broken".

> **Pitfalls specific to auto-poll:**
> - `RetryCount < 0` is always false — dead code trap. `condition: =Topic.RetryCount < 0` is never true since RetryCount starts at 0 and only increments. Fix: `condition: =Topic.RetryCount < 3`.
> - `in` operator needs `Text()` wrapper: use `in Text(Topic.var)` not bare `in Topic.var`.
> - Block scalar `|-` on `condition:` breaks `in` — use single-quoted string: `condition: '=\"Status: Completed\" in Text(Topic.ocr_payload)'`.
>
> FIXED EXAMPLE (correct Power Fx + single-quoted condition, no block scalars):
```yaml
- kind: SetVariable
  id: setVariable_poll_count
  variable: Topic.poll_count
  value: '0'

- kind: GotoAction
  id: goto_first_poll
  actionId: action_poll_status

- kind: InvokeFlowAction
  id: action_poll_status
  input:
    binding:
      job_id: =Topic.job_id
  output:
    binding:
      job_json: Topic.job_json
  flowId: <flow-id>

- kind: SetVariable
  id: setVariable_poll_increment
  variable: Topic.poll_count
  value: '=Topic.poll_count + 1'

- kind: ConditionGroup
  id: conditionGroup_completed
  conditions:
    - id: condition_completed
      condition: '=\"Status: Completed\" in Text(Topic.job_json)'
      actions:
        - kind: SendActivity
          id: sendActivity_done
          activity: 'Job complete: {Topic.job_json}'
        - kind: EndDialog
          id: endDialog_done

  elseActions:
    - kind: ConditionGroup
      id: conditionGroup_retry
      conditions:
        - id: condition_retry
          condition: '=Topic.poll_count < 3'
          actions:
            - kind: SendActivity
              id: sendActivity_retry
              activity: 'Still processing (check {Topic.poll_count}/3). Checking again...'
            - kind: GotoAction
              id: goto_poll_again
              actionId: action_poll_status
      elseActions:
        - kind: SendActivity
          id: sendActivity_timeout
          activity: 'Still processing after multiple checks. Say "check status" to retry.'
        - kind: EndDialog
          id: endDialog_timeout
```

**Pitfalls:**
- `SetVariable` counter must be initialized BEFORE the first `GotoAction` that enters the loop
- The `GotoAction` target (`actionId`) must be the `id` of a node AFTER the `GotoAction` itself (can't target a node before it in YAML order)
- Condition expression must use `=` prefix: `=\"Status: Completed\" in Topic.job_json` — without `=`, Copilot Studio treats it as a string literal
- After 3 polls, save the Job ID in a global variable so "Check Status" topic can use it without re-prompting: `System.Var.AgentName.job_id = Topic.job_id`

**PITFALL — Stale BeginDialog references to renamed/deleted topics.** When a topic uses BeginDialog to route to child topics, and those child topics are later renamed or deleted as part of a reorganization, the BeginDialog silently fails. The conversation falls to Fallback/OnUnknownIntent which gives generic answers. This caused Conv eval scores to drop from 30% to 10% on Feedback B. Fix: verify all BeginDialog targets exist before publishing. Replace BeginDialog with SendActivity + EndDialog (direct upload request) if the target topics no longer exist.

### Date Context (patterns/date-context.md)
Injects current date into agent instructions using Power Fx for accurate date-relative responses.
When: date-relative questions, schedules/calendars/deadlines, date interpretation causing confusion.

### Orchestrator-Generated Variables (patterns/orchestrator-variables.md)
Uses AutomaticTaskInput to classify or extract structured data from user's message at orchestration time — zero extra cost.
When: route knowledge searches by category, extract classification without asking user.

### Prevent Tool Call Leaks (patterns/prevent-tool-call-leaks.md)
Stops orchestrator from leaking internal reasoning and tool call metadata to end user.
When: users see raw JSON in responses, agent has connector actions invoked indirectly.

**Refinement — SearchAndSummarizeContent output:** The `SearchAndSummarizeContent` node stores its result in a *record* variable, not a string. Outputting `{Topic.VariableName}` directly causes Copilot Studio to render the raw AI response record structure (metadata, citation payloads, speech/text sub-records). **Fix:** always use `{Topic.VariableName.Text.Content}` in the SendActivity — this resolves to a clean string containing only the formatted AI answer.

### Channel-Aware Behavior (patterns/channel-aware-behavior.md)
Detects host channel from System.Activity.ChannelId and gates behavior per surface (Teams, M365 Copilot, web, Direct Line, voice).
When: feature works on one channel but breaks on another, need to detect Teams vs M365 Copilot.

### RAI Error Handling (patterns/rai-error-handling.md)
Classifies Azure OpenAI content-filter errors by subcode in OnError topic. Azure OpenAI only.
When: industry-specific error messages for RAI violations, category-specific handling.

### Line Breaks in Messages (patterns/line-breaks-in-messages.md)
Uses `<br /><br />` inside message/question nodes for reliable paragraph spacing across channels.
When: bot messages feel like walls of text, multi-part questions need visual separation.

### Knowledge Hold Message (patterns/knowledge-hold-message.md)
Sends randomized hold message during knowledge search so users know agent is working.
When: noticeable knowledge-search latency, users abandoning conversations.

### Deterministic MCP Calls (patterns/deterministic-mcp-calls.md)
Workarounds for MCP tool invocation reliability. Option 1: name tool in instructions. Option 2: child agent wrapper.
When: MCP tool must fire every time for specific intent but orchestrator skips it.

### Chain of Thought Logging (patterns/chain-of-thought-logging.md)
Sends high-level Thinking messages during multi-step orchestration for observability.
When: agent uses multiple tools/MCP servers/child agents, users experience long silences.

### Conversation History Variable (patterns/conversation-history-variable.md)
Captures best-effort conversation transcript into variable for escalation, logging, downstream automation.
When: need conversation context for live-agent escalation, downstream tool needs history.

### Teams Production Hardening (patterns/teams-production-hardening.md)
Eight coordinated production patterns for Teams and M365 Copilot: reinstalls, stale context, resets, diagnostics.
When: deploying/hardening agent on Teams, stale context after long-running conversation.

### Document Processing with OCR + AI Builder (references/document-processing-ocr.md)
Inserts an OCR/text-extraction step between file upload and AI Builder audit for PDFs, scanned images, and large multi-page documents. Supports Power Automate flow (`InvokeFlowAction`) or a 2nd AI Builder Prompty call. Required when the agent processes clinical documents where raw file uploads fail.
When: agent accepts clinical document uploads (PDF, scanned images, 100+ page EoC), AI Builder Prompty audit receives raw binary instead of text, or large documents exceed model context windows.

### Action Execution Order (patterns/action-execution-order.md)
SendActivity as the first action in a topic fires BEFORE SearchAndSummarizeContent or AnswerQuestionWithAI. The guardrail text is what the eval grader evaluates. Removing the guardrail without adding a replacement SendActivity causes `unsupportedactivity.notextresponse` execution failures (not grader failures — the eval framework can't capture Topic.Answer without an explicit send).
When: editing topic action flow, adding/removing guardrails, troubleshooting ExecutionFailed eval results, or optimizing topic response quality.

### Inline Quoted Evidence for Document Review (references/inline-quoted-evidence.md)
Forces SearchAndSummarizeContent audit topics to output the exact flagged source passage in quotation marks, paired inline with its regulation citation. Fixes the "citations-only, no source quotes" problem. Two-layer approach: instructions G4a guardrail + topic-level MANDATORY INLINE QUOTE RULE in userInput + verbatim-quote additionalInstructions. Covers per-document-type examples, YAML structure variations (multi-line vs inline CONSTRAINTS), and Episode of Care per-doc + whole-episode structure.
When: document-review agent outputs regulation citations without quoting the flagged text, user says "only the regulations show up."

### Null Guard for Generative Answers (references/null-guard-generative-answers.md)
Wraps the final SendActivity in a ConditionGroup that checks `!IsBlank(Topic.Variable.Text.Content)`. If the generative AI node returns empty, the user sees a fallback message instead of a blank screen.
When: topic outputs `SearchAndSummarizeContent` or `AnswerQuestionWithAI` results directly, generative node can fail silently, or users seeing empty messages during demos/tests.

### Text-Input Fallback for Document Upload Topics (patterns/text-input-fallback.md)
Adds a text-input path alongside the file upload path so the topic works when users paste text instead of uploading a file. Avoids the `FilePrebuiltEntity` loop that causes Conv eval failures when test sets can't attach files.

**The pattern (both paths in one topic):**
1. **Question** with `StringPrebuiltEntity` (not `FilePrebuiltEntity`) — accepts text OR file uploads
2. **ConditionGroup 1 (file path):** Check `=!IsBlank(First(System.Activity.Attachments))` — file was attached
   - AI Builder or OCR flow receives `=First(System.Activity.Attachments).Content` (the `.Content` property gives the File-typed value the AI Builder expects)
   - Output result via `SendActivity`
3. **else → ConditionGroup 2 (text path):** Check `'=!IsBlank(Trim(Topic.DocumentText))'` — text was pasted
   - `SearchAndSummarizeContent` with the pasted text as input
   - Output result via `SendActivity`
4. **else → GotoAction** — re-ask the question if nothing provided

**Critical: Both conditions MUST be single-quoted in YAML**
```yaml
# ✅ CORRECT — single-quoted, parentheses preserved
condition: '=!IsBlank(First(System.Activity.Attachments))'

# ❌ WRONG — unquoted, YAML strips parentheses content
condition: =!IsBlank(First(System.Activity.Attachments))
```

**AI Builder binding must use `.Content`:**
```yaml
# ✅ CORRECT — extracts File type from attachment record
DischargeInput: =First(System.Activity.Attachments).Content

# ❌ WRONG — passes the full Record type, causes IncorrectTypeAssignment
DischargeInput: =First(System.Activity.Attachments)
```

**When:** topic accepts file uploads but Conv test set describes documents in text, users paste text instead of uploading files, topic loops on "please upload" forever, or `FilePrebuiltEntity` never completes because the entity requires a file blob.

**Pitfalls:**
- `StringPrebuiltEntity` on the Question means `Topic.DocumentText` holds the user's text response, NOT the file blob. The file is in `System.Activity.Attachments` — two separate sources.
- `First(System.Activity.Attachments).Content` returns the File-typed content of the first attachment. Without `.Content`, it returns a Record which causes `IncorrectTypeAssignment` during publish.
- The condition `!IsBlank(First(System.Activity.Attachments))` checks for file attachments independently of `Topic.DocumentText`. They are separate checks.
- `SearchAndSummarizeContent` output goes to a Topic variable, then must be sent via `SendActivity`. Without the SendActivity, the node runs silently.

### Card → Generation → Audit (patterns/card-generation-audit.md)
Collects structured clinical data via AdaptiveCard (click buttons, minimal typing), generates a polished note via SearchAndSummarizeContent, then routes to compliance audit. For post-session documentation assistants where therapists capture session data with button clicks and the AI writes the note.
When: building a documentation agent that should minimize typing, AdaptiveCard data collection topics that need note generation, or clinical note workflows requiring compliance review after generation.

## Reference Files
- `references/inline-quoted-evidence.md` — Prompting pattern for SearchAndSummarizeContent audit topics to output verbatim flagged source quotes paired inline with regulation citations. Two-layer fix (instructions G4a + topic-level MANDATORY INLINE QUOTE RULE). Covers per-doc-type examples, YAML structure variations, and Episode of Care per-doc + whole-episode structure.
- `references/document-review-topic-architecture.md` — Architecture comparison of 6 document review topics: which have working retry/poll logic and which have broken or missing polling, with fix patterns for Evaluation/Assessment, Treatment Encounter, Recertification, and Episode of Care topics.
- `references/auto-poll-async.md` — Full YAML reference for auto-poll pattern with two counter approaches (poll_count < N and sentinel blank-out).

## Combining Patterns
- JIT Glossary + JIT User Context -> merge into single conversation-init topic
- Date Context + JIT User Context -> both in instructions
- Orchestrator Variables + JIT User Context -> classify AND personalize
- RAI Error Handling + Teams Production Hardening -> handle subcodes first, then diagnostic card
- Knowledge Hold Message + Chain of Thought Logging -> reduce perceived latency
- Null Guard + Auto-Poll + Prevent Tool Call Leaks -> production-ready document-processing topic

## Cross-Cutting Pitfall: Dataverse YAML Escaping

When PATCHing topic YAML via the Dataverse API (`PATCH /botcomponents({id})`), **the YAML uses `\"` for double-quoted Power Fx conditions** and this must survive **three layers of escaping**:

1. **YAML layer:** A condition like `condition: "=\"Status: Completed\" in Topic.var"` uses `\"` to embed literal quotes inside a YAML double-quoted scalar.
2. **Python/JS string layer:** The YAML line in your Python source becomes: `'          condition: "=\\"Status: Completed\\" in Topic.var"'`
3. **JSON layer:** When sent as `{"data": "..."}`, the backslashes double again for JSON encoding.

**Practical rule:** Use Python raw strings or carefully build the condition. The safest approach is to store the YAML in a file, read it, and PATCH it directly. Verify the Dataverse store matches a working topic byte-for-byte.

**Signs you have wrong escaping:**
- `contentValidationError` with `'Unexpected characters...' (\)` — a trailing backslash from mangled escaping
- Publish succeeds but runtime fails — the condition was accepted by YAML parser but evaluates to garbage
- The condition works when typed in the Copilot Studio UI but fails when PATCHed via API

**Reference:** Check `botcomponents({id})?$select=data` and compare the condition line `repr()` between a working topic and the PATCHed topic. The difference is often invisible to the naked eye — use `repr()` or hex dump.

## Trigger Phrase Overlap: Catch-All vs Specific Topics

When a catch-all/upload-intake topic has broad triggers like "review this progress report" or "audit my discharge summary", it can **steal** requests from the specific document review topics (Progress Report Review, Discharge Summary, etc.) that have narrower triggers.

**Pattern: Catch-all topics should only have GENERIC triggers** — phrases that can't be assigned to any specific document type. Route to specific topics via a menu question instead of trigger phrases.

**Before:** Document Upload Intake had 42 triggers including `review this progress note`, `review this evaluation`, `audit my discharge summary`, `review this recertification note`, `compare multiple documents` — all overlapping with specific doc topics.

**After:** 13 generic triggers: `I uploaded a document`, `review this uploaded document`, `check this file`, `process this uploaded file`, `review my document`, `analyze this therapy document`, `audit the attached document`, `check this clinical document`, `I need a compliance review`, `help me review this`, `I need this reviewed`.

**Test:** "review progress report" should route to Progress Report Review directly, not to Document Upload Intake. If it goes to the intake menu first, the intake's trigger phrases are too broad.

## Power Automate Flow Fix: Async OCR Check Job Status

The `InvokeFlowAction` for checking OCR job status (`flowId: 27c65bc3-277a-f111-ab0e-7ced8d6f2fba`) queries Dataverse `Notes (annotations)` for OCR results. If this flow returns "Processing" indefinitely, it's missing the **List rows** step.

**Fix (in Power Automate UI):**
1. Insert **List rows** (Dataverse connector) between the trigger and "Respond status" action
2. Configure:
   - **Table name:** `Notes (annotations)`
   - **Filter rows:** `subject eq '@{triggerBody()?['job_id']}'`
   - **Row count:** `1`
   - **Sort by:** `createdon desc`
3. Update each "Respond status" output:
   - `found` → Expression: `not(empty(outputs('List_rows')?['body/value']))`
   - `job_id` → Dynamic: Job Id from trigger
   - `job_json` → Expression: `if(empty(outputs('List_rows')?['body/value']), 'Status: Processing', concat('Status: Completed | ', first(outputs('List_rows')?['body/value'])?['notetext']))`
   - `processing_status` → Expression: `if(empty(outputs('List_rows')?['body/value']), 'Processing', 'Completed')`
   - `message` → Expression: `if(empty(outputs('List_rows')?['body/value']), 'Still Processing', first(outputs('List_rows')?['body/value'])?['notetext'])`
   - `document_type` → Literal: `Unknown`

The flow must be turned ON (statecode=1) and published for the topic's InvokeFlowAction to work.

## How to Use
Advisor: present as suggestion, explain challenge solved, use status-appropriate language (proven/recommended/experimental).
Author: when implementing chosen pattern, read pattern file for correct YAML structure.

Read pattern files at: D:/my agents copilot studio/pipeline/patterns/
