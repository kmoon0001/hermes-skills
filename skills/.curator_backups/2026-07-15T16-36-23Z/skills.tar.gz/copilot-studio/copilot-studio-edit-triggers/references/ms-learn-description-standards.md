# MS Learn Topic Description Quality Standards

From [Microsoft Learn: Authoring Descriptions](https://learn.microsoft.com/en-us/microsoft-copilot-studio/advanced-generative-actions#authoring-descriptions):
"Provide a high-quality description for each of its child agents, connected agents, topics, tools, and knowledge sources. Good descriptions ensure the agent selects the right topics, tools, other agents, and knowledge sources to respond to users."

## Writing Style

| Standard | Guideline |
|---|---|
| **Active voice, present tense** | "Audits documentation for compliance" NOT "A topic that handles documentation audits" |
| **Simple, direct language** | Avoid jargon, slang, or technical terms |
| **1-2 sentences** | Short and informative summary of the topic's functionality |
| **Indicate what it can't do** | Prevents ambiguity between similar topics (e.g., "Does not review daily notes") |

## Relevance

| Standard | Guideline |
|---|---|
| **Use keywords** | Relate to the functionality of the topic and the user's intent |
| **Descriptive name** | Short phrase, not generic or ambiguous. "Weather Forecast" NOT "Weather" |
| **Specific to prevent ambiguity** | If similar topics exist, make names and descriptions specific enough to distinguish |
| **User benefit** | Explain what the topic does and how it benefits the user |

## Generative Orchestration Specifics

With generative orchestration:
- The topic's `description` (inside `mcs.metadata`) and `modeldescription` (root-level) are the PRIMARY routing mechanism
- `triggerQueries` still help with disambiguation but are secondary
- Both description fields must exist with identical text
- Auto-generated descriptions from classic trigger phrases are "often good enough" but should be manually reviewed

## Verification Checklist

For every custom OnRecognizedIntent topic:
- [ ] `mcs.metadata.componentName` is descriptive and unique
- [ ] `mcs.metadata.description` uses active voice, present tense
- [ ] `modeldescription` (root-level) is present and identical to description
- [ ] Description is 1-2 sentences, under ~300 chars
- [ ] Description includes negative scope ("Does not handle X")
- [ ] Description starts with an action verb
- [ ] Description states user benefit
- [ ] `triggerQueries` exist (even if generative, they help disambiguation)
- [ ] `displayName` in intent is meaningful

## Good vs Bad Examples

**Bad — vague, passive, no negative scope:**
```
This tool can handle queries like these: audit evaluation, eval audit, check eval
for denial risk, initial evaluation compliance, analyze eval documentation,
review my evaluation.
```

**Good — active, specific, negative scope:**
```
Audits Evaluation and Plan of Care documentation for Medicare Part B denial risk
using CMS Chapter 15, Jimmo standards, and Ensign 7 Habits. Returns structured
findings with issue, standard, and citation. Does not review daily treatment
notes or progress reports.
```

**Bad — generic name, no description:**
```
componentName: Feedback Agent
```

**Good — descriptive name:**
```
componentName: Evaluation and Plan of Care Audit
```
