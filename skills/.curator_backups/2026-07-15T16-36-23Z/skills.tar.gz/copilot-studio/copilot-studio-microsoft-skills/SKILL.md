---
name: copilot-studio-microsoft-skills
description: "References to Microsoft's official Copilot Studio GitHub repos cloned locally. Contains YAML schemas, design patterns, evaluation tools, and agent templates from microsoft/skills-for-copilot-studio, microsoft/cat-agent-skills, and microsoft/agent-academy."
version: 1.0.0
---

# Microsoft Copilot Studio GitHub Resources (Local Clones)
# Microsoft Copilot Studio GitHub Resources (Local Clones)

## Cloned Repos (C:\Users\kevin\)

| Repo | Path | Contents | Stars |
|------|------|----------|-------|
| skills-for-copilot-studio | `C:\Users\kevin\skills-for-copilot-studio\` | 20 skills, 15 patterns, YAML schema | Microsoft official |
| cat-agent-skills | `C:\Users\kevin\cat-agent-skills\` | Copilot Studio community gallery | Microsoft official |
| agent-academy | `C:\Users\kevin\agent-academy\` | 3-part training (prompts, cards, flows) | Microsoft official |
| awesome-copilot-studio-agents | `C:\Users\kevin\awesome-copilot-studio-agents\` | 89 paste-ready M365 agent instructions | ★ 425 |
| awesome-copilot | `C:\Users\kevin\awesome-copilot\` | Community agents, instructions, hooks | GitHub community |
| awesome-harness-engineering | `C:\Users\kevin\awesome-harness-engineering\` | AI agent scaffolding meta-patterns | Community |
| mcscatblog | `C:\Users\kevin\mcscatblog\` | Microsoft CAT blog + resource pages | Microsoft CAT |
| powerplatform-mcp | `C:\Users\kevin\powerplatform-mcp\` | MCP server for Dataverse/PowerPlatform | Public |

## Key Files

### YAML Schema (validate any topic)
`C:\Users\kevin\skills-for-copilot-studio\reference\bot.schema.yaml-authoring.json`

### Design Patterns (skills-for-copilot-studio/patterns/)
- `chain-of-thought-logging.md` — RAI logging for multi-step reasoning
- `dynamic-topic-redirect.md` — Redirect between topics at runtime
- `conversation-history-variable.md` — Maintain multi-turn state
- `orchestrator-variables.md` — Variables across child agents
- `knowledge-hold-message.md` — Latency handling for knowledge calls
- `teams-production-hardening.md` — Production readiness for Teams
- `rai-error-handling.md` — Responsible AI error handling

### Copilot Studio Skills (skills-for-copilot-studio/skills/)
- `analyze-evals/` — CSV eval analysis
- `create-eval-set/` — Create test sets
- `clone-agent/` — Clone agents
- `add-adaptive-card/` — Adaptive Card patterns
- `add-generative-answers/` — Generative answers setup
- `add-knowledge/` — Knowledge source configuration
- `add-other-agents/` — Multi-agent patterns
- `int-patterns/` — Pattern library
- `edit-agent/` — Agent metadata
- `edit-triggers/` — Trigger phrase management

### 89 M365 Agent Templates (awesome-copilot-studio-agents/)
All at `C:\Users\kevin\awesome-copilot-studio-agents\agents\`:
| Category | Agents | Path |
|----------|--------|------|
| Writing & Communication | 7 | `writing-communication/` |
| Project Management | 12 | `project-management/` |
| HR & People | 3 | `hr-people/` |
| Finance | 5 | `finance/` |
| Sales & Business Dev | 5 | `sales/` |
| Commercial & Legal | 4 | `commercial-legal/` |
| Data Analytics | 4 | `data-analytics/` |
| IT & Operations | 6 | `it-ops/` |
| Learning & Dev | 4 | `learning-development/` |
| Productivity | 8 | `productivity/` |
| Strategy & Executive | 5 | `strategy-executive/` |
| Customer Success | 3 | `customer-success/` |
| Procurement | 3 | `procurement/` |
| ESG & Sustainability | 4 | `esg/` |
| Data Privacy | 4 | `data-privacy/` |
| Trade Compliance | 4 | `trade-compliance/` |
| Industry (Energy) | 3 | `industry/epc-energy/` |

## Remixing M365 Agent Instructions → Copilot Studio Topics

The 89 agents are **declarative agent instructions** (for M365 Copilot Agent Builder). But their instruction patterns directly map to Copilot Studio's **GPT instructions** (componenttype 15). 

### Direct Remix Path
1. Read the agent's `instructions` block (under `## Instructions`)
2. That block can be pasted into Copilot Studio's **Instructions** field (Settings → General → Instructions)
3. The `## Conversation Starters` become trigger phrase ideas for topics
4. The `## WHAT YOU DO NOT DO` section becomes guardrails in the instructions

### Full Remix: Agent Instructions → Topic YAML
To convert an M365 declarative agent into a full Copilot Studio topic with proper triggers, YAML nodes, and actions:

1. **Topic header**: Use `kind: AdaptiveDialog` with `OnRecognizedIntent`
2. **ModelDescription**: Extract from the agent's `description` frontmatter
3. **Trigger phrases**: Adapt from `## Conversation Starters`
4. **Actions**:
   - `SendActivity` for the output (using the agent's output format)
   - `SearchAndSummarizeContent` if knowledge sources are referenced
   - `ConditionGroup` for branching review criteria
5. **Instructions**: The agent's full instruction block becomes the GPT-level instructions

See `templates/m365-to-cs-remix.yaml` for the complete conversion template.

## CAT Resources (mcscatblog)
`C:\Users\kevin\mcscatblog\` — Microsoft Customer Architecture Team blog, agent patterns, implementation guides. Browse `src/content/` for articles.

## Supporting Files

### References
- `references/official-tooling-landscape.md` — Complete scan of all Microsoft-official Copilot Studio CLIs, SDKs, VS Code extensions, APIs, and GitHub kits. Documents what's installed vs what's available but not yet set up. Check this before making tool recommendations.
- `references/dot-cache-cleanup.md` — Tool `.cache` directory sizes and safe-delete mapping (puppeteer, codex, huggingface, webwright, etc.)

### Templates
- `templates/m365-to-cs-remix.md` — Guide: converting M365 declarative agent instructions → Copilot Studio topic YAML
- `templates/document-reviewer-topic.yaml` — Worked example: Document Reviewer agent converted to full Copilot Studio topic
- `templates/README.md` — Index of all cloned Microsoft Copilot Studio GitHub repos
