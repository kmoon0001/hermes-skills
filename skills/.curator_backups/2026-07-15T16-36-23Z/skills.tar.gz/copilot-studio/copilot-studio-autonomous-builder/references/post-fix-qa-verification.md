# Post-Fix QA Verification — Detailed Reference

## Overview

This reference documents the structured multi-phase QA verification workflow validated during the TheraDoc Workbench Loop 1 fixes (July 3, 2026). It provides the actual commands, assertion patterns, and edge cases discovered during a 14-fix, 17-file verification pass across an 81-file Copilot Studio agent.

## Prerequisites

- Node.js with `js-yaml` installed (`npm install -g js-yaml` or locally available)
- Access to `.bak` backup files alongside each modified `.mcs.yml`
- The agent's root directory containing `agent.mcs.yml` and `topics/`

## Session-Specific Patterns (Validated Jul 3, 2026)

### Fix Categories That Need Special Attention During QA

| Category | Example Fix | What to Check |
|---|---|---|
| **EndDialog addition** | Topic previously ended with SendActivity only | Confirm EndDialog is AFTER the SendActivity, not before. Confirm `clearTopicQueue: true` is set. |
| **ConditionGroup removal** | Empty group with duplicate PT condition | Confirm the ENTIRE block is gone (id, conditions, everything), not just the conditions array. |
| **String interpolation fix** | Bare double-quotes inside `|-` block scalar removed | Read the raw YAML — `|-` block scalars preserve literal `"` chars. Confirm no outer `"` wrapping the content. |
| **Value replacement** | `="ST"` → `="SLP"` | grep for BOTH old and new values. The old value should have ZERO matches in the modified file. |
| **Structural rewrite** | Single PT route → 3-branch ConditionGroup routing | Count condition branches. Confirm each branch has all 3 parts: condition, BeginDialog, and output binding. |
| **Template comment removal** | 12-line Platinum Standard block removed | grep for `# Microsoft Learn` across modified files. Should be zero. Note: unmodified files may still have these — do NOT touch them. |

### Assertion Commands (Reusable)

```bash
# Check EndDialog presence and id
grep -A2 "kind: EndDialog" topics/AuditExistingNote.mcs.yml

# Check old value is gone
grep '="ST"' topics/STDailyNoteCard.mcs.yml      # should return nothing

# Check new value is present
grep '="SLP"' topics/STDailyNoteCard.mcs.yml      # should match line

# Verify discipline routing count
grep -c "condition: =Topic.Discipline = " topics/SessionClose.mcs.yml   # expected: 3 (PT/OT/SLP)

# Check template comments entirely removed from modified files
grep -l "Microsoft Learn Platinum Standard" topics/AuditExistingNote.mcs.yml topics/ParseBrainDump.mcs.yml topics/SessionClose.mcs.yml # ...list all 14 modified files
# Expected: no output (all files should have zero matches)

# Check NO-CAVEAT section present
grep "NO-CAVEAT" agent.mcs.yml

# Count routing matrix conditions (5 note types × 3 disciplines)
grep -c "condition: =Topic.Discipline" topics/NoteIntakeRouter.mcs.yml   # expected: 15
```

### Edge Cases Caught During TheraDoc QA

1. **SessionClose never had EndDialog** — pre-existing issue, not a regression. Document it as "pre-existing" in the QA report, don't flag as a fix failure.
2. **StartOver has no EndDialog** — similar pre-existing pattern. Some system-flow topics legitimately don't end with EndDialog because they redirect via BeginDialog.
3. **ErrorTimeoutRecovery has no EndDialog** — error handler topics typically don't need EndDialog since they just send a message and the conversation ends.
4. **YAML block scalar `|-` vs `|` matters** — `|-` strips trailing newline; `|` preserves it. Look for `|-` when fixing string interpolation in SendActivity text.
5. **Template comments appear in unmodified files too** — only assert they're removed from the modified files list. Other files may still legitimately have them (not in scope).
6. **EndDialog can be inside a ConditionGroup branch** — don't just check for EndDialog at end of file. A ConditionGroup with branching logic may have EndDialog nested inside condition actions and elseActions.

### Regression Check Patterns

```bash
# Pick 5 files that were NOT modified
ls -1 topics/*.mcs.yml | grep -v -f <(printf '%s\n' "${MODIFIED_FILES[@]}") | shuf | head -5

# For each, check EndDialog is still present
for f in $SPOT_CHECK_FILES; do
  count=$(grep -c "EndDialog" "topics/$f")
  echo "$f: EndDialog count = $count"
done

# Routing matrix integrity — confirm all conditions present
grep "condition: =Topic.Discipline = \"PT\" && Topic.NoteType" topics/NoteIntakeRouter.mcs.yml
grep "condition: =Topic.Discipline = \"OT\" && Topic.NoteType" topics/NoteIntakeRouter.mcs.yml
grep "condition: =Topic.Discipline = \"SLP\" && Topic.NoteType" topics/NoteIntakeRouter.mcs.yml
# Expected: 5 matches each (one per note type)
```

## QA Report Template

Place at `D:/my agents copilot studio/pipeline/audit-results/<agent>-loop<N>-qa.md`:

```markdown
# <Agent> — Loop <N> QA Verification Report

**qa-pass: true**  or  **qa-pass: false**

## Summary
| Priority | Fixes Applied | QA Status |
|---|---|---|
| **P0** (Critical) | X/X | ✅ ALL PASS |
| **P1** (Routing/Logic) | X/X | ✅ ALL PASS |
| **P2** (Template Cleanup) | X/X | ✅ ALL PASS |

## Step 2: File-by-File Verification (Current vs .bak)
| File | Fix | Status | Detail |
|---|---|---|---|

## Step 3: YAML Validation
Total: XX files, PASS: XX, FAIL: XX

## Step 4: Fix Assertions
| # | Fix | Status |
|---|---|---|

## Step 5: Regression Checks
- Random spot-check: PASS/FAIL
- Routing matrix: PASS/FAIL
- Pre-existing issues found:
```

## Known Limitations

- **Diffing is manual (read_file side-by-side)** — no automated diff tool is used; each file is read via read_file and compared manually
- **Does NOT catch semantic regressions** — only structural/assertion-level regressions. For semantic regressions, run an eval (Phase 6).
- **Does NOT replace schema validation** — YAML parse check is a syntax gate only. Run schema-lookup.bundle.js validation afterward (Phase 3).
- **Does NOT validate cross-topic variable flow** — if a fix changes a variable name used by other topics, that must be checked separately.
