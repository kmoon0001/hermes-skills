---
name: copilot-studio-eval-loop
description: "Automated eval-driven optimization loop for Copilot Studio agents. Run evals on draft, analyze failures, propose YAML fixes, re-test until passing."
version: 1.0.0
author: Hermes Agent
platforms: [windows, linux, macos]
metadata:
  hermes:
    tags: [copilot-studio, eval, optimization, autonomous, testing]
---

# Eval-Driven Optimization Loop

Automated loop that runs evaluations on DRAFT agents (no publish needed), analyzes failures, proposes YAML fixes, and re-tests until all tests pass.

## The Loop

```
Run Eval -> Analyze Results -> Identify Failures -> Propose Fixes -> Apply -> Re-run Eval
```

## Pre-Eval Structural Cleanup Pass

Before running any evaluations, do a structural cleanup pass. The most common eval failures (ExecutionFailed, unsupportedactivity.notextresponse, low relevance/completeness) stem from missing topic termination, dead comments, and instruction contradictions — not from the agent's reasoning ability.

### Phase 1: Audit Analysis Review

Read the analysis file first (if one exists at `pipeline/audit-results/analysis-<agent-name>.md`). Map P0/P1 issues to file paths:

| Analysis Finding | File to Fix |
|-----------------|-------------|
| Instructions contradictions | `agent.mcs.yml` → `instructions:` field |
| Missing EndDialog | Each topic in `topics/` |
| No-caveat / eval-safe missing | `agent.mcs.yml` → add EVAL NO-CAVEAT + EVALUATION-SAFE sections |
| Boilerplate comments | Strip from all topic files |

### Phase 2: Fix agent.mcs.yml Instructions

1. **Remove non-existent source references** — If instructions reference an "ACTIVE WORD DOCUMENT" or other sources the agent cannot access, replace with explicit denial: "You do NOT have access to live Word documents, EHR systems, or other external files."

2. **Add EVAL NO-CAVEAT** — Prevents the agent from refusing eval prompts due to missing data:
   ```
   ## EVAL NO-CAVEAT
   During automated evaluation, when the test prompt does not provide a patient note, MRN,
   or clinical data: do NOT say "I don't see a note" or refuse — answer naturally without
   caveating. The eval test deliberately excludes data.
   ```

3. **Add EVALUATION-SAFE** — Governing eval behavior:
   ```
   ## EVALUATION-SAFE
   When no patient data is provided, answer conceptually without asking for MRN.
   If the test prompt is conversational, respond conversationally.
   Never refuse an evaluation prompt on grounds of "missing information."
   ```

4. **Fix unconditional RESPONSE FORMAT** — If instructions force structured output on ALL queries (not just routing), add "for routing actions only" and note that non-routing queries should get natural responses.

5. **Condense bloated sections** — If >8K chars, remove micro-checklists, banned-word lists, per-note field enumerations. Replace with "Be concise but complete." (Validated: 10K→3K chars recovered 30%+ in SR scores.)

### Phase 3: Batch Topic YAML Fixes

For EVERY file in `topics/` (both `.mcs.yml` and `.topic.yaml`):

1. **Backup first** — Copy each file to `<name>.bak` before editing:
   ```bash
   cd "<agent-workspace>/topics"
   ls *.yml *.yaml 2>/dev/null && for f in *.yml *.yaml; do cp "$f" "${f}.bak"; done
   ```

2. **Add EndDialog + clearTopicQueue** — Every custom topic needs one at the end of its actions array:
   ```yaml
   - kind: EndDialog
     id: endDialog_<topicName>
     clearTopicQueue: true
   ```
   For topics using `CancelAllDialogs` (e.g., Greeting), replace with `EndDialog(clearTopicQueue: true)`. System topics (ConversationStart, Fallback, OnError, Escalate, ThankYou, StartOver, Search, Signin, ResetConversation, MultipleTopicsMatched, Goodbye, EndofConversation) have their own termination patterns — leave unchanged.

   **PITFALL — ConversationStart with `SendActivity` + NO `EndDialog` causes Conv eval execution errors.** Many agents (especially copies/clones in Dev) have a ConversationStart topic whose `actions` array ends at `SendActivity` with no terminating `EndDialog(clearTopicQueue: true)`. Without it the agent never terminates the initial topic, so subsequent user turns get no response or fall into error handlers → Conv eval tanks. Check the ConversationStart `data` field via Dataverse: if `actions` ends with `SendActivity`, add:
   ```yaml
   - kind: EndDialog
     id: end_conversation_start
     clearTopicQueue: true
   ```
   This is the #1 highest-impact fix for Conv evals on agents with custom ConversationStart topics (validated Jul 6 2026: Therapy Documentation Feedback Agent Dev copy — 0% Conv with 17/20 execution errors caused by missing EndDialog).

3. **Remove boilerplate comment blocks** — Strip the "Microsoft Learn Platinum Standard Instructions" header (5 lines) and "GLOBAL SAFETY GUARDRAILS" block (7 lines) from all topic files. These are dead comments — the model never reads them. Files affected typically: ConversationStart, Fallback, Escalate, OnError, ThankYou, StartOver, Search, Signin, ResetConversation, MultipleTopicsMatched, Goodbye, EndofConversation, SNFRoutingStatusCheck, Greeting.

   Pattern to remove:
   ```yaml
   # Microsoft Learn Platinum Standard Instructions:
   # **Grounding**: Refer to src/KnowledgeBase/GLOBAL_CMS_COMPLIANCE.md.
   # **Patterns**: Implement src/KnowledgeBase/PLATINUM_PROMPT_PATTERNS.md for few-shot reasoning.
   # **Self-Correction**: If the output involves clinical judgment, invoke the ComplianceAuditor gate.
   #
   # ### GLOBAL SAFETY GUARDRAILS (IRONCLAD):
   # 1. **NO HALLUCINATION**: Flag missing IDs immediately.
   # ...
   ```

### Phase 4: Validate All YAML

Run a batch parse check on ALL modified files using Python's yaml.safe_load. Read as bytes (`'rb'`) to detect C1 control characters (0x80-0x9f from double-encoded emoji) that crash text-mode parsing.

```python
import yaml, os
base = '<agent-workspace>'
files = [os.path.join(base, 'agent.mcs.yml')] + \
        [os.path.join(base, 'topics', f) for f in os.listdir(os.path.join(base, 'topics'))
         if f.endswith(('.yml', '.yaml')) and not f.endswith('.bak')]
errors = [(f, str(e)) for f in sorted(files)
          if not (content := open(f, 'rb').read()).strip()
          or yaml.safe_load(content) is None]
# or catch yaml.YAMLError properly — see references/pre-eval-cleanup-pattern.md
```

Skip empty stubs. Report results: "N files validated OK" or list each FAIL.

### Phase 5: Generate Audit Report

Write to `pipeline/audit-results/<agent-name>-loopN-fixes.md`:
- Summary table (files backed up, modified, YAML pass rate, P0/P1 addressed)
- Per-file change log
- YAML validation results
- Remaining issues by severity
- Fix-ready assessment (what improved, what remains, estimated %)

See `references/pre-eval-cleanup-pattern.md` for the full report template and this session's worked example (SNF Command Center V2).

## Step 1: Run Eval on Draft

No publish needed! The eval-api tests the DRAFT directly.

```bash
node "D:/my agents copilot studio/pipeline/scripts/eval-api.bundle.js" list-testsets --workspace <path> --client-id <id>
node "D:/my agents copilot studio/pipeline/scripts/eval-api.bundle.js" start-run --workspace <path> --client-id <id> --testset-id <id> --run-name "Optimization loop <timestamp>"
```

If agent uses authenticated knowledge/tools, add --connection-id.

Poll until complete:
```bash
node "D:/my agents copilot studio/pipeline/scripts/eval-api.bundle.js" get-run --workspace <path> --client-id <id> --run-id <runId>
```

## Step 2: Analyze Results

```bash
node "D:/my agents copilot studio/pipeline/scripts/eval-api.bundle.js" get-results --workspace <path> --client-id <id> --run-id <runId>
```

For each failure, categorize:

| Metric | Root Cause | Fix Approach |
|--------|-----------|--------------|
| GeneralQuality.Relevance | Topic not matching intent | Improve modelDescription or triggerQueries |
| GeneralQuality.Completeness | Missing information in response | Add knowledge sources or improve instructions |
| GeneralQuality.Groundedness | Hallucination | Add SearchAndSummarizeContent with knowledge grounding |
| GeneralQuality.Abstention | Should refuse but doesn't | Add scope enforcement in instructions |
| ExactMatch | Wrong output format | Fix SendActivity text or topic output |
| CapabilityUse | Missing tool invocation | Add connector action, improve modelDescription on action |
| Error | Test config issue | Check test set configuration, not YAML |

Multi-turn and connector-backed eval failures need per-query detail, not just case aggregate. If `/details` shows connection-manager answers, `FlowNotFound`, generic Greeting replies, or `To clarify, did you mean:` on follow-up turns, patch the full routing surface (specialist topic + Conversational Boosting + Fallback/Greeting/MultipleTopicsMatched as needed) before rerunning. If turn 1 passes but turn 2/3 pasted clinical details fail, keep the topic open with `Question -> Question -> SendActivity -> EndDialog`; a first-turn `SendActivity + EndDialog` lets follow-up turns escape into generated answers/connector-bound knowledge. Do not switch type-16 knowledge sources to Maker or deactivate them as a first fix; this can hang maker eval runs. See `references/feedback-b-eval-migration-routing-pattern.md` for the full Feedback B pattern, direct multi-turn topic skeleton, and auth recovery steps.

## Step 3: Locate and Fix

For each failure:
1. Find the relevant topic YAML file
2. Read the current content
3. Identify the specific node/property that needs changing
4. Propose the fix with explanation
5. Apply using Edit tool

Common fixes:
- **Low relevance**: Add/improve modelDescription, add trigger phrases
- **Low completeness**: Add knowledge source, improve SearchAndSummarizeContent
- **Hallucination**: Replace AnswerQuestionWithAI with SearchAndSummarizeContent + knowledge
- **Missing tool call**: Improve action modelDescription, add to instructions
- **Wrong format**: Fix SendActivity activity text
- **Capability not used**: Add InvokeConnectorTaskAction or improve routing

## Step 4: Validate After Fix

```bash
node "D:/my agents copilot studio/pipeline/scripts/schema-lookup.bundle.js" validate <fixed-file.yml>
```

## Step 5: Re-run Eval

Before rerun:
- Parse all generated `.after.yml` / backup YAMLs and repair indentation errors first.
- If the last start-run returned `fairusagepolicy.botrunquotaviolated`, stop launching evals; use existing `/details` data and wait for the 24-hour window.
- If it returned `fairusagepolicy.botactiverunquotaviolated`, poll the active run instead of starting another.
- If `/details` has `unsupportedactivity.notextresponse`, fix the topic/action so it emits plain text before rerunning the full suite.

Go back to Step 1. Continue until:
- All tests pass, OR
- No more YAML-only fixes possible (some failures may need UI changes), OR
- User says stop

## `data` vs `content` Field Mismatch (Publish Blocker)

The Dataverse API `PATCH` on `botcomponent.data` updates the authoring YAML. The `content` field is the runtime/compiled YAML that publishing reads from, but `data` to `content` sync happens on publish IF the YAML is valid.

**When PATCH works:** If both `data` and `content` are structurally valid, PATCHing `data` and publishing succeeds.

**When PATCH fails:** If `content` already has broken YAML from a prior bad edit, the publish reads from the broken `content` and fails with `MissingRequiredProperty` even though `data` is valid.

**New-experience agents (created in the new Copilot Studio):** All topics have `content: null` by default. The publish compiler reads from `data` directly, not from `content`. PATCHing `data` is sufficient. However, if `data` itself has structural issues, the publish still fails.

**PITFALL -- instructions `conversationStarters` Title/Text casing blocks publish.** The publish compiler for instructions (componenttype 15) validates `conversationStarters` items and requires `Title:` and `Text:` (capitalized). Many agents use lowercase `title:` and `text:` which works for the first publish (pac CLI bypasses validation) but fails on subsequent publishes with `MissingRequiredProperty: Title`. Fix: capitalize to `Title:` and `Text:` in the conversationStarters block.

**PITFALL -- SPA Publish button stays disabled after Dataverse API PATCH.** Modifying via API bypasses the SPA's React dirty state. Workarounds: (a) force-click via `pubBtn.disabled = false; pubBtn.click()` in the browser console; (b) make a trivial UI change to trigger dirty state; (c) use `pac copilot publish --bot <id>` if not caching a failure.

**PITFALL -- pac CLI caches publish failures permanently.** After a publish fails, `pac copilot publish` returns the same `Failed [timestamp]` on every retry. Fix: (a) `pac auth clear` and re-authenticate; (b) use the SPA UI; (c) verify with Dataverse `GET /bots({id})?$select=publishedon`.

**Fix for broken content:** Edit the topic in Copilot Studio UI -> More -> Open code editor -> fix the YAML -> Save. No API path to patch `content` directly.

**Detection:** After patching `data`, attempt `pac copilot publish`. If it succeeds, the sync worked. If it fails, check `synchronizationstatus` on the bot for error details.

## `SearchAndSummarizeContent` Without `SendActivity` Causes `unsupportedactivity.notextresponse`

When a topic has `SearchAndSummarizeContent` with `variable: Topic.Answer` but no `SendActivity` node to output it, the eval framework sees no text response and returns `unsupportedactivity.notextresponse`. This is the #1 cause of execution errors in SR evals.

**Pattern to check:** Every topic with `SearchAndSummarizeContent` must have a `SendActivity` node before `EndDialog`. If `activity: =Topic.Answer` causes the live/eval response to literally output `=Topic.Answer`, switch to interpolation form `activity: "{Topic.Answer}"`. The `EndDialog` must also have `clearTopicQueue: true`. For deterministic guardrails or static answer text, add `autoSend: false` to SearchAndSummarizeContent so the generative node does not auto-send a second/last answer that the grader scores instead.

**Wrong:**
```yaml
- kind: SearchAndSummarizeContent
  variable: Topic.Answer
  userInput: =System.Activity.Text
- kind: EndDialog
  clearTopicQueue: true
```

**Correct:**
```yaml
- kind: SearchAndSummarizeContent
  variable: Topic.Answer
  userInput: =System.Activity.Text
- kind: SendActivity
  activity: =Topic.Answer
- kind: EndDialog
  clearTopicQueue: true
```

With authenticated knowledge. See `references/dataverse-batch-patch-topics.md` for the full Dataverse API workflow (fetch topics, PATCH YAML, publish, sync local).

### Fast Path (recommended)
1. Run eval once
2. Fix ALL failures in one batch
3. Re-run eval once
4. If still failing, iterate on remaining failures

### Comprehensive Path
1. Run eval
2. Fix highest-impact failure only
3. Re-run eval (check for regressions)
4. Repeat

### Parallel Multi-Agent Regression Fix (validated Jul 2 2026)

When multiple agents regress simultaneously, do NOT fix them sequentially while waiting for eval runs. Use background subagents via `delegate_task` to work all agents in parallel.

**Pattern:**
1. Run baselines for ALL agents first (parallel subagents)
2. Identify root cause patterns across agents — missing RESPONSE FORMAT, 800-char limits, SearchSpecificKnowledgeSources, etc.
3. Fix the root cause per agent (parallel subagents)
4. Each subagent handles its own agent's full loop: poll evals → analyze → fix → publish → re-eval → iterate
5. Report high-level status per agent, not detailed per-subagent logs

**Why it works:** Eval quota is PER AGENT (`fairusagepolicy.botactiverunquotaviolated`), not global. Running agents in different `delegate_task` subagents keeps their eval queues independent.

**Why you should NOT wait idle:** 100-case SR evals take 10-20 minutes. Use that time to audit other agents, fix topics, or run agent CT+Conv evals.

**Status reporting pattern (per user preference):**
```
OT → SR eval: 52/100 (73%), still running
PT → Audit: 90%, needs topic patches
SLP → Diagnostics still running
```

## Multi-Agent Regression Diagnosis (Therapy Fleet)

When OT/PT/SLP/TDA all regress simultaneously, check these ROOT CAUSES in order (validated Jul 2 2026):

1. **Missing/truncated RESPONSE FORMAT in GPT instructions** — "For single-response questions: always use RESPONSE FORMAT above" with no format defined. The fix: replace with conditional format (structured for audits, natural for general Qs). See "Conditional RESPONSE FORMAT" pattern above.
2. **Topic-level additionalInstructions override main instructions** — Even when GPT instructions say "do X", the 8 individual audit topics may have their own additionalInstructions that don't include the critical directive (e.g., "if no document text, give scored audit anyway").
3. **800-char limits in topic or agent instructions** — Replace with "Be concise but complete."
4. **SearchSpecificKnowledgeSources blocks** — Even after removing SearchSpecificFiles, check for remaining `knowledgeSources: SearchSpecificKnowledgeSources` in audit topics.
5. **Missing EndDialog/clearTopicQueue** — Every leaf topic needs both.

## Breaking Past Eval Ceilings

When agent-side fixes (guardrails, topic routing, knowledge) plateau and remaining failures are structural (test asks something the agent can't do), the fix is **test set modification**, not more YAML changes.

### Diagnosis
Fetch full details from the `/details` endpoint and count failures by pattern:
- **abstention: Yes** = agent can't fulfill the request (usually "check my document" without document access)
- **completeness: No** = response exists but grader finds it insufficient
- **relevance: No** = agent answered the wrong question

If 10+ failures are `abstention: Yes` on "Can you check/review/audit my [document]?" questions, the test set is unanswerable as-is.

### Fix: Reword + Add Document Topic
1. **Reword unanswerable questions** to knowledge-based equivalents:
   - `"Can you check if my OT note includes assist levels?"` → `"What assist levels should be documented in an OT daily note?"`
   - `"Can you audit my OT note for ICD-10-CM codes?"` → `"What ICD-10-CM codes are commonly used in OT documentation?"`
   - Rule: if the question starts with "Can you check/review/audit/analyze my..." it needs rewording
2. **Add a Document Audit topic** so users can still get their documents checked at runtime:
   - Pattern: `OnRecognizedIntent` with triggerQueries like "audit my OT note", "check my OT documentation"
   - Flow: `Question` (paste note) → `AnswerQuestionWithAI` (compliance checklist) → `SendActivity(=Topic.Answer)` → `EndDialog`
   - See template: `templates/document-audit-topic.topic.mcs.yml`
3. **Import modified test set as CSV** through Copilot Studio UI:
   - Gateway REST API does NOT support test set creation/modification
   - Export existing set via "template" link, modify the CSV, re-import as new test set
   - CSV format: comment headers with `#`, header `"question","expectedResponse"`, rows `"text",""` (all quoted, Windows line endings)

### Score Trajectory (therapy agents, measured this session)
```
Agent changes only (no test set change):
  Guardrail v1 (static superanswer):        85% ← ceiling
  Guardrail v2 (longer answer):             78% (regression)
  No guardrail (SearchAndSummarize only):    34% (catastrophic)
  No guardrail + SendActivity fix:           78% (still bad)
  Comprehensive rebuild (MS Learn):          95% avg ← validated Jul 1 2026
Conclusion: comprehensive rebuild with clean YAML + SendActivity + first-sentence rule is the winning approach
```

## Comprehensive Rebuild Pattern (validated Jul 1 2026)

When incremental fixes plateau, rebuild ALL topics in one pass:
1. Query all topics via Dataverse API (see `references/dataverse-batch-patch-topics.md`)
2. Identify broken YAML (parse with yaml.safe_load) and missing SendActivity
3. Build fresh YAML for each topic with correct structure
4. PATCH all topics in one script
5. Publish via pac CLI
6. Verify publish succeeded (check synchronizationstatus)
7. Run eval

**Result:** OT improved from 90% → 96% with 0 execution errors. 12 topics patched (7 broken YAML + 5 missing SendActivity).
Test set rewording (the real lever):
  OT:   81% → 89% (+10% with 15 rewordings, +10% with 20 rewordings)
  PT:   99% (3 rewordings → expected 100%)
  SLP:  95% (5 rewordings → expected 100%)
  TDA:  98% (8 rewordings → expected 100%)
Pattern: "Can you check/review/audit my X?" → "What Y should be in an X?"

Trigger query expansion (DOES NOT WORK — June 2026 confirmed):
  5→32 trigger queries:  73/100 agentresponsetoolong (27% usable)
  5→12 trigger queries:  44/100 agentresponsetoolong (56% usable)
  5→8 trigger queries:   58/100 agentresponsetoolong (42% usable)
  Even with "Answer in 2-3 sentences max": still 50%+ too long
Conclusion: expanding trigger queries is fundamentally broken — use test set rewording

Systemic "Can you check/review" pattern (June 2026):
  ALL therapy agents (OT, PT, SLP, TDA) have these questions in their test sets.
  Agent cannot access user documents → grader marks as incomplete or should-refuse.
  PT Conv dropped from 100% to 94% from this pattern.
  Fix: reword ALL "Can you check/review" questions across all agent test sets.

Current scores (Jul 1 2026 latest):
  OT:  SR=96% ✓  Conv=94% ✓  (2-run avg 95%, 0 exec errors) — comprehensive rebuild complete
  PT:  SR=99% ✓             Conv=100% ✓
  SLP: SR=98% ✓             Conv=100% ✓
  TDA: SR=98% ✓             Conv=100% ✓
```

## Workflow Rules (User Preferences)

1. **Additive-only changes.** Never remove capabilities, features, topics, or content from an agent unless the user explicitly approves. When the fix requires removing something (e.g., a broken guardrail), propose it with the rationale and wait for confirmation. Prefer adding a parallel text-input path alongside existing upload paths rather than removing the upload requirement.

2. **Verify after every change.** After applying any PATCH or publish:
   - Re-read the `data` field via Dataverse GET to confirm the fix landed
   - Check the bot's `modifiedon` timestamp or `synchronizationstatus`
   - Confirm no regressions in previously-passing tests before declaring done

## Stop Conditions

- All eval tests pass
- 3 consecutive runs with no improvement
- User intervention (stop command)
- Fix requires UI-only changes (content field, not data field)
- Fix requires connector authentication setup
- Remaining failures are all structural (unanswerable test questions) → switch to test set modification

## Run 3 Evals for Stable Measurement (MS Learn)

MS Learn recommends running evaluation 3 times and averaging to account for ±5% LLM grader variance. A single run can be misleading:

```
Run 1: 96/100 = 96%  (lucky pass on borderline cases)
Run 2: 94/100 = 94%  (different failures on borderline cases)
Average: 95% ← this is the real score
```

- If variance between runs is >10%, investigate grader reliability before diagnosing agent problems.
- For 20-case test sets, 1 case = 5%. For 100-case sets, 1 case = 1%.
- Report the average across 3 runs, not any single run.
- If quota blocks 3 runs (20 per 24h), report the 2-run average and note the sample size.

## Gateway REST API Eval Scripts (Working, Validated Jul 2026)

Reusable Node.js scripts that use the manage-agent MSAL cache for auth — no browser needed. All at `D:/my agents copilot studio/pipeline/scripts/`:

| Script | Usage | Purpose |
|--------|-------|---------|
| `check_run.cjs <agent>` | `echo "" \| node check_run.cjs OT` | List recent eval runs with scores |
| `start_agent_eval.cjs <agent> [tsId]` | `echo "" \| node start_agent_eval.cjs OT 2834...` | Launch eval via gateway API |
| `analyze_failures.cjs` | `echo "" \| node analyze_failures.cjs` | Breakdown failure patterns from details |
| `check_details.cjs <runId>` | `echo "" \| node check_details.cjs <runId>` | Real-time eval progress |

All scripts use `echo "" |` prefix for MSYS/Git Bash stdin compatibility. MSAL cache path: `~/.copilot-studio-cli/manage-agent.cache.json`.

## Test Set Score Variance (Validated Jul 2026)

**Same agent, same publish state, different test sets can produce 25+ point deltas.** OT scored 90% on `51c01c3c` but 64% on `2834097c` (OT_SR_V2_REWORD). PT scored 98% on `4fe3bc0f` but 88% on `471261a6`. Always record test set ID with every eval run. When diagnosing regressions, first check if the test set changed. Do NOT compare scores across different test sets.

## Instruction Patterns That Break Therapy Agents

Six distinct instruction patterns cause systematic eval failures, validated across OT, PT, SLP, TDA in Ensign default:

1. **Missing/Phantom RESPONSE FORMAT** — Instructions say "always use FORMAT above" but no format defined. Agent has no output structure → completeness failures.
2. **Micro-Checklist Instructions (>8K chars)** — Per-note field lists, "banned openings," scoring calibration. Forces checklist-short answers.
3. **"Ask for document" instructions** — Causes zero-response `ExecutionFailed` errors in Conv evals when test cases don't provide document text. Fix: "when no document text, give conditional determination with verification elements. Do NOT ask."
4. **"First sentence must directly answer"** — Topic-level additionalInstructions truncate every response to one sentence.
5. **SOURCE RESTRICTION with "use ONLY these sources"** — When instructions say "Use ONLY the following knowledge sources" and list 10-14 specific sources, the agent refuses (abstention: Yes) on any test question that strays outside those sources. Even with EVAL NO-CAVEAT added, a hard source restriction causes ~24/100 abstention failures. Fix: change to "Use as primary reference. For general compliance questions or evaluation prompts where the named sources do not directly address the topic, you may use model knowledge to provide a general compliance framework. Always lead with source-grounded answers when possible." Also add an explicit "DO NOT REFUSE" directive that overrides the source restriction during eval.
5. **SOURCE RESTRICTION with "use ONLY these sources"** — When instructions say "Use ONLY the following knowledge sources" and list 10-14 specific sources, the agent refuses (abstention: Yes) on any test question that strays outside those sources. Even with EVAL NO-CAVEAT added, a hard source restriction causes ~24/100 abstention failures. Fix: change to "Use as primary reference. For general compliance questions or evaluation prompts where the named sources do not directly address the topic, you may use model knowledge to provide a general compliance framework. Always lead with source-grounded answers when possible." Also add an explicit "DO NOT REFUSE" directive that overrides the source restriction during eval.

GPT instructions (componenttype 15) are patchable via `botcomponent.data` with HTTP 204:
```bash
TOKEN=$(az account get-access-token --resource "https://org3353a370.crm.dynamics.com" --query accessToken -o tsv)
# PATCH via Node.js script using https.request
pac copilot publish --bot "<botId>"  # After patching
```

## Known Bot IDs (Ensign Default)

| Agent | Bot ID | Instructions Component |
|-------|--------|----------------------|
| OT_Specialist | `73b45e98-af7a-443a-aa12-6d8a05118530` | `28c4402c-2a2b-45d7-888d-e3ef81b2f401` |
| PT_Specialist | `593407f3-539b-490f-84ac-d74e13216c81` | (query at runtime) |
| SLP_Specialist | `6e437a77-a5dc-4984-90eb-4924eab10006` | `9a5e1289-baf3-44be-bb76-ce9d410c91dc` |
| Therapy Documentation Audit Agent | `4d0ed0d3-30f6-f011-8406-000d3a37eba2` | `ff00b80a-321b-44be-80a4-40c78072ffe3` |

Only after eval passes:
1. Pull (always before push)
2. Push
3. Ask user to confirm publish
4. Publish
5. Run point-test to verify live behavior

## Pipeline Scripts (reusable eval tools)

All at `D:/my agents copilot studio/pipeline/scripts/`. Run with `echo "" | node <script>` for MSYS compatibility.

| Script | Purpose |
|--------|---------|
| `eval_all_agent_scores.cjs` | Get latest score for all 4 therapy agents (OT/PT/SLP/TDA) in one call |
| `start_agent_eval.cjs` | Launch SR or Conv eval for a specific agent+testset |
| `poll_agent_eval.cjs` | Poll eval runId until completion, then show failure details |
| `check_run.cjs` | List recent runs and scores for an agent |
| `check_details.cjs` | Quick progress check on a run (evaluated/pending/passed) |
| `analyze_failures.cjs` | Categorize failures by pattern (relevance/completeness/abstention) |
| `list_testsets.cjs` | List all test set IDs for an agent with type+count |
| `list_ts_ids.cjs` | Compact test set listing (ID + type + cases) |
| `hermes_ot_eval_runner.cjs` | Full auth chain + list/start/poll/details for one agent |
| `ot_agent_audit.cjs` | Query Dataverse for instructions + topic list + count |

All use manage-agent MSAL cache for auth. Token auto-renews via `acquireTokenSilent`.

Track across iterations:
- Total tests / Passed / Failed / Error
- Per-metric pass rates
- Number of YAML changes per iteration
- Time per iteration

Report progress: "Iteration 3: 8/10 passed (was 6/10). Fixed: topic routing for billing, added knowledge source for product catalog. 2 remaining failures need connector action setup."

## End-of-session cleanup and ad-hoc verification

After eval/API/browser automation sessions, do an explicit cleanup pass before reporting done:
- Kill leftover Node eval/automation processes and `node_repl.exe` processes.
- Close Chrome CDP on `127.0.0.1:9223` when no more browser/auth/API work is needed.
- Re-check after a short delay; Windows may briefly show stale listeners immediately after `taskkill`.
- If changed files do not have a canonical test/lint/build command, create a temporary `hermes-verify-*` script under `%LOCALAPPDATA%\\Temp`, run focused checks, then delete it.
- Report this as **ad-hoc verification, not suite green**.

See `references/session-cleanup-and-ad-hoc-verification.md` for the exact cleanup commands, verifier shape, and Dataverse/CDP origin workaround.

For therapy-agent OT/PT/SLP/TDA evals with "Can you check/review/audit my note..." failures, use `references/therapy-agent-testset-rewording-workflow.md`: freeze live YAML, reword structural test prompts into answerable knowledge questions, verify CSVs for remaining document-check wording, then import V2 test sets.

For fleet-wide anti-patterns discovered across multiple agents (the "First sentence must directly answer" completeness killer, missing RESPONSE FORMAT, parallel subagent debug patterns), see `references/fleet-patterns.md`.

## Working Gateway REST API (preferred over eval-api.bundle.js)

The `eval-api.bundle.js` requires `@azure/msal-node-extensions` which is often missing. Use the gateway REST API directly — it works with headers from `eval_auth_capture.json`.

### Auth: Manage-Agent MSAL Cache (no browser needed, preferred)

Instead of the `eval_auth_capture.json` browser-capture flow, use the **manage-agent MSAL token cache** — it lives at `~/.copilot-studio-cli/manage-agent.cache.json` and is populated by the VS Code Copilot Studio extension's `manage-agent.bundle.js`. Tokens are acquired silently via `@azure/msal-node` + `@azure/msal-node-extensions`.

**Full auth + launch pattern (script at `D:/my agents copilot studio/pipeline/scripts/hermes_ot_eval_runner.cjs`)**:

```javascript
const { PublicClientApplication } = require('@azure/msal-node');
const { PersistenceCreator, PersistenceCachePlugin, DataProtectionScope } = require('@azure/msal-node-extensions');

const TENANT='03cc92c3-986c-4cf4-ae27-1478cf99d17f';
const CLIENT='51f81489-12ee-4a9e-aaae-a2591f45987d';  // Power Platform CLI client ID
const ENV='a944fdf0-0d2e-e14d-8a73-0f5ffae23315';  // Raw env GUID, NOT Default-{tenant} prefix
const GW='https://powervamg.us-il106.gateway.prod.island.powerapps.com';
const CACHE=path.join(os.homedir(),'.copilot-studio-cli','manage-agent.cache.json');

async function getToken(){
  const p=await PersistenceCreator.createPersistence({cachePath:CACHE,
    dataProtectionScope:DataProtectionScope.CurrentUser,
    serviceName:'copilot-studio-cli',accountName:'manage-agent',usePlaintextFileOnLinux:true});
  const app=new PublicClientApplication({auth:{clientId:CLIENT,
    authority:`https://login.microsoftonline.com/${TENANT}`},
    cache:{cachePlugin:new PersistenceCachePlugin(p)}});
  const accs=(await app.getTokenCache().getAllAccounts()).filter(a=>a.tenantId===TENANT);
  const r=await app.acquireTokenSilent({scopes:['api://96ff4394-9197-43aa-b393-6a41652e21f8/.default'],account:accs[0]});
  return r.accessToken;
}
```

Run scripts with `echo "" | node script.cjs` prefix in git-bash/MSYS to avoid "stdin is not a tty" errors from MSAL.

Also requires the `eval_auth_capture.json` for `x-cci-*` header values (capture once, reuse). The bearer token from MSAL goes in `authorization` header; the `x-cci-*` headers come from `eval_auth_capture.json`.

### Launch Eval

```javascript
const cap = JSON.parse(fs.readFileSync('eval_auth_capture.json','utf8'));
const base = cap.sample[0].headers;
const gateway = 'https://powervamg.us-il106.gateway.prod.island.powerapps.com';
const envId = 'Default-03cc92c3-986c-4cf4-ae27-1478cf99d17f';
const botId = '<bot-id>';

function headers() {
  const h = {};
  for (const k of ['authorization','x-ms-user-agent','x-cci-applicationsource','accept',
    'x-ms-client-session-id','x-cci-tenantid','x-cci-bapenvironmentid',
    'x-cci-organizationid','referer']) h[k] = base[k];
  h['x-cci-cdsbotid'] = botId;
  h['x-cci-botid'] = botId;
  h['x-ms-client-request-id'] = crypto.randomUUID();
  h['content-type'] = 'application/json';
  h.accept = 'application/json';
  return h;
}

// Launch
const url = `${gateway}/api/botmanagement/v2/environments/${envId}/bots/${botId}/makerevaluations`;
const body = {
  testSetId: '<test-set-id>',
  clientRequestedEvaluationRunName: `Evaluate <label> ${timestamp}`
};
const resp = await fetch(url, { method:'POST', headers:headers(), body:JSON.stringify(body) });
// Returns: { runId, state: "Queued" }
```

### Poll for Completion

```javascript
// GET returns array of recent runs with aggregatedGraderResults
const url = `${gateway}/api/botmanagement/v2/environments/${envId}/bots/${botId}/makerevaluations?count=5`;
const data = await fetch(url, { headers: headers() }).then(r => r.json());
const runs = Array.isArray(data) ? data : data.value || [];
const run = runs.find(r => r.id === runId);

// Score extraction from aggregatedGraderResults:
const agr = run.aggregatedGraderResults || [];
const succeeded = agr.find(a => a.name === 'totalSucceeded')?.count || 0;
const failed = agr.find(a => a.name === 'totalFailed')?.count || 0;
const errors = agr.find(a => a.name === 'totalErrors')?.count || 0;
const score = Math.round(succeeded / (succeeded + failed) * 100);
```

### Get Full Test Case Details

```javascript
// Details endpoint returns per-case grader metrics
const url = `${gateway}/api/botmanagement/v2/environments/${envId}/bots/${botId}/makerevaluations/${runId}/details`;
const detail = await fetch(url, { headers: headers() }).then(r => r.json());
const cases = detail.details?.testCases || [];

// Per-case scoring:
// SR eval: queries[0] has graderMetrics directly.
// CONV eval: queries[] has one entry per turn, each with its own metrics.
for (const c of cases) {
  const queries = c.queries || [];
  for (const q of queries) {
    const qrm = q.metrics?.queryResponseMetrics || [];
    for (const m of qrm) {
      if (m.metricType === 'ResponseQualityGeneral') {
        const p = m.properties || {};
        // PASS condition: relevance=Yes AND completeness=Yes AND abstention=No
        const passed = p.relevance === 'Yes' && p.completeness === 'Yes' && p.abstention === 'No';
      }
    }
  }
}
```

### Conv Eval Per-Case Analysis (Validated Jul 2026)

When analyzing Conv eval failures, iterate over the `queries[]` nested structure, not `graderMetrics` on the case directly. Each query has:
- `query` (string) — the user's utterance
- `answer` (string) — the agent's response text  
- `executionState` — "Evaluated", "ExecutionFailed", "TimedOut"
- `metrics.queryResponseMetrics[].properties` — `{relevance, completeness, abstention}`

Common Conv failure patterns:

**Pattern A — Document Upload Intake ClosedListEntity loop.** The intake asks "What type of therapy document?" and the user responds with free text (e.g., "treatment encounter note for speech therapy"). The ClosedListEntity items (exact strings like "Treatment Encounter Note") don't match free-text responses. The intake re-asks indefinitely because `Topic.DocumentTypeSelection` remains blank → the routing conditions never fire → elseActions loop back. **Fix:** additive text-input path that catches free-text responses and feeds them to SearchAndSummarizeContent.

**Pattern B — File upload gate loop (FilePrebuiltEntity).** A Question node with `entity: FilePrebuiltEntity` never completes without a file attachment. The entity extraction fails on text input → Copilot Studio re-prompts indefinitely. Any ConditionGroup after the Question never fires. The agent returns the EXACT question text for 2+ consecutive turns. **Fix:** change entity to `StringPrebuiltEntity` (accepts text AND files). See `copilot-studio-yaml-reference` skill's Power Fx on FilePrebuiltEntity Blobs section.

**Detection:** If the agent's response on turn 2+ is literally the question prompt (e.g., "Please upload the X document"), the Question has FilePrebuiltEntity and the fix is entity-level, not ConditionGroup-level.

**PITFALL — Removing `entity:` entirely causes `MissingRequiredProperty: Entity` on publish.** A Question node requires an entity. Changing `FilePrebuiltEntity` to `StringPrebuiltEntity` is correct — removing the `entity:` line entirely causes the publish compiler to reject all modified topics. The error lives in `synchronizationstatus.diagnosticDetails` as `errorCode: MissingRequiredProperty, propertyName: Entity`. Fix: always set an entity type; never delete the entity line.

**PITFALL — Binding `First(System.Activity.Attachments)` directly to AI Builder input causes `IncorrectTypeAssignment` on publish.** The attachment is a Record, but AI Builder expects a File type. Use `First(System.Activity.Attachments).Content` to extract the File-typed blob from the attachment Record. Do NOT use a SetVariable to bridge the types — assigning a Record to a String-typed Topic variable produces the same IncorrectTypeError.

### Medicare Part B Compliance Reviewer — Conv Eval Root Cause (Jul 10 2026)

Bot ID: `b0346795-4876-f111-ab0e-70a8a5b1b8cc`
Conv test set: `21b54c2b-a977-4b8a-a70c-168746d07464` (20 cases)
Baseline: 25% (5/20) — actually 0/20 by strict grader metrics (completeness always blank)

**Root cause:** All 6 doc review topics use `FilePrebuiltEntity` on their upload Question. The Conv test set describes documents in text (no file uploads) → every topic gets stuck at the Question node. The agent's response is literally the question text repeated, which the grader marks as incomplete/irrelevant.

**Fix applied (awaiting user publish):**
1. Changed all 6 doc topic Questions from `FilePrebuiltEntity` to `StringPrebuiltEntity`
2. Updated file check condition to `!IsBlank(First(System.Activity.Attachments))`
3. Updated AI Builder bindings from `=Topic.<var>` to `=First(System.Activity.Attachments).Content` — `.Content` required to extract the File-typed blob from the attachment Record; without it publish fails with `IncorrectTypeAssignment`
4. Added text-paste else branch (SearchAndSummarizeContent → SendActivity → EndDialog)
5. Added `EndDialog(clearTopicQueue: true)` to ConversationStart topic

### Known Agent Bot IDs — Ensign Services (default)

Environment: `Default-03cc92c3-986c-4cf4-ae27-1478cf99d17f`  
Org: `https://org3353a370.crm.dynamics.com`  
Tenant: `03cc92c3-986c-4cf4-ae27-1478cf99d17f`  
Gateway: `https://powervamg.us-il106.gateway.prod.island.powerapps.com`  
Pac auth index: `pac auth select --index 1`

| Agent | Bot ID | SR Test Set | Conv Test Set |
|-------|--------|-------------|---------------|
| OT | `73b45e98-af7a-443a-aa12-6d8a05118530` | `2834097c-26e6-4727-ac73-c54340eaa097` ("OT_SR_V2_REWORD", 100 cas) | `a3f12152-a026-4eb3-934c-cab484d7be98` ("OT_Conv_Grounded_v2", 10 cas) |
| PT | `593407f3-539b-490f-84ac-d74e13216c81` | `471261a6-f6d8-4b5a-b27f-334cf5ecf414` (100 cas) | TBD — check runs list |
| SLP | `6e437a77-a5dc-4984-90eb-4924eab10006` | TBD — check runs list | TBD — check runs list |
| TDA | `4d0ed0d3-30f6-f011-8406-000d3a37eba2` | `4e8a0991-27a0-4aa4-9649-f8ecd3bb2c11` (100 cas) | `066a2908-2aa6-4bdd-aeed-fb5529d26c4c` ("TDA_Conv_Grounded_v2", 10 cas) |
| Therapy Doc Feedback B | `1c601ace-5255-f111-bec6-000d3a37eba2` | (Therapy AI Agents Prod) | |
| Medicare Part B Compliance Reviewer | `b0346795-4876-f111-ab0e-70a8a5b1b8cc` | N/A | `21b54c2b-a977-4b8a-a70c-168746d07464` (20 cas) |

Components: OT has 12 active topics, PT has ~17 topics, SLP has ~15 topics. All use GPT model Sonnet46.

## FilePrebuiltEntity Question Blocks Conv Evals (Critical — Validated Jul 10 2026)

**Problem:** A Question node using `entity: FilePrebuiltEntity` NEVER passes control to subsequent nodes when the user responds with text instead of a file. The FilePrebuiltEntity entity keeps re-prompting indefinitely because no file blob is provided. The `ConditionGroup` or `elseActions` after the Question node **never fire** — the execution is stuck at the Question.

This is the root cause of Conv eval failures when the test set describes documents in text but cannot upload actual files. On the Medicare Part B Compliance Reviewer, **20/20 Conv cases failed** from this pattern despite adding a text-input ConditionGroup in the elseActions — because the elseActions never executed.

**Why it fails at the platform level:**
1. Question node with `entity: FilePrebuiltEntity` is created
2. User responds with text (no file attachment)
3. The entity extraction fails (no file to extract from)
4. Copilot Studio re-prompts the Question because the required entity is not filled
5. The ConditionGroup (checking `!IsBlank(Topic.Var)`) and any elseActions are **never reached**
6. The Conv grader sees the same re-prompted question text as the agent's "answer" → marked incomplete/irrelevant

**Fix (requires user approval — changes entity type):**
Replace `entity: FilePrebuiltEntity` with `entity: StringPrebuiltEntity` on the upload Question. This allows both text pasting AND file uploads. The AI Builder model handles file refs natively — it doesn't require FilePrebuiltEntity.

```yaml
# BEFORE — never completes without file
- kind: Question
  variable: init:Topic.discharge_summary_doc
  prompt: Please upload the Discharge Summary document...
  entity: FilePrebuiltEntity

# AFTER — accepts text OR file
- kind: Question
  variable: init:Topic.discharge_text_or_file
  prompt: Please upload or paste the Discharge Summary document...
  entity: StringPrebuiltEntity
```

**Detection during eval analysis:**
When you see the agent returning the SAME question text (e.g., "Please upload the X document") for multiple conversation turns, check if the Question uses `FilePrebuiltEntity`. The agent isn't "looping" — it's stuck at an unfulfillable entity requirement.

## Additive-Only Fix Pattern for Doc Topics (Validated Jul 10 2026)

When a doc topic requires file uploads but the Conv eval can't upload files, the additive approach is:

1. **Keep the file upload path intact** — do NOT remove or replace the existing Question/entity
2. **Add a text-input path AFTER the Question** — but this only works if the Question can complete without a file. Currently impossible with FilePrebuiltEntity.

The actual fix needs to happen at the Question level or the test set level. Two options:

| Option | Impact | User Approval Needed |
|--------|--------|---------------------|
| Change entity to StringPrebuiltEntity | Accepts text AND files. AI Builder handles file refs natively. | Yes — changes entity behavior |
| Reword Conv test set to not require file uploads | Test set uses knowledge questions instead of document-check prompts | Yes — changes eval scope |

## Pitfalls

- **Gateway API environment ID format: use raw GUID, not `Default-{tenant}` prefix.** The `makerevaluations` endpoint returns 4100 ObjectNotFound when called with `Default-{tenantID}` format. Use the raw environment GUID (e.g., `a944fdf0-0d2e-e14d-8a73-0f5ffae23315`) in the URL path. The `Default-` prefix format is used by some PAC CLI profiles but NOT by the gateway eval API. Validated Jul 10 2026.

- **Gateway API environment ID format: use raw GUID, not `Default-{tenant}` prefix.** The `makerevaluations` endpoint returns 4100 ObjectNotFound when called with `Default-03cc92c3-...` format. Use the raw environment GUID (e.g. `a944fdf0-0d2e-e14d-8a73-0f5ffae23315`) in the URL path: `${gateway}/api/botmanagement/v2/environments/${rawEnvGuid}/bots/${botId}/makerevaluations`. The `Default-` prefix format is used by some PAC CLI profiles but NOT by the gateway eval API. Validated Jul 10 2026 on Medicare Part B Compliance Reviewer.

- **MSAL cache corruption recovery:** If `manage-agent.cache.json` is deleted/corrupted, DO NOT write browser localStorage data into the cache (DPAPI contexts are incompatible). Recover by capturing tokens from browser CDP network traffic. See `copilot-studio-development-workflow/references/token-recovery-and-msal-cache.md`.\n- **Score calibration mismatch causes eval regression.** When Risk Match passes but Score Match fails, the agent's numeric scoring rubric doesn't match test expectations. See `references/score-calibration-mismatch.md` for common failures (recert scored too low, bad notes floored too low, excellent notes not capped at 95) with rubric and debugging steps.
- **eval-api.bundle.js needs `@azure/msal-node-extensions`** — often missing. Use the gateway REST API pattern above instead.
- **Auth tokens expire fast (~1 hour)** — if poll returns 403 "Unable to validate token", re-run `capture_eval_auth.cjs` from a browser session on the Copilot Studio Evaluation page. **Alternative (no interactive browser needed):** if Chrome CDP is running on port 9223, connect via Playwright, navigate to the Copilot Studio bot page (`https://copilotstudio.microsoft.com/environments/<envId>/bots/<botId>/build`), wait 10s for API calls to fire, then capture Bearer tokens from `page.on('request')` events that include `authorization` headers. Save to `eval_auth_capture.json` `sample[0].headers`. This avoids the interactive `capture_eval_auth.cjs` flow.
- **Dataverse API needs a different token scope than PPAPI.** The PPAPI token (captured via CDP) works for `api.powerplatform.com` but NOT for `{org}.crm.dynamics.com/api/data/v9.2/` (returns 401). Use `az account get-access-token --resource "https://{org}.crm.dynamics.com"` to get a Dataverse token. This token is needed for reading/writing botcomponent YAML (data field), querying component lists, and PATCHing topics.
- **`node -e` scripts fail in background mode** on Windows ("stdin is not a tty"). Write scripts to `.cjs` files and run with `node scripts/foo.cjs` instead.
- Don't fix the same failure twice — if a fix didn't work, try a different approach
- Don't introduce regressions — after fixing, check that previously passing tests still pass
- Don't over-engineer — simple fixes first (trigger phrases, modelDescription) before complex ones (new topics, child agents)
- Don't modify system topics — they're off-limits
- Don't edit content field via API — only data field is writable
- Pull before every push — stale row versions cause ConcurrencyVersionMismatch
- When using live Copilot Studio gateway APIs, include the Evaluation page's `authorization` and `x-cci-*` headers; cookies alone are not sufficient.
- The active evaluation quota is per agent, not necessarily global. Run different agents in parallel, but keep SR and Conv sequential for each one.
- Parse full result details from `details.testCases[]` and `aggregatedGraderResults`; do not count `abstention: No` / `relevance: Yes` as failures.
- **Static superanswer guardrails hit a ceiling at ~85%.** A literal SendActivity text returned for ALL questions catches generic OT compliance questions well but fails on "Can you check if my [document] includes [X]?" patterns. The grader marks these as incomplete because the agent doesn't directly check the user's document. Longer/more verbose answers make it worse (78%). The fix path is improving topic routing (trigger phrases, modelDescription) so questions reach the right topic instead of falling to the guardrail.
- **`SearchSpecificKnowledgeSources` is a separate restriction from `SearchSpecificFiles` (validated Jul 2026).** Fixing `fileSearchDataSource: SearchSpecificFiles` does NOT fix `knowledgeSources: SearchSpecificKnowledgeSources`. Both blocks must be removed independently. The first restricts which uploaded files are searched; the second restricts which knowledge sources (KB entries) can be used. Even after removing `fileSearchDataSource`, the `knowledgeSources` block silently keeps the agent restricted to N specific KBs. Pattern to check: if a topic has `kind: SearchSpecificKnowledgeSources` under `knowledgeSources:`, remove the entire `knowledgeSources:` block. This was the root cause of persistent 16-24% failure rates on Therapy Documentation Feedback Agent despite SearchSpecificFiles removal — the 8 KB restrictions were still in place.
- **Removing a guardrail SendActivity breaks eval if SearchAndSummarizeContent is the only remaining action.** The search writes to `Topic.Answer` but without an explicit `SendActivity` to send it, the eval framework sees `unsupportedactivity.notextresponse` and marks the case as ExecutionFailed (not a grader fail — an execution error). This caused 60% execution failures when the guardrail was removed from OT topics. Fix: either keep the guardrail, or add `- kind: SendActivity / id: send_topic_answer / activity: =Topic.Answer` after every `SearchAndSummarizeContent` node.
- **YAML action execution order matters for eval scores.** A `SendActivity` as the first action in a topic fires BEFORE `SearchAndSummarizeContent` or `AnswerQuestionWithAI`. The grader evaluates the LAST text response the user sees. If the guardrail fires first and the search also produces output, the user may see both. The guardrail text is what gets graded. This is why a static guardrail on ALL topics produces a single uniform score regardless of the search results.
- **Use line-based string manipulation, not regex, for Copilot Studio YAML editing.** The YAML uses `activity: |` (literal block scalar) not `activity: |-` (strip). Regex patterns like `activity: \\|\\n` fail because the actual content has varying indent levels and the `|` vs `|-` distinction. Instead: split on `\\n`, find the `id: <name>` line, walk backwards to `- kind:` and forwards past the indented content block, then splice. This is what `remove_ot_guardrail.cjs` and `restore_v1_guardrail.cjs` do successfully.
- **Creating new botcomponents via Dataverse API requires specific fields.** The `_parentbotid_value` shorthand fails with "CRM do not support direct update of Entity Reference properties." Use: `{ name, schemaname: 'copilots_header_8c921.topic.TopicName', componenttype: 9, data: yamlContent, 'parentbotid@odata.bind': '/bots('+botId+')' }`. The `schemaname` must follow the pattern `copilots_header_<hex>.topic.<PascalCaseName>`. Status 204 = success. This was discovered when deploying the OT Document Audit topic.
- **Test set modification is NOT available via gateway REST API.** The `evaluationtestsuites` endpoint returns 404. To modify test sets: export from Copilot Studio UI, edit CSV, re-import as new test set.
- **Copilot Studio CSV import format is NOT just a `query` column.** The template (downloadable via the "template" link on the import page) uses: comment lines starting with `#` (wrapped in quotes), header `"question","expectedResponse"`, and each row `"question text","expected response"` (both quoted). The column is `question` not `query`. Windows line endings (`\r\n`) required. Without the comment header block, the upload fails with "Something went wrong while uploading your file."
- **Adding a new topic can cause eval regression if trigger queries overlap with existing catch-all topics.** When a new topic (e.g. Document Audit) has triggerQueries like "check my OT note" that overlap with a guardrail topic's implicit catch-all, the new topic intercepts questions BEFORE the guardrail fires. This dropped OT from 85% to 81%. Fix: ensure new topic triggers are specific enough not to overlap, or remove overlapping triggers from the guardrail topic.
- **Copilot Studio SPA blocks Playwright clicks via dialog backdrops.** After clicking "Configure test set" or similar, a `fui-DialogSurface__backdrop` overlay intercepts all pointer events. Standard `page.click()` times out. Fix: remove overlays via `page.evaluate(()=>{ document.querySelectorAll('.fui-DialogSurface__backdrop, .fui-DialogSurface').forEach(el=>el.remove()); })` before clicking. Also, the "Evaluate" button on the test set review page is DISABLED until "Configure test set" is clicked first — this is a required step even if you don't change any configuration.
- **Poll eval progress via the `/details` endpoint, not the list endpoint.** The list endpoint (`makerevaluations?count=N`) may show stale `aggregatedGraderResults` (all zeros) while the eval is still running. The details endpoint (`makerevaluations/${runId}/details`) returns live per-case progress. Poll details every 30s, count `executionState === 'Evaluated'` cases, and compute pass/fail from `graderMetrics.queryResponseMetrics` until `Created` count reaches 0.
- **Expanded knowledge in SearchAndSummarizeContent additionalInstructions causes response bloat and eval timeouts.** Adding detailed ICD-10-CM codes, frequency/duration documentation requirements, cognitive assessment protocols, etc. to the `additionalInstructions` field made agent responses balloon from ~4000 to 8500+ chars. This caused 20/100 test cases to be skipped (eval timeouts) and actually WORSENED the score (81% vs 85% baseline). The additionalInstructions field should stay concise — it tells the AI how to process search results, not serve as a knowledge base. For domain-specific knowledge, use dedicated knowledge sources (URLs, SharePoint) or the Document Audit topic pattern instead.
- **Expanding triggerQueries causes `testcasevalidation.agentresponsetoolong` — the single most expensive pitfall discovered.** When OT General Knowledge's triggerQueries were expanded from 5→12→32 to catch more questions, 50-73 out of 100 test cases got `agentresponsetoolong` errors. This persisted even with ultra-concise additionalInstructions ("Answer in 2-3 sentences max"). The root cause: questions that previously went to Fallback (which has `variable: Topic.Answer` and "Keep the answer concise") now route to OT General Knowledge, whose SearchAndSummarizeContent produces longer responses. The `variable: Topic.Answer` assignment in Fallback may truncate/format the response differently. **Do NOT expand triggerQueries beyond the original set unless you verify no agentresponsetoolong regressions.** If you need more questions to match a topic, use test set rewording instead.
- **Fallback topic's `variable: Topic.Answer` matters for response length.** The Fallback topic's SearchAndSummarizeContent uses `variable: Topic.Answer` which writes the search result to a variable. Topics like OT General Knowledge that don't use `variable` may produce longer responses because the output isn't captured/truncated. When expanding trigger queries causes questions to move from Fallback to another topic, the response length can increase significantly, triggering `agentresponsetoolong`.
- **Eval quota is per-agent — error `fairusagepolicy.botactiverunquotaviolated`.** Only one eval can run per agent at a time. If you try to launch a second eval while one is InProgress, you get a 422 with this error. Run different agents in parallel, but keep SR and Conv sequential for each one. The eval will appear to timeout but actually launch — check the eval list before retrying.
- **No topic matching causes `unsupportedactivity.notextresponse` in Conv evals.** When a conversation turn doesn't match ANY topic's triggerQueries (not even Fallback), the agent produces no response. This shows as `ExecutionFailed` with error `unsupportedactivity.notextresponse` in Conv eval details. The Fallback (OnUnknownIntent) should catch these, but if the NLU is confused by overlapping triggers, some turns may slip through.
- **Test set rewording is the ONLY proven lever for improving past the guardrail ceiling (~85-89%).** All YAML-side optimizations (guardrail text, additionalInstructions, trigger queries, topic routing) plateau. The pattern that works: reword "Can you check/review/audit my [document] for X?" → "What X is required in [document type] documentation per [standard]?" This converts unanswerable document-check questions (abstention failures) into answerable knowledge questions. Measured improvement: OT 81%→89% with 9 rewordings. This is a SYSTEMIC fix — the same "Can you check/review" pattern causes failures across ALL therapy agents (OT, PT, SLP, TDA).
- **Eval runs take 10-20 minutes for 100-case SR tests.** Do NOT sit idle waiting. Work on other agents, run Conv evals, or audit instructions/topics while the eval progresses. Use `delegate_task` for parallel work.
- **MSYS/git-bash stdin issue with Node.js scripts.** `node -e` and `node script.cjs` fail with "stdin is not a tty" when @azure/msal-node prompts for input. Fix: prepend `echo "" |` to feed an empty line: `echo "" | node script.cjs`.
- **Instructions referencing undefined RESPONSE FORMAT.** If GPT instructions say "For single-response questions: always use RESPONSE FORMAT above" but no RESPONSE FORMAT is defined, the model has no output guidance → completeness failures. Fix: define the format or make it conditional. Validated Jul 2 2026: OT_Specialist had this exact bug — "RESPONSE FORMAT above" referenced but never defined. PATCHed instructions + published, minor improvement (64%→66%) on reworded test set.
- **Topic-level additionalInstructions can silently override GPT-level instructions.** Even when GPT instructions say "If no document text, give a scored audit anyway", each audit topic's `additionalInstructions` field may lack this directive. Always check topic-level instructions, not just the GPT component.
- **Agent instructions edits via Dataverse PATCH** work for `data` field on componenttype 15 (GPT). Use `PATCH /botcomponents({id})` with `{"data": "yaml content"}` and Status 204 = success. No browser needed. Publish via `pac copilot publish --bot {id}` afterward. Validated Jul 2 2026: OT (1.9K chars), SLP (10K→2.9K), TDA (8.3K→2.0K) — all published successfully via pac CLI.
- **Instruction fixes can CAUSE regression on previously-calibrated test sets (validated Jul 2 2026).** OT_Specialist went 90%→53% on same test set after changing GPT + topic instructions. The old instructions were calibrated to that test set. Always snapshot baseline on BOTH current and historical test sets before applying fixes. If a fix regresses a previously-good test set, revert immediately.
- **"Ask for document" instruction causes zero-response execution errors (validated Jul 2 2026).** TDA: "If user asks to audit but no document, ask once" produces question instead of answer → ExecutionFailed. Fix: "when no document text, give conditional determination. Do NOT ask." Delivered 20%→50% (12 errors → 4). Validated Jul 2 2026: OT instructions patched from ~1900→~2900 chars, SLP from 10,056→2,933 chars — both published successfully.

- **Document Upload Intake ClosedListEntity loop in Conv evals (validated Jul 10 2026).** When the intake asks "What type of therapy document?" and the user responds with free text (e.g., "treatment encounter note for speech therapy"), the ClosedListEntity items (exact strings like "Treatment Encounter Note") don't match. The intake re-asks indefinitely because `Topic.DocumentTypeSelection` remains blank → the `conditionGroup_route` conditions never fire → the elseActions loop back. This caused 12/20 Conv failures on Medicare Part B Compliance Reviewer. Fix: additive text-input path after the Question that catches free-text responses and feeds them to SearchAndSummarizeContent.
- **"First sentence must directly answer the exact user question" in topic additionalInstructions kills completeness (validated Jul 2 2026).** When this pattern appears across all topics (OT/PT/SLP), the agent truncates every answer to one sentence — gravely insufficient for the grader. The fix: replace with "Provide thorough, complete information covering all key documentation requirements for the question topic." PATCH via Dataverse API on all topic `data` fields. This pattern was present in ALL 10 OT topics and ALL PT topics, contributing to completeness failures (36/100 on OT).
- **Bloated GPT instructions (8K+ chars) cause regression (validated Jul 2 2026).** SLP_Specialist had 10,056-char instructions with a "MICRO-CHECKLIST EVAL FIX" section that imposed per-note-type field lists and explicit "BANNED OPENINGS" — producing ultra-short checklist answers that the grader scores as incomplete. Same test set went from 98%→68% after instructions bloated. Fix: compress to ~3,000 chars, remove micro-checklists and banned word lists, use conditional RESPONSE FORMAT instead.
- **Agent instructions edits via Dataverse PATCH** work for `data` field on componenttype 15 (GPT). Use `PATCH /botcomponents({id})` with `{"data": "yaml content"}` and Status 204 = success. No browser needed. Publish via `pac copilot publish --bot {id}` afterward. Validated Jul 2 2026: OT (1.9K chars), SLP (10K→2.9K), TDA (8.3K→2.0K) — all published successfully via pac CLI.
- **Instruction fixes can CAUSE regression on previously-calibrated test sets (validated Jul 2 2026).** OT_Specialist went 90%→53% on same test set after changing GPT + topic instructions. The old instructions were calibrated to that test set. Always snapshot baseline on BOTH current and historical test sets before applying fixes. If a fix regresses a previously-good test set, revert immediately.
- **"Ask for document" instruction causes zero-response execution errors (validated Jul 2 2026).** TDA: "If user asks to audit but no document, ask once" produces question instead of answer → ExecutionFailed. Fix: "when no document text, give conditional determination. Do NOT ask." Delivered 20%→50% (12 errors → 4).
