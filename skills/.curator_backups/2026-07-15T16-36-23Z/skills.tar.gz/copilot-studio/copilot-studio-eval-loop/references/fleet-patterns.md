# Fleet-Level Patterns (2026-07-02)

## "First sentence must directly answer" — Fleet-Wide Completeness Killer

**Pattern:** All active topics across OT_Specialist, PT_Specialist, SLP_Specialist have
`additionalInstructions` containing:
```
- First sentence must directly answer the exact user question.
  For yes/no checks, give a conditional determination...
```

**Effect:** The model gives ultra-concise one-sentence answers. The eval grader marks
`completeness: No` on 80-100% of failures. Creates a systemic ceiling around 60-70%.

**Fix:** Batch-replace via Dataverse API across ALL topics:
```
- Provide thorough, complete information covering all key documentation requirements
  for the question topic. For yes/no checks, give a conditional determination...
```

**Batch approach:**
1. Query all active topics: `$filter=_parentbotid_value eq <botId> and componenttype eq 9 and statecode eq 0`
2. For each topic: GET `data`, string-replace the old line, PATCH `data` back (204 = success)
3. `pac copilot publish --bot <botId>`
4. Re-run eval

## Missing RESPONSE FORMAT in GPT Instructions

**Pattern:** GPT instructions (componenttype 15) reference "RESPONSE FORMAT above" but no
format is defined. The model has no output structure guidance.

**Fix:** Add conditional RESPONSE FORMAT — structured for audits, natural for general questions.
PATCH `botcomponent.data` for componenttype 15, then publish.

## Parallel Subagent Debug Pattern

When debugging multiple agents, dispatch one subagent per agent for audit→fix→publish.
Evictions are per-agent quota so they can run simultaneously.

**DON'T** put eval polling in subagents — they time out at 600s on slow evals.
Subagents: diagnostic queries, Dataverse PATCHes, publishing.
Parent: eval launches and high-level polling.

**Scripts (D:/my agents copilot studio/pipeline/scripts/):**
- `check_run.cjs <OT|PT|SLP|TDA>` — recent runs and scores
- `check_details.cjs <runId>` — eval progress
- `start_agent_eval.cjs <OT|PT|SLP|TDA> [testSetId]` — launch eval
- `analyze_failures.cjs` — categorise failures
- `fix_ot_all_topics.cjs` — batch "first sentence" replacement (adapt for other agents)
