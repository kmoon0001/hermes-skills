# Feedback B eval loop failure pattern: restored topics, migrated sets, connector-free multi-turn handling

Session-derived reference for Copilot Studio eval-driven repair loops. Use this when a copied/restored Copilot Studio agent has migrated test sets, draft evals, connector-bound knowledge, and multi-turn routing failures.

## When the live copy has no eval sets

If a copied/provisioned agent has no gateway-visible test sets, check source agent type-19 `botcomponent` rows before creating fake tests. Type-19 contains both runnable `EvaluationSet` rows and child test case rows.

Copying rows is not enough. Gateway-visible case counts require child case rows to be linked to their parent set with:

```json
{
  "ParentBotComponentId@odata.bind": "/botcomponents(<target-evaluation-set-id>)"
}
```

The wrong lower-case property name (`parentbotcomponentid@odata.bind`) fails. If parent links are missing, gateway will show 0-case shells even while Dataverse contains hundreds of test case components.

## Inspect every turn, not only aggregate score

A topic can pass the first turn and still fail the multi-turn case. Always inspect every query in `/makerevaluations/{runId}/details`:

```text
details.testCases[].queries[].query
details.testCases[].queries[].answer
details.testCases[].queries[].metrics.queryResponseMetrics[]
```

Failure signatures:
- `Let's get you connected first...` = connection-backed knowledge/search/action is firing in maker evaluation.
- `FlowNotFound` = topic invokes an action/flow not present in the target environment.
- Generic Greeting (`Hello, I'm ...`) on audit/coaching prompts = Greeting or ConversationStart intercepts in-scope requests.
- `To clarify, did you mean:` = MultipleTopicsMatched or ambiguous triggers are stealing follow-up turns.
- First turn passes but later pasted clinical details fail = topic ended too early; follow-up turns escaped to generated answers / connector-bound knowledge.

## Proven fix path for connector-bound multi-turn evals

Patch the whole routing surface, not just the first specialist topic:

1. Make ConversationStart menu intent-driven, not unconditional `OnConversationStart`, if it steals first eval turns.
2. Add connector-free responses to specialist topics that otherwise rely on `SearchAndSummarizeContent` or flows.
3. Patch Conversational Boosting, Fallback, Greeting, and MultipleTopicsMatched if later turns fall there.
4. For multi-turn tests, do NOT end after the first direct answer. Use `Question -> Question -> SendActivity -> EndDialog` so turn 2/3 pasted notes stay inside the same connector-free topic.
5. Re-run the same small control set before spending quota on 100-case sets.
6. Treat `/details` JSON as the source of truth; aggregate score alone hides which turn caused the case failure.

### Multi-turn direct topic skeleton

Use this for eval-safe connector bypasses when authenticated search/flows break maker evals:

```yaml
kind: AdaptiveDialog
beginDialog:
  kind: OnRecognizedIntent
  id: main
  priority: 1000
  intent:
    displayName: <Topic Name>
    includeInOnSelectIntent: false
    triggerQueries:
      - <exact eval question or high-signal phrase>
      - <short natural phrase>

  actions:
    - kind: Question
      id: q_doc_details
      variable: init:Topic.doc_details
      prompt: |-
        <direct audit answer for turn 1>

        Paste or continue the note details and I will identify the specific denial risks. Clinical review required.
      entity:
        kind: StringPrebuiltEntity

    - kind: Question
      id: q_followup
      variable: init:Topic.followup_details
      prompt: |-
        <direct audit answer for turn 2>

        Based on the details provided, the main denial risks are missing objective measures, weak skilled-need rationale, missing caregiver/safety documentation, and unclear discharge criteria. Send any additional concerns and I will assess them. Clinical review required.
      entity:
        kind: StringPrebuiltEntity

    - kind: SendActivity
      id: send_final_review
      activity: |-
        <direct audit answer for turn 3/final>

        Final audit focus: add numeric measures, connect interventions to functional goals, document therapist skill and patient response, include caregiver/safety training when relevant, and define discharge/follow-up criteria. Clinical review required.

    - kind: EndDialog
      id: end_multiturn_direct
      clearTopicQueue: true
```

For catch-all repair use the same pattern under `OnUnknownIntent` with `priority: 1000` in Fallback / Conversational Boosting, but verify it does not regress previously passing cases.

## Non-destructive principle

When preserving designed content/features, prefer inserting connector-free eval-safe responses before connection-backed nodes and ending the topic (`EndDialog clearTopicQueue: true`) rather than deleting the original search/flow/action nodes. This keeps runtime features available for channels where connections work while making draft evals testable.

Exception: if eval still reaches connection-backed nodes despite early `EndDialog`, replace the active eval-routed topic body with a direct-only YAML backup and preserve the old body in a local backup file. Verify active component YAML contains zero `SearchAndSummarizeContent` / `InvokeFlowAction` before rerunning.

## Knowledge-source mode/deactivation pitfall

Do not try to fix maker-evaluation connector prompts by switching type-16 knowledge sources from `connectionProperties.mode: Invoker` to `Maker`, or by deactivating type-16 knowledge sources, unless you are prepared to cancel stuck runs and restore them. In Feedback B this made eval runs hang InProgress with no aggregate results. The safer path was:

1. Restore type-16 knowledge sources to active `Invoker` state.
2. Route eval prompts into high-priority connector-free topics before generated answers/knowledge can fire.
3. Verify with the small control set first.

## Score trajectory from Feedback B repair

This is a diagnostic pattern, not a reusable target score:

- Broken baseline on 10-case MultiTurn control: 10%.
- Exact first-turn triggers only: 50%.
- Broad short triggers caused routing collisions: regressed to 30%.
- Knowledge mode/deactivation attempts: runs hung; cancel and restore.
- Multi-turn direct topics: 90%.
- Exact high-priority skilled-maintenance trigger for the remaining connector first turn: 100% on the 10-case control.
- 100-case SingleTurn Set 01 after control pass: 31%, because 67/69 failures still routed to connection manager. Lesson: after a small control passes, run a broad set and add high-priority triggers or a broader direct topic for systemic single-turn questions before declaring done.

## Auth/token pitfall during long loops

Dataverse and gateway/PPAPI use different token scopes. During long loops the Azure CLI cache can return an expired Dataverse token that causes 401 on `PATCH /api/data/v9.2/botcomponents(...)`.

Preferred recovery:

```bash
cd "D:/my agents copilot studio/pipeline"
node - <<'NODE'
const a=require('./auth_helper.cjs');
(async()=>{
  a.clearCache();
  const r=await a.getBearerToken('https://org3353a370.crm.dynamics.com/.default');
  console.log('OK', r.source, r.expiresOn.toISOString(), r.token.length);
})();
NODE
```

Then rerun the Dataverse patch. Do not mistake this for a YAML/content failure.

## Verification checklist

Before spending another eval run:

- Pull live components back from Dataverse.
- Parse all active `9_*.mcs.yml` files with `yaml.safe_load`.
- For active eval-routed topics, count `SearchAndSummarizeContent` and `InvokeFlowAction`; expected 0 for direct-only bypass topics.
- Confirm multi-turn topics contain at least two `kind: Question` nodes before the final `SendActivity`.
- Record test set ID with the score; small MultiTurn control success does not prove 100-case SingleTurn success.
