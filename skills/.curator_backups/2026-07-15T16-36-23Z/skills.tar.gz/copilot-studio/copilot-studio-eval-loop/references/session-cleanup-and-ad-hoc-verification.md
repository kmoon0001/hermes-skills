# Session Cleanup and Ad-hoc Verification for Copilot Studio Eval Work

Use this after live Copilot Studio eval/debug sessions that create temporary scripts, Chrome CDP browser sessions, or Node polling processes.

## When to run

Run this cleanup/verification pass when:
- Eval polling, Playwright/CDP automation, or Dataverse patch scripts timed out.
- Chrome remote debugging was opened on `127.0.0.1:9223`.
- Temporary `hermes-verify-*` scripts were created under `%LOCALAPPDATA%\Temp`.
- The user asks to close leftover/background processes to save CPU/RAM.

## Cleanup sequence

1. Check Hermes-managed background processes first with the process tool, if available.
2. Kill leftover local Node eval/automation processes:
   - `tasklist | grep 'node.exe'`
   - `taskkill //PID <pid> //F`
3. Kill Node REPL leftovers:
   - `tasklist | grep 'node_repl.exe'`
   - `taskkill //PID <pid> //F`
4. Close Chrome CDP only after all browser/API work is done:
   - Find listener: `netstat -ano | grep ':9223'`
   - Kill tree: `taskkill //PID <pid> //T //F`
5. Wait a few seconds and re-check; Windows can briefly show stale listeners immediately after `taskkill`.

## Required ad-hoc verification pattern

When there is no canonical test/lint/build command for the changed files, create a focused temporary verifier under:

`C:\Users\kevin\AppData\Local\Temp`

Use an OS-safe tempfile name with prefix:

`hermes-verify-`

The verifier should explicitly check the changed behavior, for example:
- Expected markdown/report file exists, is non-trivial size, and contains required sections.
- Temporary helper scripts from earlier are removed.
- `netstat -ano` shows no `LISTENING` entry on port `9223`.
- `tasklist` shows no `node.exe` / `node_repl.exe` leftovers when the user's goal is full cleanup.

Run it, print JSON-ish pass/fail output, then delete the verifier itself. Summarize as **ad-hoc verification, not suite green**.

## Dataverse / CDP verification pitfall

If a CDP-evaluated script running on `copilotstudio.microsoft.com` tries to `fetch('https://org...crm.dynamics.com/api/data/v9.2/...')`, it may fail with browser/CORS/origin `TypeError: Failed to fetch` even when the browser is authenticated.

Fix:
1. Use CDP to navigate the tab to the Dataverse org origin first, e.g. `https://org3353a370.crm.dynamics.com`.
2. Wait for the page/origin to load.
3. Run the `fetch('/api/data/v9.2/...')` or full-org Dataverse request from that org-origin tab with `credentials: 'include'` and OData headers.

This pattern was used to verify that a potentially unsafe `OT Knowledge Quick Answers` topic was absent, and that only the original `OT General Knowledge` topic remained.

## Reporting language

Use concise language:
- "Ad-hoc verification completed, not suite green."
- List exact checks that passed/failed.
- If a check fails, fix the failed condition and rerun the verifier before claiming cleanup is done.
