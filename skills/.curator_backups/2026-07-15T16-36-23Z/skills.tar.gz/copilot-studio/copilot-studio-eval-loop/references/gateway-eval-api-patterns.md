# Gateway Eval API Patterns (June 25, 2026)

Discovered during OT SR optimization loop. These patterns work when `eval-api.bundle.js` fails due to missing `@azure/msal-node-extensions`.

## Gateway Base URL

```
https://powervamg.us-il106.gateway.prod.island.powerapps.com
```

## Required Headers (from eval_auth_capture.json → sample[0].headers)

```
authorization: Bearer <token>
x-ms-user-agent: <from capture>
x-cci-applicationsource: <from capture>
accept: application/json
x-ms-client-session-id: <from capture>
x-cci-tenantid: <from capture>
x-cci-bapenvironmentid: <from capture>
x-cci-organizationid: <from capture>
referer: <from capture>
x-cci-cdsbotid: <bot-id>       # ADD these two
x-cci-botid: <bot-id>          # ADD these two
x-ms-client-request-id: <uuid> # Generate fresh per request
content-type: application/json
```

## Auth Capture Script

```bash
node "D:/my agents copilot studio/pipeline/scripts/capture_eval_auth.cjs"
```

Requires an active browser session on copilotstudio.microsoft.com with the Evaluation page loaded. The script intercepts network requests to extract auth headers. **Tokens expire in ~1 hour.**

## API Endpoints

### List Recent Runs
```
GET {gateway}/api/botmanagement/v2/environments/{envId}/bots/{botId}/makerevaluations?count=N
```
Returns array of run objects. Key fields: `id`, `name`, `state`, `testCaseCount`, `aggregatedGraderResults`.

### Launch New Run
```
POST {gateway}/api/botmanagement/v2/environments/{envId}/bots/{botId}/makerevaluations
Body: { "testSetId": "<uuid>", "clientRequestedEvaluationRunName": "<name>" }
```
Returns `{ "runId": "<uuid>", "state": "Queued" }`. **Only one active run per agent at a time** — second launch returns 422 "fairusagepolicy.botactiverunquotaviolated".

### Get Run Details (full test case data)
```
GET {gateway}/api/botmanagement/v2/environments/{envId}/bots/{botId}/makerevaluations/{runId}/details
```
Returns full run object with `details.testCases[]`. Each test case has `graderMetrics.queryResponseMetrics[]` with per-metric pass/fail.

**NOTE**: The individual run endpoint `GET .../makerevaluations/{runId}` returns 405. Use `?count=N` list endpoint or `/details` endpoint instead.

## Score Extraction

### From List Endpoint (aggregatedGraderResults)
```javascript
const agr = run.aggregatedGraderResults || [];
const succeeded = agr.find(a => a.name === 'totalSucceeded')?.count || 0;
const failed = agr.find(a => a.name === 'totalFailed')?.count || 0;
const errors = agr.find(a => a.name === 'totalErrors')?.count || 0;
const score = Math.round(succeeded / (succeeded + failed) * 100);
```

### From Details Endpoint (per-case grader metrics)
```javascript
for (const c of cases) {
  if (c.executionState !== 'Evaluated') continue;
  const qrm = c.graderMetrics?.queryResponseMetrics || [];
  for (const m of qrm) {
    if (m.metricType === 'ResponseQualityGeneral') {
      const p = m.properties || {};
      const passed = p.relevance === 'Yes' && p.completeness === 'Yes' && p.abstention === 'No';
      // Also available: p.explanations (JSON string with detailed reasoning)
    }
  }
}
```

### Evaluation Result States
- `evaluationResult: "NoResult"` — Agent returned text (normal for guardrail answers)
- `evaluationResult: "Passed"` — Structured result passed
- `executionState: "Evaluated"` — Test case completed
- `executionState: "EvaluationSkipped"` — Test case skipped (no agent response)
- `executionState: "Created"` — Test case not yet processed

## Auth Refresh Pattern

When poll returns 403 "Unable to validate token":
1. Open Copilot Studio Evaluation page in browser (ensure logged in)
2. Run `node scripts/capture_eval_auth.cjs`
3. Continue polling

The auth helper (`auth_helper.cjs`) uses `InteractiveBrowserCredential` which opens browser popups. For eval API calls, the capture-based approach is faster and more reliable.

### Auth Refresh via Playwright CDP (no user interaction needed)

If Chrome is running with CDP on port 9223, refresh auth automatically:

```javascript
const { chromium } = require('playwright-core');
const fs = require('fs');

const browser = await chromium.connectOverCDP('http://127.0.0.1:9223');
const context = browser.contexts()[0];
const page = await context.newPage();

// Capture ALL requests with Bearer auth headers
const captured = [];
page.on('request', req => {
  const h = req.headers();
  if (h.authorization && h.authorization.startsWith('Bearer ')) {
    captured.push({ url: req.url(), method: req.method(), headers: h });
  }
});

// Navigate to the bot page — triggers API calls with fresh auth
const botUrl = 'https://copilotstudio.microsoft.com/environments/<envId>/bots/<botId>/build';
await page.goto(botUrl, { waitUntil: 'networkidle', timeout: 60000 });
await page.waitForTimeout(10000);

// Find the best request (one with x-cci-* headers) and save
if (captured.length > 0) {
  const best = captured.find(r => r.headers['x-cci-tenantid']) || captured[0];
  const existing = JSON.parse(fs.readFileSync('../eval_auth_capture.json', 'utf8'));
  existing.sample[0].headers = best.headers;
  fs.writeFileSync('../eval_auth_capture.json', JSON.stringify(existing, null, 2));
}
await page.close();
```

This captures fresh Bearer tokens without running `capture_eval_auth.cjs` (which needs a separate interactive browser). The Copilot Studio bot page makes API calls that include all needed `x-cci-*` headers.

## Polling Script Pattern

```javascript
// Write to .cjs file (node -e fails in background mode on Windows)
// Poll every 30 seconds, check aggregatedGraderResults
// When state === "Completed", extract final score
// Save result to live_agent_dump/<label>_eval_result.json
```

## Known Quirks

1. **List endpoint returns empty aggregatedGraderResults during early InProgress** — the `totalSucceeded/totalFailed` counts may show 0 for several minutes even though test cases are being evaluated. Use the `/details` endpoint for intermediate progress.
2. **Auth expires fast** — plan for re-capture mid-session.
3. **Only 1 active eval per agent** — cannot launch SR and Conv simultaneously for the same agent.
4. **Run may disappear from top-N list** — if many evals were launched, use higher `count` parameter or search by run ID.

## Three-Run Eval Protocol (MS Learn, validated Jul 1 2026)

General quality grading has ~5-10% variance between runs. A single eval run is not sufficient to confirm a score. MS Learn recommends:

1. **Run 1:** Baseline measurement
2. **Run 2:** Confirm score is stable (should be within ±5% of Run 1)
3. **Run 3:** If Run 1 and Run 2 differ by >5%, run a third to establish average

**When variance is >10% between runs:** Investigate grader reliability or agent non-determinism before diagnosing individual failures. Per MS Learn: "Up to 5% variance between runs is normal. If runs vary by more than 10%, investigate grader reliability."

**OT Jul 1 evidence:** Run 1 = 96%, Run 2 = 94%. Variance = 2% (well within ±5%). Average = 95%. Stable.

**Recording:** Save all eval detail files with run label (e.g., `OT_MSLEARN_RUN1_`, `OT_MSLEARN_RUN2_`) so the average can be computed later.

## Diagnosing agentresponsetoolong

When eval cases show `EvaluationSkipped` with error `testcasevalidation.agentresponsetoolong`:

1. **Check the error code** — `agentresponsetoolong` means response text exceeded the eval framework's max character limit. This is NOT a timeout.
2. **Common trigger**: Expanding triggerQueries in a topic causes more questions to route there. The SearchAndSummarizeContent in that topic produces longer responses than the Fallback topic would have.
3. **Why Fallback produces shorter responses**: Fallback uses `variable: Topic.Answer` in its SearchAndSummarizeContent, which may truncate/format the response. It also has "Keep the answer concise" in additionalInstructions.
4. **Fix approaches** (in order of reliability):
   a. **Revert triggerQueries** to original set — proven to resolve the issue
   b. **Add `variable: Topic.Answer`** to the topic's SearchAndSummarizeContent
   c. **Shorten additionalInstructions** to bare minimum ("Answer in 2-3 sentences. No lists.")
   d. **Use test set rewording** instead of expanding trigger queries
5. **What does NOT work**: Making additionalInstructions more concise ("2-3 sentences max") still produces agentresponsetoolong when trigger queries are expanded. The response length is controlled by the SearchAndSummarizeContent action itself, not just the instructions.

## Creating New Topics via Dataverse API

```javascript
const url = org + '/api/data/v9.2/botcomponents';
const body = {
  name: 'Topic Display Name',
  schemaname: 'copilots_header_8c921.topic.TopicPascalCaseName',
  componenttype: 9,  // topic
  data: yamlContent,
  'parentbotid@odata.bind': '/bots(' + botId + ')'
};
// POST returns 204 on success
```

- The `schemaname` must follow `copilots_header_<hex>.topic.<PascalCaseName>` pattern
- The `<hex>` portion (e.g., `8c921`) is environment-specific — find it from existing topic schemanames
- Use `componenttype: 9` for topics, `15` for actions
- To update existing topics: `PATCH {org}/api/data/v9.2/botcomponents({componentId})` with `{ data: newYaml }` — returns 204
- All Dataverse calls require authenticated browser cookies (use Playwright CDP pattern above)
