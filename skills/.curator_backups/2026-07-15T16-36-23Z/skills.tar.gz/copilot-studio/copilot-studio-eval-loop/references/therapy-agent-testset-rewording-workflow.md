# Therapy Agent Test-Set Rewording Workflow

Use this for Copilot Studio OT/PT/SLP/TDA therapy agents when evals fail on document-check prompts.

## When to use

Use test-set rewording before YAML changes when failures look like:
- "Can you check/review/audit my [note/document] for X?"
- "Is my [note/document] compliant?"
- "Does my [note/document] include X?"

These prompts are structurally risky because the eval usually does not provide the actual note text. The agent may abstain, ask for the document, or provide a generic checklist; graders often mark completeness/abstention/groundedness failures.

## Methodical order

1. Freeze live agent behavior.
   - Do not edit broad trigger queries.
   - Do not add catch-all quick-answer topics.
   - Do not add aggressive global instructions.

2. Create a V2 test set, never overwrite baseline.
   - Preserve the original test set for comparison.
   - Use CSV import with header: `question,expectedResponse`.

3. Reword only structural failures.
   - Bad: `Can you check if my PT note includes measurable goals?`
   - Better: `What makes PT goals measurable and compliant with Medicare documentation standards?`
   - Bad: `Can you review my OT note for compliance with CMS Chapter 15?`
   - Better: `What OT documentation elements are required for compliance with CMS Chapter 15?`

4. Verify the CSV locally before asking the user to import it.
   - Confirm header is exactly `question,expectedResponse`.
   - Confirm all rows have two columns.
   - Confirm no blank questions.
   - Confirm the expected row count.
   - Grep/check for remaining obvious bad phrases: `can you check`, `can you review`, `can you audit`, `review my`, `audit my`, `my note`, `my discharge summary`, `my recertification`.
   - If any remain, inspect them manually. Some may be intentional, but do not assume.

5. Import and evaluate.
   - Import as a new test set in Copilot Studio UI.
   - Refresh gateway auth if API returns 401/403.
   - Run one eval at a time per agent/eval type.
   - If it fails, extract exact failed cases and repeat only for those cases.

## What to reuse across agents

Reusable:
- Rewording unanswerable document-check prompts into answerable knowledge prompts.
- Failure categories: wording, routing, groundedness, execution/no-text, response length.
- One-change-at-a-time eval loop.

Do not reuse:
- Broad OT General Knowledge trigger expansion.
- Catch-all quick-answer topics.
- Long SearchAndSummarizeContent instructions.
- Aggressive global instructions with MUST/CRITICAL/MANDATORY wording.
- TDA routing constraints on audit agents or audit-agent verbosity on TDA.

## Verification note

When no canonical test/lint/build command exists, create a temporary `hermes-verify-*` script under `%LOCALAPPDATA%\\Temp`, run focused checks, delete it, and report results as ad-hoc verification — not suite green.
