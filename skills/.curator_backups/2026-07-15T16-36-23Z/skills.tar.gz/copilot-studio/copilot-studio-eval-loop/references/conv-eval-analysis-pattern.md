# Conv Eval Analysis: Gateway API Pattern (Validated Jul 10 2026)

## Auth: MSAL Cache (no browser needed)

```javascript
const { PublicClientApplication } = require('@azure/msal-node');
const { PersistenceCreator, PersistenceCachePlugin, DataProtectionScope } = require('@azure/msal-node-extensions');

const TENANT='03cc92c3-986c-4cf4-ae27-1478cf99d17f';
const CLIENT='51f81489-12ee-4a9e-aaae-a2591f45987d';  // Power Platform CLI
const ENV='a944fdf0-0d2e-e14d-8a73-0f5ffae23315';     // RAW GUID — NOT Default-{tenant}
const GW='https://powervamg.us-il106.gateway.prod.island.powerapps.com';
const CACHE=path.join(os.homedir(),'.copilot-studio-cli','manage-agent.cache.json');
const BOT_ID='b0346795-4876-f111-ab0e-70a8a5b1b8cc';

async function getToken(){
  const p=await PersistenceCreator.createPersistence({cachePath:CACHE,
    dataProtectionScope:DataProtectionScope.CurrentUser,
    serviceName:'copilot-studio-cli',accountName:'manage-agent',
    usePlaintextFileOnLinux:true});
  const app=new PublicClientApplication({auth:{clientId:CLIENT,
    authority:`https://login.microsoftonline.com/${TENANT}`},
    cache:{cachePlugin:new PersistenceCachePlugin(p)}});
  const accs=(await app.getTokenCache().getAllAccounts()).filter(a=>a.tenantId===TENANT);
  const r=await app.acquireTokenSilent({
    scopes:['api://96ff4394-9197-43aa-b393-6a41652e21f8/.default'],
    account:accs[0]});
  return r.accessToken;
}
```

## Headers (minus eval_auth_capture.json fallback)

```javascript
function headers(botId){
  return {
    authorization:'Bearer '+bearer, accept:'application/json',
    'content-type':'application/json',
    referer:'https://copilotstudio.microsoft.com/',
    'x-ms-user-agent':'PVA-Portal/1.0.0',
    'x-cci-applicationsource':'Web',
    'x-cci-tenantid':TENANT,
    'x-cci-bapenvironmentid':ENV,
    'x-cci-organizationid':'bd048f00-0d2e-e14d-8a73-0f5ffae23315',
    'x-ms-client-principal-id':'700a4462-830f-4df4-96f2-2627f16fbc86',
    'x-cci-cdsbotid':botId,
    'x-cci-botid':botId,
    'x-ms-client-session-id':crypto.randomUUID(),
    'x-ms-client-request-id':crypto.randomUUID(),
  };
}
```

## List Recent Eval Runs

```javascript
const base=`${GW}/api/botmanagement/v2/environments/${ENV}/bots/${BOT_ID}/makerevaluations`;
const resp=await fetch(base+'?count=10',{headers:headers(BOT_ID)});
const j=await resp.json();
const runs=Array.isArray(j)?j:(j.value||j.evaluationRuns||[]);
for(const run of runs){
  const agr=run.aggregatedGraderResults||[];
  const s=agr.find(x=>x.name==='totalSucceeded')?.count||0;
  const f=agr.find(x=>x.name==='totalFailed')?.count||0;
  const e=agr.find(x=>x.name==='totalErrors')?.count||0;
  console.log(`${run.id.slice(0,12)} ${run.state} ${s/(s+f)*100}% (${s}/${s+f+e})`);
}
```

## Launch Conv Eval

```javascript
const body={
  testSetId:'21b54c2b-a977-4b8a-a70c-168746d07464',  // Conv test set
  clientRequestedEvaluationRunName:`Conv ${new Date().toISOString().slice(11,16)}`
};
const resp=await fetch(`${base}/makerevaluations`,{
  method:'POST',headers:headers(BOT_ID),body:JSON.stringify(body)
});
const j=await resp.json();  // { runId, state: "Queued" }
```

## Poll + Analyze Conv Eval

```javascript
// Poll details every 30s
const d=await fetch(`${base}/${runId}/details`,{headers:headers(BOT_ID)});
const dj=await d.json();
const cases=dj.details?.testCases||dj.testCases||[];

// Conv evals: each case has queries[] (one per conversation turn)
for(const c of cases){
  const queries=c.queries||[];
  let casePass=true;
  for(const q of queries){
    const query=q.query||'';
    const answer=q.answer||'';
    const state=q.executionState||'';
    let rel='',com='',abs='';
    for(const m of q.metrics?.queryResponseMetrics||[]){
      if(m.metricType==='ResponseQualityGeneral'){
        const p=m.properties||{};
        rel=p.relevance||'?'; com=p.completeness||'?'; abs=p.abstention||'?';
      }
    }
    const passed=rel==='Yes'&&com==='Yes'&&abs==='No';
    if(!passed) casePass=false;
    console.log(`${passed?'✅':'❌'} Q: "${query.slice(0,80)}" → A: "${answer.slice(0,80)}" [rel=${rel} com=${com} abs=${abs}]`);
  }
}
```

## Known Conv Failure Patterns (Validated Jul 10 2026)

**Pattern A — "What type of therapy document?" loop (Document Upload Intake)**
- Symptom: Bot keeps asking "What type of therapy document did you want reviewed?"
- Root cause: ClosedListEntity items don't match user's free-text responses
- Fix: Add text-input path or change entity type

**Pattern B — "Please upload X document" loop (Specific doc topics)**
- Symptom: Bot keeps saying "Please upload the Discharge Summary document..."
- Root cause: FilePrebuiltEntity never completes without actual file attachment
- Fix: Change entity to StringPrebuiltEntity (accepts text AND files)

**Pattern C — ConvStart missing EndDialog**
- Symptom: ExecutionFailed on subsequent turns after welcome message
- Root cause: No `EndDialog(clearTopicQueue: true)` after SendActivity
- Fix: Add EndDialog node
