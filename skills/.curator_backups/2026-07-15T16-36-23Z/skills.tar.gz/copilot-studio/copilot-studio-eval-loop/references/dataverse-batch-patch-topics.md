# Dataverse Batch Topic Patching

Validated Jul 2026 across OT (10 topics), PT (8 topics), and TDA (1 GPT component) in Ensign default.

## Auth
```bash
TOKEN=$(az account get-access-token --resource "https://org3353a370.crm.dynamics.com" --query accessToken -o tsv)
```

## Read a Component
```bash
curl -s -H "Authorization: Bearer $TOKEN" -H "Accept: application/json" \
  "https://org3353a370.crm.dynamics.com/api/data/v9.2/botcomponents(<id>)?%24select=data"
```

## PATCH a Component (HTTP 204 on success)
```javascript
const https = require('https');
function patchDV(org, entity, id, body, token) {
  const url = `https://${org}.crm.dynamics.com/api/data/v9.2/${entity}(${id})`;
  return new Promise((res, rej) => {
    const d = JSON.stringify(body);
    const r = https.request(url, {
      method: 'PATCH',
      headers: {
        'Authorization': 'Bearer ' + token,
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(d),
        'Accept': 'application/json',
        'If-Match': '*'
      }
    }, resp => {
      let b = ''; resp.on('data', c => b += c);
      resp.on('end', () => res({ status: resp.statusCode, body: b }));
    });
    r.write(d); r.end();
  });
}
// PATCH topic data:
patchDV('org3353a370', 'botcomponents', '<componentId>', { data: newYaml }, token);
// PATCH GPT instructions:
patchDV('org3353a370', 'botcomponents', '<gptComponentId>', { data: newInstructionsYaml }, token);
```

## Query Active Topics
```
$select=botcomponentid,name&$filter=_parentbotid_value eq <botId> and componenttype eq 9 and statecode eq 0
```

## Topic additionalInstructions Fix Pattern
Replace in topic YAML `data`:
```
old: "- First sentence must directly answer the exact user question. For yes/no checks, give a conditional determination"
new: "- Provide thorough, complete information covering all key documentation requirements for the question topic. For yes/no checks, give a conditional determination"
```

## Publish After All Patches
```bash
pac auth select --index 1  # Select Ensign Default
pac copilot publish --bot "<botId>"
```

## Known Component IDs (Ensign Default)

| Agent | Type | Component ID | Purpose |
|-------|------|-------------|---------|
| OT | 15 | 28c4402c-2a2b-45d7-888d-e3ef81b2f401 | GPT Instructions |
| SLP | 15 | 9a5e1289-baf3-44be-bb76-ce9d410c91dc | GPT Instructions |
| TDA | 15 | ff00b80a-321b-44be-80a4-40c78072ffe3 | GPT Instructions |

Component types: 9=topic, 14=uploaded file, 15=GPT instructions, 16=web/SharePoint KB, 19=trigger phrase
