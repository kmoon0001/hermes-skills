# Refresh Gateway Auth via Playwright CDP

When `capture_eval_auth.cjs` times out (it opens an interactive browser window), use this pattern to refresh auth from the existing Chrome CDP session.

## Prerequisites
- Chrome running with CDP on port 9223 (`--remote-debugging-port=9223`)
- Already logged into Copilot Studio in that browser

## Script: `refresh_auth_via_cdp.cjs`

```javascript
const { chromium } = require('playwright-core');
const fs = require('fs');

(async () => {
  const browser = await chromium.connectOverCDP('http://127.0.0.1:9223');
  const context = browser.contexts()[0];
  const page = await context.newPage();

  // Capture ALL requests with Bearer auth headers
  const captured = [];
  page.on('request', req => {
    const h = req.headers();
    if (h.authorization && h.authorization.startsWith('Bearer ')) {
      captured.push({ url: req.url(), method: req.method(), headers: h });
    }
  });

  // Navigate to the bot's build page — this triggers API calls with auth
  const envId = 'Default-03cc92c3-986c-4cf4-ae27-1478cf99d17f';
  const botId = '<bot-id>';
  const botUrl = `https://copilotstudio.microsoft.com/environments/${envId}/bots/${botId}/build`;
  await page.goto(botUrl, { waitUntil: 'networkidle', timeout: 60000 }).catch(() => {});
  await page.waitForTimeout(10000);

  if (captured.length > 0) {
    // Find the best request (one with x-cci-* headers)
    const best = captured.find(r => r.headers['x-cci-tenantid']) || captured[0];
    const existing = JSON.parse(fs.readFileSync('../eval_auth_capture.json', 'utf8'));
    existing.sample[0].headers = best.headers;
    existing.sample[0].url = best.url;
    fs.writeFileSync('../eval_auth_capture.json', JSON.stringify(existing, null, 2));
    console.log('Auth refreshed. Has x-cci-tenantid:', !!best.headers['x-cci-tenantid']);
  } else {
    console.log('No auth captured — user may need to log in first');
  }

  await page.close().catch(() => {});
})();
```

## Key Details
- The Copilot Studio SPA makes API calls to `powervamg.us-il106.gateway.prod.island.powerapps.com` that include Bearer + x-cci-* headers
- `waitUntil: 'networkidle'` + 10s wait ensures API calls fire before capture
- The captured headers work for both eval API and component PATCH endpoints
- Token lifetime is ~1 hour — refresh before each batch of API calls
