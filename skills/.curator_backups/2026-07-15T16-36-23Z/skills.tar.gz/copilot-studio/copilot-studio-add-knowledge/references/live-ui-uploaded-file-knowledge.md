# Live UI uploaded-file knowledge workflow

Use when migrating web knowledge into Copilot Studio uploaded files, especially when the user says the live UI is source of truth.

## Verified live UI workflow

1. Open the target agent's live Knowledge tab in the correct environment.
2. Confirm the agent name and environment in the UI before editing.
3. Upload PDFs manually/UI-only: Knowledge → Add knowledge → Upload files.
4. Wait until every uploaded file shows **Ready**.
5. Open each uploaded file source detail page.
6. Rewrite the display name from raw filename to a clean authoritative name.
7. Rewrite the description with retrieval terms and authority context.
8. Turn **Official source** on for authoritative files.
9. When Copilot Studio shows **Update agent instructions? (preview)**, click **Got it** if intended.
10. Save and verify:
    - Save is disabled afterward.
    - Status remains Ready.
    - Official source toggle is on.
    - List row shows the clean name.

## Description pattern

`Official <publisher> <source type/topic>. Covers <clinical or domain scope>, <important instruments/terms>, <workflow/use cases>, and <documentation/compliance concepts>.`

Example:
`Official ASHA practice portal for adult dysphagia. Covers bedside and instrumental assessment, aspiration risk, diet recommendations, compensatory strategies, exercises, caregiver training, and skilled SLP documentation.`

## Important pitfalls

- File upload is UI-only; do not invent YAML/API upload paths.
- The live UI is source of truth for uploaded file source names, descriptions, Ready status, and Official source flags.
- All view may include uploaded files in some tenants; use the Files filter to isolate PDFs, not because All necessarily hides them.
- Do not deactivate old Public website sources until uploaded files are Ready and verified, unless the user explicitly directs it.
- If Dataverse API auth fails because the Azure public client app is not tenant-consented (AADSTS700016 for `04b07795-8ddb-461a-bbee-02f9e1bf7b46`), do not treat that as a product limitation. Use live UI editing instead or ask for tenant/admin consent if API automation is required.

## Ensign SLP migration notes (2026-06-30)

The SLP migration confirmed that marking Official source in Copilot Studio updates agent grounding instructions and requires confirmation. After save, detail pages showed status Ready, Official source ON, and Save disabled. The old Public website sources remained visible and Ready above the new uploaded files, so retrieval variance can persist until those old sources are intentionally removed/deactivated.