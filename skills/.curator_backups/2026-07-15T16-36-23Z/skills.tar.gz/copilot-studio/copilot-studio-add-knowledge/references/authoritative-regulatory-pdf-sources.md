# Authoritative Regulatory PDF Sources (Medicare / CMS / CFR — pre-upload KB assembly)

Use this bank when the user wants to assemble a Medicare/CMS/SNF/therapy
compliance Knowledge base of UPLOADED files (folder of PDFs) for a
Copilot Studio agent. Plain `curl -sL -A "Mozilla/5.0"` downloads the
CMS.gov `/Downloads/*.pdf` URLs directly and reliably.

## Live direct-download URLs (verified working)

| Topic | Save-As filename | URL |
|---|---|---|
| Medicare Benefit Policy Manual Ch15 §220-230 (therapy/skilled) | `CMS-Ch15-Therapy-Services-Sec220-230.pdf` | `https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/Downloads/bp102c15.pdf` |
| Jimmo v. Sebelius — CMS fact sheet (SUBSTITUTE for the dead `/SNFPPPS/Downloads/Jimmo-FAQ.pdf`) | `Jimmo-v-Sebelius-CMS-FAQ.pdf` | `https://www.cms.gov/medicare/medicare-fee-for-service-payment/snfpps/downloads/jimmo-factsheet.pdf` |
| CMS State Operations Manual Appendix PP (SNF survey/deficiency) | `CMS-SOM-AppendixPP-SNF-Survey-Guidelines.pdf` | `https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/Downloads/som107ap_pp_guidelines_ltcf.pdf` |
| Medicare Claims Processing Manual Ch5 (Part B, 8-min rule, GP/GO/GN) | `CMS-Claims-Processing-Manual-Ch5-PartB.pdf` | `https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/Downloads/clm104c05.pdf` |
| Medicare Program Integrity Manual Ch3 (auditor review method) | `CMS-Program-Integrity-Manual-Ch3.pdf` | `https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/Downloads/pim83c03.pdf` |
| PDPM fact sheet (admin level-of-care presumption) | `CMS-PDPM-Fact-Sheet-SNF-PPS.pdf` | `https://www.cms.gov/Medicare/Medicare-Fee-for-Service-Payment/SNFPPS/Downloads/PDPM_Fact_Sheet_AdminPresumption_v6_508.pdf` |
| PDPM technical report (classification methodology + therapy scoring) | `CMS-PDPM-Technical-Report-Classification.pdf` | `https://www.cms.gov/medicare/medicare-fee-for-service-payment/snfpps/downloads/pdpm_technical_report_508.pdf` |
| Medicare Parts A & B Appeals Process (MLN booklet, ALJ/OMHA) | `Medicare-Appeals-Process-ALJ-Decisions.pdf` | `https://www.cms.gov/files/document/mln006562-medicare-parts-b-appeals-process.pdf` |
| APTA PT Documentation of Patient/Client Management (guidelines) | `APTA-AOTA-ASHA-Clinical-Practice-Standards.pdf` | `https://www.apta.org/siteassets/pdfs/policies/guidelines-documentation-patient-client-management.pdf` |

## eCFR heavy regulation parts — DO NOT use the eCFR PDF renderer

Pitfall: `https://www.ecfr.gov/api/renderer/v1/content/enhanced/<date>/title-42.pdf?part=409`
returns either `429 Too Many Requests` (aggressive per-IP throttle) OR the
JSON error `{"error":"Found unpermitted parameter: :format..."}`. It is
unreliable for automated pulls. Use the **GovInfo annual CFR PDFs** instead —
stable, direct, not rate-limited. Volume mapping for Title 42:

| Part | GovInfo URL (2024 edition — valid PDF) |
|---|---|
| 409 SNF Covered Services | `https://www.govinfo.gov/content/pkg/CFR-2024-title42-vol2/pdf/CFR-2024-title42-vol2-part409.pdf` |
| 422 Medicare Advantage | `https://www.govinfo.gov/content/pkg/CFR-2024-title42-vol3/pdf/CFR-2024-title42-vol3-part422.pdf` |
| 483 Subpart B SNF Requirements of Participation | `https://www.govinfo.gov/content/pkg/CFR-2024-title42-vol5/pdf/CFR-2024-title42-vol5-part483.pdf` |

Note: GovInfo `CFR-2025-title42-vol*` may return `text/html` (not yet
published for that part); the `2024` editions reliably return `application/pdf`.
The regulation text is the same for KB purposes.

## MAC Local Coverage Determinations (therapy) — jurisdiction-dependent

File 9 in the user's manifest is "your MAC." Pull the LCD for the
jurisdiction that covers the facilities. Direct PDF examples:

- CGS (JF) L34049 — `https://cgsmedicare.com/partb/mr/pdf/physical_therapy.pdf`
- Noridian (JE) Outpatient Therapy — page: `https://med.noridianmedicare.com/web/jeb/specialties/outpatient-therapy`
  (find the LCD PDF link on that page; LCD IDs rotate by version).
- CMS coverage-database LCD viewer: `https://www.cms.gov/medicare-coverage-database/view/lcd.aspx?lcdId=34428&ver=93` (Outpatient PT L34428)

Always confirm the MAC jurisdiction with the user before finalizing file 9 —
wrong jurisdiction = wrong LCD.

## Internal / hand-built files (cannot download — get from compliance dept)

- `2026-Medicare-PartB-LCR-Form.pdf` — internal Ensign MAC Live Clinical Review form
- `Ensign-7-Habits-Documentation-Framework.pdf` — internal Ensign doc

Leave these as placeholders; the user supplies them from the compliance department.

## Workflow snippet (folder of PDFs → ready for UI upload)

```bash
mkdir -p ~/Desktop/PacCoast-Defense-KB
cd ~/Desktop/PacCoast-Defense-KB
# CMS manual PDFs:
curl -sL -A "Mozilla/5.0" -o CMS-Ch15-Therapy-Services-Sec220-230.pdf \
  https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/Downloads/bp102c15.pdf
# ...repeat per row above...
# verify each is a real PDF (not an HTML error page):
for f in *.pdf; do head -c5 "$f" | grep -q '%PDF' && echo "OK $f" || echo "BAD $f"; done
```

## Notes the user should hear

- The Jimmo FAQ URL in older manifests (`/SNFPPPS/Downloads/Jimmo-FAQ.pdf`)
  is DEAD (CMS site reorg). Substitute the Jimmo **fact sheet** URL above.
- eCFR rate-limits hard. Do not burn retries on the renderer; go straight to GovInfo.
- Upload step itself is UI-only (Copilot Studio Knowledge tab) — see
  `live-ui-uploaded-file-knowledge.md`. The folder of PDFs is the clean
  hand-off: open the bot → Knowledge → Add knowledge → upload each →
  paste the manifest Description → toggle Official source → Save.
