# QM Coach V2 Topic Cleanup Workflow (Jun 19, 2026)

## Context
QM Coach V2 agent (a944fdf0, bot ea52ad9c-8233) had 62 topics. Eval score was 71% (100 single-response cases, 29 failures).

## Failure Analysis
29 failures categorized into 4 types:
- 20 (69%) — Interactive menu topics returning cards instead of text
- 7 (24%) — System error topics with broken actions/connectors
- 2 (7%) — HIPAA questions misrouted to Greeting
- 1 (3%) — Prompt injection from empty template variable

## Topic Overlap Analysis
Identified 10 duplicate/overlapping topics via name grouping:

| Deleted Topic | Kept Replacement | Reason |
|---|---|---|
| QM Escalation Rules | Escalate QM Concern | Interactive menu causing failures |
| HITL APPROVAL | QM - HITL Approval | Generic duplicate |
| QM - Human Review Gate | QM - HITL Approval | Same purpose |
| Power BI (lowercase) | Power BI (uppercase) | Exact duplicate, different casing |
| QM DRIVERS | QM Driver Analysis | Less developed version |
| QM - Latest Resident Submission | LATEST RESIDENT SUBMISSION ROUTER | Duplicate |
| QM Intake | SNF - Clinical Intake Handoff Router | Duplicate |
| QM - Extract Clinical Elements | QM - Validate Documentation Completeness | Overlapping |
| WORKFLOW MENU | QM Orchestrator | Interactive menu causing failures |
| Start Over | Reset Conversation | Same function |

## Deletion via Dataverse API
```javascript
// Delete topic
await fetch(`https://org.crm.dynamics.com/api/data/v9.2/botcomponents(${guid})`, {
    method: 'DELETE',
    credentials: 'include',
    headers: { 'Accept': 'application/json', 'OData-MaxVersion': '4.0', 'OData-Version': '4.0' }
});
// Returns 204 on success
```

## Cross-Reference Audit (CRITICAL)
After deletion, search ALL remaining topic content for deleted topic names:
```javascript
for (const topic of remainingTopics) {
    for (const deletedName of deletedNames) {
        if (topic.content.includes(deletedName)) {
            console.log(`${topic.name} references deleted: ${deletedName}`);
        }
    }
}
```

**Result**: QM Orchestrator referenced deleted "QM Intake" in its menu and condition blocks. Had to remove both the menu option AND the condition block (BeginDialog reference).

## Results
- Topics: 62 → 52 (10 deleted)
- Single-response eval: 71% → 95% (+24 points!)
- Conversation eval: 0% (broken BeginDialog references to deleted topics)

## Lessons
1. Always republish after topic deletions
2. Always check remaining topics for cross-references before republishing
3. Single-response and conversation evals can diverge dramatically
4. Conversation eval 0% with single-response 95% = routing issue, not platform issue
5. BeginDialog references to deleted topics cause empty agent responses
