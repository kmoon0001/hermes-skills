# Topic Overlap Analysis Workflow

Reusable workflow for identifying and removing duplicate/overlapping topics from agents with 30+ topics.

## When to Use

- Agent has 40+ custom topics
- Eval scores are low despite correct instructions
- Multiple topics handle similar question types
- Guard topic count exceeds 10 (per OT stability analysis)

## Step 1: Get All Topics via Dataverse API

```javascript
const botId = 'YOUR_BOT_ID';
const orgUrl = 'https://YOUR_ORG.crm.dynamics.com';
const filter = `_parentbotid_value eq '${botId}' and componenttype eq 9`;
const url = `${orgUrl}/api/data/v9.2/botcomponents?$select=name,botcomponentid,content&$filter=${encodeURIComponent(filter)}&$top=100`;

const resp = await fetch(url, { credentials: 'include', headers: { 'Accept': 'application/json', 'OData-MaxVersion': '4.0', 'OData-Version': '4.0' } });
const data = await resp.json();
// Returns: [{ name, botcomponentid, content }, ...]
```

## Step 2: Group by Functional Area

Group topics by keyword matching on names:
- **System**: Greeting, Goodbye, Sign in, End of Conversation, Conversational boosting, Fallback, Multiple Topics Matched, Conversation Start, On Error
- **Connected Agents**: Any topic that routes to another agent
- **Escalation/HITL**: escalation, hitl, human review
- **HIPAA/Compliance**: hipaa, compliance, safety, critical risk
- **QM Analysis**: driver, analysis, trend, facility qm
- **Intake/Resident**: resident, intake, submission, outlier
- **Documentation**: document, classify, validate, extract, normalize
- **Workflow**: workflow, menu, orchestrat, action plan, coaching

## Step 3: Identify Overlaps

For each group, check:
1. **Exact duplicates**: Same topic created twice (different casing, e.g., "Power BI - Run a query" vs "Power BI - Run a Query")
2. **Functional duplicates**: Different names but same purpose (e.g., "HITL APPROVAL" vs "QM - HITL Approval" vs "QM - Human Review Gate")
3. **Subset topics**: One topic's functionality is fully contained in another (e.g., "Start Over" is a subset of "Reset Conversation")

## Step 4: Choose Which to Keep

For each overlap group:
- Keep the topic with the MOST specific name (e.g., "QM - HITL Approval" over "HITL APPROVAL")
- Keep the topic with the MOST trigger queries or most developed YAML
- Keep the topic that was most recently modified
- If one topic is causing eval failures (interactive menu), keep the one that gives text answers

## Step 5: Check Cross-References Before Deleting

**CRITICAL**: Search all remaining topic content for references to topics you're about to delete:
```javascript
const deletedNames = ['WORKFLOW MENU', 'Start Over', ...];
for (const topic of remainingTopics) {
    for (const name of deletedNames) {
        if (topic.content.includes(name)) {
            console.log(`${topic.name} references deleted: ${name}`);
        }
    }
}
```

Fix any broken references before deleting. Common patterns:
- Menu options pointing to deleted topics
- Condition nodes routing to deleted topics
- Connected agent references

## Step 6: Delete via Dataverse API

```javascript
for (const topicGuid of toDelete) {
    const resp = await fetch(`${orgUrl}/api/data/v9.2/botcomponents(${topicGuid})`, {
        method: 'DELETE',
        credentials: 'include',
        headers: { 'Accept': 'application/json', 'OData-MaxVersion': '4.0', 'OData-Version': '4.0' }
    });
    console.log(resp.ok ? `Deleted ${topicGuid}` : `Failed: ${resp.status}`);
}
```

Returns 204 on success. Batch deletes work (10+ topics in sequence).

## Step 7: Republish and Test

1. Navigate to overview page
2. Click Publish
3. Wait 10-15 seconds for propagation
4. Run single-response eval first (quick check)
5. Run conversation eval (full check)

## QM Coach V2 Example (Jun 2026)

Agent had 62 topics. Identified 10 duplicates:
- QM Escalation Rules → duplicate of Escalate QM Concern
- HITL APPROVAL → duplicate of QM - HITL Approval
- QM - Human Review Gate → duplicate of QM - HITL Approval
- Power BI lowercase → exact duplicate of Power BI uppercase
- QM DRIVERS → duplicate of QM Driver Analysis
- QM - Latest Resident Submission → duplicate of LATEST RESIDENT SUBMISSION ROUTER
- QM Intake → duplicate of SNF - Clinical Intake Handoff Router
- QM - Extract Clinical Elements → overlaps QM - Validate Documentation Completeness
- WORKFLOW MENU → interactive menu, overlaps QM Orchestrator
- Start Over → duplicate of Reset Conversation

Result: 62 → 52 topics. Single-response eval: 71% → 95%.

**Pitfall**: Conversation eval hit 0% after deletions because QM Orchestrator still referenced deleted "QM Intake" in its menu options. Fix: search all remaining content for deleted names before republishing.

## Pitfalls

1. **Don't delete without checking cross-references** — Remaining topics may reference deleted ones in menus, conditions, or routing logic
2. **Always republish after deletions** — The agent re-indexes on publish. Without republish, routing is stale.
3. **Conversation eval is more sensitive to deletions than single-response** — Single-response tests individual topics; conversation tests the full routing chain
4. **"By agent" topics don't use trigger phrases** — Don't waste time adding trigger phrases to AI-routed topics. Fix the topic description instead.
5. **Background processes fail on Windows Git Bash** — `stdin is not a tty` error. Use foreground commands with generous timeouts.
