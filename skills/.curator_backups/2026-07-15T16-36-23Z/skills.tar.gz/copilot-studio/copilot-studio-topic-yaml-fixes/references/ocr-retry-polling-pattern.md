# OCR Async Job Retry Polling Pattern

## When to Use
Any topic that uses `InvokeFlowAction` for async OCR processing where a `GotoAction` loops back to check job status.

## Problem
A bare `GotoAction` (no retry counter) in the "not complete" branch creates an infinite loop. Copilot Studio kills the topic at ~500 dialog executions, causing conversation crashes and eval failures with no user-facing response.

## Fix — Retry Counter Guard

### Variables needed
- `Topic.RetryCount` (Number) — initialized to 0 before polling starts

### YAML Structure
```yaml
    # Initialize counter BEFORE the polling loop
    - kind: SetVariable
      id: init_retry_count
      variable: Topic.RetryCount
      value: 0

    # Status-check InvokeFlowAction (the GotoAction target)
    - kind: InvokeFlowAction
      id: invokeFlow_check_ocr_status
      ...

    - kind: SetVariable
      id: set_ocr_payload
      variable: Topic.ocr_payload
      value: =Topic.job_json

    - kind: ConditionGroup
      id: check_ocr_status
      conditions:
        - id: condition_completed
          condition: '="Status: Completed" in Text(Topic.ocr_payload)'
          actions:
            # Success — generate report, show results, EndDialog
      elseActions:
        - kind: ConditionGroup
          id: check_retry_count
          conditions:
            - id: condition_retry_remaining
              condition: '=Topic.RetryCount < 10'
              actions:
                - kind: SetVariable
                  id: increment_retry
                  variable: Topic.RetryCount
                  value: =Topic.RetryCount + 1
                - kind: SendActivity
                  id: send_waiting
                  activity: |-
                    Still processing (attempt {Topic.RetryCount} of 10)...
                # IMPORTANT: GotoAction targets the status-check flow, NOT the submit flow
                - kind: GotoAction
                  id: goto_retry
                  actionId: invokeFlow_check_ocr_status
          elseActions:
            - kind: SendActivity
              id: send_timeout
              activity: Job is taking too long. Check back later.
            - kind: EndDialog
              id: end_timeout
              clearTopicQueue: true
```

### Critical Rules
1. **Initialize RetryCount BEFORE the first status-check action** — placing the SetVariable after the status-check flow means the GotoAction restarts the counter to 0 every loop, defeating the guard entirely.
2. **Increment BEFORE GotoAction** — the `+1` must execute before the loop jumps back.
3. **10 retries max** — ~50-100s total at ~5-10s per cycle. Tune for document size.
4. **Single-quoted scalar for condition (`'=...'`)** — block scalar (`|-`) introduces whitespace Power Fx can't parse, causing "Incompatible type" errors.
5. **`Text()` wrapper on the variable** — `'="Status: Completed" in Text(Topic.ocr_payload)'` prevents type mismatch. Bare `Topic.ocr_payload` can fail even when declared as `string`.

### Batch Application
When fixing the same pattern across 8+ documentation topics:
1. Use the template above as the fix, changing only `document_type`, `displayName`, `triggerQueries`, and variable name per topic
2. Validate each file: `schema-lookup.bundle.js validate <file>` — must pass all checks
3. Apply via Copilot Studio code editor (manual paste — the only reliable path for Monaco)
4. Publish after all topics are saved

### Related Eval Failures
- "The dialog was executed more than 500 times" — caused by bare GotoAction
- Empty agent responses after long OCR processing — topic crashed before completing
- "Incompatible type" on condition formula — missing `Text()` wrapper or using `|-` block scalar
