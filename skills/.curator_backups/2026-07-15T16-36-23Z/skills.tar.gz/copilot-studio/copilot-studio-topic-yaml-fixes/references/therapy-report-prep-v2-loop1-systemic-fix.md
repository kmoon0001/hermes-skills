# Therapy Report Prep V2 — Loop 1 Systemic Fix

**Date:** 2026-07-03
**Bot ID:** `fd1bce12-cf47-f111-bec5-70a8a5b1c3a3`
**Workspace:** `D:/my agents copilot studio/Pac Coast Report Prep Agent/`
**Analysis:** `analysis-Therapy-Report-Prep-V2.md`

## What Was Done

### Agent Instructions
- **Created** root `agent.mcs.yml` (was missing/empty) with EVAL NO-CAVEAT STANDARDS CHECK and EVALUATION-SAFE ORCHESTRATION sections
- **Updated** `SNF Rehab Agent/agent.mcs.yml` — same eval sections injected after MICROSOFT LEARN ALIGNED ORCHESTRATION block

### Topic Backups
- **70 `.bak` files** created across `src/Topics/` (50) and `SNF Rehab Agent/topics/` (20)

### EndDialog + clearTopicQueue:true Added
- **Main agent (11 topics):** BuildSummaryForReport, ClarificationQuestionBuilder, ClassifyAndRouteRehabRecord_ESY, DeliverSummary, DischargeSummaryCheck, DisciplineSpecificBranching, Escalate, EvalAnalysis_LM9, GetDueReports, MissingElementChecklist, ProgressAnalysis_xNp, SkilledVsNonSkilledLanguageHelp
- **Sub-agent (8 topics):** ClassifyAndRouteRehabRecord, DischargeAnalysis, Escalate, EvalAnalysis, ManualIntakeFallback, ProgressAnalysis, RecertAnalysis, Search
- **Total: 19 topics** received EndDialog

### Corrupted Bytes Fixed
- **2 files:** EvalAnalysis_LM9.mcs.yml, ProgressAnalysis_xNp.mcs.yml — both had double-encoded emoji bytes (0x8f C1 control characters) in `additionalInstructions` causing `yaml.safe_load` to fail
- **Fix:** Binary-level strip of all bytes in 0x80-0x9f range, then text-level replacement of garbled Unicode replacement characters

### YAML Validation
- **69/69 valid** — all agent + topic files pass PyYAML `safe_load()`
- **5 empty stubs** (expected): ClassifyAndRouteRehabRecord, DischargeAnalysis, EvalAnalysis, ProgressAnalysis, RecertAnalysis (0 bytes each)

## Key Techniques

### Batch EndDialog via Python + PyYAML
```python
import yaml, os, shutil

def add_enddialog_to_topic(data):
    begin = data.get('beginDialog', {})
    actions = begin.get('actions', [])
    if not actions:
        return data, False
    has_ed = any(isinstance(a, dict) and a.get('kind') == 'EndDialog'
                 and a.get('clearTopicQueue') == True for a in actions)
    if not has_ed:
        actions.append({'kind': 'EndDialog', 'id': 'end-topic', 'clearTopicQueue': True})
        begin['actions'] = actions
        data['beginDialog'] = begin
        return data, True
    return data, False
```

### File-Based YAML Validation Loop
```python
import yaml, os
errors = []
for yaml_path in all_yaml:
    with open(yaml_path, 'rb') as f:
        content = f.read()
    if not content.strip():
        continue  # empty stub
    try:
        yaml.safe_load(content)
    except yaml.YAMLError as e:
        errors.append((yaml_path, str(e)))
```

### Corrupted Byte Detection
```python
with open(filepath, 'rb') as f:
    data = f.read()
bad = [i for i, b in enumerate(data) if 0x80 <= b <= 0x9f]
```

## Remaining Issues (Loop 2+)
1. Empty stub topics (5)
2. Question nodes blocking SR eval (MissingElementChecklist, DischargeSummaryCheck, EndofConversation, Escalate)
3. Nested routing to empty topics (ClassifyAndRouteRehabRecord_ESY)
4. webBrowsing=false vs Search publicDataSource conflict
5. Escalate ConditionGroup "yes" branch has no actions
6. BuildSummaryForReport empty triggerQueries
7. Placeholder flow IDs in CrossAgentAuditLog actions

## Files Modified
- `agent.mcs.yml` (root) — **CREATED**
- `SNF Rehab Agent/agent.mcs.yml` — UPDATED (backup: agent.mcs.yml.bak)
- `src/Topics/*.mcs.yml` — all 50 backed up, 19 modified
- `SNF Rehab Agent/topics/*.mcs.yml` — all 20 backed up, 8 modified
