# PT Caregiver Breakthrough — 95% Conv (Jun 17, 2026)

## The Problem
PT Conv stuck at 85% for weeks. 2 of 20 test cases failed — both caregiver-related:
- "assess caregiver competency documentation"
- "review caregiver education documentation"

## What Failed (Instruction-Level Checkboxes)
- MANDATORY language → 85%→80%
- CAREGIVER QUESTIONS section with 8-element checklist → 85%→85%
- Inline citation requirement → 95%→85%
- Any new instruction section with "MUST include ALL" → regression

## What Worked (Topic-Level Checkboxes)
- Baseline instructions (90% Conv) + topic YAML additionalInstructions with caregiver checklist → **95% Conv**
- The 8-element caregiver checklist (identity, content, teach-back, safety, supervision, carryover, escalation, discharge) placed in topic YAML `additionalInstructions` with "Include ALL of these elements with Met/Missing/Verify status"
- Templates at: `D:/my agents copilot studio/pt_topic_caregiver_competency_v2.yaml` and `pt_topic_caregiver_education_v2.yaml`

## Key Principle
**Checklists belong in topic YAML, not agent instructions.** Topic YAML scopes the checklist to only the questions that trigger that topic. Agent-level instructions with checklists cause the model to overcorrect across ALL responses.

## Confirmed Pattern
OT achieves 100% Conv using the same pattern — topic-level caregiver checklists, soft agent instructions.
