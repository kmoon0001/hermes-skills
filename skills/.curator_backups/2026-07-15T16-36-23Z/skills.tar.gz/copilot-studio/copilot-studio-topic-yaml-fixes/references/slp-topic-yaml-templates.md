# SLP Topic YAML Templates — Verified June 14 2026

All 5 SLP audit topics fixed and injected via Playwright. Complete pasteable YAML blocks.

## SLP Agent Info
- Bot ID: `6e437a77-a5dc-4984-90eb-4924eab10006`
- 5 audit topics + Dysphagia Analysis Audit + General SLP Clinical Inquiry
- Topics visible on Topics page (NOT all on Overview page)
- Progress Note and Recertification Note are NOT on Overview — must use Topics tab

## Key Pattern
All 5 topics follow the same structure:
- `kind: AdaptiveDialog` root
- `OnRecognizedIntent` trigger with 5 triggerQueries
- `SearchAndSummarizeContent` action with `additionalInstructions`
- `EndDialog` with `clearTopicQueue: true`
- Citation rules: `Cite CMS Chapter 15 and ASHA guidelines by natural source name. Do not output cite:1 or metadata tags.`
- No 800-char limit: `Be concise but complete. Prioritize accuracy over strict length limits.`
