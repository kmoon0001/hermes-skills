# PT Conv Regression History (Jun 16-17, 2026)

## Timeline

| Date | Time | Score | Change | Effect |
|------|------|-------|--------|--------|
| Jun 16 | AM | 90% | Baseline (original instructions) | 18/20 pass |
| Jun 16 | PM | 85% | Stacked fixes (cite ban + hedging) | -5% regression |
| Jun 16 | PM | 80% | Removed hedging only | -10% regression |
| Jun 17 | 7:32 | 90% | Citation requirement added | Restored baseline |
| Jun 17 | 9:17 | 85% | MANDATORY caregiver checklist | -5% regression |
| Jun 17 | 10:01 | 85% | After revert | Stable at 85% |
| Jun 17 | 11:48 | 85% | No change | Stable at 85% |
| Jun 17 | 1:35 | 70% | Corrupted topic YAML (CDP injection) | -15% regression |
| Jun 17 | 4:29 | **95%** | Baseline instr + topic caregiver checklist | HIGHEST EVER |
| Jun 17 | 4:43 | 85% | INLINE citation rule added | -10% regression |

## Proven Formula (95% Conv)

1. **Instructions**: PT baseline (5,969 chars) — soft language, no CRITICAL/MANDATORY/INLINE
2. **Caregiver Competency topic**: Checklist in additionalInstructions (Met/Missing/Verify format)
3. **Caregiver Education topic**: Checklist in additionalInstructions (Met/Missing/Verify format)
4. **Publish immediately after all changes**

## Regression Patterns

- CRITICAL/NEVER: 5-15% drop
- MANDATORY checklist in instructions: 5% drop
- "INLINE" citation rule: 10% drop
- Corrupted topic YAML: 15% drop
- Check in instructions + topics: 15% drop (cumulative corruption)

## Topic YAML Corruption

CDP clipboard injection permanently corrupts Monaco editor models.
Detection: Read topic YAML → <100 chars or "NO LINES" = corrupted.
Fix: Delete topic → recreate → manual paste only.
