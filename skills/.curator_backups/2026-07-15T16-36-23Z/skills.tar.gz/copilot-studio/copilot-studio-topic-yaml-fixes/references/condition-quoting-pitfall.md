# Condition Power Fx Quoting in YAML

When writing Power Fx conditions in YAML, **any expression with parentheses or dots must be wrapped in single quotes**. Without quotes, the YAML parser strips the content between parentheses, turning `=!IsBlank(First(System.Activity.Attachments))` into `=!IsBlank()`.

## Correct vs Incorrect

```yaml
# ✅ CORRECT — single-quoted, parentheses and dots preserved
condition: '=!IsBlank(First(System.Activity.Attachments))'
condition: '=!IsBlank(Trim(Topic.DocumentText))'
condition: '="Status: Completed" in Text(Topic.ocr_payload)'

# ❌ WRONG — unquoted, content stripped by YAML parser
condition: =!IsBlank(First(System.Activity.Attachments))
condition: =!IsBlank(Trim(Topic.DocumentText))

# ❌ WRONG — double-quoted, backslash escaping required
condition: "=!IsBlank(First(System.Activity.Attachments))"
```

## Signs You Hit This
- Condition renders as `=!IsBlank()` (empty parens) when read back from Dataverse
- Topic always takes the else branch
- The condition never evaluates correctly at runtime

## Fix
Re-paste the YAML with single quotes around the condition value. Use the code editor (`</>` button), not the visual editor, to ensure the YAML is parsed correctly.

## Why It Happens
YAML parsers treat parentheses `()` as special characters in unquoted scalars. `First(...)` looks like a YAML tag or function call. Single quotes tell YAML to treat everything inside as a literal string.

This applies to ALL Power Fx conditions in Copilot Studio YAML that use:
- Function calls: `First()`, `Trim()`, `IsBlank()`, `Concatenate()`
- Dot notation: `System.Activity.Attachments`, `Topic.Variable.Text.Content`
- Comparison operators: `in`, `=`, `<>`
