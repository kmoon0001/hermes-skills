# PT Conv 95% Breakthrough (June 17-18, 2026)

## The Formula

**Instructions kept at proven baseline (no caregiver checklist) + Caregiver checklist in topic YAML additionalInstructions = 95% Conv**

## Chronology

| Time | Action | Score | Notes |
|------|--------|-------|-------|
| Start | PT baseline with citation fix | 90% | 2 caregiver failures |
| Fix 1 | Added caregiver MUST checklist to instructions | 85% | Regression |
| Fix 2 | Reverted instructions, moved checklist to topic YAML | 70% | CDP corrupted topics |
| Fix 3 | Manual topic YAML paste + baseline instructions | 95% | **BREAKTHROUGH** |
| Fix 4 | Added "INLINE citation" rule to instructions | 85% | Regression |
| Fix 5 | OT-style stripped instructions (3,100 chars) | Regressed | No discipline content |
| Fix 6 | Hybrid: OT patterns + PT content (5,104 chars) | Pending | |

## Root Cause

1. **Caregiver checklist in instructions** → model overcorrects across ALL responses → 5-15% regression
2. **Checklist in topic YAML** → scoped to caregiver questions only → other responses unaffected
3. **CDP clipboard injection** → silently corrupts Monaco model → 70% scores
4. **Instruction simplification removing discipline content** → 10-15% regression

## The Working Topic YAML

```yaml
additionalInstructions: |-
  Assess caregiver [competency/education] documentation. Include ALL of these elements with Met/Missing/Verify status:
  1. Caregiver identity and role
  2. Training content delivered
  3. Return demonstration / teach-back result
  ...
  Provide corrective documentation for each Missing element.
  Cite CMS Chapter 15 and APTA guidelines by natural source name.
  Do not output cite:1 or metadata tags. Be concise but complete.
```

## Regression Triggers (NEVER add to instructions)

- CRITICAL: NEVER → 5-15% drop
- MANDATORY checklist → 5-10% drop
- "Cite INLINE within the response body" → 5% drop
- ANY new structured "MUST include ALL" section → regression
- Stripping discipline-specific content → 10-15% drop
