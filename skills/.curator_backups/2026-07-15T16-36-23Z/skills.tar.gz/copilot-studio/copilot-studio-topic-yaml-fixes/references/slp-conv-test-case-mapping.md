# SLP Conv Test Case Mapping (20 cases)

Mapped for diagnosis of SLP Conv 90% (June 14 2026).

## Test Cases and Topic Coverage

| # | Test Case | Maps To Topic | Status |
|---|-----------|---------------|--------|
| 1 | Can you audit this SLP evaluation report for completeness and compliance? | Eval Report | ✅ |
| 2 | Can you check if my SLP daily therapy note meets Medicare requirements? | Daily Note | ✅ |
| 3 | Can you review this SLP progress note for missing elements and compliance risks? | Progress Note | ✅ |
| 4 | Can you analyze this SLP discharge summary for documentation gaps and defensibility? | Discharge | ✅ |
| 5 | Can you evaluate my SLP recertification note for required elements and compliance? | Recertification | ✅ |
| 6 | Can you identify missing skilled justification in this SLP progress note? | Progress Note | ✅ |
| 7 | Can you assess if the diagnosis and prognosis are clearly documented in this SLP evaluation? | Eval Report | ✅ |
| 8 | Can you check if standardized tests are properly included in this SLP evaluation report? | Eval Report | ✅ |
| 9 | Can you review my SLP daily note for objective metrics and skilled interventions? | Daily Note | ✅ |
| 10 | Can you determine if caregiver safety is adequately addressed in this SLP documentation? | **CAREGIVER** | ❌ |
| 11 | Can you analyze if the plan of care and goals are updated in this SLP recert note? | Recertification | ✅ |
| 12 | Can you check for vague language in my SLP discharge summary and suggest improvements? | Discharge | ✅ |
| 13 | Can you evaluate if the functional status at discharge is clearly documented in this note? | Discharge | ✅ |
| 14 | Can you audit this SLP daily note for clear differentiation between skilled and aide services? | Daily Note | ✅ |
| 15 | Can you assess if the baseline comparison is included in this SLP progress note? | Progress Note | ✅ |
| 16 | Can you review if caregiver cognitive capacity is documented in this SLP note? | **CAREGIVER** | ❌ |
| 17 | Can you check if follow-up recommendations are present in this SLP discharge summary? | Discharge | ✅ |
| 18 | Can you analyze denial risk factors in this SLP recertification documentation? | Recertification | ✅ |
| 19 | Can you evaluate if daily objective metrics are present in this SLP daily therapy note? | Daily Note | ✅ |
| 20 | Can you review if recertification documentation meets Medicare compliance standards? | Recertification | ✅ |

## Diagnosis

- 18/20 cases have matching topics → 90% (exactly matches SLP Conv score)
- 2/20 cases (10, 16) are caregiver-related → NO matching topic
- Missing: SLP Caregiver Competency Assessment

## Fix Applied

Created SLP Caregiver Competency Assessment topic with trigger queries for caregiver safety, cognitive capacity, and training documentation. Expected to bring Conv from 90% → 95%+.

## Cross-Reference

PT has: "PT Eval Guard - Caregiver Competency Intake" → 100% Conv
OT has: "OT Caregiver Competency Prompt" → 100% Conv
