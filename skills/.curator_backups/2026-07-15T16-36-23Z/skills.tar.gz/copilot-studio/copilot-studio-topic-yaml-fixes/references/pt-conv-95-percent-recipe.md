# PT Conv 95% Breakthrough Recipe (Jun 17, 2026)

## The Formula

**Instructions (baseline, 5,969 chars) + Topic YAML caregiver checklist = 95% Conv**

Instructions stay at the proven 90% baseline. Caregiver checklist goes in topic YAML `additionalInstructions`, NOT in agent instructions.

## Failed Approaches (all caused regression)

| Approach | Score | Root Cause |
|----------|-------|------------|
| Remove hedging from instructions | 80% | Removed useful context |
| "CRITICAL: NEVER use cite:1" | 85% | Aggressive language pattern |
| MANDATORY caregiver checklist in instructions | 85% | Checklist in instructions |
| "MUST include ALL" caregiver elements in instructions | 70% | Checklist in instructions |
| "Cite INLINE within body" requirement | 85% | Overconstrains citation |
| Caregiver topic YAML via CDP clipboard injection | 70% | Topic YAML corrupted |

## What Worked

1. Baseline instructions restored (5,969 chars, 90% Conv)
2. Caregiver checklist placed in topic YAML `additionalInstructions`:
   - PT Eval Guard - Caregiver Competency Intake
   - PT Eval Guard - Caregiver Education Intake
3. Published → Conv eval: 95% (19/20 pass)

## Remaining Failure

1 test case: general education question (first turn, no record_id).
Grader: "citations not inline within response body."
NOT fixed by adding inline citation rule (caused regression).

## Key Files

- `pt_instructions_final.txt` — baseline instructions (5,969 chars)
- `pt_topic_caregiver_competency_v2.yaml` — caregiver competency topic YAML
- `pt_topic_caregiver_education_v2.yaml` — caregiver education topic YAML
- `pt_instructions_otstyle.txt` — OT-style simplified version (3,100 chars, untested)
