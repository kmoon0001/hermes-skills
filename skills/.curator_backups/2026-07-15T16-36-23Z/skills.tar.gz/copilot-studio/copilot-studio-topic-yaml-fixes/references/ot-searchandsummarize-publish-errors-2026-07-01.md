# OT / SearchAndSummarizeContent publish-error lessons (2026-07-01)

Scope: Copilot Studio audit agents using `SearchAndSummarizeContent`, `CreateSearchQuery`, `SendActivity`, and Dataverse API topic patches.

## Symptoms observed

- Copilot Studio topic list suddenly showed many topic errors after a batch patch.
- `pac copilot publish` failed after draft topic data looked locally valid.
- Publish diagnostic in `bot.synchronizationstatus.lastFinishedPublishOperation.diagnosticDetails` pointed to one action:
  - `AnalyzeOTRecertificationNote`
  - action `search-analyze-ot-recertification-note`
  - `MissingRequiredProperty: ApiVersion`
  - `EmptyCollection: DataSources cannot be empty`

## Root causes

1. `autoSend: false` was added to `SearchAndSummarizeContent` nodes. The OT_Specialist runtime/schema rejected that property and surfaced topic errors. Do not batch-add unsupported node properties based only on intuition.

2. One Recertification topic contained an invalid copied datasource block inside `SearchAndSummarizeContent`:
   - `fileSearchDataSource:`
   - `knowledgeSources:`
   - `azureOpenAIOnYourDataSource:`

   The platform interpreted this as an invalid action-reference datasource shape and failed publish with `ApiVersion` / `DataSources` diagnostics. The working pattern for these OT topics was the simpler node shape with `applyModelKnowledgeSetting: true`.

## Recovery pattern

1. Remove invalid `autoSend: false` lines from all affected topic YAML.
2. Pull `bot.synchronizationstatus` from the bot row and read `lastFinishedPublishOperation.diagnosticDetails`; do not guess from the UI error count.
3. For `MissingRequiredProperty ApiVersion` / `DataSources cannot be empty` on `SearchAndSummarizeContent`, inspect the named topic/action and remove unsupported datasource blocks unless there is a known-good schema example for that exact runtime.
4. Re-dump topics and search for forbidden fields before publishing:
   - `autoSend:`
   - `fileSearchDataSource:`
   - `azureOpenAIOnYourDataSource:`
5. Run the local inspector/schema validation, then publish.

## Safe baseline shape

Use this shape for knowledge-grounded OT audit topics unless a validated template says otherwise:

```yaml
- kind: CreateSearchQuery
  id: create-search-query
  userInput: =System.Activity.Text
  result: Topic.SearchQuery

- kind: SearchAndSummarizeContent
  id: search-topic
  latencyMessageSettings:
    allowLatencyMessage: false
  variable: Topic.Answer
  userInput: =Topic.SearchQuery.SearchQuery
  additionalInstructions: |-
    First sentence directly answers the user question.
    Use knowledge sources silently for grounding.
  applyModelKnowledgeSetting: true

- kind: SendActivity
  id: send-answer
  activity: =Topic.Answer

- kind: EndDialog
  id: end-topic
  clearTopicQueue: true
```

If eval literally displays `=Topic.Answer`, change only SendActivity to:

```yaml
activity: "{Topic.Answer}"
```

Then retest; do not add unsupported properties to suppress auto-output unless schema validation proves they are accepted.
