# Instruction Regression Pattern — Aggressive Language

**Date**: June 17, 2026
**Agent**: PT_Specialist
**MS Learn anchor**: "Keep it simple" / "The system treats agent instructions similar to code. The wrong code might break your system."

## Regression Cascade

| Change | Baseline | Result | Delta |
|--------|----------|--------|-------|
| Original 90% baseline | 90% Conv | — | — |
| "CRITICAL: NEVER use numbered citations" | 90% | 85% | -5% |
| Restore baseline + remove hedging only | 90% | 80% | -10% |
| "MANDATORY — ALWAYS include ALL of:" checklist in instructions | 90% | 85% | -5% (2nd attempt) |
| "MUST include ALL of these elements" caregiver checklist in instructions | 85% | 70% | -15% |

## Pattern

**ANY structured checklist in agent instructions causes regression.** This includes:
- `MUST include ALL of: 1. X, 2. Y, 3. Z...`
- `MANDATORY — when asked about X, ALWAYS include ALL of...`
- `CRITICAL: NEVER do X`
- Bullet-point checklists with explicit "must"/"always"/"never" directives

**What does NOT cause regression:**
- Soft global rules: "Cite knowledge sources by natural source name"
- Citation requirements: "EVERY response MUST include at least one citation" (this is a single behavior, not a checklist)
- Conciseness rules: "Keep responses concise — limit each section to 2-3 sentences"
- "Do not output cite:1 or metadata tags" (negation is fine; forced "include ALL of X,Y,Z" is not)

## The Fix

Checklist content belongs in **topic YAML `additionalInstructions`**, NOT in agent-level instructions. Topic YAML scopes requirements to specific triggered question types without affecting the model's behavior across all responses.

## Per MS Learn

From MS Learn generative mode guidance:
- "Try removing your agent instructions and adding individual instructions back slowly. Test between each addition."
- "Give the agent an out — don't force it to fabricate."
- The system treats instructions like code — aggressive directives break the model's reasoning pattern.
