# Audit Topic Pipeline — Standard Pattern (Feedback B, Jul 2026)

Every documentation-audit topic (Evaluation, Progress Note, Treatment Encounter, Recert/UPOT, Discharge Summary, Episode of Care) follows this pipeline:

```
Question (FilePrebuiltEntity) → ConditionGroup (!IsBlank file) → InvokeAIBuilderModelAction → SendActivity (audit results)
```

## Core YAML Structure

```yaml
kind: AdaptiveDialog
modelDescription: "Audits [Note Type] for Medicare Part B denial risk..."
mcs.metadata:
  componentName: [Component Name]
  description: |-
    [Same description, active voice, 1-2 sentences, with "Does not..." negative scope]
beginDialog:
  kind: OnRecognizedIntent
  id: main
  intent:
    displayName: TDFA [Name] Audit
    triggerQueries:
      - audit [note]
      - [note] audit
      ...
  actions:
    - kind: Question
      id: ask_for_document
      variable: init:Topic.TopicUploadedDoc
      entity: FilePrebuiltEntity
      valueType:
        kind: FileType
    - kind: ConditionGroup
      id: check_file_uploaded
      conditions:
        - id: file_is_valid
          condition: =!IsBlank(Topic.TopicUploadedDoc)
          actions:
            - kind: InvokeAIBuilderModelAction
              id: invokeAIBuilderModelAction
              input:
                binding:
                  Document_20input: =Topic.TopicUploadedDoc
              output:
                binding:
                  predictionOutput: Global.GlobalAuditResultstext
              aIModelId: [GUID]
            - kind: SendActivity
              id: send_audit_results
              activity: "=Global.GlobalAuditResultstext"
      elseActions:
        - kind: SendActivity
          id: send_error_message
          activity: It looks like you didn't upload a valid file.
    - kind: EndDialog
      id: end-topic
      clearTopicQueue: true
```

## Key Rules

1. **Do NOT add InvokeFlowAction for OCR** — The AI Builder model handles documents natively (PDFs, images, text). Passing a FilePrebuiltEntity blob to a flow expecting `string` type causes `Input variable of incorrect type: File` errors.

2. **Pass file blob directly** — `Document_20input: =Topic.TopicUploadedDoc` (no `.Content` suffix). The `.` operator on blob values causes `PowerFxError: '.' operator cannot be used on Blob values`.

3. **Model IDs vary by note type** — Progress Report uses model `7ee33989-8f83-4035-b99e-345d380a4d41` while all others use `9dd0f78c-43a2-4e68-8b6a-ca41de4955ab`. Don't assume all topics share the same model.

4. **Descriptions follow MS Learn format for generative AI**:
   - Active voice, present tense starts with "Audits..."
   - 1-2 sentences max
   - Include negative scope: "Does not review..."
   - componentName + description + modeldescription all populated

5. **SendActivity after AI Builder** — Without it, the audit result is stored to `Global.GlobalAuditResultstext` but the user sees silence. Always add `SendActivity` in the success path.

## Publishing Via .ps1 (most reliable)

Use a standalone `.ps1` file with `Invoke-RestMethod`, not inline bash+Powershell (fragile quoting). Pattern:

```powershell
$token = az account get-access-token --resource $ORG --query accessToken -o tsv
$body = @{ data = $yamlString }
Invoke-RestMethod -Uri $patchUrl -Method Patch -Headers $headers -Body ($body | ConvertTo-Json -Depth 100 -Compress)
```

## Flow Binding Pitfall

The OCR Text Extraction flow (`c71672f2`) expects `file_content: string` (Base64 text). Passing a `FilePrebuiltEntity` blob to a string parameter causes type mismatch at publish validation ("Input variable 'File Content' is of incorrect type: File"). The AI Builder model is a better path for direct file input.
