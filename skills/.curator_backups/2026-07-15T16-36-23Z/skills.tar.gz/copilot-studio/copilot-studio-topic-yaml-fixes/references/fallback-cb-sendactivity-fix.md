# Fallback and Conversational Boosting Fix Pattern

Use when `unsupportedactivity.notextresponse` errors appear in eval details, especially on general knowledge questions that don't match any specific topic.

## Root Cause

`SearchAndSummarizeContent` with `variable: Topic.Answer` writes the result to a variable. If no `SendActivity` follows, the variable is never sent to the user. The eval framework sees no text → `ExecutionFailed`.

Fallback and Conversational Boosting (CB) are catch-all system topics for ALL unmatched queries. If they're broken, every unmatched question fails.

## Diagnostic

1. Fetch `/details` for the eval run.
2. Count cases with `errorCodes: ['unsupportedactivity.notextresponse']`.
3. Check if these cases have `triggeredPluginSchemaNames: []` (no topic matched).
4. Read the Fallback and CB topic YAML — look for `variable: Topic.Answer` without a matching `SendActivity`.

## Fix Template

### Fallback Topic
```yaml
kind: AdaptiveDialog
beginDialog:
  kind: OnUnknownIntent
  id: main
  actions:
    - kind: SearchAndSummarizeContent
      id: search_fallback
      latencyMessageSettings:
        allowLatencyMessage: false
      variable: Topic.Answer
      userInput: =System.Activity.Text
      additionalInstructions: |-
        [Domain-specific grounding instructions]
        - Sentence 1 must directly answer the exact question.
        - Plain text only. No metadata or adaptive cards.
      applyModelKnowledgeSetting: true
    - kind: SendActivity
      id: send_fallback_answer
      activity: =Topic.Answer
    - kind: EndDialog
      id: end_fallback
      clearTopicQueue: true
inputType: {}
outputType: {}
```

### Conversational Boosting Topic
Same structure but with `priority: -1` (lower priority than Fallback):
```yaml
kind: AdaptiveDialog
beginDialog:
  kind: OnUnknownIntent
  id: main
  priority: -1
  actions:
    - kind: SearchAndSummarizeContent
      id: search_cb
      latencyMessageSettings:
        allowLatencyMessage: false
      variable: Topic.Answer
      userInput: =System.Activity.Text
      additionalInstructions: |-
        [Concise grounding — CB should be short for routing agents]
      applyModelKnowledgeSetting: true
    - kind: SendActivity
      id: send_cb_answer
      activity: =Topic.Answer
    - kind: EndDialog
      id: end_cb
      clearTopicQueue: true
inputType: {}
outputType: {}
```

## Key Rules
- `SendActivity` MUST reference the same variable as `SearchAndSummarizeContent`.
- `EndDialog` MUST have `clearTopicQueue: true` (prevents topic stacking).
- For audit agents: REMOVE 800-char limit from CB/Fallback additionalInstructions.
- For routing agents (TDA): KEEP 800-char limit on CB.
- After Dataverse PATCH, GET the topic back and verify `SendActivity` is present.

## Verification Script Pattern
```javascript
const verify = await dv(`/api/data/v9.2/botcomponents(${topicId})?$select=data`, t);
const newData = verify.data || '';
console.log('HAS_SENDACTIVITY:', newData.includes('SendActivity'));
console.log('HAS_ENDDIALOG:', newData.includes('EndDialog'));
console.log('HAS_CLEAR:', newData.includes('clearTopicQueue: true'));
```
