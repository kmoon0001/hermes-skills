# Power BI Connector for Copilot Studio — Research Summary (Jun 19, 2026)

## Architecture
Copilot Studio Agent → Power BI Connector Action (Power Platform) → Power BI REST API → Semantic Model → DAX Query → JSON Response

## Auth Options

### Option A: Service Principal (recommended for healthcare)
1. Register app in entra.microsoft.com → save Client ID + Tenant ID
2. Create client secret → save value
3. Add API permissions: Dataset.Read.All, Workspace.Read.All → grant admin consent
4. Enable tenant settings (Power BI Admin Portal):
   - "Allow service principals to use Power BI APIs" = ON (Developer settings)
   - "Dataset Execute Queries REST API" = ON (Developer settings)
5. Add service principal to workspace as Contributor+

### Option B: Delegated user auth (OAuth)
Simpler but uses individual user credentials. Not recommended for production healthcare agents.

## Connector Response Limit
Per MS Learn: 500 KB max response per connector action. Fix: configure DAX queries with TOPN() and SUMMARIZE() to limit data.

## DAX Query APIs

### Execute Queries (JSON) — simpler
- Endpoint: `executeQueries`
- Works on Pro, PPU, Premium/Fabric
- Hard limit: 100,000 rows, 1,000,000 values
- JSON response

### Execute DAX Queries (Arrow) — faster for large datasets
- Endpoint: `executeDaxQueries`
- Premium or Fabric capacity only
- No fixed row limit (use resultsetRowcountLimit)
- Apache Arrow IPC response (needs pyarrow)

## Connection Setup in Copilot Studio
1. Create connection in Power Apps (NOT Copilot Studio directly)
2. Power Apps → More → Discover all → Data → Custom connectors
3. Configure security (OAuth 2.0 with service principal)
4. Then the connector appears in Copilot Studio Tools

## Key MS Learn References
- https://learn.microsoft.com/power-bi/developer/execute-dax-queries-arrow/overview
- https://learn.microsoft.com/troubleshoot/power-platform/copilot-studio/actions/connector-request-failure
- https://learn.microsoft.com/power-bi/developer/embedded/service-principal-profile-sdk
- https://learn.microsoft.com/training/modules/extend-declarative-agents-connector-actions-copilot-studio/

## QM Coach V2 Specific
- Dashboard: "One Clinical Outcomes Dashboard" on Microsoft Fabric
- Workspace: "Restricted-Reports"
- Pages: Clinical Outcomes - Current Patients, ADLs and Ambulation
- Metrics: Avg Functional Score, Patients w Improvement/Decline, Walking 10 Ft Exclusions
- Plan file: D:/my agents copilot studio/qm_coach_v2_powerbi_plan.md
