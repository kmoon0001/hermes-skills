# Power Fx Condition Formatting in Copilot Studio YAML

## The 3 Quoting Traps

### Trap 1: Single-quoted conditions strip content
```yaml
# BROKEN — single quotes cause YAML parser to strip content inside ()
condition: '=!IsBlank(First(System.Activity.Attachments))'

# WORKS — bare Power Fx, no quotes
condition: =!IsBlank(First(System.Activity.Attachments))

# ALSO WORKS — double-quoted with escaped inner quotes
condition: "=!IsBlank(First(System.Activity.Attachments))"
```
The Copilot Studio YAML parser eats the content inside parentheses when the condition is single-quoted. Always use bare (unquoted) or double-quoted format.

### Trap 2: StringPrebuiltEntity + `=` comparison fails publish
```yaml
# BROKEN — publish validator throws IdentifierNotRecognized
condition: =Topic.VarName = 'Some Value'

# WORKS — use `in Text()` operator instead
condition: '="Some Value" in Text(Topic.VarName)'
```
With `StringPrebuiltEntity` on a Question node, the publish validator can't resolve the variable type for `=` comparisons. The `in Text()` pattern validates correctly.

### Trap 3: Variables need `init:` prefix with StringPrebuiltEntity
```yaml
# BROKEN — variable won't be declared
variable: Topic.VarName

# WORKS
variable: init:Topic.VarName
```

## Text-Paste Path Pattern (file OR text input)

Use this when a topic accepts both file uploads and pasted text:

```yaml
- kind: Question
  id: question_input
  variable: init:Topic.DocumentText
  entity:
    kind: StringPrebuiltEntity
  prompt: Paste the text of or upload the document...

- kind: ConditionGroup
  id: conditionGroup_file_check
  conditions:
    - id: condition_file_uploaded
      condition: =!IsBlank(First(System.Activity.Attachments))
      actions:
        - kind: InvokeAIBuilderModelAction
          input:
            binding:
              ModelInput: =First(System.Activity.Attachments).Content
          output:
            binding:
              predictionOutput: Topic.Result
          aIModelId: <model-guid>

        - kind: SendActivity
          activity: "{Topic.Result.text}"

  elseActions:
    - kind: ConditionGroup
      id: conditionGroup_text_check
      conditions:
        - id: condition_has_text
          condition: =!IsBlank(Trim(Topic.DocumentText))
          actions:
            - kind: SearchAndSummarizeContent
              id: search_text_audit
              variable: Topic.AuditResult
              userInput: '=Concatenate(...)'
              applyModelKnowledgeSetting: true
              responseCaptureType: FullResponse

            - kind: SendActivity
              activity: "{Topic.AuditResult}"

      elseActions:
        - kind: GotoAction
          actionId: question_input
```

Key rules:
1. Question node MUST have an entity (`StringPrebuiltEntity`) — `MissingRequiredProperty` otherwise
2. File check uses `First(System.Activity.Attachments)` not `!IsBlank(Topic.DocumentText)`
3. AI Builder binding uses `=First(System.Activity.Attachments).Content` (extracts File type)
4. Text check uses `Trim(Topic.DocumentText)` to handle whitespace-only input
5. SendActivity in file path uses `.text` property: `{Topic.Result.text}`

## Document Upload Intake Fix (SR eval improvement)

Replace `ClosedListEntity` with `StringPrebuiltEntity` + `in Text()` conditions + generative else:

```yaml
# Before: ClosedListEntity → Question blocks until menu match
# After: StringPrebuiltEntity → conditions + else catches anything
condition: '="Evaluation and Plan of Care" in Text(Topic.DocumentTypeSelection)'
condition: '="Progress Report" in Text(Topic.DocumentTypeSelection)'
# etc.

elseActions:
  - kind: SearchAndSummarizeContent
    id: search_catchall
    variable: Topic.FallbackResult
    userInput: '=Concatenate("Handle this request: ", Topic.DocumentTypeSelection)'
    applyModelKnowledgeSetting: true
    responseCaptureType: FullResponse
  - kind: SendActivity
    activity: "{Topic.FallbackResult}"
  - kind: EndDialog
    clearTopicQueue: true
```

## Publish Caching

`pac copilot publish` caches **failed** results with the original timestamp. After fixing the underlying error, pac still returns the cached failure.

**Workarounds:**
1. Check real publish status via Dataverse API:
   `GET /bots({botId})?$select=synchronizationstatus` → parse `lastFinishedPublishOperation.diagnosticDetails`
2. Clear pac auth: `pac auth clear` then re-authenticate
3. Use Copilot Studio UI Publish button (bypasses pac cache)
