# System Topic Patterns: Question Nodes & Missing EndDialog

## Question Node → SendActivity + EndDialog

System topics (Greeting, Goodbye, Conversation Start, Multiple Topics Matched, End of Conversation) with `kind: Question` nodes break SR eval because the agent asks a question instead of answering.

### Greeting — BEFORE (broken)
```yaml
actions:
  - kind: Question
    variable: init:Topic.navigation_level1
    prompt: Hello, I'm the Therapy Documentation Feedback agent. What can I help you with today?
    entity:
      kind: EmbeddedEntity
        items:
          - id: Review my documentation
          - id: Other
  - kind: ConditionGroup
    ...
  - kind: CancelAllDialogs  # ← also broken!
```

### Greeting — AFTER (fixed)
```yaml
actions:
  - kind: SendActivity
    activity: Hello, I am the Therapy Documentation Feedback agent. I can answer questions about Medicare therapy documentation requirements. How can I help you today?
  - kind: EndDialog
    clearTopicQueue: true
```

## CancelAllDialogs → EndDialog

`CancelAllDialogs` terminates the conversation without producing output. Replace with `EndDialog` + `clearTopicQueue: true`.

### Reset Conversation — BEFORE
```yaml
actions:
  - kind: SendActivity
    activity: What can I help you with?
  - kind: ClearAllVariables
    variables: ConversationScopedVariables
  - kind: CancelAllDialogs  # ← broken
```

### Reset Conversation — AFTER
```yaml
actions:
  - kind: SendActivity
    activity: What can I help you with?
  - kind: ClearAllVariables
    variables: ConversationScopedVariables
  - kind: EndDialog
    clearTopicQueue: true
```

## Catch-All Topic: Fallback When KB Empty

When `OnUnknownIntent` uses `SearchAndSummarizeContent` with a `ConditionGroup` that only acts when `!IsBlank(Topic.Answer)`, the topic silently exits if KB returns nothing.

### Conversational boosting — BEFORE (broken)
```yaml
actions:
  - kind: SearchAndSummarizeContent
    variable: Topic.Answer
    userInput: =System.Activity.Text
    applyModelKnowledgeSetting: true
  - kind: ConditionGroup
    conditions:
      - condition: =!IsBlank(Topic.Answer)
        actions:
          - kind: EndDialog
            clearTopicQueue: true
    # NO elseActions — silent exit when KB empty!
```

### Conversational boosting — AFTER (fixed)
```yaml
actions:
  - kind: SearchAndSummarizeContent
    variable: Topic.Answer
    userInput: =System.Activity.Text
    applyModelKnowledgeSetting: true
  - kind: ConditionGroup
    conditions:
      - condition: =!IsBlank(Topic.Answer)
        actions:
          - kind: EndDialog
            clearTopicQueue: true
    elseActions:
      - kind: SendActivity
        activity: Based on my knowledge sources, I can provide guidance on Medicare therapy documentation compliance. Please ask a specific question about CMS Chapter 15 requirements, Jimmo v Sebelius standards, Ensign 7 Habits documentation framework, or Medicare Part B skilled therapy guidelines.
      - kind: EndDialog
        clearTopicQueue: true
```

## Missing EndDialog in Simple Topics

Topics with only `SendActivity` or `BeginDialog` but no `EndDialog` silently hang.

### Thank You — BEFORE
```yaml
actions:
  - kind: SendActivity
    activity: You are welcome!
  # NO EndDialog!
```

### Thank You — AFTER
```yaml
actions:
  - kind: SendActivity
    activity: You are welcome! I am here to help.
  - kind: EndDialog
    clearTopicQueue: true
```

## Full Topic Checklist

For every active topic, verify:
1. No `kind: Question` (except in interactive wizard topics like OCR)
2. Has `EndDialog` with `clearTopicQueue: true` at the end
3. No `CancelAllDialogs` (replace with EndDialog)
4. Any `SearchAndSummarizeContent` has a fallback path when answer is empty
5. `BeginDialog` targets exist and are active
