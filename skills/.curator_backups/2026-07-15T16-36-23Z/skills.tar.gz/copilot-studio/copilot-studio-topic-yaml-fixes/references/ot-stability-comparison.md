# OT vs PT/SLP/TDA — Full Side-by-Side (June 18, 2026)

## Topic Architecture

### OT (99% SR, stable)
- 20 topics total, 20 ON
- 5 audit topics: Progress Note, Daily Note, Recertification Note, Evaluation, Discharge
- 0 guard/intake topics
- 6 other: Exact Intake topics (OT Recert Missing Elements Exact Intake, OT Progress Missing Elements Exact Intake), Clinical Documentation Standards, Caregiver Competency Prompt, Insurance Denial Risk Prompt, General Knowledge
- 9 system topics

### PT (95% Conv)
- 31 topics total, 31 ON
- 7 audit topics
- 15 guard topics: Denial Risk Intake, Daily Note Compliance Intake, Progress High Risk Intake, Fall Risk Intake, Functional Outcomes Intake, CPT Alignment Intake, Skilled Justification Intake, Section GG Intake, Continued Care Intake, Fall Interventions Intake, Recommendations Intake, Missing Components Intake, Evaluation Compliance Intake, Caregiver Competency Intake, Caregiver Education Intake
- 9 system topics

### SLP (90% Conv, drifting)
- 36 topics total, 36 ON
- 10 audit topics: Progress Note, Discharge Summary, Review Standard, Caregiver Competency Assessment, Denial Risk Assessment, Daily Therapy Note, Recertification Note, Evaluation Report, Dysphagia Analysis Audit, General Clinical Inquiry
- 17 guard topics: Denial Risk Recert, Recert Goals POC, Eval Standardized Tests, Discharge Followup, Discharge Vague Language, Progress Missing Elements, Eval Completeness, Discharge Regulatory, Progress Skilled Justification, Eval Diagnosis Prognosis, Discharge Functional Status, Daily Objective Metrics, Caregiver Safety, Progress Baseline Compare, Daily Skilled vs Aide, Caregiver Cognitive Capacity, Recert Medicare Compliance
- 9 system topics

### TDA (96% SR)
- 33 topics total, 30 ON (3 OFF: Work IQ Preview topics)
- 11 audit topics: Recertification Audit, Discharge Audit, Evaluation Audit, Progress Note Audit, Daily Note Audit, Missing Element Checklist, Habit Compliance Check, Longitudinal Compliance Audit, Audit Self-Help Guide, Medicare Part B Auditor, Medicare Part A/PDPM Auditor
- 0 guard topics
- 10 other: agents (OT_Specialist, PT_Specialist, SLP_Specialist), routing/classification topics

## Knowledge Sources

### OT (8 sources, all AOTA discipline-specific)
1. AOTA Scope of Practice
2. AM-PAC Outcome Measure (Boston University)
3. AOTA Home Modifications Practice
4. AOTA Occupational Therapy Practice Framework
5. NINDS Patient/Caregiver Education
6. AOTA Standards and Competencies
7. AOTA Documentation Practice Resources
8. Likely shared sources not listed (CMS, Ensign)

### PT (5 sources)
1. APTA Clinical Practice Guidelines
2. CMS Medicare Learning Network — Therapy Services
3. Therapy Shared Knowledge — Ensign compliance
4. Core Clinical Manuals — CMS PDPM, Part B, MDS 3.0, Jimmo, Ch5&Ch15
5. (shared source)

### SLP (5 sources)
1. ASHA Scope of Practice in Speech-Language Pathology
2. CMS Medicare Learning Network Therapy Resources
3. Therapy Shared Knowledge — Ensign compliance
4. Core Clinical Manuals — CMS PDPM, Part B, MDS 3.0, Jimmo, Ch5&Ch15
5. (shared source)

### TDA (2 sources)
1. Therapy Shared Knowledge — Ensign compliance
2. Core Clinical Manuals — CMS PDPM, Part B, MDS 3.0, Jimmo, Ch5&Ch15

## Instruction Comparison

| Section | OT | PT | SLP | TDA |
|---------|-----|-----|-----|-----|
| Clinical Role | ✅ | ✅ | ✅ | ❌ (Routing Logic) |
| Response Format | ✅ | ✅ | ✅ | ❌ |
| Response Behavior | ✅ | ✅ | ✅ | ❌ |
| Format Rules | ❌ | ✅ | ✅ | ❌ |
| Discipline-Specific | ❌ | ✅ | ✅ | ❌ |
| XAI & Transparency | ✅ | ✅ | ✅ | ❌ |
| Conversation Continuity | ✅ | ✅ | ✅ | ❌ |
| Safety | ✅ | ✅ | ✅ | ✅ |
| Length (chars) | 6,002 | 5,959 | 4,851 | 5,237 |

## Key Patterns

1. **Guard topics = instability**: The single biggest difference between stable OT and drifting SLP/PT is the number of guard/intake topics. Each guard topic adds a routing decision the model must make. With 15+ guard topics, the model routes inconsistently across runs.

2. **Discipline-specific knowledge = grounding**: OT has 8 AOTA-specific sources. PT and SLP rely more on shared sources. TDA has only shared sources. The more discipline-specific knowledge, the more stable the agent.

3. **Instruction complexity has diminishing returns**: OT's 5-section structure works for OT because of its specific topic/knowledge architecture. Copying it to agents with different architectures caused regression.

## Root Cause Summary for SLP Drift

1. 17 guard topics causing routing instability (contrast: OT has 0)
2. Had "CRITICAL: NEVER" citation language in instructions (proven regression poison)
3. OT-style simplification applied and not reverted (instructions at 3,045 chars instead of 4,861)
4. 5 knowledge sources vs OT's 8
