# Corrupted Topic Detection and Recovery

## Detection

| Symptom | Root Cause | Action |
|---------|-----------|--------|
| Monaco shows "NO LINES" or 0-8 chars | CDP clipboard injection corrupted model | Delete + recreate |
| Save button won't enable (Space+Backspace fails) | Monaco model is corrupted | Delete + recreate |
| Topic name shows as "PT_Specialist" in code editor | YAML content is empty | Delete + recreate |
| `botcomponents(${guid})?$select=name` returns agent name not topic name | YAML corrupted | Delete + recreate |
| Score drops 10-15% after topic "fix" | Save committed corrupted/old content | Verify then recreate |

## Recovery Procedure

1. **Delete** the corrupted topic from Copilot Studio UI
2. Create new topic: **Add a topic → From blank**
3. Name it with the EXACT same name as the deleted topic
4. Open code editor, paste FULL YAML from file
5. Type one character + Backspace to unlock Save
6. Save
7. Verify: re-open code editor, paste should show full content (>500 chars)

## Why CDP Clipboard Injection Fails

The Monaco editor lives in an iframe. Three failure modes:
1. `textarea.value` setter writes to accessibility textarea, not model → Save commits old content
2. Clipboard paste doesn't trigger React onChange → Save button stays disabled
3. Space+Backspace enables Save but if #1 happened, old content is committed

## Prevention

- After every CDP injection, verify topic YAML by re-reading Monaco
- If any topic shows <100 chars, delete and have user recreate manually
- Never chain multiple CDP topic injections in one session without verifying each
