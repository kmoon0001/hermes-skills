# Working Topic YAML Examples (Validated June 14 2026)

## PT Daily Note (Fixed — 100% Conv achieved)
```yaml
kind: AdaptiveDialog
beginDialog:
  kind: OnRecognizedIntent
  id: main
  intent:
    displayName: Analyze PT Daily Note
    triggerQueries:
      - audit pt daily note
      - check pt daily note compliance
      - is this pt daily note skilled
      - verify pt daily therapy documentation
      - analyze physical therapy daily note

  actions:
    - kind: SearchAndSummarizeContent
      id: search_AnalyzePTDailyNote
      latencyMessageSettings:
        allowLatencyMessage: false

      userInput: =System.Activity.Text
      additionalInstructions: |-
        Audit this PT daily note for compliance. Focus on:
        1. Skilled PT intervention documented (therapeutic exercise parameters, gait training, neuromuscular re-education, manual therapy techniques)
        2. Objective patient response with measurable data (assist levels, distance, TUG/Berg scores, ROM, strength grades)
        3. Medical necessity — treatment relates to goals and requires PT skill level per CMS Ch. 15
        4. Functional outcomes linked to mobility, balance, or safe discharge
        Use risk levels (High/Moderate/Low). Cite CMS Chapter 15 and APTA guidelines by natural source name. Do not output cite:1 or metadata tags.
      applyModelKnowledgeSetting: true

    - kind: EndDialog
      id: end-topic
      clearTopicQueue: true

inputType: {}
outputType: {}
```

## SLP Daily Therapy Note (Fixed — partial improvement)
```yaml
kind: AdaptiveDialog
beginDialog:
  kind: OnRecognizedIntent
  id: main
  intent:
    displayName: Analyze SLP Daily Therapy Note
    triggerQueries:
      - analyze SLP daily note
      - review speech therapy daily note
      - SLP daily therapy note audit
      - check SLP daily note for compliance
      - assess SLP daily note quality

  actions:
    - kind: SearchAndSummarizeContent
      id: searchDailyNote
      latencyMessageSettings:
        allowLatencyMessage: false

      userInput: =System.Activity.Text
      additionalInstructions: |-
        Audit this SLP daily therapy note for Medicare compliance. Analyze against CMS Chapter 15, Jimmo v. Sebelius, ASHA Scope of Practice, PDPM, and 42 CFR 424-24.
        1. Measurable progress toward goals (objective data, percentages, cue levels)
        2. Skilled service demonstration — why an SLP was required, not routine care
        3. Patient response with specific clinical examples
        4. Continued skilled need rationale for next session
        5. Functional reporting and denial risk indicators
        Use risk levels (High/Moderate/Low). Cite CMS Chapter 15 and ASHA guidelines by natural source name. Do not output cite:1 or metadata tags.
        Be concise but complete. Prioritize accuracy over strict length limits.
      webBrowsing: false
      applyModelKnowledgeSetting: true

    - kind: EndDialog
      id: end_topic_daily
      clearTopicQueue: true

inputType: {}
outputType: {}
```

## Key Patterns
- Always start with `kind: AdaptiveDialog`
- `SearchAndSummarizeContent` + `EndDialog` + `clearTopicQueue: true`
- `applyModelKnowledgeSetting: true` (never false)
- `webBrowsing: false` on SLP topics (optional on others)
- Citation rule: `Cite [discipline] guidelines by natural source name. Do not output cite:1 or metadata tags.`
- Length rule: `Be concise but complete. Prioritize accuracy over strict length limits.` (NOT "Keep response under 800 characters")
