# SearchAndSummarizeContent must explicitly send Topic.Answer

Use this for Copilot Studio document-review topics that call `SearchAndSummarizeContent`, store a result, then end silently.

## Symptom

The topic appears to run, but the user receives no substantive answer or the conversation ends after retrieval/generation.

## Required topic shape

For document-review workflows:

```yaml
- kind: SearchAndSummarizeContent
  id: search_audit
  variable: Topic.Answer
  userInput: =System.Activity.Text
  additionalInstructions: |-
    ...

- kind: SendActivity
  id: send_topic_answer
  activity: =Topic.Answer

- kind: EndDialog
  id: end-topic
```

## Repair rules

1. Add or preserve `variable: Topic.Answer` on every `SearchAndSummarizeContent` action that should answer the user.
2. Insert `SendActivity` with `activity: =Topic.Answer` before `EndDialog`.
3. If a `SendActivity` already exists after the search but uses a literal, empty, or card-like activity, change it to `=Topic.Answer` unless the topic intentionally sends a different message.
4. Keep `EndDialog` after the send to prevent loops.
5. Validate by parsing YAML and by re-reading live botcomponent data after PATCH/push.

## Pitfalls

- `{Topic.Answer}` and `=Topic.Answer` are not interchangeable in all contexts. Prefer `=Topic.Answer` for plain SendActivity expression binding when repairing live topic YAML.
- Do not remove clinical, compliance, or regulatory instructions while inserting the send node.
- Publish diagnostics may surface unrelated blockers after this fix; treat them as real blockers and resolve in order rather than assuming the SendActivity patch failed.
