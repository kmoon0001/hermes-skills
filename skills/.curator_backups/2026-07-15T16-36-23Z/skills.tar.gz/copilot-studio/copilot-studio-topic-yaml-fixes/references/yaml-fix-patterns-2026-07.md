# YAML Condition Format — Bare vs Quoted Power Fx

## Problem
The Copilot Studio code editor's YAML parser strips content inside parentheses when conditions are single-quoted:

```yaml
# BROKEN — content inside () gets stripped → shows as `fx !IsBlank()`
condition: '=!IsBlank(First(System.Activity.Attachments))'

# WORKING — bare format preserves the expression
condition: =!IsBlank(First(System.Activity.Attachments))
```

## Root Cause
Single quotes around Power Fx conditions cause the YAML parser to misinterpret the parentheses as YAML list/flow syntax. All existing working topics use bare (unquoted) conditions.

## Rule
**Never single-quote Power Fx conditions.** Use bare format:
```yaml
condition: =!IsBlank(First(System.Activity.Attachments))
condition: =!IsBlank(Trim(Topic.DocumentText))
```

The `userInput` field in SearchAndSummarizeContent IS safe to single-quote because it's a different YAML context.

## Verification
After pasting into code editor, the condition should show:
- `fx !IsBlank(First(System.Activity.Attachments))` — NOT `fx !IsBlank()`
- No PowerFxError

---

# FilePrebuiltEntity → StringPrebuiltEntity + File Attachment Pattern

## Problem
`FilePrebuiltEntity` on a Question node only accepts file uploads. When the user types text, the Question loops forever re-prompting. This kills Conv evals (test sets describe documents in text, never upload files).

## The Fix (additive — keeps upload path intact)

### Change entity
```yaml
# BEFORE
variable: init:Topic.DocumentText
entity: FilePrebuiltEntity

# AFTER
variable: init:Topic.DocumentText
entity:
  kind: StringPrebuiltEntity
```

### Change file check to use System.Activity.Attachments
```yaml
# BEFORE (checks the text variable, not attachments)
condition: =!IsBlank(Topic.DocumentText)

# AFTER (checks actual file attachment)
condition: =!IsBlank(First(System.Activity.Attachments))
```

### Change AI Builder binding to use attachment content
```yaml
# BEFORE (passes text variable to model)
DischargeInput: =Topic.DocumentText

# AFTER (passes file content from attachment)
DischargeInput: =First(System.Activity.Attachments).Content
```
The `.Content` property extracts the File-typed value from the attachment Record, which AI Builder expects.

### Add text-paste else branch
Add a second ConditionGroup in the elseActions that checks `=!IsBlank(Trim(Topic.DocumentText))` and runs SearchAndSummarizeContent:

```yaml
elseActions:
  - kind: ConditionGroup
    id: conditionGroup_text_check
    conditions:
      - id: condition_has_text
        condition: =!IsBlank(Trim(Topic.DocumentText))
        actions:
          - kind: SearchAndSummarizeContent
            id: search_text_audit
            variable: Topic.AuditResult
            userInput: '=Concatenate("Perform a structured Medicare Part B compliance audit...", Topic.DocumentText, ...)'
            applyModelKnowledgeSetting: true
            responseCaptureType: FullResponse
          - kind: SendActivity
            id: sendActivity_text_audit
            activity: "{Topic.AuditResult}"
    elseActions:
      - kind: GotoAction
        id: goto_upload_retry
        actionId: question_upload_doc
```

## The Three-Branch Flow
```
Condition 1: =!IsBlank(First(System.Activity.Attachments))  → File? → AI Builder
Condition 2 (else): =!IsBlank(Trim(Topic.DocumentText))     → Text? → SearchAndSummarizeContent
Else (else): GotoAction → re-ask Question
```

## Verification
Check the published topic can:
1. Accept a file upload → AI Builder audit
2. Accept pasted text → SearchAndSummarizeContent audit  
3. Re-ask if neither provided

---

# API PATCH + UI Cache Overwrite Problem

## Problem
PATCHing topic data via Dataverse API (`PATCH /botcomponents({id})`) succeeds, but the Copilot Studio UI caches topic data in memory. If you open the topic in the visual editor after an API PATCH, the UI loads its cached (old) version. When you save or navigate away, the UI writes the cached version back, **overwriting the API changes**.

## Prevention
- **Do NOT open topics in the UI visual editor after API PATCHes**
- Use the code editor (`</>`) instead of the visual editor
- After PATCHing, verify via Dataverse GET, not by looking at the UI
- If you must open, do a hard refresh (Ctrl+Shift+R) first

## Recovery
If a topic got overwritten, re-PATCH the correct YAML via API:
```python
pb = json.dumps({"data": correct_yaml}).encode()
req = urllib.request.Request(f"{dv}/botcomponents({cid})", data=pb, method="PATCH", headers=headers)
```

## Alternative Workflow
Write corrected YAML to a file, have user paste into the code editor directly. No API PATCH = no cache conflict.

---

# Response Formatting Box Override (Settings → Generative AI → Responses)

## Problem
The "Response formatting" box in Settings → Generative AI → Responses **overrides all instructions** when there's a conflict. The warning text states: "If these conflict with other instructions for this agent, these will override."

If the box says "No headers or markdown", it prevents the Route A document review format from using markdown headers, tables, and 🔴🟡🟢 risk ratings.

## Fix
Keep the Response formatting generic and route-aware:

```
Follow your route-specific output contracts:
• Document audits — markdown headers, tables, 🔴🟡🟢 risk ratings, inline citations
• General questions — 2–3 concise bullet points with citations
• Missing docs — state what's needed, invite paste

Cite sources, disclose AI status, keep simple answers under 4 sentences.
```

## Key Rules
- Never put "No headers or markdown" here — it kills the document audit format
- Keep under 500 characters
- Reference the output contracts in the main instructions rather than duplicating them
