# QM Coach V2 — Full Eval Triage Example (June 2026)

Complete workflow: eval analysis → failure categorization → topic YAML fixes → overlap cleanup → manual paste.

## Agent Context
- Agent: SimpleLTC QM Coach V2
- Bot ID: ea52ad9c-8233-f111-88b3-6045bd09a824
- Environment: Therapy AI Agents Dev (a944fdf0, orgbd048f00)
- Model: GPT-5 Chat
- Knowledge: 15 sources (8 public websites + 7 files)
- Topics: Started at 62, reduced to 52 after deduplication

## Score Progression

| Date | Single-Response | Conversation | Notes |
|------|----------------|-------------|-------|
| 5/23/26 | 93-96% | 60% | Best historical scores |
| 5/28/26 | 71-73% | 45-50% | Regression (unknown cause) |
| 6/19/26 (before) | 71% | 50% | Baseline after instruction cleanup |
| 6/19/26 (after dedup) | **95%** | 0% (broken) | Topic deletions broke conv routing |

## 29 Failures Categorized (at 71%)

| Category | Count | Root Cause | Fix |
|----------|-------|-----------|-----|
| Interactive menus | 20 (69%) | Topics return cards instead of text | Add text-first SendActivity before menu nodes |
| System errors | 7 (24%) | Broken action/connector nodes | Fix action references, add fallback text |
| HIPAA misroute | 2 (7%) | Missing trigger phrases | Add natural language triggers |
| Prompt injection | 1 (3%) | Empty template variable | Sanitize template |

## Step 1: Pull Eval Results via Playwright

Navigate to eval page → click the latest result → click "Fail (N)" tab to filter failures.

Key pattern: Click "Evaluate" button ON the test set card (not "New evaluation"). After results load, click "Fail (29)" tab. Read each failure's question + agent response.

## Step 2: Categorize Failures

Read each failure and assign to a category. Decision rule: If >50% are topic-level, instruction changes won't help. Fix topics first.

## Step 3: Get Topic GUIDs via Dataverse API

Navigate to org URL first (NOT copilotstudio.microsoft.com):
```javascript
await page.goto('https://orgbd048f00.crm.dynamics.com', ...);
await sleep(8000);
const filter = `_parentbotid_value eq '${botId}' and componenttype eq 9`;
const url = `https://orgbd048f00.crm.dynamics.com/api/data/v9.2/botcomponents?$select=name,botcomponentid&$filter=${encodeURIComponent(filter)}&$top=100`;
```

**Pitfall**: API calls to `copilotstudio.microsoft.com/api/data/...` return HTML login page. Must use the Dataverse org URL.

## Step 4: Topic Overlap Analysis

Group topics by functional area. Identify duplicates:
- Exact duplicates (different casing)
- Functional duplicates (different names, same purpose)
- Subset topics (one contained in another)

For each overlap, keep the most specific/developed topic.

## Step 5: Batch Delete via Dataverse API

```javascript
await fetch(`https://org.crm.dynamics.com/api/data/v9.2/botcomponents(${id})`, {
    method: 'DELETE', credentials: 'include',
    headers: { 'Accept': 'application/json', 'OData-MaxVersion': '4.0', 'OData-Version': '4.0' }
});
// Returns 204 on success
```

**CRITICAL**: After deletions, search ALL remaining topic content for references to deleted names. Fix broken references before republishing.

## Step 6: Manual Topic Fixes (User)

Per cdp-instructions-injection skill: CDP injection into Monaco editors is NOT reliable. Manual paste only.

## Step 7: Publish + Re-eval

1. Navigate to Overview → click Publish → confirm
2. Wait 15s for publish to complete
3. Run single-response eval first (quick health check)
4. Run conversation eval (full routing check)

## Key Learnings

1. **Instruction cleanup had zero effect** — all 29 failures were topic-level
2. **69% of failures were interactive menus** — topics returning cards instead of text
3. **Text-first pattern fixes menu topics** — give text answer, then offer interactive follow-up
4. **Topic deduplication massively improved SR** — 71%→95% after removing 10 duplicates
5. **Topic deletions can break conversation evals** — remaining topics may reference deleted ones
6. **Always search for cross-references after deletions** — QM Orchestrator referenced deleted QM Intake
7. **Single-response works + Conversation errors = routing issue** — not a platform issue
8. **"By agent" topics use AI routing** — trigger phrases don't help, fix topic descriptions instead
9. **Dataverse API requires org URL** — not copilotstudio.microsoft.com
10. **Chrome CDP hangs on heavy eval pages** — kill + restart between heavy operations

## Files Produced
- `D:/my agents copilot studio/qm_coach_v2_fix_plan.md` — 516-line fix plan
- `D:/my agents copilot studio/qm_coach_v2_powerbi_plan.md` — Power BI connector plan
- `D:/my agents copilot studio/qm_coach_v2_topic_guids.md` — Full topic GUID map
- `D:/my agents copilot studio/fix_hipaa_guardrail.yaml` — HIPAA fix YAML
- `D:/my agents copilot studio/fix_latest_resident_submission.yaml` — Submission router fix YAML
