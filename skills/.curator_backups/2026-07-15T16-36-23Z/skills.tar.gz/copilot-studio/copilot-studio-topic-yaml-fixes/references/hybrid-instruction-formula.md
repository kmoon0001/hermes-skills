# Hybrid Instruction Formula (Jun 18, 2026)

## Discovery

OT (99% SR, 100% Conv) has a 5-section instruction format that produces stable scores. Attempting to copy OT's entire format to PT/SLP WITHOUT discipline-specific content caused massive regression (SLP 90%→75%). OT's stability comes from its ENTIRE system — not just instruction simplicity.

## The Safe Hybrid Approach

**Copy OT's 6 behavioral patterns while KEEPING discipline-specific content:**

| Pattern | MS Learn Source | Safe to Copy? |
|---------|----------------|---------------|
| "For single-response questions: always use RESPONSE FORMAT" | "Specify response format" | ✅ Yes |
| "For general clinical questions: natural answer without format" | "Give the agent an out" | ✅ Yes |
| Banned phrases: "best-effort", "preliminary", "verification is limited" | "Be specific" | ✅ Yes |
| "Commit fully to expert analysis" | Consistent voice | ✅ Yes |
| "Keep responses concise — 2-3 sentences per section" | "Keep it brief" | ✅ Yes |
| "Adapt output format to the turn" | Conversation flow | ✅ Yes |

**Do NOT copy:** OT's 5-section-only structure (removing discipline content causes regression).

## Regression History

| Agent | Version | Result |
|-------|---------|--------|
| SLP | OT-style (3,045 chars, no discipline content) | 75% ❌ |
| SLP | Fixed (4,861 chars, discipline content, no CRITICAL) | 90% |
| SLP | MS-Learn-only (4,092 chars, OT patterns, no discipline) | 75% ❌ |
| SLP | Hybrid (4,512 chars, OT patterns + discipline content) | TBD |
| PT | Baseline (5,959 chars, discipline content) | 95% ✅ |
| PT | OT-style (3,100 chars, no discipline content) | Scores dropped |
| PT | MS-Learn-only (4,147 chars, OT patterns, no discipline) | TBD |
| PT | Hybrid (5,104 chars, OT patterns + discipline content) | TBD |

## Key Lesson

PT's 95% formula = baseline instructions + caregiver topic YAML checklist. The baseline had discipline-specific content (PT-SPECIFIC REQUIRED CONTENT section). Removing this content caused regression. Adding OT behavioral patterns WITHOUT removing discipline content is the safe path.

## File Reference

- `pt_instructions_final.txt` — 95% Conv baseline (5,959 chars)
- `pt_instructions_mslearn.txt` — OT patterns only (4,147 chars, no discipline content, REGRESSED)
- `pt_instructions_hybrid.txt` — OT patterns + PT content (5,104 chars, TBD)
- `slp_instructions_fixed.txt` — Best SLP version (4,861 chars)
- `slp_instructions_mslearn.txt` — OT patterns only (4,092 chars, no discipline content, REGRESSED 90%→75%)
- `slp_instructions_hybrid.txt` — OT patterns + SLP content (4,512 chars, TBD)
