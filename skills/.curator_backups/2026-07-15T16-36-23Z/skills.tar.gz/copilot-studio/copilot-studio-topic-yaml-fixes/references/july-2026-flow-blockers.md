# Topic Flow Blockers Discovered July 2026

## OnConversationStart + Question Nodes = 0% SR

When Conversation Start uses `OnConversationStart` with `kind: Question` nodes, it fires first on EVERY conversation and returns a question ("What can I help you with today?") instead of letting intent-matching topics handle the query. The eval grader sees the question as the response → abstention → 0% SR.

**Fix:** Deactivate Conversation Start, OR replace Question nodes with direct SendActivity + EndDialog.

**Evidence:** Therapy Documentation Feedback Agent scored 0-4% across 10+ eval runs until Conversation Start was deactivated.

## Conversational Boosting Needs Fallback

When `SearchAndSummarizeContent` returns nothing (empty KB, ghost references), and the topic has only `ConditionGroup: =!IsBlank(Topic.Answer)` without `elseActions`, the topic exits silently → abstention.

**Fix:** Add `elseActions` to ConditionGroup with fallback SendActivity:
```yaml
elseActions:
  - kind: SendActivity
    activity: [helpful fallback message about what the agent CAN help with]
  - kind: EndDialog
    clearTopicQueue: true
```

## CancelAllDialogs vs EndDialog

System topics (On Error, Reset Conversation) use `CancelAllDialogs` which terminates conversation without proper cleanup. For SR eval compatibility, replace with `EndDialog` + `clearTopicQueue: true`.

## Ghost KB References

Topics reference knowledge sources by schemaname in `knowledgeSources` arrays. If those components don't exist in Dataverse (componenttype 14/16), search returns nothing. Verified: 5/8 KB refs were ghosts.

**Detection:**
```bash
# Query actual KB components
curl ... "$org/api/data/v9.2/botcomponents?$filter=...componenttype in (14,16)"
# Cross-reference with topic knowledgeSources arrays
```

**Fix:** Remove ghost references from topic data, set `applyModelKnowledgeSetting: true`.

## Dataverse `data` Field PATCH Works (Unlike `content`)

The topic `data` field can be patched via Dataverse API (HTTP 204). The `content` field cannot (returns 400 "Unexpected character k"). GPT component instructions also patchable via `data` field. Publish required after patch.

## PAC Publish Display Bug

`pac copilot publish` sometimes reports "Failed to publish" but the PAC log shows successful completion. Verify by checking the log file at `~/.dotnet/tools/.store/microsoft.powerapps.cli.tool/<version>/.../logs/pac-log.txt`.
