# Power Fx Condition Formatting in Copilot Studio YAML

## The Block Scalar Trap

### Problem

Using YAML block scalars (`|-`, `|`, `>-`) for Power Fx condition formulas introduces unwanted whitespace/newlines that break the formula parser:

```yaml
# BROKEN — block scalar introduces formatting issues
condition: |-
  ="Status: Completed" in Topic.ocr_payload
```

The `|-` strip block scalar can leave residual newlines or spaces that Power Fx interprets as syntax errors, producing "Incompatible type" or "We can't evaluate your formula" errors.

### Fix

Always use double-quoted or single-quoted YAML strings for Power Fx conditions:

```yaml
# CORRECT — quoted string
condition: '="Status: Completed" in Text(Topic.ocr_payload)'
```

Or with double quotes (must escape inner quotes):

```yaml
# CORRECT — double-quoted with escaped inner quotes
condition: "=\"Status: Completed\" in Text(Topic.ocr_payload)"
```

## The `Text()` Type Safety Wrapper

### Problem

Power Fx can throw "Incompatible type" errors when using the `in` operator against topic variables, even when the variable is declared as `string` type. This happens because Copilot Studio's runtime may type the variable differently at evaluation time.

### Fix

Wrap the variable in the `Text()` function to force string type resolution:

```yaml
# BROKEN — type error possible
condition: '="Status: Completed" in Topic.ocr_payload'

# CORRECT — Text() wrapper ensures string type
condition: '="Status: Completed" in Text(Topic.ocr_payload)'
```

### Defensive Pattern

When a condition formula involves:
- The `in` operator
- String comparison with `=`
- String concatenation with `&`
- Passing to `Concatenate()`

Always wrap the topic variable in `Text()` to prevent type errors at runtime:

| Expression | Safe Version |
|-----------|-------------|
| `"text" in Topic.Var` | `"text" in Text(Topic.Var)` |
| `Topic.Var = "value"` | `Text(Topic.Var) = "value"` |
| `!IsBlank(Topic.Var)` | OK as-is — `IsBlank` handles all types |

## Async OCR Polling Pattern

When a Copilot Studio topic needs to poll an async OCR job via `InvokeFlowAction`, use this pattern to avoid infinite loops and provide user feedback:

### Structure

```yaml
actions:
  # Step 1: Submit the job
  - kind: InvokeFlowAction
    id: invokeFlow_submit_job
    flowId: <flow-id>
    input:
      binding:
        file: ={ contentBytes: ..., name: ... }
    output:
      binding:
        job_id: "Topic.job_id"

  # Step 2: Initialize retry counter
  - kind: SetVariable
    id: init_retry
    variable: Topic.RetryCount
    value: "=0"

  # Step 3: Send confirmation to user
  - kind: SendActivity
    id: send_confirmation
    activity: "Job submitted. Job ID: {Topic.job_id}"

  # Step 4: Check status (this is the loop target)
  - kind: InvokeFlowAction
    id: invokeFlow_check_status
    flowId: <check-status-flow-id>
    input:
      binding:
        job_id: =Topic.job_id
    output:
      binding:
        job_json: "Topic.job_json"

  # Step 5: Parse and check result
  - kind: SetVariable
    id: parse_result
    variable: Topic.parsed_result
    value: =Topic.job_json

  # Step 6: Condition — is it done?
  - kind: ConditionGroup
    id: condition_check
    conditions:
      - id: is_completed
        condition: '="Status: Completed" in Text(Topic.parsed_result)'
        actions:
          # SUCCESS PATH
          - kind: SearchAndSummarizeContent
            id: generate_report
            userInput: "=Concatenate('Generate report from: ', Text(Topic.job_json))"
          - kind: SendActivity
            id: send_report
            activity: "{Topic.Answer}"
          - kind: EndDialog
            id: end_success
            clearTopicQueue: true

    elseActions:
      # NOT COMPLETE — check retry limit
      - kind: ConditionGroup
        id: check_retries
        conditions:
          - id: retries_left
            condition: "=Topic.RetryCount < 10"
            actions:
              # Increment and loop
              - kind: SetVariable
                id: inc_retry
                variable: Topic.RetryCount
                value: "=Topic.RetryCount + 1"
              - kind: SendActivity
                id: wait_msg
                activity: "Still processing (attempt {Topic.RetryCount} of 10)..."
              - kind: GotoAction
                id: loop_back
                actionId: invokeFlow_check_status

        elseActions:
          # MAX RETRIES EXCEEDED
          - kind: SendActivity
            id: timeout_msg
            activity: "Job taking too long. Check back later with Job ID: {Topic.job_id}"
          - kind: EndDialog
            id: end_timeout
            clearTopicQueue: true
```

### Key Requirements

1. **`RetryCount` variable**: Must be Topic-level, type Number, default 0
2. **`Text()` wrapper**: Required on the variable in the status check condition
3. **`GotoAction` target**: Must match the `id` of the status-check InvokeFlowAction
4. **Retry limit**: Use `< 10` (not `<= 10`) so Topic.RetryCount starts at 0 and gives exactly 10 attempts
5. **`SendActivity` before loop**: Gives the user visual feedback between retries

### Pitfalls

- **Monaco code editor is NOT automatable via CDP or API**. The ONLY way to update topic content is manual paste into the code editor. See `cdp-instructions-injection` skill for full documentation of this limitation.
- **YAML validation**: Always validate after editing — the `|-` block scalar vs quoted string difference is invisible in most editors until Power Fx rejects it at runtime.
- **`content` field vs `data` field**: PATCHing the `content` field via Dataverse API returns HTTP 400. ALL topic edits must go through the Copilot Studio UI code editor. PATCHing `data` works via API but does NOT sync to `content` on publish — the runtime reads `content`, not `data`.
