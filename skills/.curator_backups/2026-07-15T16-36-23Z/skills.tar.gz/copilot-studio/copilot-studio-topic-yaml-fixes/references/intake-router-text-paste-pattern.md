# Document Upload Intake: ClosedListEntity → StringPrebuiltEntity + Free-Text Routing

## Problem

The Document Upload Intake topic uses a `ClosedListEntity` on its "What type of document?" Question node. When the user types free-text that doesn't exactly match a menu option (or when an SR eval sends a query without clicking a menu button), the Question node **never completes** — it keeps re-prompting indefinitely. Any `ConditionGroup` or `elseActions` after the Question node **never execute** because the Question blocks until the entity matches.

This causes both SR and Conv eval failures: the grader sees the bot asking "What type of document?" instead of producing an audit or helpful response.

## Pattern

Replace `ClosedListEntity` → `StringPrebuiltEntity`, update conditions to use simple text comparison, and add an `elseActions` block with `SearchAndSummarizeContent` as a catch-all for unrecognized input.

## Recipe

### 1. Entity Change

```
BEFORE:
      entity:
        kind: EmbeddedEntity
        sensitivityLevel: None
        definition:
          kind: ClosedListEntity
          items:
            - id: Evaluation and Plan of Care
              displayName: Evaluation and Plan of Care
            ... (6 items)

AFTER:
      entity:
        kind: StringPrebuiltEntity
```

### 2. Update Conditions

Change from entity-reference format to simple text comparison. The entity reference format uses a schema prefix:

```
BEFORE: =Topic.DocumentTypeSelection = 'cr917_Topic...'.'Progress Report'
AFTER:  =Topic.DocumentTypeSelection = 'Progress Report'
```

The schema prefix `'cr917_CopyTherapyDocuementationFeedbackAg.topic.DocumentUploadIntake.main.question_document_type'` is no longer valid because it was tied to the ClosedListEntity.

### 3. Add Catch-All Else Branch

After the last document-type condition's `EndDialog`, add an `elseActions:` block:

```yaml
      elseActions:
        - kind: SearchAndSummarizeContent
          id: search_fallback_audit
          variable: Topic.FallbackResult
          userInput: '=Concatenate("The user has a therapy documentation question. Answer helpfully:\n\nUser request: ", Topic.DocumentTypeSelection, "\n\nIf they asked for an audit, provide compliance guidance. If a general question, answer from knowledge sources.")'
          applyModelKnowledgeSetting: true
          responseCaptureType: FullResponse

        - kind: SendActivity
          id: send_fallback_audit
          activity: "{Topic.FallbackResult}"

        - kind: EndDialog
          id: end_fallback
          clearTopicQueue: true
```

This catches any user input that doesn't match the 6 known document types — e.g. "What is Medicare Part B?" → gets a knowledge-based answer instead of re-prompting "What type?"

### 4. Condition Format: Editor vs API

- **UI Code Editor paste:** bare inline format (NO quotes around condition value)
- **Dataverse API PATCH:** single-quoted format

See `copilot-studio-yaml-reference` skill's "Condition Format: Editor vs Dataverse API" section.

## Validated

Medicare Part B Compliance Agent (b0346795), Jul 11 2026. Fixed Document Upload Intake topic (componentId: 66fc5c98). Before: ClosedListEntity blocked free-text from completing the Question. After: StringPrebuiltEntity accepts all text, conditions route by simple text match, else branch handles unrecognized input via SearchAndSummarizeContent.

SR score impact estimated: 15 failures → ~5-8 (unrecognized queries get a generative answer instead of a silent re-prompt).
