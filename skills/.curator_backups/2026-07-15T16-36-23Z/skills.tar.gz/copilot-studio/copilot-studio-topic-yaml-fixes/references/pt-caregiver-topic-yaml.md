# PT Caregiver Topic YAMLs (95% Conv Validated)

## Caregiver Competency Intake

```yaml
kind: AdaptiveDialog
beginDialog:
  kind: OnRecognizedIntent
  id: main
  intent:
    displayName: PT Eval Guard - Caregiver Competency Intake
    triggerQueries:
      - assess caregiver competency documentation
      - check caregiver competency in PT evaluation
      - verify caregiver competency
      - caregiver competency compliance
      - caregiver training competency
      - review caregiver competency documentation

  actions:
    - kind: SearchAndSummarizeContent
      id: search-caregiver-competency
      latencyMessageSettings:
        allowLatencyMessage: false

      userInput: =System.Activity.Text
      additionalInstructions: |-
        Assess caregiver competency documentation. Include ALL of these elements with Met/Missing/Verify status:
        1. Caregiver physical/cognitive ability to perform tasks
        2. Transfer/gait/device competency with cues needed
        3. Supervision level required for safety
        4. Safe body mechanics demonstrated
        5. Documented competency result (competent/not competent)
        6. Follow-up plan if not yet competent
        Provide corrective documentation language for each Missing element. Use risk levels (High/Moderate/Low). Cite CMS Chapter 15 and APTA guidelines by natural source name. Do not output cite:1 or metadata tags. Be concise but complete.
      applyModelKnowledgeSetting: true

    - kind: EndDialog
      id: end-topic-caregiver-comp
      clearTopicQueue: true

inputType: {}
outputType: {}
```

## Caregiver Education Intake

```yaml
kind: AdaptiveDialog
beginDialog:
  kind: OnRecognizedIntent
  id: main
  intent:
    displayName: PT Eval Guard - Caregiver Education Intake
    triggerQueries:
      - review caregiver education documentation
      - check caregiver education completeness
      - verify caregiver education in PT evaluation
      - caregiver education compliance
      - caregiver training documentation
      - assess caregiver education

  actions:
    - kind: SearchAndSummarizeContent
      id: search-caregiver-education
      latencyMessageSettings:
        allowLatencyMessage: false

      userInput: =System.Activity.Text
      additionalInstructions: |-
        Assess caregiver education documentation. Include ALL of these elements with Met/Missing/Verify status:
        1. Caregiver identity and role documented
        2. Training content delivered (specific skills taught)
        3. Return demonstration / teach-back result
        4. Safety comprehension assessment
        5. Supervision/assist level needed
        6. Carryover/home program status
        7. Red flags/escalation indicators
        8. Discharge linkage and skilled PT rationale
        Provide corrective documentation language for each Missing element. Use risk levels (High/Moderate/Low). Cite CMS Chapter 15 and APTA guidelines by natural source name. Do not output cite:1 or metadata tags. Be concise but complete.
      applyModelKnowledgeSetting: true

    - kind: EndDialog
      id: end-topic-caregiver-edu
      clearTopicQueue: true

inputType: {}
outputType: {}
```
