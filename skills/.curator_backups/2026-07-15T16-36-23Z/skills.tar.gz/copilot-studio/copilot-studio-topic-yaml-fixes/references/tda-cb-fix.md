# TDA CB (Conversational Boosting) Topic Fix — June 14 2026

## Root Cause
TDA CB topic had `Keep responses under 800 characters.` in `additionalInstructions`.
This caused SR to drop from 99% to 92-94% while Conv stayed at 100%.

## Fix
Replace the 800-char limit with `Be concise but complete. Prioritize accuracy over strict length limits.`
Add citation rules: `Cite by natural source name. Do not output cite:1 or metadata tags.`

## TDA Agent Info
- Bot ID: `4d0ed0d3-30f6-f011-8406-000d3a37eba2`
- CB topic name: "Conversational boosting" (lowercase 'b')
- CB is a System topic — must click "System (N)" filter on Topics page
- NOT visible on Overview page

## Key Finding
The CB topic is the fallback for ALL unmatched queries. Fixing it has the widest impact on SR scores because SR test questions often fall through to CB when no specific topic matches.
