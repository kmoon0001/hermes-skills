# Cross-Agent Score Drift Detection (June 18, 2026)

When all four agents (OT, PT, SLP, TDA) show simultaneous score changes, the root cause is shared — not individual agent issues.

## Detection Method

Run a comprehensive audit across all agents:
1. Pull live instructions from each agent
2. Compare against expected lengths/properties
3. Check topic states (ON/OFF) via Dataverse API
4. Check knowledge source counts via UI
5. Check model configuration

## SLP/TDA Reversion Case

**Symptom**: SLP at 90% Conv (drifting), TDA at lower score. Both had "fixes" applied but scores didn't improve.

**Detection**: Pulled live instructions. SLP = 3,045 chars (should be 4,861). TDA = 1,609 chars (should be 5,237). Both were still on the wrong OT-style versions.

**Root cause**: Multiple Notepad windows with similar filenames (_fixed.txt vs _otstyle.txt). User pasted wrong file.

**Fix**: Re-opened correct files (slp_instructions_fixed.txt, tda_instructions_fixed.txt), re-pasted.

## Audit Script Pattern

```javascript
// Check all 4 agents in one pass
const agents = [
    { id: '73b45e98-...', name: 'OT', expectedInstrLen: 6002 },
    { id: '593407f3-...', name: 'PT', expectedInstrLen: 5959 },
    { id: '6e437a77-...', name: 'SLP', expectedInstrLen: 4861 },
    { id: '4d0ed0d3-...', name: 'TDA', expectedInstrLen: 5237 },
];

for (const a of agents) {
    // Navigate to instructions page
    // Click Edit button
    // Read contenteditable div
    // Compare length against expected
    // Check for CRITICAL/MANDATORY
    // Check for cite:1 ban
}
```

## Prevention

1. After every instruction paste, verify live instruction length matches expected
2. Use the deep dive audit script before and after any multi-agent change
3. If any agent's instructions are < 60% of expected length, wrong version is applied
