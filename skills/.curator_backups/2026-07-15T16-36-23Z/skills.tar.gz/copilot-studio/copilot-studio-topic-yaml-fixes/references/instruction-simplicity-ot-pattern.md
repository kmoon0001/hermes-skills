# OT's 5-Section Instruction Formula (99% SR, High Stability)

Discovered Jun 17, 2026. OT is the most stable agent — 99% SR, consistent scores across runs.
Side-by-side comparison against PT (95%), SLP (90%), TDA (96%) revealed the pattern.

## The 5-Section Model

```
1. CLINICAL ROLE       — scope, domains, what the agent does
2. RESPONSE BEHAVIOR   — conversation rules, format, citation rules
3. XAI & TRANSPARENCY  — confidence, source mapping, reasoning
4. CONVERSATION CONTINUITY — context preservation across turns
5. SAFETY              — disclaimers, PHI rules
```

## What OT does NOT have (that others do)

| Element | OT | PT | SLP | Effect |
|---------|-----|-----|------|--------|
| "Format Rules" section | ❌ | ✅ | ✅ | Adds redundant constraints |
| "Discipline-Specific Required Content" | ❌ | ✅ | ✅ | Checklist in instructions = regression |
| "MUST include" language | ❌ | ✅ | ✅ | Overcorrects model |
| "Do NOT ask for document" verbose | ❌ | ✅ | ✅ | Unnecessary negation |
| "CRITICAL: NEVER" language | ❌ | ❌ | ✅ | Causes 5-15% regression |
| Inline citation requirement | ❌ | ❌ | ❌ | Caused PT 95%→85% |

## The Principle

**Less instruction structure = more model stability.**

Each additional section, rule, or "MUST" in instructions is a constraint that the model must
balance against its training. More constraints = more chance of overcorrection = more regression.

Discipline-specific content and checklists belong in **topic YAML `additionalInstructions`**,
not in agent instructions. Topic-level instructions only apply when the topic triggers.

## Template

```text
AGENT_NAME

SCOPE:
- [domain, setting, patient population]
- Out of scope: [brief]

CLINICAL ROLE
- [3-4 bullet points on what the agent audits/validates]

RESPONSE BEHAVIOR
- Always answer directly. Never refuse or go silent.
- Never display internal JSON, metadata, or tool internals.
- Preserve context across turns.
- A record_id is sufficient context. Do not ask for document text.
- For any audit request, include: classification, risk tier/score, required-elements check,
  high-risk gaps, corrective documentation, source anchors, safety advisory.
- Do not ask follow-up questions. End with advisory.
- Cite knowledge sources by natural source name. Do not output cite:1 or metadata tags.
- Be concise but complete.

XAI & TRANSPARENCY
- Include confidence levels. Map findings to citations.
- Separate AI-generated from verified data.
- Explain score drivers.

CONVERSATION CONTINUITY
- Maintain context across turns. Avoid repetition.

SAFETY
- Administrative compliance only. No PHI. Clinical review required.
```

## Results

| Agent | Before | After (OT-style) | Status |
|-------|--------|-------------------|--------|
| PT | 95% | TBD | Applied Jun 17 |
| SLP | 90% (drifting) | TBD | Applied Jun 17 |
| TDA | 96% | TBD | Applied Jun 17 |
