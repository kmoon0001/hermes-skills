# API PATCH + UI Editor Dual-Write Corruption

When you patch topic YAML via the Dataverse API (`PATCH /botcomponents({id})`) and then open the topic in the Copilot Studio visual editor, **the UI overwrites your API changes with its cached version**.

## Root Cause
Copilot Studio's SPA caches topic data in memory when the page loads. Opening a topic loads the cached version (from initial page load), not the live Dataverse version. If you then save in the UI, it writes the old cached data back to Dataverse, undoing API patches.

## Signs You Hit This
- API PATCH returns 204, but topic still shows old behavior
- Re-reading Dataverse shows original YAML (not patched version)
- `modifiedon` timestamp is later than the patch time
- "My topics keep resetting/undoing themselves"

## Workarounds

### Option 1: Code Editor Only (Recommended)
Use the `</> Code editor` button in the topic editor to paste YAML directly and save. This is a single-write path — no API patching, no cache conflict.

### Option 2: Refresh Before Opening
If you must API-patch, refresh the browser tab (Shift+Reload bypasses cache) before opening the patched topic in the UI.

### Option 3: Files on Disk
Generate the corrected YAML as a `.yaml` file. The user opens it in Notepad and pastes into the code editor. No API involved, no cache issues.

### Option 4: Disable Browser Cache
F12 → Network tab → check "Disable cache" while editing. Keeps DevTools open while you work.

## Note on Direct URL Navigation
Navigating directly to the topic's canonical URL loads fresh from the API:
```
https://copilotstudio.microsoft.com/environments/{env}/bots/{bot}/adaptive/{topic-guid}
```
This bypasses the SPA's in-memory cache for that topic.
