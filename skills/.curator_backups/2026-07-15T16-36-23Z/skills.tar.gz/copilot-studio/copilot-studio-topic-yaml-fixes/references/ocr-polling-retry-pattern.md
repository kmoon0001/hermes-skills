# OCR Polling Retry Pattern (Feedback B)

When a Copilot Studio topic uses `InvokeFlowAction` for async OCR, the initial OCR check often returns "Status: Processing" — the topic needs a retry loop to poll until completion.

## Pattern (Discharge Summary reference)

Insert in the `elseActions` block after `conditionGroup_ocr_completed` if the OCR check failed:

```yaml
      elseActions:
        - kind: SendActivity
          id: sendActivity_processing_status
          activity: |-
            The OCR audit job is not complete yet.

            Job ID: {Topic.async_job_id}
            Current status response: {Topic.ocr_payload}

            Use "check OCR job status" with this Job ID to retrieve the completed report.

        - kind: SetVariable
          id: setVariable_retry_count
          variable: Topic.retry_count_num
          value: =If(Value(Text(Topic.'retry_count_num')) + 1 >= 10, Blank(), Value(Text(Topic.'retry_count_num')) + 1)

        - kind: ConditionGroup
          id: conditionGroup_retry_limit
          conditions:
            - id: conditionItem_retry_exit
              condition: =IsBlank(Topic.retry_count_num)

        - kind: GotoAction
          id: goto_retry_ocr_check
          actionId: invokeFlow_check_async_ocr_status
```

## How it works

1. Send "not complete" status message
2. Increment `retry_count_num` — sentinel formula: `>= 10 → Blank()`
3. `IsBlank(Topic.retry_count_num)` — if true, stop retrying (silent exit)
4. `GotoAction` → `invokeFlow_check_async_ocr_status` — loops back to the OCR check

## Topics patched with this pattern (Jul 10 2026)

- **Evaluation/Assessment + Plan of Care** — replaced dead `RetryCount < 0` condition
- **Treatment Encounter Note Review** — added retry loop (had none)
- **Recertification/UPOC Review** — added retry loop (had none)
- **Episode of Care** — replaced dead `RetryCount < 0` condition

## Topics that already had retry (reference)

- **Discharge Summary** — used `retry_count_num` sentinel pattern
- **Progress Report Review** — used `RetryCount < 10` with increment (different var name, works)
