# AI Builder Audit Topics That Silently End

A common defect in Copilot Studio compliance/audit topics: the topic asks for a document, runs AI Builder, stores results... then ends without showing the user anything.

## Symptom

- User uploads a document when prompted
- The topic "runs" (visible via activity map) but ends abruptly
- No audit results, no error message — just silence or conversation end
- Eval scores for these topics are 0% or very low because the model never receives a response

## Root Cause

The `ConditionGroup` has two branches:
- **success** (`file_is_valid`): runs `InvokeAIBuilderModelAction` and stores output to a Global variable — but has **no `SendActivity`** to show the result
- **failure** (`elseActions`): has a `SendActivity` with an error message

The AI Builder runs successfully but the result is silently discarded because the success branch ends without output. The only `SendActivity` in the topic is in the error path.

## Detection

Query the live Dataverse botcomponents YAML and check for this pattern:

```yaml
- kind: ConditionGroup
  id: check_file_uploaded
  conditions:
    - id: file_is_valid
      condition: =!IsBlank(Topic.TopicUploadedDoc)
      actions:
        - kind: InvokeAIBuilderModelAction
          id: invokeAIBuilderModelAction_XXX
          input:
            binding:
              Document_20input: =Topic.TopicUploadedDoc
          output:
            binding:
              predictionOutput: Global.GlobalAuditResultstext
          aIModelId: <guid>
        # <--- NO SendActivity HERE — result stored but never shown

  elseActions:
    - kind: SendActivity
      id: send_error_message
      activity: It looks like you didn't upload a valid file...

- kind: EndDialog
  id: end-topic
  clearTopicQueue: true
```

The tell: `predictionOutput: Global.SomeVariable` is present but `SendActivity` referencing that variable is absent in the success branch.

## Fix

Add a `SendActivity` inside the success `actions` block, AFTER the `InvokeAIBuilderModelAction`:

```yaml
    - id: file_is_valid
      condition: =!IsBlank(Topic.TopicUploadedDoc)
      actions:
        - kind: InvokeAIBuilderModelAction
          id: invokeAIBuilderModelAction_XXX
          ...  # existing AI Builder call — keep as-is

        - kind: SendActivity
          id: send_audit_results
          activity: "=Global.GlobalAuditResultstext"

  elseActions:
    - kind: SendActivity
      id: send_error_message
      activity: It looks like you didn't upload a valid file...
```

## Important Considerations

- **Output binding format matters**: If the output binding uses `predictionOutput: Global.Variable.text` (nested property, `.text` suffix), the SendActivity should reference that exact path: `activity: "=Global.Variable.text"`. If it uses `predictionOutput: Global.Variable` (top-level), reference `activity: "=Global.Variable"`. **Inconsistent nesting between topics using the same AI model is a common secondary defect** — all topics using the same model should have the same output binding depth.

- **SendActivity format**: The `activity` field MUST be a plain string. **Do NOT use this invalid format:**
  ```yaml
  # BROKEN — activity as map instead of string
  activity:
    value: =Global.SomeVar
    text:
      - "{Global.SomeVar}"
  ```
  This format is accepted by the YAML parser at storage time but the Copilot Studio runtime doesn't render it correctly. The correct form is:
  ```yaml
  # CORRECT
  activity: "=Global.SomeVar"
  ```

- **If the topic also has an InvokeFlowAction** (for OCR text extraction), the flow output (e.g., `Topic.extracted_text`) is piped into the AI Builder's `Document_20input`. This is correct — the SendActivity should reference the AI Builder's output (`Global.GlobalAuditResultstext`), not the flow's output (`Topic.extracted_text`).

## Batch Fix Strategy

When 6 audit topics have the same defect:

1. Read each topic's live `data` field
2. For each, identify: `aIModelId` (should be same for all), output binding variable name, SendActivity position
3. Build new YAML with `mcs.metadata` / `modeldescription` / `description` added AND the SendActivity inserted in the success branch
4. PATCH each topic's `data` field via Dataverse REST API
5. **Verify by re-querying** each topic — check for `send_audit_results` in the data field
6. Publish

## Example (Before/After)

**Before (broken)** — Treatment Encounter Note Review:
```
Question (upload file) →
ConditionGroup:
  success: InvokeAIBuilderModelAction → output to Global.GlobalAuditResultstext [SILENT]
  else: SendActivity error message →
EndDialog
```

**After (fixed)**:
```
Question (upload file) →
ConditionGroup:
  success: InvokeAIBuilderModelAction → SendActivity "=Global.GlobalAuditResultstext" → 
  else: SendActivity error message →
EndDialog
```
