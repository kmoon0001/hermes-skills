# OT Specialist July 1 2026 — Comprehensive Rebuild Example

## Background
OT was at 90% (90/100, 6 fail, 4 exec errors). The `content` field was empty for 11/18 topics. The `data` field had broken YAML from prior patches (additionalInstructions at column 0, missing applyModelKnowledgeSetting, no SendActivity).

## What was done
1. Rebuilt 12 topics in one script pass with clean MS Learn YAML
2. Updated agent instructions with first-sentence direct-answer rule
3. Added SendActivity + EndDialog to Fallback and CB topics
4. Published from pac CLI (after rebuild cleared the stuck state)
5. Ran 2 evals: 96% and 94% = 95% avg, 0 exec errors

## Script used
`D:/my agents copilot studio/pipeline/scripts/hermes_ot_fix_all_comprehensive.cjs`

Key function — topic template:
```javascript
function topic(name, triggers, instructions) {
  const tq = triggers.length ? `  intent:\n    displayName: ${name}\n    triggerQueries:\n${triggers.map(q=>'      - '+q).join('\n')}` : '';
  const aiLines = instructions.split('\n').map(l=>'        '+l).join('\n');
  return `kind: AdaptiveDialog
beginDialog:
  kind: OnRecognizedIntent
  id: main
${tq}
  actions:
    - kind: SearchAndSummarizeContent
      id: search-${name.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/-+/g,'-').replace(/^-|-$/g,'')}
      latencyMessageSettings:
        allowLatencyMessage: false
      variable: Topic.Answer
      userInput: =System.Activity.Text
      additionalInstructions: |-
${aiLines}
      applyModelKnowledgeSetting: true
    - kind: SendActivity
      id: send-answer
      activity: =Topic.Answer
    - kind: EndDialog
      id: end-topic
      clearTopicQueue: true
inputType: {}
outputType: {}`;
}
```

## Result
| Run | Pass | Fail | Exec Fail | Score |
|-----|------|------|-----------|-------|
| Run 1 | 96 | 4 | 0 | 96% |
| Run 2 | 94 | 6 | 0 | 94% |
| **Avg** | | | | **95%** |

## Remaining 4-6 failures per run
All abstention failures — agent asks for note text instead of giving conditional determination. The first-sentence rule works for most cases but these slip through. Future fix: tighten the no-refusal rule at instruction level.
