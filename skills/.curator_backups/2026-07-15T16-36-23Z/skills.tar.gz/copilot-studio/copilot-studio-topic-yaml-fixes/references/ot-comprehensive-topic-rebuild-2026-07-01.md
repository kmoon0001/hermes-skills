# OT Comprehensive Topic Rebuild (Jul 1 2026)

When multiple topics have broken YAML (malformed indentation, missing properties, structural issues), incremental fixes are unreliable. Rebuild ALL topics in one comprehensive script.

## Verified Result
- 12 topics patched (7 broken YAML + 5 missing SendActivity)
- Publish succeeded: `Synchronized` state
- Eval improved: 90% → 96% with 0 execution errors (was 4)

## Standard OT Topic Template

```yaml
kind: AdaptiveDialog
beginDialog:
  kind: OnRecognizedIntent
  id: main
  intent:
    displayName: [Topic Name]
    triggerQueries:
      - [trigger 1]
      - [trigger 2]
  actions:
    - kind: SearchAndSummarizeContent
      id: search-[topic-slug]
      latencyMessageSettings:
        allowLatencyMessage: false
      variable: Topic.Answer
      userInput: =System.Activity.Text
      additionalInstructions: |-
        [Topic-specific focus]
        - First sentence must directly answer the exact user question.
        - Do not invent patient facts, scores, or citations not in sources.
        - Cite by natural source name. No cite:1 or metadata.
        - Plain text only. No adaptive cards or JSON.
        - End with: Clinical review required. Non-Device CDS only.
      applyModelKnowledgeSetting: true
    - kind: SendActivity
      id: send-answer
      activity: =Topic.Answer
    - kind: EndDialog
      id: end-topic
      clearTopicQueue: true
inputType: {}
outputType: {}
```

## Standard OT First-Sentence Rule

For yes/no document-check prompts, sentence 1 must answer conditionally:
```
- First sentence must directly answer the exact user question. For yes/no checks, give a conditional determination: it meets/supports/is compliant only if required elements are documented; if absent, it does not.
```

## Standard Groundedness Guardrails

```yaml
- Do not invent patient facts, numeric scores, denial/penalty/recoupment outcomes, COTA supervision/authorship, or exact citations unless supported by the source.
- Cite knowledge sources by natural source name. Do not output cite:1, Citation-1, or metadata tags.
- Plain text only. Never output adaptive cards, raw JSON, or metadata.
```

## CB/Fallback Topic Template

```yaml
kind: AdaptiveDialog
beginDialog:
  kind: OnUnknownIntent
  id: main
  priority: -1  # CB only; omit for Fallback
  actions:
    - kind: SearchAndSummarizeContent
      id: search-cb
      latencyMessageSettings:
        allowLatencyMessage: false
      variable: Topic.Answer
      userInput: =System.Activity.Text
      additionalInstructions: |-
        OT compliance focus: answer the exact question using CMS Chapter 15 and AOTA OTPF-4.
        - Sentence 1 must directly answer. For yes/no checks, give conditional determination.
        - Keep responses concise.
        - Do not invent scores, denial outcomes, or citations not in sources.
        - Plain text only.
      applyModelKnowledgeSetting: true
    - kind: SendActivity
      id: send-cb
      activity: =Topic.Answer
    - kind: EndDialog
      id: end-cb
      clearTopicQueue: true
inputType: {}
outputType: {}
```

## Key Differences from Previous Plan-100 Approach

| Aspect | Plan-100 (old) | MS Learn Fix (new) |
|--------|----------------|---------------------|
| YAML structure | Broken indentation, missing properties | Clean 2-space indent, all required properties |
| SendActivity | Missing on Fallback/CB | Present on ALL topics |
| additionalInstructions | At column 0 | Properly indented at 8 spaces |
| applyModelKnowledgeSetting | Missing | Present on all SearchAndSummarizeContent |
| Static guardrails | Broad superanswers | None — clean topic-level instructions only |
| First-sentence rule | In agent instructions | In BOTH agent instructions AND topic additionalInstructions |
