# File+Text Dual-Input Pattern for Document Review Topics

## Problem
Question nodes using `entity: FilePrebuiltEntity` never complete when a user responds with text instead of a file. The Question keeps re-prompting because the file entity expects a binary attachment. This is the #1 cause of Conversational eval failures (20-35% scores).

## Pattern

### Entity: StringPrebuiltEntity (NOT FilePrebuiltEntity)
Accept any user input by switching to `StringPrebuiltEntity`. This lets users paste text OR upload files.

### File Detection
Use `=!IsBlank(First(System.Activity.Attachments))` instead of `=!IsBlank(Topic.var)` to check for file upload. `System.Activity.Attachments` holds uploaded files regardless of the Question's entity type.

### AI Builder Input Binding
When a file IS present, bind the AI Builder input to `=First(System.Activity.Attachments).Content` — NOT `=Topic.var` and NOT `=First(System.Activity.Attachments)`:

- `=Topic.var` → holds user's text (since entity is StringPrebuiltEntity), not the file blob
- `=First(System.Activity.Attachments)` → returns a Record type → causes `IncorrectTypeAssignment` error on publish
- `=First(System.Activity.Attachments).Content` → returns a File type → matches AI Builder's expected input

### Text-Input Branch
In the `elseActions` of the file check, add a nested ConditionGroup that checks `=!IsBlank(Trim(Topic.var))` for text. If text exists, pipe to SearchAndSummarizeContent → SendActivity → EndDialog.

### Fallback
If neither file nor text is present, GotoAction back to the Question.

### Critical: Do NOT Remove entity Entirely
A Question node requires an entity. Removing `entity:` causes `MissingRequiredProperty: Entity` on publish. Always change the type, never remove it.

## Full YAML Template

```yaml
    - kind: Question
      id: question_upload_doc
      interruptionPolicy:
        allowInterruption: true
      variable: init:Topic.DocumentText
      entity:
        kind: StringPrebuiltEntity
      prompt: Paste the text of or upload the document for audit.

    - kind: ConditionGroup
      id: conditionGroup_file_check
      conditions:
        - id: condition_file_uploaded
          condition: =!IsBlank(First(System.Activity.Attachments))
          actions:
            - kind: InvokeAIBuilderModelAction
              id: invokeAIBuilderModelAction
              input:
                binding:
                  InputField: =First(System.Activity.Attachments).Content
              output:
                binding:
                  predictionOutput: Topic.Results
              aIModelId: <model-guid>
            - kind: SendActivity
              id: sendActivity_file_audit
              activity: "{Topic.Results.text}"

      elseActions:
        - kind: ConditionGroup
          id: conditionGroup_text_check
          conditions:
            - id: condition_has_text
              condition: '=!IsBlank(Trim(Topic.DocumentText))'
              actions:
                - kind: SearchAndSummarizeContent
                  id: search_text_audit
                  variable: Topic.AuditResult
                  userInput: '=Concatenate("Audit this: ", Topic.DocumentText)'
                  applyModelKnowledgeSetting: true
                  responseCaptureType: FullResponse
                - kind: SendActivity
                  id: sendActivity_text_audit
                  activity: "{Topic.AuditResult}"
          elseActions:
            - kind: GotoAction
              id: goto_upload_retry
              actionId: question_upload_doc

    - kind: EndDialog
      id: endDialog_main
      clearTopicQueue: true
```

## Verification Checklist
- [ ] `FilePrebuiltEntity` NOT present
- [ ] `StringPrebuiltEntity` present on Question
- [ ] Condition uses `First(System.Activity.Attachments)`
- [ ] AI Builder binding uses `.Content` suffix
- [ ] No `SetVariable` assigning `First(System.Activity.Attachments)` to a string variable
- [ ] Text-path has `SearchAndSummarizeContent` + `SendActivity` + `EndDialog`
- [ ] YAML validates with `yaml.safe_load()`
