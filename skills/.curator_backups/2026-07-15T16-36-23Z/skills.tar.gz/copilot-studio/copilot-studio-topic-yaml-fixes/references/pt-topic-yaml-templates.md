# PT Audit Topic YAML Templates (Verified Working — 100% Conv)

These 5 topic YAMLs are verified to produce 100% Conversation eval for PT_Specialist.
Key changes from original: removed 800-char limits, added natural citation instructions.

## Analyze PT Daily Note

```yaml
kind: AdaptiveDialog
beginDialog:
  kind: OnRecognizedIntent
  id: main
  intent:
    displayName: Analyze PT Daily Note
    triggerQueries:
      - audit pt daily note
      - check pt daily note compliance
      - is this pt daily note skilled
      - verify pt daily therapy documentation
      - analyze physical therapy daily note

  actions:
    - kind: SearchAndSummarizeContent
      id: search_AnalyzePTDailyNote
      latencyMessageSettings:
        allowLatencyMessage: false

      userInput: =System.Activity.Text
      additionalInstructions: |-
        Audit this PT daily note for compliance. Focus on:
        1. Skilled PT intervention documented (therapeutic exercise parameters, gait training, neuromuscular re-education, manual therapy techniques)
        2. Objective patient response with measurable data (assist levels, distance, TUG/Berg scores, ROM, strength grades)
        3. Medical necessity — treatment relates to goals and requires PT skill level per CMS Ch. 15
        4. Functional outcomes linked to mobility, balance, or safe discharge
        Use risk levels (High/Moderate/Low). Cite CMS Chapter 15 and APTA guidelines by natural source name. Do not output cite:1 or metadata tags.
      applyModelKnowledgeSetting: true

    - kind: EndDialog
      id: end-topic
      clearTopicQueue: true

inputType: {}
outputType: {}
```

## Analyze PT Progress Note

```yaml
kind: AdaptiveDialog
beginDialog:
  kind: OnRecognizedIntent
  id: main
  intent:
    displayName: Analyze PT Progress Note
    triggerQueries:
      - audit pt progress note
      - check pt progress note compliance
      - pt progress review
      - verify pt progression documentation
      - analyze physical therapy progress note

  actions:
    - kind: SearchAndSummarizeContent
      id: search_AnalyzePTProgressNote
      latencyMessageSettings:
        allowLatencyMessage: false

      userInput: =System.Activity.Text
      additionalInstructions: |-
        Audit this PT progress note for compliance. Focus on:
        1. Measurable progress from baseline — gait distance, assist level changes, TUG/Berg/Tinetti score improvement, ROM/strength gains
        2. Continued skilled need per Jimmo v. Sebelius — why PT services remain necessary (complexity, safety risk, skilled judgment)
        3. Goal status updates with functional outcomes tied to mobility and safe discharge
        4. Timing compliance per 42 CFR 409-44(c) — within 10 treatment days or 30 calendar days
        Use risk levels (High/Moderate/Low). Cite CMS Chapter 15 and APTA guidelines by natural source name. Do not output cite:1 or metadata tags.
      applyModelKnowledgeSetting: true

    - kind: EndDialog
      id: end-topic
      clearTopicQueue: true

inputType: {}
outputType: {}
```

## Analyze PT Discharge

```yaml
kind: AdaptiveDialog
beginDialog:
  kind: OnRecognizedIntent
  id: main
  intent:
    displayName: Analyze PT Discharge
    triggerQueries:
      - audit PT discharge summary
      - check PT discharge documentation compliance
      - PT discharge note review
      - verify discharge summary completeness
      - analyze PT discharge documentation
      - PT discharge compliance check
      - is my discharge summary compliant
      - PT discharge documentation audit

  actions:
    - kind: SearchAndSummarizeContent
      id: search_AnalyzePTDischarge
      latencyMessageSettings:
        allowLatencyMessage: false

      userInput: =System.Activity.Text
      additionalInstructions: |-
        - Verify discharge summary completeness: goal achievement, functional status at discharge, discharge recommendations, equipment needs, follow-up plan.
        - Compare admission vs discharge functional status with objective measures.
        - Assign risk level (High/Moderate/Low). Be concise but complete.
        - Cite CMS Chapter 15 and APTA guidelines by natural source name. Do not output cite:1 or metadata tags.
        - End with: Advisory - clinical review required.
      applyModelKnowledgeSetting: true

    - kind: EndDialog
      id: end-topic
      clearTopicQueue: true

inputType: {}
outputType: {}
```

## Analyze PT Evaluation

```yaml
kind: AdaptiveDialog
beginDialog:
  kind: OnRecognizedIntent
  id: main
  intent:
    displayName: Analyze PT Evaluation
    triggerQueries:
      - audit PT evaluation
      - check PT eval compliance
      - PT evaluation documentation review
      - verify PT eval for Medicare
      - analyze physical therapy evaluation
      - PT eval compliance check
      - is my PT evaluation compliant
      - PT evaluation audit

  actions:
    - kind: SearchAndSummarizeContent
      id: search_AnalyzePTEvaluation
      latencyMessageSettings:
        allowLatencyMessage: false

      userInput: =System.Activity.Text
      additionalInstructions: |-
        - Verify PT licensure (not PTA), Section GG alignment, and medical necessity with prior level of function.
        - Check objective baselines (ROM, MMT, Berg/TUG, gait parameters) and goal quality (functional, measurable, time-bound).
        - Assign risk level (High/Moderate/Low). Be concise but complete.
        - Cite CMS Chapter 15 and APTA guidelines by natural source name. Do not output cite:1 or metadata tags.
        - End with: Advisory - clinical review required.
      applyModelKnowledgeSetting: true

    - kind: EndDialog
      id: end-topic
      clearTopicQueue: true

inputType: {}
outputType: {}
```

## Analyze PT Recertification Note

```yaml
kind: AdaptiveDialog
beginDialog:
  kind: OnRecognizedIntent
  id: main
  intent:
    displayName: Analyze PT Recertification Note
    triggerQueries:
      - review recert note
      - audit recertification
      - pt recert documentation check
      - analyze cert note
      - validate recertification
      - is my recert compliant
      - check recertification requirements

  actions:
    - kind: SearchAndSummarizeContent
      id: search_AnalyzePTRecertificationNote
      latencyMessageSettings:
        allowLatencyMessage: false

      userInput: =System.Activity.Text
      additionalInstructions: |-
        - Verify physician certification (signature, date, period) and continued medical necessity justification.
        - Check objective progress vs prior cert period and updated measurable goals.
        - Assign risk level (High/Moderate/Low). Be concise but complete.
        - Cite CMS Chapter 15 and APTA guidelines by natural source name. Do not output cite:1 or metadata tags.
        - End with: Advisory - clinical review required.
      applyModelKnowledgeSetting: true

    - kind: EndDialog
      id: end-topic
      clearTopicQueue: true

inputType: {}
outputType: {}
```
