# SLP Daily Therapy Note — Verified Working Topic YAML

This is the only SLP topic that was fully fixed and verified. The other 3 SLP topics
(Evaluation Report, Progress Note, Discharge Summary) still need the same treatment.

```yaml
kind: AdaptiveDialog
beginDialog:
  kind: OnRecognizedIntent
  id: main
  intent:
    displayName: Analyze SLP Daily Therapy Note
    triggerQueries:
      - analyze SLP daily note
      - review speech therapy daily note
      - SLP daily therapy note audit
      - check SLP daily note for compliance
      - assess SLP daily note quality
      - SLP progress note review
      - audit my SLP daily documentation
      - is my SLP daily note compliant
      - review speech therapy treatment note
      - SLP daily note defensibility check

  actions:
    - kind: SearchAndSummarizeContent
      id: searchDailyNote
      latencyMessageSettings:
        allowLatencyMessage: false

      userInput: =System.Activity.Text
      additionalInstructions: |-
        Audit this SLP daily therapy note for Medicare compliance. Analyze against CMS Chapter 15, Jimmo v. Sebelius, ASHA Scope of Practice, PDPM, and 42 CFR 424-24.
        1. Measurable progress toward goals (objective data, percentages, cue levels)
        2. Skilled service demonstration — why an SLP was required, not routine care
        3. Patient response with specific clinical examples
        4. Continued skilled need rationale for next session
        5. Functional reporting and denial risk indicators
        Use risk levels (High/Moderate/Low). Cite CMS Chapter 15 and ASHA guidelines by natural source name. Do not output cite:1 or metadata tags.
        Be concise but complete. Prioritize accuracy over strict length limits.
      webBrowsing: false
      applyModelKnowledgeSetting: true

    - kind: EndDialog
      id: end_topic_daily
      clearTopicQueue: true

inputType: {}
outputType: {}
```

## Notes
- `webBrowsing: false` is explicitly set (SLP specific)
- `42 CFR 424-24` uses hyphen not dot — dot causes YAML parse error
- EndDialog id uses `end_topic_daily` (not generic `end-topic`)
