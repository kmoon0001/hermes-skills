/**
 * Playwright Copilot Studio Topic Injector — Full Workflow
 * 
 * Handles both EXISTING topics (click from Overview) and NEW topics (Add topic).
 * Connects to existing Chrome on port 9223.
 * 
 * Usage:
 *   node inject_full.cjs <BOT_ID> <TOPIC_NAME> <YAML_FILE> [--new]
 * 
 * Examples:
 *   node inject_full.cjs "6e437a77-a5dc-4984-90eb-4924eab10006" "Analyze SLP Evaluation Report" "./slp_fix_eval_report.yaml"
 *   node inject_full.cjs "6e437a77-a5dc-4984-90eb-4924eab10006" "Analyze SLP Progress Note" "./slp_progress_note.yaml" --new
 * 
 * Key implementation details:
 * - Chrome must be running with --remote-debugging-port=9223
 * - User must be authenticated to Copilot Studio (approve Authenticator if prompted)
 * - Topics must be visible on the Overview page (custom topics only, not system topics)
 * - For system topics (CB, Fallback), use manual approach via +N overflow -> Topics -> System filter
 * - Playwright times out with 30+ Chrome tabs — close unused tabs first
 * - Monaco editor clipboard injection: focus -> Ctrl+A -> clipboard.writeText -> Ctrl+V
 * - React save tracker: Space + Backspace wakes the dirty flag
 */

const { chromium } = require('playwright-core');
const fs = require('fs');
const path = require('path');

const ENV_ID = 'Default-03cc92c3-986c-4cf4-ae27-1478cf99d17f';

async function connectBrowser() {
  const browser = await chromium.connectOverCDP('http://127.0.0.1:9223');
  const context = browser.contexts()[0];
  if (!context) throw new Error('No browser context');
  return { browser, context };
}

async function navigateToOverview(page, botId) {
  console.log('Navigating to agent Overview...');
  await page.goto(`https://copilotstudio.microsoft.com/environments/${ENV_ID}/bots/${botId}/overview`);
  await page.waitForLoadState('networkidle');
  await page.waitForTimeout(15000);
  console.log('Overview loaded');
}

async function clickExistingTopic(page, topicName) {
  console.log(`Looking for topic: ${topicName}`);
  await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
  await page.waitForTimeout(2000);
  
  const topicLink = page.locator('a', { hasText: topicName }).first();
  const visible = await topicLink.isVisible({ timeout: 10000 }).catch(() => false);
  
  if (visible) {
    console.log('Topic link found, clicking...');
    await topicLink.click();
    await page.waitForTimeout(5000);
    return true;
  }
  
  console.log('Topic not found on Overview page');
  return false;
}

async function openCodeEditor(page) {
  console.log('Opening code editor...');
  const moreBtns = await page.getByRole('button', { name: 'More' }).all();
  
  for (let i = 0; i < moreBtns.length; i++) {
    const btn = moreBtns[i];
    if (!(await btn.isVisible().catch(() => false))) continue;
    await btn.click();
    await page.waitForTimeout(1500);
    
    const codeEditor = page.getByText(/open code editor/i);
    if (await codeEditor.isVisible({ timeout: 1000 }).catch(() => false)) {
      console.log('Found Open code editor at button', i);
      await codeEditor.click();
      await page.waitForTimeout(5000);
      
      const hasMonaco = await page.locator('.monaco-editor').isVisible({ timeout: 10000 }).catch(() => false);
      if (hasMonaco) {
        console.log('Monaco editor loaded');
        return true;
      }
    } else {
      await page.keyboard.press('Escape');
      await page.waitForTimeout(500);
    }
  }
  return false;
}

async function injectYAML(page, yamlContent) {
  console.log(`Injecting YAML (${yamlContent.length} chars)...`);
  await page.locator('.monaco-editor').click();
  await page.waitForTimeout(500);
  await page.keyboard.press('Control+A');
  await page.waitForTimeout(300);
  await page.evaluate((text) => navigator.clipboard.writeText(text), yamlContent);
  await page.waitForTimeout(200);
  await page.keyboard.press('Control+V');
  await page.waitForTimeout(1000);
  await page.keyboard.press('Space');
  await page.waitForTimeout(100);
  await page.keyboard.press('Backspace');
  await page.waitForTimeout(500);
  console.log('YAML injected');
}

async function clickSave(page) {
  console.log('Clicking Save...');
  const saveBtn = page.getByRole('button', { name: 'Save' }).first();
  if (await saveBtn.isVisible({ timeout: 3000 }).catch(() => false)) {
    await saveBtn.click();
    await page.waitForTimeout(3000);
    const hasError = await page.evaluate(() => document.body.innerText.includes('Invalid kind'));
    if (hasError) { console.log('Validation error!'); return false; }
    console.log('Saved successfully!');
    return true;
  }
  return false;
}

async function main() {
  const args = process.argv.slice(2);
  const [botId, topicName, yamlFile] = args.filter(a => !a.startsWith('--'));
  if (!botId || !topicName || !yamlFile) {
    console.error('Usage: node inject_full.cjs <BOT_ID> <TOPIC_NAME> <YAML_FILE>');
    process.exit(1);
  }
  
  const yamlContent = fs.readFileSync(path.resolve(yamlFile), 'utf8');
  const { browser, context } = await connectBrowser();
  const page = await context.newPage();
  
  try {
    await navigateToOverview(page, botId);
    if (!(await clickExistingTopic(page, topicName))) { process.exit(1); }
    if (!(await openCodeEditor(page))) { process.exit(1); }
    await injectYAML(page, yamlContent);
    await clickSave(page);
  } catch(e) {
    console.error('Error:', e.message);
  }
  await browser.close();
}

main().catch(e => { console.error('Fatal:', e.message); process.exit(1); });
