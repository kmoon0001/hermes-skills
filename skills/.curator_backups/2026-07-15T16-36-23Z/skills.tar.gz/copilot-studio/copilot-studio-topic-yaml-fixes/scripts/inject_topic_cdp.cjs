/**
 * CDP-based Copilot Studio topic YAML injector
 * 
 * Uses direct CDP WebSocket connection (more reliable than Playwright for many tabs)
 * 
 * Usage: node inject_topic_cdp.cjs <BOT_ID> <TOPIC_NAME> <YAML_FILE_PATH>
 * Example: node inject_topic_cdp.cjs "6e437a77-a5dc-4984-90eb-4924eab10006" "Analyze SLP Evaluation Report" "./slp_fix_eval_report.yaml"
 * 
 * PITFALLS:
 * - Chrome must be running with --remote-debugging-port=9223
 * - SPA needs 25-30s to render after navigation
 * - Monaco editor may not load if too many tabs are open (>15-20)
 * - Save button may stay disabled if React dirty-state doesn't trigger
 * - User must manually type char + Backspace if Save stays disabled
 */

const WebSocket = require('ws');
const http = require('http');
const fs = require('fs');
const path = require('path');

const ENV_ID = 'Default-03cc92c3-986c-4cf4-ae27-1478cf99d17f';

async function getTargets() {
  return new Promise(resolve => {
    http.get('http://127.0.0.1:9223/json', res => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => resolve(JSON.parse(d)));
    });
  });
}

async function createTab(url) {
  return new Promise(resolve => {
    const req = http.request(`http://127.0.0.1:9223/json/new?${url}`, { method: 'PUT' }, res => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => resolve(JSON.parse(d)));
    });
    req.end();
  });
}

async function cdpEval(pageId, expression, timeout = 30000) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(`ws://127.0.0.1:9223/devtools/page/${pageId}`);
    let done = false;
    
    ws.on('open', () => {
      ws.send(JSON.stringify({
        id: 1,
        method: 'Runtime.evaluate',
        params: { expression, returnByValue: true }
      }));
    });
    
    ws.on('message', (data) => {
      try {
        const msg = JSON.parse(data.toString());
        if (msg.id === 1) {
          done = true;
          ws.close();
          resolve(msg.result?.result?.value);
        }
      } catch(e) {}
    });
    
    ws.on('error', (err) => {
      if (!done) {
        done = true;
        reject(err);
      }
    });
    
    setTimeout(() => {
      if (!done) {
        done = true;
        ws.close();
        reject(new Error('Timeout'));
      }
    }, timeout);
  });
}

async function main() {
  const botId = process.argv[2];
  const topicName = process.argv[3];
  const yamlFile = process.argv[4];
  
  if (!botId || !topicName || !yamlFile) {
    console.error('Usage: node inject_topic_cdp.cjs <BOT_ID> <TOPIC_NAME> <YAML_FILE_PATH>');
    process.exit(1);
  }
  
  const yamlContent = fs.readFileSync(path.resolve(yamlFile), 'utf8');
  console.log(`Bot: ${botId}`);
  console.log(`Topic: ${topicName}`);
  console.log(`YAML: ${yamlContent.length} chars`);
  
  // Create new tab for topics page
  console.log('\nOpening topics page...');
  const topicsUrl = `https://copilotstudio.microsoft.com/environments/${ENV_ID}/bots/${botId}/topics`;
  const tab = await createTab(topicsUrl);
  console.log(`Tab: ${tab.id}`);
  
  // Wait for page to load (SPA needs 25-30s)
  console.log('Waiting for page to load...');
  await new Promise(r => setTimeout(r, 25000));
  
  // Check if topics loaded
  const pageText = await cdpEval(tab.id, 'document.body.innerText.substring(0, 500)');
  console.log('Page loaded:', pageText?.includes('Topics') ? 'Yes' : 'No');
  
  // Search for the topic
  console.log(`\nSearching for topic: ${topicName}`);
  const searchResult = await cdpEval(tab.id, `
    (function() {
      var inputs = document.querySelectorAll('input');
      for(var inp of inputs) {
        if(inp.placeholder && (inp.placeholder.includes('search') || inp.placeholder.includes('filter'))) {
          inp.focus();
          inp.value = '${topicName}';
          inp.dispatchEvent(new Event('input', {bubbles: true}));
          return 'search_filled';
        }
      }
      return 'no_search_input';
    })()
  `);
  console.log('Search:', searchResult);
  
  // Wait for search results
  await new Promise(r => setTimeout(r, 3000));
  
  // Click on the topic
  console.log('Clicking topic...');
  const clickResult = await cdpEval(tab.id, `
    (function() {
      var all = document.querySelectorAll('*');
      for(var el of all) {
        if(el.textContent && el.textContent.includes('${topicName}') && el.offsetParent && el.tagName !== 'BODY') {
          el.click();
          return 'clicked_' + el.tagName;
        }
      }
      return 'not_found';
    })()
  `);
  console.log('Click:', clickResult);
  
  // Wait for topic to open
  await new Promise(r => setTimeout(r, 5000));
  
  // Open code editor (click More -> Open code editor)
  console.log('\nOpening code editor...');
  const moreResult = await cdpEval(tab.id, `
    (function() {
      var btns = document.querySelectorAll('button');
      for(var b of btns) {
        if(b.textContent && b.textContent.includes('More') && b.offsetParent) {
          b.click();
          return 'clicked_more';
        }
      }
      return 'no_more_button';
    })()
  `);
  console.log('More:', moreResult);
  
  await new Promise(r => setTimeout(r, 2000));
  
  // Click "Open code editor"
  const codeEditorResult = await cdpEval(tab.id, `
    (function() {
      var all = document.querySelectorAll('*');
      for(var el of all) {
        if(el.textContent && el.textContent.includes('Open code editor') && el.offsetParent) {
          el.click();
          return 'clicked_code_editor';
        }
      }
      return 'not_found';
    })()
  `);
  console.log('Code editor:', codeEditorResult);
  
  // Wait for Monaco editor to load
  console.log('Waiting for Monaco editor...');
  await new Promise(r => setTimeout(r, 5000));
  
  // Check if Monaco editor is present
  const hasMonaco = await cdpEval(tab.id, 'document.querySelector(".monaco-editor") ? "yes" : "no"');
  console.log('Monaco editor:', hasMonaco);
  
  if (hasMonaco === 'no') {
    console.log('⚠️ Monaco editor not found. Manual intervention may be needed.');
    console.log('Tab left open for manual use.');
    process.exit(1);
  }
  
  // Inject YAML content using Input.insertText
  console.log('\nInjecting YAML content...');
  
  // First, select all content
  await cdpEval(tab.id, `
    (function() {
      var editor = document.querySelector('.monaco-editor');
      if(editor) {
        editor.click();
        return 'editor_focused';
      }
      return 'no_editor';
    })()
  `);
  
  await new Promise(r => setTimeout(r, 500));
  
  // Use CDP Input.dispatchKeyEvent to send Ctrl+A and insert text
  const ws2 = new WebSocket(`ws://127.0.0.1:9223/devtools/page/${tab.id}`);
  
  await new Promise((resolve) => {
    ws2.on('open', async () => {
      // Send Ctrl+A to select all
      ws2.send(JSON.stringify({
        id: 1,
        method: 'Input.dispatchKeyEvent',
        params: { type: 'keyDown', key: 'a', code: 'KeyA', modifiers: 2 }
      }));
      
      ws2.send(JSON.stringify({
        id: 2,
        method: 'Input.dispatchKeyEvent',
        params: { type: 'keyUp', key: 'a', code: 'KeyA', modifiers: 2 }
      }));
      
      await new Promise(r => setTimeout(r, 300));
      
      // Insert text using Input.insertText
      ws2.send(JSON.stringify({
        id: 3,
        method: 'Input.insertText',
        params: { text: yamlContent }
      }));
      
      await new Promise(r => setTimeout(r, 1000));
      
      // Type a space and backspace to wake save tracker
      ws2.send(JSON.stringify({
        id: 4,
        method: 'Input.dispatchKeyEvent',
        params: { type: 'keyDown', key: ' ', code: 'Space' }
      }));
      
      ws2.send(JSON.stringify({
        id: 5,
        method: 'Input.dispatchKeyEvent',
        params: { type: 'keyUp', key: ' ', code: 'Space' }
      }));
      
      await new Promise(r => setTimeout(r, 100));
      
      ws2.send(JSON.stringify({
        id: 6,
        method: 'Input.dispatchKeyEvent',
        params: { type: 'keyDown', key: 'Backspace', code: 'Backspace' }
      }));
      
      ws2.send(JSON.stringify({
        id: 7,
        method: 'Input.dispatchKeyEvent',
        params: { type: 'keyUp', key: 'Backspace', code: 'Backspace' }
      }));
      
      await new Promise(r => setTimeout(r, 500));
      
      console.log('✅ Content injected!');
      ws2.close();
      resolve();
    });
  });
  
  // Click Save button
  console.log('Clicking Save...');
  const saveResult = await cdpEval(tab.id, `
    (function() {
      var btns = document.querySelectorAll('button');
      for(var b of btns) {
        if(b.textContent && b.textContent.trim() === 'Save' && b.offsetParent && !b.disabled) {
          b.click();
          return 'save_clicked';
        }
      }
      return 'save_not_found_or_disabled';
    })()
  `);
  console.log('Save:', saveResult);
  
  await new Promise(r => setTimeout(r, 3000));
  
  // Check for validation errors
  const errorCheck = await cdpEval(tab.id, `
    (function() {
      var t = document.body.innerText;
      if(t.includes('Invalid kind')) return 'validation_error: ' + t.substring(t.indexOf('Invalid kind'), t.indexOf('Invalid kind') + 100);
      if(t.includes('error')) return 'possible_error';
      return 'no_errors';
    })()
  `);
  console.log('Validation:', errorCheck);
  
  if (errorCheck?.includes('validation_error')) {
    console.log('❌ YAML validation error. Check the YAML format.');
  } else {
    console.log('✅ Topic saved successfully!');
  }
  
  console.log('\nDone! Tab left open for verification.');
}

main().catch(e => {
  console.error('Error:', e.message);
  process.exit(1);
});
