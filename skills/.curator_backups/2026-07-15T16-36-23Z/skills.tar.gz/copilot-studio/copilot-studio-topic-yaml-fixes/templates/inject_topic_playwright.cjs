/**
 * Playwright-based Copilot Studio topic YAML injector
 * 
 * WORKING pattern validated June 14 2026.
 * Injects YAML into a topic's code editor via Playwright.
 * 
 * Usage: node inject_topic_playwright.cjs <YAML_FILE>
 * The topic name is extracted from the YAML's displayName field.
 * 
 * Prerequisites:
 * - Chrome running with --remote-debugging-port=9223
 * - User signed in to Copilot Studio
 * - playwright-core installed: npm install playwright-core
 * 
 * How it works:
 * 1. Connects to existing Chrome instance
 * 2. Navigates to agent Overview page (NOT /topics — SPA won't render)
 * 3. Clicks topic link from Overview (custom topics are visible as links)
 * 4. Opens code editor via More → Open code editor
 * 5. Injects YAML via clipboard (Ctrl+A → clipboard writeText → Ctrl+V)
 * 6. Wakes React save tracker (Space → Backspace)
 * 7. Clicks Save
 */

const { chromium } = require('playwright-core');
const fs = require('fs');
const path = require('path');

// CONFIGURE THESE FOR YOUR AGENT
const BOT_ID = '6e437a77-a5dc-4984-90eb-4924eab10006'; // SLP bot ID
const ENV_ID = 'Default-03cc92c3-986c-4cf4-ae27-1478cf99d17f';

async function injectTopic(page, topicName, yamlContent) {
  console.log(`\n=== Injecting: ${topicName} ===`);
  
  // Navigate to Overview page (topics are visible as links here)
  await page.goto(`https://copilotstudio.microsoft.com/environments/${ENV_ID}/bots/${BOT_ID}/overview`);
  await page.waitForTimeout(15000);
  
  // Click topic link from Overview
  const topicLink = page.locator('a', { hasText: topicName }).first();
  if (!(await topicLink.isVisible({ timeout: 10000 }).catch(() => false))) {
    console.log(`Topic link not found: ${topicName}`);
    return false;
  }
  
  await topicLink.click();
  await page.waitForTimeout(5000);
  
  // Find More button with "Open code editor" (iterate through all More buttons)
  const moreBtns = await page.getByRole('button', { name: 'More' }).all();
  for (const btn of moreBtns) {
    if (!(await btn.isVisible().catch(() => false))) continue;
    
    await btn.click();
    await page.waitForTimeout(1500);
    
    const codeEditor = page.getByText(/open code editor/i);
    if (await codeEditor.isVisible({ timeout: 1000 }).catch(() => false)) {
      await codeEditor.click();
      await page.waitForTimeout(5000);
      
      if (await page.locator('.monaco-editor').isVisible({ timeout: 10000 }).catch(() => false)) {
        // Focus editor
        await page.locator('.monaco-editor').click();
        await page.waitForTimeout(500);
        
        // Select all
        await page.keyboard.press('Control+A');
        await page.waitForTimeout(300);
        
        // Inject via clipboard
        await page.evaluate((text) => navigator.clipboard.writeText(text), yamlContent);
        await page.waitForTimeout(200);
        await page.keyboard.press('Control+V');
        await page.waitForTimeout(1000);
        
        // Wake React save tracker
        await page.keyboard.press('Space');
        await page.waitForTimeout(100);
        await page.keyboard.press('Backspace');
        await page.waitForTimeout(500);
        
        // Click Save
        const saveBtn = page.getByRole('button', { name: 'Save' }).first();
        if (await saveBtn.isVisible({ timeout: 3000 })) {
          await saveBtn.click();
          await page.waitForTimeout(3000);
          
          const hasError = await page.evaluate(() => document.body.innerText.includes('Invalid'));
          if (hasError) {
            console.log(`❌ Validation error for ${topicName}`);
            return false;
          } else {
            console.log(`✅ ${topicName} saved!`);
            return true;
          }
        } else {
          console.log('Save button not available');
          return false;
        }
      } else {
        console.log('Monaco editor not found');
        return false;
      }
    } else {
      await page.keyboard.press('Escape');
      await page.waitForTimeout(500);
    }
  }
  
  console.log('Could not find code editor');
  return false;
}

async function main() {
  const yamlFile = process.argv[2];
  if (!yamlFile) {
    console.error('Usage: node inject_topic_playwright.cjs <YAML_FILE>');
    process.exit(1);
  }
  
  const yamlContent = fs.readFileSync(path.resolve(yamlFile), 'utf8');
  
  // Extract topic name from YAML
  const nameMatch = yamlContent.match(/displayName:\s*(.+)$/m);
  const topicName = nameMatch ? nameMatch[1].trim() : 'Unknown';
  
  console.log(`Topic: ${topicName}`);
  console.log(`YAML: ${yamlContent.length} chars`);
  
  const browser = await chromium.connectOverCDP('http://127.0.0.1:9223');
  const context = browser.contexts()[0];
  const page = await context.newPage();
  
  const success = await injectTopic(page, topicName, yamlContent);
  
  console.log(success ? '\n✅ Done!' : '\n❌ Failed — manual injection needed');
  
  await browser.close();
}

main().catch(e => {
  console.error('Error:', e.message);
  process.exit(1);
});
