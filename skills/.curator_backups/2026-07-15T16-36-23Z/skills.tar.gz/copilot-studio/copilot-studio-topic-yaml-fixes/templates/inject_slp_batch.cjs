/**
 * Batch SLP topic injector using CDP
 * 
 * Injects all 4 SLP audit topic YAMLs in sequence
 * Usage: node inject_slp_batch.cjs
 * 
 * Requires:
 * - Chrome running with --remote-debugging-port=9223
 * - SLP topic YAML files in the same directory:
 *   - slp_fix_eval_report.yaml
 *   - slp_fix_progress_note.yaml
 *   - slp_fix_discharge.yaml
 */

const WebSocket = require('ws');
const http = require('http');
const fs = require('fs');
const path = require('path');

const HOME = path.join(process.env.USERPROFILE || process.env.HOME, 'AppData/Local/hermes/profiles/coding-profile/home');
const BOT_ID = '6e437a77-a5dc-4984-90eb-4924eab10006';
const ENV_ID = 'Default-03cc92c3-986c-4cf4-ae27-1478cf99d17f';

const TOPICS = [
  { name: 'Analyze SLP Evaluation Report', file: 'slp_fix_eval_report.yaml' },
  { name: 'Analyze SLP Progress Note', file: 'slp_fix_progress_note.yaml' },
  { name: 'Analyze SLP Discharge Summary', file: 'slp_fix_discharge.yaml' },
];

async function createTab(url) {
  return new Promise(resolve => {
    const req = http.request(`http://127.0.0.1:9223/json/new?${url}`, { method: 'PUT' }, res => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => resolve(JSON.parse(d)));
    });
    req.end();
  });
}

async function cdpEval(pageId, expression, timeout = 30000) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(`ws://127.0.0.1:9223/devtools/page/${pageId}`);
    let done = false;
    
    ws.on('open', () => {
      ws.send(JSON.stringify({
        id: 1,
        method: 'Runtime.evaluate',
        params: { expression, returnByValue: true }
      }));
    });
    
    ws.on('message', (data) => {
      try {
        const msg = JSON.parse(data.toString());
        if (msg.id === 1) {
          done = true;
          ws.close();
          resolve(msg.result?.result?.value);
        }
      } catch(e) {}
    });
    
    ws.on('error', (err) => {
      if (!done) {
        done = true;
        reject(err);
      }
    });
    
    setTimeout(() => {
      if (!done) {
        done = true;
        ws.close();
        reject(new Error('Timeout'));
      }
    }, timeout);
  });
}

async function injectTopic(tabId, topicName, yamlContent) {
  console.log(`\n=== Injecting: ${topicName} ===`);
  
  // Navigate to topics page
  await cdpEval(tabId, `
    window.location.href = 'https://copilotstudio.microsoft.com/environments/${ENV_ID}/bots/${BOT_ID}/topics';
  `);
  
  // Wait for SPA to load
  console.log('Waiting for SPA to load...');
  await new Promise(r => setTimeout(r, 25000));
  
  // Search for topic
  console.log(`Searching for: ${topicName}`);
  await cdpEval(tabId, `
    (function() {
      var inputs = document.querySelectorAll('input');
      for(var inp of inputs) {
        if(inp.placeholder && (inp.placeholder.includes('search') || inp.placeholder.includes('filter'))) {
          inp.focus();
          inp.value = '${topicName}';
          inp.dispatchEvent(new Event('input', {bubbles: true}));
          return 'search_filled';
        }
      }
      return 'no_search_input';
    })()
  `);
  
  await new Promise(r => setTimeout(r, 3000));
  
  // Click topic
  console.log('Clicking topic...');
  await cdpEval(tabId, `
    (function() {
      var all = document.querySelectorAll('*');
      for(var el of all) {
        if(el.textContent && el.textContent.includes('${topicName}') && el.offsetParent && el.tagName !== 'BODY') {
          el.click();
          return 'clicked';
        }
      }
      return 'not_found';
    })()
  `);
  
  await new Promise(r => setTimeout(r, 5000));
  
  // Open code editor
  console.log('Opening code editor...');
  await cdpEval(tabId, `
    (function() {
      var btns = document.querySelectorAll('button');
      for(var b of btns) {
        if(b.textContent && b.textContent.includes('More') && b.offsetParent) {
          b.click();
          return 'clicked_more';
        }
      }
      return 'no_more_button';
    })()
  `);
  
  await new Promise(r => setTimeout(r, 2000));
  
  await cdpEval(tabId, `
    (function() {
      var all = document.querySelectorAll('*');
      for(var el of all) {
        if(el.textContent && el.textContent.includes('Open code editor') && el.offsetParent) {
          el.click();
          return 'clicked_code_editor';
        }
      }
      return 'not_found';
    })()
  `);
  
  // Wait for Monaco editor
  console.log('Waiting for Monaco editor...');
  await new Promise(r => setTimeout(r, 5000));
  
  const hasMonaco = await cdpEval(tabId, 'document.querySelector(".monaco-editor") ? "yes" : "no"');
  if (hasMonaco === 'no') {
    console.log('⚠️ Monaco editor not found. Skipping this topic.');
    return false;
  }
  
  // Focus editor and select all
  await cdpEval(tabId, `
    (function() {
      var editor = document.querySelector('.monaco-editor');
      if(editor) { editor.click(); return 'focused'; }
      return 'no_editor';
    })()
  `);
  
  await new Promise(r => setTimeout(r, 500));
  
  // Inject via CDP Input.insertText
  const ws = new WebSocket(`ws://127.0.0.1:9223/devtools/page/${tabId}`);
  
  await new Promise((resolve) => {
    ws.on('open', async () => {
      // Ctrl+A
      ws.send(JSON.stringify({ id: 1, method: 'Input.dispatchKeyEvent', params: { type: 'keyDown', key: 'a', code: 'KeyA', modifiers: 2 } }));
      ws.send(JSON.stringify({ id: 2, method: 'Input.dispatchKeyEvent', params: { type: 'keyUp', key: 'a', code: 'KeyA', modifiers: 2 } }));
      await new Promise(r => setTimeout(r, 300));
      
      // Insert text
      ws.send(JSON.stringify({ id: 3, method: 'Input.insertText', params: { text: yamlContent } }));
      await new Promise(r => setTimeout(r, 1000));
      
      // Space + Backspace to wake save tracker
      ws.send(JSON.stringify({ id: 4, method: 'Input.dispatchKeyEvent', params: { type: 'keyDown', key: ' ', code: 'Space' } }));
      ws.send(JSON.stringify({ id: 5, method: 'Input.dispatchKeyEvent', params: { type: 'keyUp', key: ' ', code: 'Space' } }));
      await new Promise(r => setTimeout(r, 100));
      ws.send(JSON.stringify({ id: 6, method: 'Input.dispatchKeyEvent', params: { type: 'keyDown', key: 'Backspace', code: 'Backspace' } }));
      ws.send(JSON.stringify({ id: 7, method: 'Input.dispatchKeyEvent', params: { type: 'keyUp', key: 'Backspace', code: 'Backspace' } }));
      await new Promise(r => setTimeout(r, 500));
      
      console.log('✅ Content injected!');
      ws.close();
      resolve();
    });
  });
  
  // Click Save
  console.log('Clicking Save...');
  const saveResult = await cdpEval(tabId, `
    (function() {
      var btns = document.querySelectorAll('button');
      for(var b of btns) {
        if(b.textContent && b.textContent.trim() === 'Save' && b.offsetParent && !b.disabled) {
          b.click();
          return 'save_clicked';
        }
      }
      return 'save_not_found_or_disabled';
    })()
  `);
  console.log('Save:', saveResult);
  
  await new Promise(r => setTimeout(r, 3000));
  
  // Check for errors
  const errorCheck = await cdpEval(tabId, `
    (function() {
      var t = document.body.innerText;
      if(t.includes('Invalid kind')) return 'validation_error';
      return 'no_errors';
    })()
  `);
  
  if (errorCheck === 'validation_error') {
    console.log('❌ YAML validation error!');
    return false;
  }
  
  console.log(`✅ ${topicName} saved!`);
  return true;
}

async function main() {
  console.log('SLP Batch Topic Injector');
  console.log('========================');
  
  let successCount = 0;
  
  for (const topic of TOPICS) {
    const yamlPath = path.join(HOME, topic.file);
    
    if (!fs.existsSync(yamlPath)) {
      console.log(`⚠️ File not found: ${topic.file}`);
      continue;
    }
    
    const yamlContent = fs.readFileSync(yamlPath, 'utf8');
    
    // Create a new tab for each topic
    const tab = await createTab(`https://copilotstudio.microsoft.com/environments/${ENV_ID}/bots/${BOT_ID}/topics`);
    console.log(`Tab: ${tab.id}`);
    
    const success = await injectTopic(tab.id, topic.name, yamlContent);
    if (success) successCount++;
  }
  
  console.log(`\n=== Summary ===`);
  console.log(`Injected: ${successCount}/${TOPICS.length} topics`);
  
  if (successCount === TOPICS.length) {
    console.log('\n✅ All topics injected! Next steps:');
    console.log('1. Publish SLP agent');
    console.log('2. Trigger Conversation evaluation');
  }
}

main().catch(e => {
  console.error('Error:', e.message);
  process.exit(1);
});
