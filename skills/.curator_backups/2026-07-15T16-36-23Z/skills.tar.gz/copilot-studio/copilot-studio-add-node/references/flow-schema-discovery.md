# Flow Schema Discovery (Power Automate → Copilot Studio)

Query Dataverse to find Power Automate flows and their input/output schemas for InvokeFlowAction wiring.

## Find flows by name

```python
import urllib.parse, json

filt = urllib.parse.quote("contains(name, 'OCR') or contains(name, 'Extraction')")
url = f"{org}/api/data/v9.2/workflows?$filter={filt}&$select=workflowid,name,statecode,clientdata&$top=20"
```

## Get flow definition (clientdata JSON)

```python
url = f"{org}/api/data/v9.2/workflows({flow_id})?$select=workflowid,name,clientdata"
# Parse clientdata:
parsed = json.loads(clientdata)
definition = parsed["properties"]["definition"]
triggers = definition["triggers"]
```

## Verify VirtualAgent trigger

Only flows with `kind: VirtualAgent` work with Copilot Studio InvokeFlowAction:

```python
for tname, tdef in triggers.items():
    if tdef.get("kind") == "VirtualAgent":
        print(f"Compatible: {tname}")
        schema = tdef["inputs"]["schema"]
        print(f"Inputs: {list(schema.get('properties', {}).keys())}")
```

## Extract output schema

Find the Response action:

```python
actions = definition.get("actions", {})
for aname, adef in actions.items():
    if adef.get("type") == "Response":
        output_schema = adef["inputs"]["schema"]
        print(f"Outputs: {list(output_schema.get('properties', {}).keys())}")
```

## Check flow state

- `statecode=1` = Published/Active (good)
- `statecode=0` = Draft (won't trigger)
- `category=5` = Power Automate flow

## Common VirtualAgent flow I/O

| Direction | Property | Type | Notes | String-safe? |
|-----------|----------|------|-------|-------------|
| Input | file_name | string | Original filename with extension | ✅ |
| Input | document_type | string | Type descriptor for the flow's logic | ✅ |
| Input | requesting_agent | string | Caller identifier | ✅ |
| Input | extraction_goal | string | What to extract/summarize | ✅ |
| Input | file_content | file | The uploaded file (pass `=Topic.xxx_doc` directly) | ✅ |
| Output | extracted_text | string | OCR-processed or extracted text | ✅ bind this |
| Output | processing_status | string | "Success"/"Failed"/etc. | ✅ bind this |
| Output | char_count | **integer** | Extracted text character count | ❌ **omit** — causes 4-5 validation errors per topic |
| Output | error_message | string | Error details if processing failed | ✅ bind if needed, but not required downstream |

### PITFALL: Only bind string-type flow outputs in topic YAML
The `char_count` field is type `integer` in the flow's output schema. When bound to a topic variable in YAML via `char_count: "Topic.xxx_count"`, Copilot Studio raises schema validation errors (~4-5 per topic) because topic variables are implicitly typed as strings. **Remove `char_count` and any other non-string output bindings.** The flow still processes them internally — they just don't need topic variables.

## Per-topic naming convention

When adding OCR to N document processing topics:

| Topic | File Var | Extracted Text Var | Flow |
|-------|----------|-------------------|------|
| Evaluation | `Topic.eval_doc` | `Topic.eval_doc_extracted` | OCR txt extraction |
| Progress Report | `Topic.progress_doc` | `Topic.progress_doc_extracted` | OCR txt extraction |
| Discharge Summary | `Topic.discharge_doc` | `Topic.discharge_doc_extracted` | OCR txt extraction |
| Treatment Note | `Topic.daily_note_doc` | `Topic.daily_note_doc_extracted` | OCR txt extraction |
| Recertification | `Topic.recert_doc` | `Topic.recert_doc_extracted` | OCR txt extraction |
| Episode of Care | `Topic.episode_doc` | `Topic.episode_doc_extracted` | Large doc processor (100+ pages) |
