---
name: copilot-studio-add-node
description: Add or modify nodes in existing Copilot Studio topics (SendActivity, Question, ConditionGroup, etc.)
category: copilot-studio
---

# Add Node to Topic

Add or modify nodes in existing Copilot Studio topics. Nodes are elements inside a topic's actions array (SendActivity, Question, ConditionGroup, etc.). Different from actions/*.mcs.yml which are connector-based TaskDialogs.

For generative answers (SearchAndSummarizeContent, AnswerQuestionWithAI), use copilot-studio-add-generative-answers instead.

## Instructions

1. Auto-discover agent directory: Glob **/agent.mcs.yml. NEVER hardcode.

2. Parse arguments to identify node type, target topic file, and whether modifying existing node.

3. Look up node schema:
```bash
node "D:/my agents copilot studio/pipeline/scripts/schema-lookup.bundle.js" resolve <NodeType>
```

4. Read existing topic file to understand structure.

5. Generate/modify node with unique ID (format: <nodeType>_<6-8 random alphanumeric>) and all required properties.

6. Determine correct insertion point in actions array.

## Common Node Types

| Node | Purpose | Key Properties |
| SendActivity | Send message | kind, id, activity |
| Question | Ask user input | kind, id, variable, prompt, entity |
| SetVariable | Set/compute value | kind, id, variable, value |
| SetTextVariable | Set text with interpolation (YAML-only) | kind, id, variable, value |
| ConditionGroup | Branching logic | kind, id, conditions |
| BeginDialog | Call another topic | kind, id, dialog |
| EndDialog | End topic | kind, id |
| CancelAllDialogs | Cancel all topics | kind, id |
| AdaptiveCardPrompt | Adaptive Card | kind, id, card, output, outputType |
| SearchAndSummarizeContent | Generative answers | kind, id, variable, userInput |
| InvokeAIBuilderModelAction | Call AI Builder Prompty model | kind, id, aIModelId, input.binding, output.binding |
| InvokeFlowAction | Call Power Automate flow | kind, id, flowId, input.binding, output.binding |

## Generative Orchestration (GenerativeActionsEnabled: true)
- Prefer AutomaticTaskInput over Question nodes
- Still use Question for conditional asks or end-of-flow confirmations
- Prefer topic outputs over SendActivity for results

## Power Fx Quick Reference
- Expressions start with =
- String interpolation uses {}
- Variable init on first assignment: variable: init:Topic.MyVar
- Common: Text(), Now(), IsBlank(), !IsBlank()

## Example: Question Node
```yaml
- kind: Question
  id: question_k7xPm2
  variable: init:Topic.UserName
  prompt: What is your name?
  entity: StringPrebuiltEntity
  alwaysPrompt: true
  interruptionPolicy:
    allowInterruption: false
```

## InvokeFlowAction: Wiring Power Automate Flows

### Finding flow IDs and schemas
Query the Dataverse `workflows` entity (category=5 = Power Automate flow):
```
GET /api/data/v9.2/workflows?$filter=category eq 5 and contains(name, 'OCR')&$select=workflowid,name,clientdata
```
The flow's input/output schema is in `clientdata` JSON:
- Parse: `clientdata → properties → definition → triggers → manual`
- Check `kind: VirtualAgent` (required for Copilot Studio compatibility)
- Input schema: `triggers.manual.inputs.schema.properties`
- Output schema: find the Response action's `inputs.schema` in the actions array

### Common VirtualAgent flow I/O
| Direction | Parameter | Type | Purpose |
|-----------|-----------|------|---------|
| Input | file_name | string | Original filename |
| Input | document_type | string | Doc type descriptor |
| Input | requesting_agent | string | Agent/caller name |
| Input | extraction_goal | string | What to extract |
| Input | file_content | file | Uploaded file bytes |
| Output | extracted_text | string | OCR/processed text |
| Output | processing_status | string | Status indicator |
| Output | char_count | integer | Extracted char count |
| Output | error_message | string | Error details |

### OCR pipeline pattern (document processing topics)
Insert InvokeFlowAction between Question (file upload) and InvokeAIBuilderModelAction.
**Only bind string-type outputs — omit `char_count` (integer) to avoid 27 topic validation errors.**

```yaml
- kind: Question
  id: question_upload_doc
  variable: init:Topic.audit_doc
  prompt: Please upload the document.
  entity: FilePrebuiltEntity
- kind: InvokeFlowAction
  id: invokeFlowAction_ocr
  flowId: "<workflow-guid>"
  input:
    binding:
      file_name: "=Topic.audit_doc.name"
      document_type: Evaluation
      requesting_agent: Feedback_Agent
      extraction_goal: Extract all clinical text
      file_content: "=Topic.audit_doc"
  output:
    binding:
      extracted_text: Topic.ocr_text        # string ✅
      processing_status: Topic.ocr_status    # string ✅
      # char_count: Topic.ocr_count          # integer ❌ omit — causes validation errors
      # error_message: Topic.ocr_error       # string, but omit if not used downstream
- kind: SetVariable
  id: setVar_clean_text
  variable: Topic.clean_text
  value: "=Topic.ocr_text"
- kind: InvokeAIBuilderModelAction
  id: invokeAIBuilder_audit
  input:
    binding:
      poc_doc: "=Topic.clean_text"  # extracted text, not raw file
  output:
    binding:
      predictionOutput: audit_result
```
For large docs (100+ pages), use a chunking-capable flow instead of a simple OCR flow.

### PITFALL: Flow output binding type mismatch (char_count integer → 27 topic errors)
When copying InvokeFlowAction output bindings from a flow's schema, **non-string types cause topic validation errors**. In particular, `char_count` (type: integer) and any boolean/number output fields trigger ~4-5 schema errors per topic (totaling 27 errors for 6 topics). Copilot Studio topic variables in YAML are implicitly typed as strings.

**Fix:** Only bind string-type outputs in the YAML. Omit `char_count` and `error_message` (if string but unused) — keep only `extracted_text` (string) and `processing_status` (string). The integer output is still set in the flow but doesn't need a topic variable.

```yaml
# ✅ Correct — only string outputs bound
output:
  binding:
    extracted_text: Topic.ocr_text
    processing_status: Topic.ocr_status
    # char_count omitted — integer type causes validation errors
    # error_message omitted — not used downstream
```

The example in the OCR pipeline section above shows all 4 bindings for documentation purposes, but in practice remove the integer/bool types to avoid validation failures.

### PITFALL: PvaPublish returns empty PublishedBotContentId
`POST .../PvaPublish` with body `{}` returns HTTP 200 but `"PublishedBotContentId": ""`. This is a known quirk — the publish may still succeed. Verify by checking `bot.componentstate=0` (Published) or the Copilot Studio UI publish timestamp. The empty response does NOT mean failure. If unsure, use gateway publishv2-operations API or `pac copilot publish` as an alternative.

### Bulk-patching pattern (add OCR to N topics)
When adding the same node pattern across multiple topics (e.g., inserting InvokeFlowAction before InvokeAIBuilderModelAction in 6 doc topics):

1. **Define per-topic mapping**: `[(schemaname_suffix, doc_var, display_name, flow_id), ...]`
2. **Build node template** with f-string using per-topic vars
3. **Insert into YAML** by finding the line index of the next action after the insertion point
4. **PATCH via Dataverse REST** — replace `data` field and send `PATCH /botcomponents({id})`
5. **Verify** by re-querying and checking for `InvokeFlowAction` + correct binding refs in the live data

Naming convention for OCR pipeline:
- Upload file var: `Topic.{doc_type}_doc` (e.g., `Topic.eval_doc`)
- OCR output var: `Topic.{doc_type}_doc_extracted` (e.g., `Topic.eval_doc_extracted`)
- Flow selection: small docs (<50 pages) → OCR flow, large docs (100+ pages) → chunking flow

### PITFALL: Verify flow compatibility
Flows with trigger `kind: VirtualAgent` are designed for Copilot Studio. Other triggers (plain Request, Scheduled, PowerApp) won't work. Always check `clientdata` before wiring. State=1 means published/active; state=0 means draft.

For discovering flow schemas and names from Dataverse, see `references/flow-schema-discovery.md`.

## Important
- Unique IDs: random 6-8 alphanumeric. Duplicate IDs cause errors.
- Verify node type exists in schema before generating.
- ConditionGroup needs at least one condition item with its own unique ID.
