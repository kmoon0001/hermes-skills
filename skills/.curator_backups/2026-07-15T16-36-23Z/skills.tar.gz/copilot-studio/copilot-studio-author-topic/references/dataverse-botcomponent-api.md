# Dataverse Botcomponent API Patterns (June 25, 2026)

Discovered when deploying the OT Document Audit topic programmatically via CDP/Playwright.

## Creating New Topics via Dataverse API

The `POST /api/data/v9.2/botcomponents` endpoint creates new bot components (topics, actions, knowledge sources).

### Required Fields

```json
{
  "name": "Topic Display Name",
  "schemaname": "copilots_header_8c921.topic.TopicPascalCase",
  "componenttype": 9,
  "data": "<full topic YAML as string>",
  "parentbotid@odata.bind": "/bots(<bot-uuid>)"
}
```

### Field Details

| Field | Required | Notes |
|-------|----------|-------|
| `name` | Yes | Display name shown in Copilot Studio UI |
| `schemaname` | Yes | Must follow pattern: `copilots_header_<hex>.topic.<PascalCaseName>`. Get existing schema names via `$select=schemaname` on any component. |
| `componenttype` | Yes | `9` for topics. Other types: `11` = action, `12` = knowledge source |
| `data` | Yes | Full YAML content of the topic. Must be valid Copilot Studio YAML. |
| `parentbotid@odata.bind` | Yes | Navigation property syntax. **Do NOT use `_parentbotid_value`** — CRM rejects it with "do not support direct update of Entity Reference properties" |

### Common Errors

| Error | Cause | Fix |
|-------|-------|-----|
| `Attribute 'schemaname' cannot be NULL` | Missing `schemaname` field | Add `schemaname` following the naming pattern |
| `CRM do not support direct update of Entity Reference properties` | Using `_parentbotid_value` | Switch to `'parentbotid@odata.bind': '/bots(<id>)'` |
| `204` (no body) | Success | Topic created/updated |

### Discovering the Schema Name Pattern

```javascript
// Get one existing component's schemaname
const comp = await page.evaluate(async({org, botId}) => {
  const r = await fetch(org+'/api/data/v9.2/botcomponents?$filter=_parentbotid_value eq \''+botId+'\' and componenttype eq 9 and name eq \'OT General Knowledge\'&$select=schemaname');
  return (await r.json()).value[0].schemaname;
});
// Returns: "copilots_header_8c921.topic.OTGeneralKnowledge"
```

### Updating Existing Topics

```javascript
// PATCH requires If-Match header for concurrency control
const r = await fetch(org+'/api/data/v9.2/botcomponents('+componentId+')', {
  method: 'PATCH',
  headers: {
    'Content-Type': 'application/json',
    'If-Match': '*',  // Required for PATCH
    'OData-MaxVersion': '4.0',
    'OData-Version': '4.0'
  },
  credentials: 'include',
  body: JSON.stringify({ data: new_yaml })
});
// Returns 204 on success
```

## Test Set API

The gateway REST API does **NOT** support test set creation or modification:
- `GET .../evaluationtestsuites` returns 404
- `POST .../evaluationtestsuites` returns 404

Test sets must be managed through the Copilot Studio UI:
1. Export existing test set as CSV
2. Modify questions in the CSV
3. Import as new test set via UI (Evaluation → New evaluation → Import from file)

CSV format (download template from UI for exact format):
- Comment lines starting with `#` (wrapped in quotes)
- Header: `"question","expectedResponse"`
- Each row: `"question text","expected response"` (both quoted)
- Windows line endings (`\r\n`)
- Column is `question` NOT `query`
- Without the comment header block, upload fails with "Something went wrong"
