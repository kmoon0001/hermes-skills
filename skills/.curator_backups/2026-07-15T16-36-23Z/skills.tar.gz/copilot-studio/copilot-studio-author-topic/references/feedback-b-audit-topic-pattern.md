# Feedback B — Documentation Audit Topic Pattern

## Purpose

The **Topic Therapy Documentation Feedback** agent (botId `b0346795`) is a Medicare Part B compliance auditor. Its documentation audit topics follow **two possible pipelines** depending on whether the agent uses AI Builder models or SearchAndSummarizeContent generative answers.

## Current State (Jul 7 2026) — All 7 Topics Use OCR → AI Builder Pipeline

After the Jul 7 2026 rebuild, ALL documentation audit topics use the **file upload → InvokeFlowAction OCR extraction → InvokeAIBuilderModelAction → SendActivity** pipeline. No topics use SearchAndSummarizeContent (SASC) anymore.

**Topics rebuilt (all 7):**
- Evaluation/Assessment Audit
- Discharge Summary Audit
- Episode of Care Longitudinal Audit
- Progress Note Audit
- Recertification/UPOT Audit
- Treatment Encounter Note Audit
- Large Document OCR Audit (rebuilt from old paste-text+flow pattern)

**All use the same pattern:** `Question(FilePrebuiltEntity) → InvokeFlowAction(OCR) → InvokeAIBuilderModelAction → SendActivity → EndDialog`

| Topic | Schemaname | Component ID | Model ID |
|---|---|---|---|
| Evaluation/Assessment | ...EvaluationAssessmentandPlanofCare | aa5160f7-dced-49b7-bb9f-473946e77dd5 | 70a3c581-9fb2-4080-ab37-2189e2d6ed17 |
| Discharge Summary | ...DischargeSummary | adb841c6-e617-4c91-b69b-60b165634ced | 9dd0f78c-43a2-4e68-8b6a-ca41de4955ab |
| Episode of Care | ...EpisodeofCare | 800cc37e-27c6-4bc0-8169-d3936b7133c1 | 9dd0f78c-43a2-4e68-8b6a-ca41de4955ab |
| Progress Report Review | ...ProgressReportReview | fcd7c66e-e6b0-40fc-84fe-59b16119027d | 7ee33989-8f83-4035-b99e-345d380a4d41 |
| Recertification/UPOT | ...RecertificationUPOTReview | de006936-a7d7-4635-8b6f-e41e9622385d | 9dd0f78c-43a2-4e68-8b6a-ca41de4955ab |
| Treatment Encounter Note | ...TreatmentEncounterNoteReview | 261541b8-d3e2-41f0-bbad-e0f0f59217be | 9dd0f78c-43a2-4e68-8b6a-ca41de4955ab |
| Large Document OCR | ...LargeDocumentOCRExtraction | 9f1f6b99-0b06-4e9b-a5b6-cc9c6acbde1e | 9dd0f78c-43a2-4e68-8b6a-ca41de4955ab |

## Pipeline A: SASC-Only (Historical — Replaced Jul 7 2026)

The **Prod agent** (`Therapy Documentation Feedback Agent Prod`) uses **SearchAndSummarizeContent** — not AI Builder — for 5 of the 6 audit topics. No InvokeFlowAction or OCR extraction step is needed for text-based documents.

```yaml
kind: AdaptiveDialog
mcs.metadata:
  componentName: TDFA [Document Type] Audit
  description: |-
    Medicare Part B Therapy Documentation Compliance Auditor topic specialized in [ComponentName].
    Evaluates submitted therapy documentation for denial risk using CMS Chapter 15, Jimmo standards,
    and Ensign 7 Habits framework. Returns structured compliance findings.
modeldescription: |-
  Medicare Part B Therapy Documentation Compliance Auditor topic specialized in [ComponentName].
  Evaluates submitted therapy documentation for denial risk using CMS Chapter 15, Jimmo standards,
  and Ensign 7 Habits framework. Returns structured compliance findings.
beginDialog:
  kind: OnRecognizedIntent
  id: main
  intent:
    displayName: TDFA [Display Name]
    triggerQueries:
      - audit [document]
      - [document] documentation audit
      - check [document] for denial risk

  actions:
    # Step 1 — Ask user to upload the document
    - kind: Question
      id: upload_doc
      variable: init:Topic.UploadedDoc
      prompt: Please upload the [Document Name] for review.
      entity: FilePrebuiltEntity
      valueType:
        kind: FileType

    # Step 2 — Generative answers searches knowledge sources (no OCR flow, no AI Builder)
    - kind: SearchAndSummarizeContent
      userInput: "=Concatenate(\"Review the uploaded document for compliance. Document content: \", Topic.UploadedDoc.Content, \". Provide structured audit findings.\")"

    # Step 3 — Display results
    - kind: SendActivity
      activity: "=Topic.Answer"

    - kind: EndDialog
      id: end-topic
      clearTopicQueue: true
```

**Topics using this pattern (Prod):**
- Discharge_Summary_Review
- Episode_of_Care
- Progress_Report_Review
- Recertification_UPOT_Review
- Treatment_Encounter_Note_Review
- Evaluation_and_Plan_of_Care_Review__Copy_ (Copy variant uses SASC)

## Pipeline B: File Upload → OCR → AI Builder (Dev Agent or Scanned Images)

When the topic must handle **scanned images** (not native text PDFs/DOCX), the InvokeFlowAction OCR extraction + AI Builder model pipeline is required. See the full YAML template below.

```yaml
kind: AdaptiveDialog
mcs.metadata:
  componentName: TDFA [Document Type] Audit
  description: |-
    Medicare Part B Therapy Documentation Compliance Auditor topic specialized in [ComponentName].
    Evaluates submitted therapy documentation for denial risk using CMS Chapter 15, Jimmo standards,
    and Ensign 7 Habits framework. Returns structured compliance findings with issue, standard, and inline citation.
modeldescription: |-
  Medicare Part B Therapy Documentation Compliance Auditor topic specialized in [ComponentName].
  Evaluates submitted therapy documentation for denial risk using CMS Chapter 15, Jimmo standards,
  and Ensign 7 Habits framework. Returns structured compliance findings with issue, standard, and inline citation.
beginDialog:
  kind: OnRecognizedIntent
  id: main
  intent:
    displayName: TDFA [Display Name]
    triggerQueries:
      - audit [document]
      - [document] documentation audit
      - check [document] for denial risk
      - analyze [document]
      - review my [document]

  actions:
    # Step 1 — File upload
    - kind: Question
      id: ask_for_document
      interruptionPolicy:
        allowInterruption: true
      variable: init:Topic.TopicUploadedDoc
      prompt: Please upload the [Document Name] for review.
      entity: FilePrebuiltEntity
      valueType:
        kind: FileType

    # Step 2 — OCR text extraction (required for scanned docs/images)
    - kind: InvokeFlowAction
      id: invokeFlowAction_OCR
      input:
        binding:
          file_content: "=Topic.TopicUploadedDoc.Content"
          file_name: "=Topic.TopicUploadedDoc.Name"
      output:
        binding:
          extracted_text: Topic.extracted_text
      flowId: c71672f2-113b-f111-88b4-0022480b6bd9

    # Step 3 — Validate input + run audit
    - kind: ConditionGroup
      id: check_file_uploaded
      conditions:
        - id: file_is_valid
          condition: =!IsBlank(Topic.TopicUploadedDoc)
          actions:
            # Run AI Builder audit model on EXTRACTED text (not raw file)
            - kind: InvokeAIBuilderModelAction
              id: invokeAIBuilderModelAction
              input:
                binding:
                  Document_20input: =Topic.extracted_text
              output:
                binding:
                  predictionOutput: Global.GlobalAuditResultstext
              aIModelId: 9dd0f78c-43a2-4e68-8b6a-ca41de4955ab

            # CRITICAL: Must display results to user
            - kind: SendActivity
              id: send_audit_results
              activity: "=Global.GlobalAuditResultstext"

      elseActions:
        - kind: SendActivity
          id: send_error_message
          activity: It looks like you didn't upload a valid file. Please ensure the document is attached and try again.

    - kind: EndDialog
      id: end-topic
      clearTopicQueue: true
```

## AI Model IDs

| Topic | Model ID | Name |
|-------|----------|------|
| Treatment Encounter, Recert, Discharge, Eval, Episode of Care | `9dd0f78c-43a2-4e68-8b6a-ca41de4955ab` | Prompt for Progress Report |
| Progress Report Review | `7ee33989-8f83-4035-b99e-345d380a4d41` | Progress Report Prompt |

## Diagnostic Checklist for Silent Topics

When a Feedback B topic triggers, asks for a document, but then hangs or ends silently:

1. **Which pipeline is the topic using?** Check if it has `SearchAndSummarizeContent` (Pipeline A) or `InvokeAIBuilderModelAction` (Pipeline B).
2. **Pipeline A check:** Is the `SearchAndSummarizeContent` receiving proper `userInput`? Is there a `SendActivity` after it with `activity: "=Topic.Answer"`?
3. **Pipeline B check:** Is there a `SendActivity` in the success path? Format check: flat string, not nested dict.
4. **Pipeline B check:** Is the OCR flow present (Pipeline B)? Without it, scanned documents fail silently.
5. **Pipeline B check:** Is the AI Builder receiving `extracted_text` (Pipeline B)? `Document_20input` should bind to `=Topic.extracted_text`, NOT `=Topic.TopicUploadedDoc`.
6. **Pipeline B check:** Is the model ID correct? Progress Report uses `7ee33989`. All others use `9dd0f78c`.
7. **Both pipelines:** Are `modeldescription` + `description` present? Required for generative orchestration.

## Common Bugs Found (Jul 2026 Audit)

| Topic | Bug | Fixed |
|-------|-----|-------|
| Treatment Encounter Note Review | Missing SendActivity in success path; no OCR flow; missing metadata | Added all 3 |
| Recertification/UPOT Review | Same 3 bugs | Added all |
| Progress Report Review | Same 3 bugs + wrong model was used during early fix (restored `7ee33989`) | Added OCR flow + restored model |
| Discharge Summary | Same 3 bugs | Added all |
| Episode of Care | Same 3 bugs | Added all |
| Evaluation/Assessment | SendActivity used nested `activity: {value, text}` format (silently ignored); already had OCR flow | Fixed SendActivity format |
| Large Document OCR Extraction | Processing ran but never showed extracted text to user | Added ConditionGroup + SendActivity for output |

### 1. Missing SendActivity in success path
The most common cause of "topic hangs / ends silently." The topic runs the AI Builder, captures output to `Global.GlobalAuditResultstext`, but never sends it to the user. Fix: add a `SendActivity` inside the condition's success actions.

### 2. Wrong SendActivity format
```yaml
# BROKEN — nested activity with value+text
activity:
  value: =Global.GlobalAuditResultstext.text
  text:
    - "{Global.GlobalAuditResultstext.text}"

# FIXED — flat string
activity: "=Global.GlobalAuditResultstext"
```

### 3. Missing OCR extraction step
Directly passing `=Topic.TopicUploadedDoc` to the AI Builder only works for plain text files. For scanned images or PDFs, the flow `c71672f2` must extract text first. The AI Builder should receive `=Topic.extracted_text` instead.

### 4. Wrong output reference
The AI Builder output binding maps to `Global.GlobalAuditResultstext` (no `.text` suffix). The Evaluation topic had `Global.GlobalAuditResultstext.text` which creates a nested property access that doesn't exist.

### 5. No modeldescription/description metadata
Without both `mcs.metadata.description` and root-level `modeldescription`, generative orchestration may not select these topics correctly. See `copilot-studio-author-topic` for the standardised pattern.
