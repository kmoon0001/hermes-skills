# Power Automate: "Invalid Character in Dataverse Field" — documentbody Sanitization

## Problem
When a Power Automate flow writes to the Dataverse `annotations` table (Notes entity), the `documentbody` field can reject certain control characters, producing:

```
Invalid Character in Dataverse Field
```

This occurs intermittently because only some source files contain the problematic bytes.

## Root Cause
The `documentbody` field (nvarchar/ntext in Dataverse) rejects control characters in the range `0x00`–`0x1F` (non-printable ASCII), with the exception of `0x09` (tab), `0x0A` (newline), and `0x0D` (carriage return). If the file content (e.g., base64-encoded PDF binary) contains any of these characters — commonly `0x00` null bytes or `0x12` (DC2 / device control 2) — the Dataverse API call fails.

## Fix: Strip All Control Characters

### Approach A: Inline Expression (Single Action)
Replace the `item/documentbody` expression in the "Create job note" (or equivalent) Dataverse action with 29 nested `replace()` calls:

```
@replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(
  outputs('Resolve_file_content_base64'),
  decodeUriComponent('%00'), ''),
  decodeUriComponent('%01'), ''),
  ... (all %00–%1F except %09, %0A, %0D) ...
  decodeUriComponent('%1F'), '')
```

This preserves tab (%09), newline (%0A), and carriage return (%0D) while stripping all other control characters.

### Approach B: Compose Action (Cleaner)
Insert a "Compose" action between the file resolution step and the Dataverse create step:

1. Add a **Compose** action named `Sanitize_document_body`
2. Set its input to the same 29-nested-replace expression
3. Change the `Create job note` action's `item/documentbody` to `@outputs('Sanitize_document_body')`
4. Update `runAfter` on Create job note to depend on the Compose action

This is more maintainable — the expression lives in one place and the field reference is simple.

## Important Notes
- The `file_content` type MUST NOT have `"type":"string"` in the flow's `workflow.clientdata` — Dataverse's validator rejects File→String coercion. Remove via PATCH on the `workflow` entity in Dataverse.
- The `documentbody` field expects the file as a base64-encoded string, NOT decoded binary
- Blob/file upload fields use `.contentBytes` — do NOT add a dot on Blobs (the Dataverse API ignores dot-separated OData annotation suffixes on this field type)

## Flow Structure Affected
The typical affected flow is the **OCR Text Extraction - Async Submit and Process** (flowId `3f1304de-89ff-1a28-dc83-2e3488d49b9e`, Dataverse workflowEntityId `c71672f2-113b-f111-88b4-0022480b6bd9`) in the **Therapy AI Agents Dev** environment (a944fdf0-0d2e-e14d-8a73-0f5ffae23315).

## Applying the Fix via Power Automate UI
1. Open the flow → click the "Create job note" action
2. Go to the **Code view** tab
3. Locate `item/documentbody` in the JSON
4. Replace its value with the 29-nested-replace expression
5. Click **Save draft** → **Publish**

The UIA code editor element is at: `element_index: 111` with label `"Editor content"` in the Code view tab. Use `set_value` on this element to replace the entire action JSON.
