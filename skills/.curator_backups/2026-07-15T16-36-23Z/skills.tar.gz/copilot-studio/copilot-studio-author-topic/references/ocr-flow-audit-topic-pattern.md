# OCR Flow + AI Builder Audit Topic Pattern

For Copilot Studio topics that accept uploaded documents for compliance analysis via AI Builder, where the uploaded file may be a scanned image (not just text/native format).

## The Pipeline

```
User uploads file
  → Question (FilePrebuiltEntity, Topic.TopicUploadedDoc)
  → InvokeFlowAction: OCR Text Extraction (flow c71672f2)
    extracts text from: =TopicUploadedDoc.Content
    outputs: Topic.extracted_text, Topic.processing_status, Topic.error_message
  → ConditionGroup (file not blank?)
    → InvokeAIBuilderModelAction (audit on extracted_text)
      Document_20input: =Topic.extracted_text
      predictionOutput → Global.GlobalAuditResultstext
    → SendActivity (show results)
      activity: "=Global.GlobalAuditResultstext"
  → EndDialog
```

## Auto-Polling Retry Loop Pattern

When the OCR flow returns a job_id for async processing, topics need to poll for completion instead of dead-ending with "check back later."

### Variables needed
- `Topic.RetryCount` (Number, default 0) — tracks retry attempts

### Flow structure (after the submit action)
```
→ InvokeFlowAction (check status) → returns job_json
→ Set Topic.ocr_payload = Topic.job_json
→ Condition: "Status: Completed" in Topic.ocr_payload
  ├─ TRUE: Create generative answers → Message (show results) → End
  └─ FALSE: Condition: Topic.RetryCount < 10
       ├─ TRUE: Topic.RetryCount += 1 →
       │        Message "Still processing (attempt {Topic.RetryCount}/10)..." →
       │        GotoAction → status-check InvokeFlowAction
       └─ FALSE: Message "Job is taking too long." → End
```

### In Copilot Studio UI
1. Variables → + New → name: `RetryCount`, type: Number, default: 0
2. Click **+** below the "not complete" Message (on "All other conditions" branch)
3. Add **Condition**: `Topic.RetryCount < 10`
4. **True**: SetVariable (RetryCount+1) → Message "Still processing..." → GotoAction (target: status-check flow)
5. **False**: Message "Job is taking too long" → End
6. Save → Publish

### ⚠️ YAML `|-` block scalar + Power Fx condition pitfall

When writing the status-check condition in YAML with a block scalar (`|-`), the YAML processor introduces trailing whitespace/newlines that Power Fx cannot parse, resulting in **"Incompatible type"** errors in the Copilot Studio UI.

**WRONG** (block scalar adds unwanted whitespace to the formula):
```yaml
        - id: status_completed
          condition: |-
            ="Status: Completed" in Topic.ocr_payload
```

**CORRECT** (single-quoted string — YAML keeps the formula clean):
```yaml
        - id: status_completed
          condition: '="Status: Completed" in Text(Topic.ocr_payload)'
```

**`Text()` wrapper is required** — without it, `Topic.ocr_payload` (declared as `string` type) causes `in` operator failure. `Text()` forces explicit string context.

**Rule**: Any Power Fx formula that uses `in` operator against a topic variable MUST wrap the variable in `Text()` AND use a quoted scalar, not a block scalar.

### Max retries
10 attempts × ~5-10s per cycle = ~50-100s. Adjust threshold per document type.

### Pitfall: Infinite loop without retry limit
GotoAction back to status check with NO Topic.RetryCount guard = 500-iteration kill from Copilot Studio. Always add the counter.

## Power Automate Flow: Dataverse Invalid Character Fix

The OCR flow ("OCR Text Extraction - Async Submit and Process", flowId c71672f2) creates a Dataverse Notes record with the document body. `item/documentbody` fails with **"Invalid Character in Dataverse Field"** if the file has non-printable chars (0x00-0x1F).

### Root cause
Original expression only stripped `%12` (0x12/DC2). Other control chars (null bytes, etc.) still caused failures.

### Fix: 29-deep nested replace()
Replace `item/documentbody` in the "Create job note" action's Code view:

```
"item/documentbody": "@replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(outputs('Resolve_file_content_base64'), decodeUriComponent('%00'), ''), decodeUriComponent('%01'), ''), decodeUriComponent('%02'), ''), decodeUriComponent('%03'), ''), decodeUriComponent('%04'), ''), decodeUriComponent('%05'), ''), decodeUriComponent('%06'), ''), decodeUriComponent('%07'), ''), decodeUriComponent('%08'), ''), decodeUriComponent('%0B'), ''), decodeUriComponent('%0C'), ''), decodeUriComponent('%0E'), ''), decodeUriComponent('%0F'), ''), decodeUriComponent('%10'), ''), decodeUriComponent('%11'), ''), decodeUriComponent('%12'), ''), decodeUriComponent('%13'), ''), decodeUriComponent('%14'), ''), decodeUriComponent('%15'), ''), decodeUriComponent('%16'), ''), decodeUriComponent('%17'), ''), decodeUriComponent('%18'), ''), decodeUriComponent('%19'), ''), decodeUriComponent('%1A'), ''), decodeUriComponent('%1B'), ''), decodeUriComponent('%1C'), ''), decodeUriComponent('%1D'), ''), decodeUriComponent('%1E'), ''), decodeUriComponent('%1F'), '')"
```

Strips 28 control chars (0x00-0x1F) except 0x09 (tab), 0x0A (LF), 0x0D (CR) — the three Dataverse tolerates in nvarchar fields.

### Flow ID Mapping
The flow has TWO identifiers:
- **Power Automate UI ID** (from URL): `3f1304de-89ff-1a28-dc83-2e3488d49b9e` — used in `make.powerautomate.com/.../flows/{id}`
- **Dataverse workflow entity ID**: `c71672f2-113b-f111-88b4-0022480b6bd9` — the same flow appears in topics as `flowId: c71672f2`

### Power Automate Management API: READ-ONLY
- `GET api.flow.microsoft.com/.../flows/{id}` with `az` token for `https://service.powerapps.com/` — works, returns full flow definition
- `PUT` to the same URL — **fails** (management API is read-only). You cannot PATCH flow definitions programmatically via this API.
- Alternative: Dataverse API PATCH on `workflows` entity — requires internal DNS (`powervamg.us-il106.crm.dynamics.com`) that git-bash terminal can't resolve; works from browser.

### Applying via UIA (when API/CDP is blocked) — VERIFIED WORKING

**For Power Automate flow Code view** (Monaco editor):
1. Open flow editor → select action → Code view tab
2. Find the editor UIA element: `get_window_state(query="Editor", pid, window_id)`. Look for `role=Edit, label="Editor content"` — it exposes UIA `ValuePattern`.
3. `mcp__cua_driver__set_value(pid, window_id, element_index=N, value=fullJSON)` — replaces the entire action JSON atomically
4. Click **Save draft** → **Publish**
5. Verify: flow title status shows `•Published`

**Element discovery**: The editor has `role=Edit` with `label="Editor content"` and supports UIA ValuePattern. Query with `"Editor"` filter. Nested inside a Text container. The element index changes after tab switches — re-snapshot after clicking Code view.

**Pitfall**: The Code view editor only shows the selected ACTION's JSON, NOT the full flow definition. You must provide the complete action JSON including `type`, `inputs`, `parameters`, and `host`.

**CRITICAL**: Do NOT use `type_text` — the code editor content is hundreds of chars and `type_text` is unreliable for large blocks. `set_value` with UIA ValuePattern is the correct approach on Power Automate's Code view (which is NOT Monaco — it's a native UIA edit control).

**For Copilot Studio topic code editor** (Monaco — different):
- Monaco's UIA ValuePattern does NOT sync changes to the editor model
- `set_value` on Monaco writes to the accessibility textarea, not the model
- Save commits the OLD content despite visual verification showing new content
- **Only reliable path:** Write YAML to Desktop file, user opens → Ctrl+A → Ctrl+C → Alt+Tab to Copilot Studio → More → Open code editor → Ctrl+A → Delete → Ctrl+V → type space+backspace → Save

### YAML file delivery to Desktop
When providing paste-ready YAML blocks:
```python
import os
desktop = os.path.expanduser("~/Desktop")
path = os.path.join(desktop, f"{topic_name}_fixed.mcs.yml")
with open(path, "w") as f:
    f.write(yaml_content)
```
Then open Explorer: `powershell.exe -Command "Start-Process explorer 'C:\Users\<user>\Desktop'"`

**Pitfall — git-bash Notepad wrapper**: `notepad.exe` from git-bash may open a git wrapper script instead of the file. The wrapper shows shell code with `unix2dos.exe`/`dos2unix.exe`. **Fix:** Use Explorer double-click instead.

**MANDATORY: Schema-validate every fix file BEFORE delivery.**
```bash
node "D:/my agents copilot studio/pipeline/scripts/schema-lookup.bundle.js" validate "C:/Users/kevin/Desktop/${topic_name}_fixed.mcs.yml"
```
Only deliver files that pass all checks (18/18 or better). Never deliver unvalidated YAML — "it looks right" ≠ "it works in Copilot Studio." Schema validation catches: missing required properties, invalid kind values, duplicate node IDs, missing EndDialog, Power Fx prefix issues, and variable scope problems.

### Test schedule
Fix removes characters only — no change to trigger inputs or output contract. Topics calling this flow do NOT need updating.

## Known AI Model IDs (Feedback B Agent, orgbd048f00)

| Topic | Model ID |
|-------|----------|
| Main audit model | `9dd0f78c-43a2-4e68-8b6a-ca41de4955ab` |
| Progress Report model | `7ee33989-8f83-4035-b99e-345d380a4d41` |

## The `file` Binding YAML Quoting Pitfall

When the InvokeFlowAction passes a `file` object with `contentBytes` and `name`, the Power Fx expression uses curly braces: `={ contentBytes: First(System.Activity.Attachments).Content, name: First(System.Activity.Attachments).Name }`

**In YAML, curly braces `{}` are interpreted as flow mappings.** The expression MUST be quoted:

```yaml
# WRONG — YAML parser reads `{ contentBytes: ... }` as a mapping, not a Power Fx expression
file: ={ contentBytes: First(...).Content, name: First(...).Name }

# CORRECT — quoted string prevents YAML parsing
file: "={ contentBytes: First(System.Activity.Attachments).Content, name: First(System.Activity.Attachments).Name }"
```

**Detection**: If the topic's YAML fails to validate or the flow action returns empty for the file parameter, check for unquoted `={...}` expressions. The error manifests as the YAML linter throwing "mapping values are not allowed here" at the opening brace.

**What works**: Double-quotes (`"={ ... }"`) or single-quotes (`'={ ... }'`). Both prevent the YAML engine from interpreting the braces.

OCR flow returns `char_count` as integer-typed. Binding it as `Topic.char_count` in InvokeFlowAction output causes `FlowActionBadRequest` (StringDataType vs UnspecifiedDataType). **Fix:** Remove `char_count` from output binding entirely.

## The `file_content` / `file_name` Binding Pitfall

| Before (broken) | After (fixed) |
|---|---|
| `file_content: TopicUploadedDoc.Content` | `file_content: "=Topic.TopicUploadedDoc.Content"` |
| `file_name: =Topic.TopicUploadedDoc` | `file_name: "=Topic.TopicUploadedDoc.Name"` |

## Bug Checklist for Doc Audit Topics

- [ ] SendActivity in success path (after AI Builder/Flow)?
- [ ] SendActivity uses `activity: "=Global.GlobalAuditResultstext"` (flat string, not nested value/text)?
- [ ] Document_20input passing `=Topic.extracted_text` (not `=Topic.TopicUploadedDoc`)?
- [ ] char_count bindings removed from InvokeFlowAction output?
- [ ] file_content/file_name bindings use `"=Topic.TopicUploadedDoc.Content"` / `"=Topic.TopicUploadedDoc.Name"`?
- [ ] All key nodes appear exactly once (no duplicates from botched YAML surgery)?
- [ ] Model ID matches correct model for this topic type?
- [ ] elseActions SendActivity for error messages?
- [ ] EndDialog at end of actions (not inside a condition)?
- [ ] EndDialog has `clearTopicQueue: true`?
- [ ] **Auto-polling:** Topic.RetryCount guard on any GotoAction that loops to status-check?
