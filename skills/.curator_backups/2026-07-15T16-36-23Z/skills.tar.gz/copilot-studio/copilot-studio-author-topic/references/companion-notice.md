For OCR async job retry polling pattern (GotoAction + RetryCount guard, condition syntax, 500-execution crash fix), see companion reference: `../copilot-studio-topic-yaml-fixes/references/ocr-retry-polling-pattern.md`

This reference covers the **Power Automate flow** side (sanitization, Code view UIA) and the **topic YAML pattern** for submit+status-check. The companion covers the **infinite loop guard** detail and batch application across multiple topics.
