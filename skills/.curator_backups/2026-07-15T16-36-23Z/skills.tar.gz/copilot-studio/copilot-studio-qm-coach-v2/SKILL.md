---
name: copilot-studio-qm-coach-v2
description: "Agent-specific rules for SimpleLTC QM Coach V2 — bot IDs, topic paths, routing matrix, eval patterns. Loads alongside copilot-studio-pipeline."
version: 1.0.0
author: Copilot Studio Pipeline
license: MIT
platforms: [windows]
metadata:
  hermes:
    tags: [copilot-studio, qm-coach, therapy-agents]
---

# QM Coach V2 — Agent-Specific Rules

This skill is agent-specific. The universal pipeline rules live in `copilot-studio-pipeline`.

## Key IDs

| Field | Value |
|-------|-------|
| Bot ID | `ea52ad9c-8233-f111-88b3-6045bd09a824` |
| Environment | `a944fdf0-0d2e-e14d-8a73-0f5ffae23315` (Therapy AI Agents Dev) |
| Dataverse org | `https://orgbd048f00.crm.dynamics.com` |
| Tenant | `03cc92c3-986c-4cf4-ae27-1478cf99d17f` |
| PAC CLI | `C:/Users/kevin/.dotnet/tools/pac.exe` |

## Topic YAML Location

```
D:/my agents copilot studio/topic_templates/   # canonical source-of-truth
```

Use the `agents/qm_coach_v2.json` config file in the pipeline folder:
```bash
node D:/my agents copilot studio/pipeline/publish_pipeline.cjs qm_coach_v2
```

## Standard Run Sequence

1. Verify auth chain: `node -e "const a = require('D:/my agents copilot studio/pipeline/auth_helper.cjs'); a.probe([a.KNOWN_SCOPES.dataverse('https://orgbd048f00.crm.dynamics.com')]).then(ok => console.log(ok ? 'OK' : 'FAIL'))"`
2. Edit topics under `D:/my agents copilot studio/topic_templates/`
3. **Test:** `node D:/my agents copilot studio/pipeline/test_topics.cjs --agent qm_coach_v2`
4. Lint: `node D:/my agents copilot studio/pipeline/topic_lint.cjs D:/my agents copilot studio/topic_templates/`
5. Publish: `node D:/my agents copilot studio/pipeline/publish_pipeline.cjs qm_coach_v2`
6. Review: `cat D:/my agents copilot studio/pipeline/eval_history.jsonl | tail -3`

## Topic Inventory (13 Custom Topics, Validated Jul 3, 2026)

Topics live at `D:/my agents copilot studio/topic_templates/`. All use `SendActivity` → `EndDialog` pattern with zero `ConditionGroup`, `Question`, or `SearchSpecificFiles` nodes.

See `D:/my agents copilot studio/pipeline/routing_matrix.json` for per-topic trigger phrases and routing rules.

| # | File | Triggers | EndDialog | clearTopicQueue | Ends With Question |
|---|------|:--------:|:---------:|:---------------:|:-----------------:|
| 1 | `escalate_qm_concern.yaml` | 5 | ✅ | ✅ | Yes — SR risk |
| 2 | `qm_driver_analysis.yaml` | 5 | ✅ | ✅ | Yes — SR risk |
| 3 | `qm_action_plan.yaml` | 5 | ✅ | ✅ | Yes — SR risk |
| 4 | `clinical_intake_handoff.yaml` | 5 | ✅ | ✅ | Yes — SR risk |
| 5 | `qm_email_generator.yaml` | 5 | ✅ | ✅ | Yes — SR risk |
| 6 | `facility_trend_reporter.yaml` | 5 | ✅ | ✅ | Yes — SR risk |
| 7 | `qm_severity_classification.yaml` | **3** ⚠️ | ✅ | ✅ | Yes — SR risk |
| 8 | `hitl_approval.yaml` | 5 | ✅ | ✅ | Yes — SR risk |
| 9 | `workflow_menu.yaml` | **3** ⚠️ | ✅ | ✅ | Yes — SR risk |
| 10 | `accountability_matrix.yaml` | 5 | ✅ | ✅ | Yes — SR risk |
| 11 | `coaching_corner.yaml` | 5 | ✅ | ✅ | Yes — SR risk |
| 12 | `escalation_matrix.yaml` | 5 | ✅ | ✅ | Yes — SR risk |
| 13 | `qm_data_upload_decline_detection.yaml` | 7 | ✅ | ✅ (pre-existing) | Yes — SR risk |

**System topics:** `conversational_boosting.yaml` (OnUnknownIntent) — has `clearTopicQueue: true` ✅.

### P1 Items Not Yet Addressed (from Static Analysis, Jul 3, 2026)

| Issue | Details | Priority |
|-------|---------|:-------:|
| Topics end with questions | All 13 topics ask follow-up question → single-response eval risk | High |
| Insufficient triggers | `qm_severity_classification` (3) and `workflow_menu` (3) need ≥5 | Medium |
| Routing overlap | `escalate_qm_concern` ↔ `escalation_matrix` share "escalation" intent surface | Low |
| Instruction duplication | "missing data" guidance appears in both CONSTRAINTS and RESPONSE QUALITY | Low |

### Audit Reports (Reference Location)

- **Static analysis:** `D:/my agents copilot studio/pipeline/audit-results/analysis-qm-coach-v2.md`
- **Loop 1 fix report:** `D:/my agents copilot studio/pipeline/audit-results/qm-coach-loop1-fixes.md`

## Domain Rules

- Must-not-contain: "best-effort", "preliminary" — these undermine clinical confidence
- Response length: 2-3 sentences for single-question answers, bullet lists for multi-part
- Format: always match the question type (single vs general question)
- OT behavioral patterns are portable: conciseness, weak-phrase bans, single-vs-general format
- OT content structure is NOT portable: discipline-specific rules stay in their own agents

## Eval History Patterns (from prior sessions)

| Pattern | SR Impact | Root Cause |
|---------|-----------|------------|
| Question nodes in DoR Summary | 95% → 12% | Orphan Question nodes (R4) — re-ask for input incorrectly |
| Topic dedup | 71% → 95% | Removing duplicate topics fixed routing confusion |
| Empty topics | publish crash | Empty AdaptiveDialog crashes publish (R3) |
| Aggressive language | 5-15% regression | "NEVER" / "ALWAYS" in instructions poisons model |

## Kiro Anti-Corruption + Taxonomy Rules

Adopted from Kiro's text-corruption-prevention.md and agent-guardrails.md. Full details in `copilot-studio-pipeline` skill. Key points for QM Coach V2 specifically:

| QM-Specific Concern | Rule |
|---------------------|------|
| GPT instructions healthy range | 2,000-6,000 chars (not 8000+) |
| Post-patch verify | Check for "RESPONSE LENGTH" duplication |
| Mid-word splices | Full replacement, never append |
| Topic stacking | `clearTopicQueue: true` on EndDialog |
| Latency messages | Disable `allowLatencyMessage` on all topics |
| Instruction length | ≤ 4 bullet points in `additionalInstructions` |

## Known Issues (2026-06-22)

- **DoR Summary + Resident Outlier Analysis — Question nodes**: Both topics had `kind: Question` nodes asking "please paste the DoR summary" before answering. This causes Single Response eval failure (95% → 12%). **Data field fixed** (removed Question node, set `userInput: =System.Activity.Text`). **Content field still stale** — requires edit in Copilot Studio UI to sync. See `copilot-studio-pipeline` skill for the `content` vs `data` field behavior.
- **GPT instruction size**: 7768 chars (above 6000 ceiling). Causes response truncation. Needs rewrite to ~4500 chars.
- **Ghost GPT component**: empty 0-char component sitting next to real one. Delete via Dataverse API.
- **Knowledge source list in GPT instructions**: 14 sources listed inline (~1500 chars). Remove — model already has access.
- **R5 trigger overlap**: DoR Summary ↔ qm_email_generator at 67% Jaccard. FIXED — rewrote email generator triggers to be email-focused.
