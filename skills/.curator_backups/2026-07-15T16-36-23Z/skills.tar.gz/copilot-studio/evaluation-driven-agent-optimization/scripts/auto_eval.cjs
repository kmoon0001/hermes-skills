const { chromium } = require('playwright-core');

const ENV = 'Default-03cc92c3-986c-4cf4-ae27-1478cf99d17f';

async function triggerEval(botId, botName, type = 'conv') {
  const browser = await chromium.connectOverCDP('http://127.0.0.1:9223');
  const context = browser.contexts()[0];
  const page = await context.newPage();

  const testCaseCount = type === 'sr' ? 100 : 20;
  
  await page.goto(`https://copilotstudio.microsoft.com/environments/${ENV}/bots/${botId}/evaluation`, { timeout: 30000 }).catch(() => {});
  await page.waitForTimeout(15000);

  const testLink = page.locator(`text=${testCaseCount} test cases`).first();
  if (!(await testLink.isVisible({ timeout: 5000 }).catch(() => false))) {
    console.log(`${botName}: test set not found`);
    await browser.close();
    return null;
  }
  await testLink.click();
  await page.waitForTimeout(5000);

  const evalBtn = page.getByRole('button', { name: /evaluate/i }).first();
  if (!(await evalBtn.isVisible({ timeout: 5000 }).catch(() => false))) {
    console.log(`${botName}: Evaluate button not found`);
    await browser.close();
    return null;
  }
  await evalBtn.click();
  await page.waitForTimeout(5000);

  const runBtn = page.getByRole('button', { name: /run/i }).first();
  const isEnabled = await runBtn.isEnabled({ timeout: 3000 }).catch(() => false);
  if (!isEnabled) {
    const label = await runBtn.getAttribute('aria-label').catch(() => '');
    console.log(`${botName}: Run disabled - ${label}`);
    await browser.close();
    return null;
  }
  await runBtn.click();
  console.log(`${botName} ${type.toUpperCase()} triggered`);

  for (let i = 0; i < 40; i++) {
    await page.waitForTimeout(30000);
    const text = await page.evaluate(() => document.body.innerText.substring(0, 2000));
    const isRunning = text.includes('Running') || text.includes('In progress');
    if (!isRunning) {
      const scoreMatch = text.match(/(\d{1,3})%/);
      const score = scoreMatch ? scoreMatch[1] : 'unknown';
      console.log(`\n✅ ${botName} ${type.toUpperCase()}: ${score}% (${(i+1)*0.5}min)`);
      await browser.close();
      return parseInt(score);
    }
    console.log(`${botName}: running... [${(i+1)*0.5}min]`);
  }
  console.log(`${botName}: timeout`);
  await browser.close();
  return null;
}

async function main() {
  const tasks = [
    ['6e437a77-a5dc-4984-90eb-4924eab10006', 'SLP', 'conv'],
    ['593407f3-539b-490f-84ac-d74e13216c81', 'PT', 'conv']
  ];
  console.log('=== AUTO EVAL TRIGGER ===\n');
  const results = [];
  for (const [botId, name, type] of tasks) {
    console.log(`Triggering ${name} ${type}...`);
    const result = await triggerEval(botId, name, type);
    results.push({ name, type, score: result });
  }
  console.log('\n=== RESULTS ===');
  for (const r of results) {
    const status = r.score >= 95 ? '✅' : r.score ? '⚠️' : '❌';
    console.log(`${status} ${r.name} ${r.type.toUpperCase()}: ${r.score || 'failed'}%`);
  }
}
main().catch(e => console.error(e.message));
