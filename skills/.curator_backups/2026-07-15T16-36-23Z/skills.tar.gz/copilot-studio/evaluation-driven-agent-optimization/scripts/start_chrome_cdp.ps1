# start_chrome_cdp.ps1 — Relaunch Chrome with remote debugging on port 9223
# Preserves original user data dir (auth cookies intact — no re-login)
# Usage: powershell -ExecutionPolicy Bypass -File start_chrome_cdp.ps1

$ErrorActionPreference = "Stop"
$ChromePath = "C:\Program Files\Google\Chrome\Application\chrome.exe"
$UserDataDir = "$env:LOCALAPPDATA\Google\Chrome\User Data"
$DebugPort = 9223

Write-Host "[1/3] Killing all Chrome processes..."
Get-Process chrome -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Seconds 3

Write-Host "[2/3] Launching Chrome with CDP on port $DebugPort..."
$args = @(
    "--remote-debugging-port=$DebugPort",
    '--remote-allow-origins=*',
    '--no-first-run',
    "--user-data-dir=$UserDataDir"
)
Start-Process $ChromePath -ArgumentList $args
Start-Sleep -Seconds 8

Write-Host "[3/3] Verifying CDP..."
try {
    $r = Invoke-WebRequest -Uri "http://127.0.0.1:$DebugPort/json/version" -UseBasicParsing -TimeoutSec 5
    $data = $r.Content | ConvertFrom-Json
    Write-Host "SUCCESS: Chrome CDP ready — $($data.Browser) Protocol $($data.'Protocol-Version')"
    Write-Host "User-Agent: $($data.UserAgent.Substring(0, [Math]::Min(80, $data.UserAgent.Length)))..."
    exit 0
} catch {
    Write-Host "FAIL: Port $DebugPort not listening. Retry once more (profile lock may clear on second attempt)."
    exit 1
}
