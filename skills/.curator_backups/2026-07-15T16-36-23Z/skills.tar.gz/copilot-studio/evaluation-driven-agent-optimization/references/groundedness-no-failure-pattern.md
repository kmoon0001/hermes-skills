# Groundedness=No Failure Pattern

## What It Is

A failure where the agent answers the question correctly and completely but the
grader cannot match the answer to knowledge source content. The metric breakdown:
- **Abstention: No** — agent IS answering
- **Relevance: Yes** — answer is on-topic
- **Completeness: Yes** — answer covers the question
- **Groundedness: No** — answer is NOT traceable to KB sources

## Root Cause

`SearchAndSummarizeContent` without `additionalInstructions` produces generic
answers that lack proper KB citations. The grader expects answers grounded in
specific knowledge source content, but the agent responds with general knowledge.

## Fix

Add `additionalInstructions` to the `SearchAndSummarizeContent` node that
explicitly requires KB-sourced answers with citations:

```yaml
additionalInstructions: |-
  Answer the question comprehensively using only the knowledge sources.
  Provide specific CMS Chapter 15, Medicare Part B requirements with
  inline citations. Never fabricate requirements not found in the
  knowledge sources.
```

Key phrases that fix Groundedness:
- "using only the knowledge sources"
- "with inline citations"
- "Never fabricate requirements not found in the knowledge sources"
- Name the specific sources (CMS Ch.15, Jimmo, Ensign Habits)

## Distinction from Abstention

| Symptom | Abstention | Groundedness Fail |
|---------|-----------|-------------------|
| Agent responds? | No / evasive | Yes, detailed answer |
| Answer correct? | N/A | Usually yes |
| Fix level | Topic flow / guardrails | additionalInstructions |

Groundedness=No is a LATER-STAGE problem — it only appears after abstention and
relevance issues are resolved. It typically emerges when scores reach 70-85%.
