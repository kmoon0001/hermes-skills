# Evaluation Case vs Instruction Mismatch Detection

When agent instructions change behavioral patterns (e.g., from "ask-first" to "answer-first") but evaluation test cases still expect the old pattern, the agent fails for following its own instructions. This is a distinct root cause from "stale expected answer" — the expected answer may be clinically correct, but the conversational FLOW it expects conflicts with current instructions.

## Detection Technique

### Step 1: Extract evaluation case definitions via Dataverse API

```javascript
// Componenttype 19 = evaluation cases
const filter = `_parentbotid_value eq '${botId}' and componenttype eq 19`;
const url = `/api/data/v9.2/botcomponents?$select=name,botcomponentid,data,modifiedon&$filter=${encodeURIComponent(filter)}&$top=5000`;
const resp = await fetch(url, { credentials: 'include', headers: { 'Accept': 'application/json' } });
const cases = (await resp.json()).value;
```

### Step 2: Parse case data for conversational patterns

Each case's `data` field contains YAML with `kind: MultiTurnEvaluationCase` and an `activities` array. Parse for:

```python
import json

# Load cases
cases = json.loads(open('eval-components-type19.json').read())
items = cases.get('value', cases) if isinstance(cases, dict) else cases

conv_cases = [x for x in items if 'MultiTurnEvaluationCase' in x.get('data', '')]

# Detect prompt-first patterns
prompt_first = []
for c in conv_cases:
    data = c.get('data', '')
    has_please_provide = 'please provide' in data.lower()
    has_record_id_ask = 'record_id' in data.lower() and 'provide' in data.lower()
    has_clarification = 'could you' in data.lower() or 'do you have' in data.lower()
    
    if has_please_provide or has_record_id_ask:
        prompt_first.append(c)

print(f"Total conv cases: {len(conv_cases)}")
print(f"Prompt-first cases: {len(prompt_first)} ({len(prompt_first)/len(conv_cases)*100:.0f}%)")
```

### Step 3: Compare to current instructions

Read the agent's current instructions (componenttype 15) and check for behavioral rules that conflict with the detected patterns:

| Instruction Pattern | Evaluation Pattern | Conflict? |
|--------------------|--------------------|-----------|
| "Answer directly, do not ask follow-up" | Expected agent asks for record_id | YES |
| "Provide full audit when record_id mentioned" | Expected agent asks clarification | YES |
| "Ask brief clarification if discipline unclear" | Expected agent asks for discipline | NO (aligned) |

### Step 4: Quantify the mismatch

```
PT:  94% of cases expect ask-first, instructions say answer-first → HIGH conflict
SLP: 98% of cases expect ask-first, instructions say answer-first → HIGH conflict
TDA: 0% prompt-first, routing tests → NO conflict
OT:  76% prompt-first, instructions still ask-first → NO conflict (aligned)
```

## Why OT Scores 95% Despite 76% Prompt-First Cases

OT's instructions were never changed to "answer-first." OT naturally asks clarifying questions as part of its clinical workflow. The evaluation cases match OT's behavior. No conflict exists.

When PT/SLP instructions were changed to "answer-first" (to improve response quality), the evaluation cases weren't updated to match. The agent is penalized for following its own instructions.

## Microsoft Learn Classification

Per Microsoft Learn evaluation triage:
- "If the agent response is acceptable, fix the evaluation."
- "If expected answer is stale/wrong, fix the evaluation."
- "If test case is unrealistic, fix the evaluation."

This is an evaluation setup issue, not an agent configuration issue.

## Fix Options

### Option A: Update existing test cases
- Edit the evaluation cases to include synthetic note content in the user's first message
- Update expected agent turns to accept answer-first audits
- Keep clinical quality standards (score, recommendations, advisory)

### Option B: Switch to General quality grading (RECOMMENDED)
- Per Microsoft Learn: "General quality judges relevance, groundedness, completeness, and abstention"
- "For General quality, expected answers are not required for open-ended broad clinical/compliance questions"
- Removes rigid expected transcript turns entirely
- Tests actual response quality without dictating conversational flow

### Option C: Create new test set alongside existing
- Create a new test set with 50+ cases designed for answer-first behavior
- Keep existing test set for regression comparison
- Avoids destabilizing current baseline

## Key Sample Case

Case `fe85142b-d13c-4dec-b87f-0610ef90507e` (PT denial risk assessment):

```
User: "Can you perform an insurance denial risk assessment on this PT documentation?"
Expected Agent: "Certainly. Please provide the record_id for the PT documentation."
User: "The record_id is DENIAL2023."
Expected Agent: "Thank you. Are there any specific areas you're concerned about?"
User: "I'm concerned about skilled justification and plan of care details."
Expected Agent: [full audit with score/recommendations]
```

This case has TWO clarification rounds before the audit. If the PT agent follows its instructions ("answer directly, do not ask follow-up"), it produces the audit immediately and fails the expected transcript.

## Relationship to Other Root Causes

This root cause is distinct from:
- **Stale expected answer**: The expected answer content is correct, but the flow is wrong
- **Inactive guard topics**: Topic state issues, not instruction-evaluation conflict
- **Non-deterministic variance**: Platform noise, not structural conflict
- **Instruction budget problem**: Too many instructions, not conflicting instructions

It often COMPOUNDS with non-deterministic variance: the agent sometimes follows instructions (fails test) and sometimes doesn't (passes test), producing high score variance across runs.
