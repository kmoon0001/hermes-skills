# Dataverse API: Evaluation Cases (Componenttype 19)

## ⚠️ CRITICAL PITFALL: DO NOT REWRITE MULTITURN CASE DATA

**Attempting to transform MultiTurnEvaluationCase `data` fields via Dataverse API
broke all 4 agents' evaluations (Jun 18, 2026).** The transform function collapsed
6-turn conversations into 2-turn single-response cases, corrupting the YAML structure.

**What went wrong:**
- Original: 6 activities (3 user turns, 3 agent turns) with `\r\n` line endings
- Written: 2 activities (1 user, 1 agent) with `\n` line endings and quoted text
- Result: Copilot Studio evaluation system couldn't parse the malformed cases
- Fix required: Revert all 40 cases (20 PT + 20 SLP) from backup JSON files

**The correct approach per Microsoft Learn:**
1. **Change the grading method** to General quality in the Copilot Studio UI
2. General quality "judges relevance, groundedness, completeness, and abstention"
3. "Expected answers are not required for open-ended clinical/compliance questions"
4. This eliminates the prompt-first vs answer-first conflict without touching case data

**If you must modify test cases, use the Copilot Studio UI, not the API.**

---

## Safe Uses of This API (Reading/Querying)

The Dataverse API is safe for READING evaluation case data. Use it to:
- Analyze prompt-first vs answer-first patterns across cases
- Count cases with specific behavioral expectations
- Extract case definitions for offline analysis
- Identify flaky test cases

## Token Acquisition

```bash
az account get-access-token --resource 'https://org3353a370.crm.dynamics.com/' --query accessToken -o tsv > /tmp/dv_token.txt
```

**Pitfall: Secret redaction breaks inline tokens.** Save to file, read from Python.

## Query Evaluation Cases

```python
import json, urllib.request, urllib.parse

token = open('/tmp/dv_token.txt').read().strip()
bot_id = '593407f3-539b-490f-84ac-d74e13216c81'
org_url = 'https://org3353a370.crm.dynamics.com'

params = urllib.parse.urlencode({
    '$filter': f"componenttype eq 19",
    '$orderby': 'modifiedon desc',
    '$top': '25',
    '$select': 'name,botcomponentid,modifiedon,data'
}, quote_via=urllib.parse.quote)

url = f"{org_url}/api/data/v9.2/botcomponents?{params}"
req = urllib.request.Request(url, headers={
    'Authorization': f'Bearer {token}',
    'Accept': 'application/json',
    'OData-MaxVersion': '4.0',
    'OData-Version': '4.0'
})
with urllib.request.urlopen(req, timeout=30) as resp:
    data = json.loads(resp.read().decode())
```

**Pitfall: `_owningbotid` doesn't exist.** Use `_parentbotid_value` or filter by `componenttype eq 19` only.

**Pitfall: Spaces in URL.** Use `quote_via=urllib.parse.quote` to encode special characters.

## Detect Prompt-First Patterns (Read-Only Analysis)

```python
items = data.get('value', [])
multi_turn = [x for x in items if 'MultiTurnEvaluationCase' in x.get('data', '')]

prompt_first = []
for case in multi_turn:
    d = case.get('data', '').lower()
    if 'please provide' in d or ('record_id' in d and 'provide' in d):
        prompt_first.append(case)

print(f"{len(prompt_first)}/{len(multi_turn)} cases expect prompt-first behavior")
```

**Quantified evidence (Jun 18, 2026):**
| Agent | Conv Cases | Prompt-First | % |
|-------|-----------|-------------|---|
| PT | 904 | 852 | 94% |
| SLP | 1020 | 1006 | 98% |
| TDA | 794 | 0 | 0% |
| OT | 1199 | 916 | 76% |

## Reverting Corrupted Cases (Emergency Procedure)

If cases were accidentally modified, revert from the original component JSON files:

```python
# Load original data
with open('artifacts/pt-evaluation-components-type19.json') as f:
    components = json.load(f)
items = components if isinstance(components, list) else components.get('value', [])
original_lookup = {x['botcomponentid']: x for x in items}

# Revert each case
for case_id in case_ids_to_revert:
    original = original_lookup[case_id]
    url = f"{org_url}/api/data/v9.2/botcomponents({case_id})"
    payload = json.dumps({'data': original['data']}).encode('utf-8')
    req = urllib.request.Request(url, data=payload, method='PATCH', headers={
        'Authorization': f'Bearer {token}',
        'Content-Type': 'application/json',
        'OData-MaxVersion': '4.0',
        'OData-Version': '4.0',
        'If-Match': '*'
    })
    with urllib.request.urlopen(req, timeout=30) as resp:
        pass  # 204 = success
```

**Pitfall: `If-Match: *` bypasses etag concurrency.** Use this for emergency reverts only.
For normal updates, use the original etag from `@odata.etag`.
