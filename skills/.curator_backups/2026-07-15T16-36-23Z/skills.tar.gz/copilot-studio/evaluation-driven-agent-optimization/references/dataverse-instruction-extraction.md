# Reading Agent Instructions via Dataverse API

## The Problem

Copilot Studio instructions are NOT reliably readable via:
- The SPA's `/instructions` URL (shows collapsed overview — only "Edit" visible)
- The `contenteditable` div on the overview page (hidden until edit mode)
- The `content` field of the `botcomponent` record (always null)

## The Solution: The `data` Field

Agent instructions are stored in the `data` field of the **type-15 (GptComponentMetadata)** `botcomponent`.

### Finding the Component

```javascript
// Component type 15 = GPT config (instructions + model settings)
const filter = `_parentbotid_value eq '${botId}' and componenttype eq 15`;
const url = `/api/data/v9.2/botcomponents?$select=botcomponentid,data,name,description&$filter=${encodeURIComponent(filter)}`;
const resp = await fetch(url, {
  credentials: 'include',
  headers: {
    'Accept': 'application/json',
    'OData-MaxVersion': '4.0',
    'OData-Version': '4.0'
  }
});
const data = await resp.json();
const component = data.value[0];
```

### Parsing the `data` Field

The `data` field contains YAML that looks like:
```yaml
kind: GptComponentMetadata
displayName: OT_Specialist
instructions: |
  [full instruction text here]

responseInstructions: |-
  [optional response-level instructions]

gptCapabilities:
  webBrowsing: false
  codeInterpreter: false

aISettings:
  model:
    modelNameHint: GPT5Chat
  extensionData:
    lastUsedCustomModel: {}
```

### Extracting Instructions

```javascript
const raw = component.data;
const instrStart = raw.indexOf('instructions: |');
if (instrStart >= 0) {
  const instrContent = raw.substring(instrStart + 15);
  // instrContent is the full instruction text
}
```

### What Also Lives in `data`

| Field | Description |
|-------|-------------|
| `instructions` | Main agent instruction text (the "system prompt") |
| `responseInstructions` | Additional formatting rules (rarely used) |
| `gptCapabilities.webBrowsing` | Whether web search is enabled |
| `aISettings.model.modelNameHint` | Current model (e.g., GPT5Chat) |
| `conversationStarters` | Suggested conversation starters |

## Additional Fields on the Component

| Field | Description |
|-------|-------------|
| `description` | Agent description (shown in Overview) |
| `name` | Agent display name |
| `schemaname` | Internal schema name (e.g., `copilots_header_8c921.gpt.default`) |
| `modifiedon` | Last modified timestamp (ISO 8601) |

## Other Component Types

| Type | Description |
|------|-------------|
| 9 | Topic/Dialog component (content stored elsewhere — null in API) |
| 14 | File/knowledge source |
| 15 | GPT config (instructions + model settings — THIS one) |
| 16 | Knowledge source |
| 19 | Suggested prompt |
