# Therapy Documentation Feedback Agent — Session Learnings (July 2026)

Key techniques, pitfalls, and workflows discovered during the Prod agent optimization session.

---

## Pitfall: Over-Aggressive Regex Nukes knowledgeSources

When surgically removing `fileSearchDataSource` from topic YAMLs via regex `re.sub`, a greedy pattern can consume the adjacent `knowledgeSources` and `applyModelKnowledgeSetting` blocks. These blocks are at the same indentation level and the regex `\s+[^\n]*\n` matches across block boundaries.

**Symptom:** Score drops to 0-4%. Agent abstains on ALL queries. Dataverse `data` field shrinks from ~2600 to ~1050 chars — missing the entire `knowledgeSources` block.

**Detection:** After PATCH, verify `data` length hasn't shrunk by more than the `fileSearchDataSource` block alone (~600 chars). Verify `knowledgeSources:` string is still present.

**Correct approach — line-by-line removal, not regex:**
```python
lines = original.split('\n')
new_lines = []
skip = False
for line in lines:
    if 'fileSearchDataSource:' in line:
        skip = True
        continue
    if skip:
        if line.startswith('      ') or line.startswith('        '):
            continue  # skip indented lines in fileSearchDataSource block
        else:
            skip = False  # stop skipping at next non-indented line
            new_lines.append(line)
    else:
        new_lines.append(line)
fixed = '\n'.join(new_lines)
```

**Evidence:** Therapy Feedback Agent 25-case KB-aligned test went from 0% → 83% after restoring `knowledgeSources` blocks that were accidentally removed. The regex removed 1643 chars including the critical `knowledgeSources` + `applyModelKnowledgeSetting` blocks.

---

## Pitfall: PPAPI Progress Counter Unreliable

The PPAPI `testruns/{runId}` endpoint returns `testCasesProcessed: 0` even when the eval is actively running and producing results in the Copilot Studio UI. Do NOT trust it for live progress.

**Workaround:** Scrape the evaluation page directly via CDP Playwright (see below: CDP Eval Page Scraping).

---

## CDP WebSocket Token Capture

When the eval-api's MSAL interactive flow fails (missing `http://localhost` redirect URI in Azure app registration), capture PPAPI tokens directly from the browser's signed-in session.

**Prerequisite:** Edge running with `--remote-debugging-port=9223` and `--user-data-dir` pointing to authenticated profile.

**Script pattern** (`cdp_simple.cjs`):
1. Connect to CDP via WebSocket
2. List tabs, find evaluation page
3. Enable `Fetch.enable` to intercept network requests
4. Navigate/reload evaluation page
5. Capture `Authorization: Bearer` header from requests to `*.api.powerplatform.com`
6. Save to `~/.copilot-studio-cli/test-agent-token.txt`

**Edge startup (Windows PowerShell):**
```powershell
$args = '--remote-debugging-port=9223','--remote-allow-origins=*','--no-first-run','--user-data-dir=C:\Users\kevin\AppData\Local\Microsoft\Edge\User Data'
Start-Process 'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe' -ArgumentList $args
```

---

## CDP Eval Page Scraping

When PPAPI is unreliable, scrape eval results directly from the Copilot Studio evaluation page via Playwright connectOverCDP. The eval overview page shows pass/fail counts, scores, and run history.

**Reliable selector patterns:**
- Score: `document.body.innerText` contains `83%` next to run name
- Pass/fail counts: Text matching `(\d+)\s*of\s*(\d+)\s*(?:passed|correct)`
- Run history: Look for "Recent results" section in page text

**Pitfall:** The "Evaluate" button detail expansion is blocked by Fluent UI overlay divs with `data-testid`. Force-clicks through PointerEvents interception sometimes work, but the detail panel may not be readable via `document.body.innerText`. Consider navigating to a run-specific URL if available.

---

## Dataverse API Topic Editing Patterns

### PATCH `data` field — works (HTTP 204)
```python
patch_url = f'{org}/api/data/v9.2/botcomponents({topic_id})'
body = json.dumps({'data': yaml_content})
# Headers: Authorization, Content-Type: application/json, OData-MaxVersion: 4.0, OData-Version: 4.0
```

### PATCH `content` field — FAILS (HTTP 400)
The `content` field rejects YAML with "Unexpected character encountered while parsing value: k" (the 'k' from `kind:`). Use `data` field instead.

### PATCH `statecode` — activate/deactivate topics (HTTP 204)
```python
body = json.dumps({'statecode': 1})  # 1 = inactive, 0 = active
```

### Query: Get all topic GUIDs by state
```
/api/data/v9.2/botcomponents?$select=botcomponentid,name&$filter=_parentbotid_value eq '{botId}' and componenttype eq 9 and statecode eq 0
```

---

## KB Source Verification

Knowledge sources are stored as `botcomponents` with:
- **componenttype 14** — file-based sources (PDF, TXT, DOCX)
- **componenttype 16** — reference/summary sources

**Query all KB sources:**
```
/api/data/v9.2/botcomponents?$select=name,schemaname,componenttype&$filter=_parentbotid_value eq '{botId}' and (componenttype eq 14 or componenttype eq 16)
```

The `schemaname` field contains the exact reference used in topic YAML's `knowledgeSources:` block. Match these to verify KB references are valid — mismatched schemanames cause `SearchAndSummarizeContent` to return nothing.

**Evidence:** Only 4 of 13 KB sources were initially found (pagination issue with `$top=70` without proper type filter). The type-specific filter `componenttype eq 14 or componenttype eq 16` correctly returns all 13.

---

## Topic Logical Flow Audit Pattern

When agent scores are stuck at low percentages despite correct configuration, trace EVERY topic from conversation start:

1. **List all active topics** via Dataverse (componenttype 9, statecode 0)
2. **Check each for:** `kind: Question` nodes, missing `EndDialog`, `CancelAllDialogs` without answers, broken `BeginDialog` references
3. **Trace the flow:** For a test case query, identify which topic fires first, which fires next, and what the final output is
4. **Key blockers found in this session:**
   - `Conversation Start` (`OnConversationStart`) with Question nodes blocks every eval by asking a question instead of answering
   - `Greeting` with Question nodes + `CancelAllDialogs` = broken flow
   - `Multiple Topics Matched` with Question node = asks user to choose instead of answering
   - Catch-all topic (`Conversational boosting`) with `SearchAndSummarizeContent` but no `elseActions` fallback = silent exit when KB returns nothing
   - Topics missing `EndDialog` at the end = conversation hangs

---

## Score Progression Reference

```
16% → 18% → 16% → 22% → 4% → 0% → 8% → 0% → 30% → 50% → 83%
 ↑ GPT fix    ↑ partial search fix     ↑ topic flow    ↑ knowledgeSources
                                       fixes           RESTORED
```

- **16%**: Baseline — agent abstains on 84% of original test cases (guardrails + missing KB)
- **22%**: SearchSpecificFiles removed (but knowledgeSources accidentally nuked)
- **30%**: Topic flow fixes applied (Question nodes removed, EndDialog added, catch-all improved)
- **50%**: More topic cleanups
- **83%**: knowledgeSources RESTORED to all 6 audit topics — KB search finally works
