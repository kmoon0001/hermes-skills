# Checkpointed Fix Approach (Jul 2026)

Apply ONE fix, run ONE eval between each. Never batch changes — cascading failures hide which fix caused a regression.

## Fix Priority by Risk

| Risk | Type | Examples | Test After |
|------|------|----------|------------|
| None | Additive instructions | Conditional format rules, citation clarifications | Optional |
| Low | Structural additive | EndDialog+clearTopicQueue, extra trigger phrases | Recommended |
| Medium | Topic rework | Changing trigger type, adding/removing nodes | Required |
| High | Topic delete/merge | Deleting duplicates, merging topics | Required |
| Unknown | Reactivating disabled topics | statecode 1→0 on ConvStart | **Required** — investigate cause first |

## ConvStart Reactivation Protocol

When a Conversation Start topic was previously deactivated:
1. READ the topic content first — identify the structural issue
   - `kind: OnConversationStart` + Question/ClosedListEntity = hijacks every conversation with a menu
   - Global variable scope = cross-conversation bleed
2. Fix the issue BEFORE reactivating:
   - Change `OnConversationStart` to `OnRecognizedIntent` so it only fires on specific triggers
   - Replace menu Question with a SendActivity welcome message
   - Change Global variables to Topic.scoped
3. Reactivate (PATCH statecode=0 on the botcomponent)
4. Run eval immediately to verify no regression
5. If regression appears, deactivate (statecode=1) and refine the fix

## Sequential Eval Workflow

1. Run Conv eval (20 cases) first — faster (~15 min), catches routing issues
2. Run SR eval (100 cases) second — gives stable score measurement (~30 min)
3. SR and Conv for SAME agent must be sequential (PPAPI limit)
4. Use cron heartbeat for polling every 10 min
5. Analyze aggregate failure categories when `/details` endpoint is broken:
   - ABSTAINED → no topic matched or guardrails blocked
   - INCOMPLETE → topic routed but missing expected content
   - LOW_RELEVANCE → wrong topic matched
   - OTHER/ERROR → format, binding, or transient issue
