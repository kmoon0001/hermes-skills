# Score Calibration Mismatch — Common Regression Pattern

When an agent's eval scores don't match expected ranges, the root cause is often **score calibration**, not knowledge or instructions.

## Symptoms

- Risk Match passes (agent correctly identifies risk level)
- Score Match fails (agent's numeric score doesn't fall in expected range)
- Pattern: agent scores consistently too high OR too low across document types

## Common Calibration Failures

### 1. Recertification Notes Scored Too Low
**Symptom:** Expected 94-99 (LOW), got 83 (MODERATE)
**Cause:** Agent penalizes goal specificity too harshly
**Fix:** Recertification with 2/4 goals met + core elements present (physician signature, CCC-SLP credential, frequency/duration) should score 90+. Goal specificity is a "nice to have" for recerts, not a requirement.

### 2. Bad Notes Scored Too Low
**Symptom:** Expected 65-78 (MODERATE), got 35 (HIGH)
**Cause:** Agent has no floor — scores clearly bad notes at absolute minimum
**Fix:** Any note with SOME elements (CCC-SLP signed, frequency stated, even vague goals) should floor at 60. A note at 35 suggests the agent is ignoring partial credit entirely.

### 3. Excellent Notes Scored Too High
**Symptom:** Expected 88-95 (LOW), got 97 (LOW)
**Cause:** Agent has no ceiling — gives near-perfect scores
**Fix:** Cap all scores at 95 max. CMS guidelines never give 100% — there's always room for documentation improvement.

## Calibration Rubric (Quick Reference)

| Note Quality | Expected Risk | Score Range | Key Elements |
|---|---|---|---|
| Excellent (minimal gaps) | LOW | 88-95 | All core elements + most secondary |
| Good (minor gaps) | LOW | 80-89 | Core elements present, 1-2 gaps |
| Moderate (significant gaps) | MODERATE | 65-79 | Some core elements, missing secondary |
| Poor (major gaps) | HIGH | 40-64 | Few core elements, major omissions |
| Non-compliant | HIGH | <40 | Missing most/all core elements |

**Core elements (required for any score above 40):**
- Document type identified
- CCC-SLP credential noted
- Frequency/duration stated
- At least one measurable goal or objective
- Physician/MD certification referenced

**Secondary elements (boost score but not required):**
- Standardized assessment scores (FOIS, CLQT, MoCA, VHI-10)
- Objective instrumental data (MBSS/FEES/stroboscopy)
- SMART goal specificity (accuracy %, cue level, timeframe)
- Discharge criteria
- Caregiver training documentation

## Debugging Steps

1. Pull the test case and actual agent response
2. Compare expected score range vs actual score
3. Check which elements the agent weighted heavily
4. If agent scored too LOW: check if it's penalizing secondary elements as if they're required
5. If agent scored too HIGH: check if it's not applying the 95 cap
6. Adjust instructions to clarify the rubric above

## Example Fix (Agent Instructions)

```
SCORING RULES:
- Maximum score: 95 (never 100 — CMS always has room for improvement)
- Minimum score with ANY core element present: 60 (never below)
- Recertification notes: score 90+ if core elements present, regardless of goal specificity
- Do not penalize missing secondary elements (standardized assessments, discharge criteria) 
  as heavily as missing core elements
```
