# Conversation Start Question Node Blocking (July 2026)

## Root Cause

When a Copilot Studio agent has an `OnConversationStart` topic with `kind: Question` nodes, it fires at the beginning of EVERY conversation and returns a question instead of an answer. For single-response evaluation, the grader sees this question as the agent's response → FAIL (abstention). The intent-matching audit topics NEVER get a chance to fire because Conversation Start consumes the first turn.

## Detection via Dataverse API

```python
# Query all active topics
filter_val = "_parentbotid_value eq '{bot_id}' and componenttype eq 9 and statecode eq 0"
url = f"{org}/api/data/v9.2/botcomponents?$select=botcomponentid,name,data&$filter={filter_val}"

for topic in topics:
    if 'OnConversationStart' in topic['data'] and 'kind: Question' in topic['data']:
        print(f"BLOCKER: {topic['name']} has OnConversationStart + Question nodes")
    if 'OnRecognizedIntent' in topic['data'] and 'kind: Question' in topic['data']:
        print(f"WARNING: {topic['name']} has Intent + Question nodes (may block matching queries)")
```

## The Full Flow Trace

For a typical therapy documentation agent:

```
Query: "What are CMS Ch.15 requirements for daily notes?"
  ↓
Conversation Start [OnConversationStart] → FIRES FIRST
  → Question node: "What can I help you with today?" → SR EVAL SEES THIS → FAIL
  ↓ (even with interruptionPolicy: allowInterruption: true)
Greeting [OnRecognizedIntent] → trigger mismatch (Hello/Hi)
  ↓
Audit Topics [OnRecognizedIntent] → trigger mismatch (specific "audit X" phrases)
  ↓
Conversational boosting [OnUnknownIntent, p-1] → NEVER REACHES because Conversation Start consumed turn
```

## Fix

Deactivate Conversation Start via Dataverse PATCH `statecode: 1`:

```javascript
await fetch(`/api/data/v9.2/botcomponents(${convStartId})`, {
  method: 'PATCH',
  body: JSON.stringify({ statecode: 1 })
});
```

After deactivation, the flow becomes:

```
Query → Greeting (miss) → Audit Topics (miss) → Conversational boosting (catch-all) → SearchAndSummarizeContent → answer
```

## Related: Full Topic Audit

Beyond Conversation Start, check EVERY active topic for:

| Signal | Problem | Fix |
|--------|---------|-----|
| `kind: Question` | Returns question instead of answer → SR eval fails | Replace with SendActivity or deactivate |
| `CancelAllDialogs` | Silently ends without answer | Replace with EndDialog + clearTopicQueue |
| Missing `EndDialog` | Topic exits without clean termination | Add EndDialog + clearTopicQueue |
| Missing `clearTopicQueue` | Stale topics intercept next query | Add clearTopicQueue: true |
| `NO-EndDialog` on system topics | Greeting/Goodbye/Thank you leave conversation hanging | Add SendActivity + EndDialog |

## Evidence

**Therapy Documentation Feedback Agent (July 2026):**
- Conversation Start had 2 Question nodes routing to 6 document-type selections
- Greeting had duplicate Question-node pattern
- 6 audit topics had correct structure (SearchAndSummarizeContent + EndDialog)
- 8 additional topics had missing EndDialog or CancelAllDialogs
- Fixing all 11 + deactivating Conversation Start: 0% → 50% → 83% SR

## Full Topic Audit Results Template

```
TOPIC                          TYPE         END  CLEAR  QUESTION  ISSUES
Conversation Start             ConvStart    NO   NO     YES       NO-EndDialog, Question-node
Greeting                       Intent       NO   NO     YES       NO-EndDialog, CancelAllDialogs
Goodbye                        Intent       NO   NO     YES       NO-EndDialog, Question-node
Thank you                      Intent       NO   NO     NO        NO-EndDialog
Multiple Topics Matched        -            NO   NO     YES       Question-node
End of Conversation            -            NO   NO     YES       Question-node
Fallback                       Unknown      NO   NO     NO        NO-EndDialog
On Error                       -            NO   NO     NO        CancelAllDialogs
Reset Conversation             -            NO   NO     NO        CancelAllDialogs
Escalate                       -            NO   NO     NO        NO-EndDialog
Conversational boosting        Unknown      YES  YES    NO        ✅ Clean
Discharge Summary Review       Intent       YES  YES    NO        ✅ Clean
Progress Report Review         Intent       YES  YES    NO        ✅ Clean
Episode of Care                Intent       YES  YES    NO        ✅ Clean
Treatment Encounter Note       Intent       YES  YES    NO        ✅ Clean
Eval & Plan of Care (Copy)     Intent       YES  YES    NO        ✅ Clean
Recertification/UPOT           Intent       YES  YES    NO        ✅ Clean
```
