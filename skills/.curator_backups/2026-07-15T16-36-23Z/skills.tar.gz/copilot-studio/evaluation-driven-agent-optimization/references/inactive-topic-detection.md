# Inactive Guard Topic Detection & Activation

Detect and batch-activate inactive guard/intake topics in Copilot Studio agents via the Dataverse API.

## Why This Matters

Inactivated exact-match intake topics (Eval Guards, Conv Guards, * Intake) cause evaluation test case questions to fall through to generic generative AI responses. Since the grader expects topic-specific answers, these fallback responses fail grading.

**Evidence (Jun 2026):** PT had 16/31 topics inactive (52%) — Conv was stuck at 74% despite 95% peaks. Activating all 16 pushed Conv to 95% on the very next run. OT had 0 inactive topics → stable 95% Conv.

## Detection Script

```javascript
const botId = '593407f3-539b-490f-84ac-d74e13216c81'; // PT agent
const filter = `_parentbotid_value eq '${botId}' and componenttype eq 9`;
const url = `/api/data/v9.2/botcomponents?$select=name,statecode,statuscode&$filter=${encodeURIComponent(filter)}&$top=50`;

const resp = await fetch(url, {
  credentials: 'include',
  headers: { 'Accept': 'application/json', 'OData-MaxVersion': '4.0', 'OData-Version': '4.0' }
});
const data = await resp.json();

const total = data.value.length;
const inactive = data.value.filter(t => t.statecode === 1);

console.log(`${inactive.length}/${total} topics inactive (${Math.round(inactive.length/total*100)}%)`);
inactive.forEach(t => console.log(`  ❌ ${t.name}`));
```

## Batch Activation

```javascript
for (const topic of inactive) {
  const resp = await fetch(`/api/data/v9.2/botcomponents(${topic.botcomponentid})`, {
    method: 'PATCH',
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
      'OData-MaxVersion': '4.0',
      'OData-Version': '4.0'
    },
    body: JSON.stringify({ statecode: 0 })
  });
  console.log(`${topic.name}: ${resp.status === 204 ? '✅' : '❌ ' + resp.status}`);
}

// Must publish after activation for changes to take effect
```

## Detection Heuristics

- Check ALL agents, not just the struggling one. Asymmetric inactive counts explain asymmetric scores.
- Pay special attention to topic names containing "Guard", "Intake", "Eval Guard", "Conv Guard"
- Conversational boosting (CB topic) should NOT be inactive — it handles unmatched queries
- Statecode 0 = Active, 1 = Inactive. Statuscode varies (0=Draft, 1=Active, 2=Published, 3=Off)
