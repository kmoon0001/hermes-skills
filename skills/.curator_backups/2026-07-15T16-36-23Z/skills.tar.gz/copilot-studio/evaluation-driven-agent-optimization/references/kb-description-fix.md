# Knowledge Source Description Fix

Fix blank or auto-generated knowledge source descriptions in Copilot Studio via Dataverse API.

## Why Descriptions Matter

Knowledge source descriptions are the primary routing signal for GPT-based retrieval. Blank or auto-generated descriptions ("searches information contained in...") cause the retrieval router to skip relevant sources, producing ungrounded responses that graders penalize.

## Detection

Check for descriptions that are empty or auto-generated:
```javascript
const filter = `_parentbotid_value eq '${botId}' and componenttype eq 16`;
const url = `/api/data/v9.2/botcomponents?$select=name,description&$filter=${encodeURIComponent(filter)}&$top=30`;
const resp = await fetch(url, { credentials: 'include' });
const data = await resp.json();

data.value.forEach(k => {
  const desc = (k.description || '').trim();
  const bad = !desc || desc.startsWith('searches information') || desc.startsWith('This knowledge source');
  if (bad) console.log(`⚠️ ${k.name}: ${desc ? 'auto-gen' : 'BLANK'}`);
});
```

## Fix — Set Description via PATCH

```javascript
const kbId = '...'; // from botcomponentid
await fetch(`/api/data/v9.2/botcomponents(${kbId})`, {
  method: 'PATCH',
  credentials: 'include',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    description: 'Keyword-rich description of the source content. Include what it covers and when to use it.'
  })
});
```

## Description Best Practices

- 80-200 characters
- Include what the source covers AND when GPT should route to it
- Avoid file extensions (.pdf, .md) in the description
- Avoid generic auto-generated text
- Example fixes:
  - BLANK → "International Dysphagia Diet Standardisation Initiative framework for diet texture levels and liquid thickness classifications. Use for dysphagia diet recommendations and IDDSI level documentation."
