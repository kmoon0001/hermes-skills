# Model Retirement Detection in Copilot Studio

## The Signal

When you see this text on any agent's Overview page — in the "Select your agent's model" section:

```
Your selected agent model was retired, so we updated your agent to use another model.
```

This is a **shared root cause** that explains simultaneous Conv regression across ALL agents in the environment.

## Impact

- Model changes cause **5-15% score variance** on both SR and Conv
- The change affects ALL conversations — not individual topics
- The grader evaluates responses against expectations set by the OLD model behavior, so the NEW model's different style causes failures even when content is equally correct
- The impact is most visible on **Conversation (multi-turn)** evaluations because the new model handles context differently

## What NOT to Do

- Do NOT diagnose individual topics or instructions when this signal is present
- Do NOT make topic YAML changes before re-baselining
- Do NOT create new topics to compensate
- Do NOT revert topic changes that were working before the model shift

## What to Do

1. **Re-run ALL evaluations** to establish a new baseline with the new model
2. Compare new scores to previous baseline
3. Only fix failures that **persist across 2-3 consecutive eval runs**
4. If scores stabilize at an acceptable level (≥90%), adjust targets rather than making changes
5. If specific failures repeat consistently, then diagnose with the NEW model as the context

## Detection via Playwright/CDP

```javascript
// Check for model retirement message on any agent
const text = await page.evaluate(() => document.body.innerText);
const modelRetired = text.indexOf('was retired') >= 0;
if (modelRetired) {
  console.log('WARNING: Model was retired. Shared root cause for regression.');
  // Find the current model name
  const modelName = text.match(/GPT-\d+\s+\w+/);  // e.g., "GPT-5 Chat"
  console.log('Current model:', modelName ? modelName[0] : 'unknown');
}
```

## Confirmed Cases

| Date | Agent | Previous Score | Current Model | Old Model (retired) |
|------|-------|---------------|---------------|-------------------|
| June 15 2026 | SLP | Conv 95% | GPT-5 Chat | Unknown (retired) |
| June 15 2026 | OT | Conv 90%+ | GPT-5 Chat | Unknown (retired) |

## Notes

- The "retired" message only shows on the Overview page when the model dropdown is expanded
- It's visible in `document.body.innerText` even when collapsed — search for "was retired"
- All agents in the same environment were migrated to the same model (GPT-5 Chat observed in all cases)
