# Agent Description Conflict — Root Cause Pattern

**Discovered:** June 16, 2026  
**Impact:** PT SR dropped from 96% to 82%

## The Problem

The Copilot Studio agent "Description" field (shown on the Overview page under Details) is read by the model as system-level context. When the description conflicts with the agent instructions, GPT-5 Chat follows the DESCRIPTION, not the instructions.

### PT Example

**Description (WRONG):**
```
Non-conversational backend Physical Therapy clinical documentation intelligence agent...
Returns deterministic JSON with confidence scores and SHAP-style feature attribution.
HIPAA-compliant: processes record_id pointers only.
```

**Instructions (correct):**
```
RESPONSE FORMAT — Use for full document audits only:
1. Classification - Document type, Medicare coverage (Part A/B), PT vs PTA scope
2. Compliance Findings - [HIGH/MODERATE/LOW RISK] with confidence
3. Score - X/100 with tier
4. Missing Elements
5. Recommendations - Top 3 actionable steps
6. Advisory
```

The model returned JSON (following description) instead of the numbered format (following instructions) → evaluation grader failed the response → 82% SR.

## Detection

1. Navigate to agent Overview page
2. Look at the Description field under "Details" section
3. Check for conflicting language: "JSON", "deterministic", "structured output", "machine-readable"
4. Compare to the RESPONSE FORMAT in instructions

## Fix via Playwright

```javascript
// Navigate to Overview
await page.goto(baseUrl + botId + '/overview', { timeout: 30000, waitUntil: 'domcontentloaded' });
await page.waitForTimeout(15000);

// Click first Edit button (opens Details panel, NOT instructions)
const editBtns = page.locator('button:has-text("Edit")');
await editBtns.nth(0).click();
await page.waitForTimeout(5000);

// Find description textarea (contains old description text)
const textareas = page.locator('textarea');
const taCount = await textareas.count();
for (let i = 0; i < taCount; i++) {
  const val = await textareas.nth(i).inputValue().catch(() => '');
  if (val.includes('deterministic JSON') || val.includes('Returns JSON')) {
    await textareas.nth(i).fill(newDescription);
    break;
  }
}

// Click Save
const saveBtn = page.locator('button:has-text("Save"):visible').first();
await saveBtn.click();
await page.waitForTimeout(5000);

// Click Publish (confirmation dialog will appear)
await page.locator('button:has-text("Publish")').first().click();
await page.waitForTimeout(5000);
await page.locator('[role="dialog"] button:has-text("Publish")').click({ force: true });
await page.waitForTimeout(15000);
```

## Correct Description Template (Audit Agents)

```
[DISCIPLINE] compliance auditor for Ensign Services SNF therapy documentation.
Audits [DISCIPLINE] records against Medicare Part A/B, CMS Chapter 15,
[DISCIPLINE-SPECIFIC GUIDELINES], CPT codes, PDPM, ICD-10-CM, MDS Section GG,
and Noridian LCD. Covers [DOMAINS]. Returns compliance findings with risk levels,
scores, and recommendations. Part of the Therapy Documentation Audit multi-agent
system. HIPAA-compliant: references record_id pointers only. AI-generated output
requires human verification.
```

**Key phrase:** "Returns compliance findings with risk levels, scores, and recommendations"  
**NEVER:** "Returns JSON", "Returns deterministic output", "Returns structured data"
