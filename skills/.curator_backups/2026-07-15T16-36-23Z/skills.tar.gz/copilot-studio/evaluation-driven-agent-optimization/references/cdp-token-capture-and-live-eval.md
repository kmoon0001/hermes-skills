# CDP Token Capture & Live Eval Monitoring (July 2026)

## When Azure Portal Access is Unavailable

If the user gets 401 on Azure app registrations and cannot add `http://localhost` as a redirect URI, the eval-api's MSAL interactive flow will fail with AADSTS50011. **CDP token capture is the permanent workaround.**

## Token Capture Script

```javascript
// cdp_simple.cjs — connects to Edge on port 9223, navigates to eval page, captures PPAPI token
const WebSocket = require('ws');
const fs = require('fs');
const http = require('http');

// 1. Get tab list from http://127.0.0.1:9223/json/list
// 2. Find eval tab or create one via PUT /json/new?URL
// 3. Connect via WebSocket to tab's webSocketDebuggerUrl
// 4. Enable Fetch domain: Page.enable, Fetch.enable
// 5. Reload page: Page.reload
// 6. Capture Authorization header from requests to powerplatform.com
```

Token saved to `~/.copilot-studio-cli/test-agent-token.txt` (~4500 chars).

## Starting Edge with Persistent CDP

PowerShell script (`start_edge_cdp.ps1`):
```powershell
$edgePath = "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
$args = @(
    "--remote-debugging-port=9223",
    "--remote-allow-origins=*",
    "--no-first-run",
    "--user-data-dir=$env:LOCALAPPDATA\Microsoft\Edge\User Data"
)
Get-Process msedge -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Process $edgePath -ArgumentList $args
```

**Critical:** `--user-data-dir` MUST point to the ORIGINAL Edge profile to preserve Copilot Studio auth cookies.

## PPAPI Progress Counter is Unreliable

The PPAPI `testruns/{runId}` endpoint may show `testCasesProcessed: 0` even while the eval is actively processing in the Copilot Studio UI. The UI shows real-time results; the API lags.

## Computer Use for Live Eval Scraping

When PPAPI is unreliable, use cua-driver MCP (installed via `hermes computer-use install`) to scrape eval results directly from the user's Edge browser:

1. `get_accessibility_tree` to find Edge window
2. `get_window_state` to read page content
3. Parse score from the DOM text

This bypasses PPAPI auth, progress counter issues, and token expiry entirely.
