# QM Coach V2 — Topic Overlap Audit (June 19, 2026)

## Agent: SimpleLTC QM Coach V2
- Bot ID: ea52ad9c-8233-f111-88b3-6045bd09a824
- Environment: a944fdf0 (orgbd048f00.crm.dynamics.com)
- Model: GPT-5 Chat

## Before Cleanup: 62 topics (48 custom + 7 system + 7 connected agents)

## Topics Deleted (10 duplicates)

| Deleted Topic | GUID | Kept Instead | Reason |
|---------------|------|--------------|--------|
| QM Escalation Rules | 94492644-9856-f111-bec6-7ced8d3b6116 | Escalate QM Concern | Interactive menu causing eval failures |
| HITL APPROVAL | 87492644-9856-f111-bec6-7ced8d3b6116 | QM - HITL Approval | Generic duplicate of QM-specific version |
| QM - Human Review Gate | 3aed2623-76ad-479b-9cf6-e004723e83ee | QM - HITL Approval | Same purpose as HITL Approval |
| Power BI - Run a query (lowercase) | 1331a76c-b23f-4ec6-9563-5c700b79b4cb | Power BI - Run a Query (uppercase) | Exact duplicate with different casing |
| QM DRIVERS | 92492644-9856-f111-bec6-7ced8d3b6116 | QM Driver Analysis | Shorter/less developed duplicate |
| QM - Latest Resident Submission | 64ced8ef-b63a-42c9-98be-9a21b414aa93 | LATEST RESIDENT SUBMISSION ROUTER | Duplicate, router version was fixed |
| QM Intake | 1474651f-654e-4261-bb63-b665d561bd1f | SNF - Clinical Intake Handoff Router | Generic duplicate |
| QM - Extract Clinical Elements | 73bc6080-957a-47fc-980e-f865d9b6a6cc | QM - Validate Documentation Completeness | Overlapping functionality |
| WORKFLOW MENU | 3bef494a-9856-f111-bec6-7ced8d3b6116 | QM Orchestrator | Interactive menu causing eval failures |
| Start Over | 98492644-9856-f111-bec6-7ced8d3b6116 | Reset Conversation | Same functionality |

## Also Deleted (corrupted topics)
| Topic | GUID | Reason |
|-------|------|--------|
| HIPAA Guardrail | 85492644-9856-f111-bec6-7ced8d3b6116 | Monaco corruption (8 chars) |
| QM - HIPAA Guardrail | 5a8d5c91-bb36-41f2-abdb-d06e551f0950 | Monaco corruption (8 chars) |

## Recreated
| Topic | Notes |
|-------|-------|
| HIPAA Guardrail | Fresh topic with 17 trigger phrases + EndDialog |

## After Cleanup: 52 topics

## Eval Impact
- Single-response: 71% → 95% (+24 points)
- Conversation: 0% (all errors — needs republish + rerun)

## Key Finding
The 71% SR score was NOT an instruction problem. ALL 29 failures were topic-level:
- 20 (69%) interactive menus returning cards instead of text
- 7 (24%) system errors from broken action nodes
- 2 (7%) misrouted to greeting

Instruction cleanup (removing CRITICAL/NEVER) had zero effect on score because failures were all in topics.
