# Topic Data Patching via Dataverse API

## Critical: `data` vs `content` Fields

When modifying Copilot Studio topic YAML via the Dataverse API:

| Field | Behavior | PATCH Result |
|-------|----------|-------------|
| `data` | Contains full topic YAML | **HTTP 204** (works) |
| `content` | Usually `null` for UI-created topics | **HTTP 400** (API parses YAML as JSON) |

**Rule: Always PATCH the `data` field, never `content`.**

```javascript
// CORRECT — PATCH data field
await fetch(`${org}/api/data/v9.2/botcomponents(${topicId})`, {
  method: 'PATCH',
  headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json', 'OData-MaxVersion': '4.0', 'OData-Version': '4.0' },
  body: JSON.stringify({ data: newYaml })
}); // → HTTP 204

// WRONG — PATCH content field
await fetch(`${org}/api/data/v9.2/botcomponents(${topicId})`, {
  method: 'PATCH',
  body: JSON.stringify({ content: newYaml })
}); // → HTTP 400 "Unexpected character encountered while parsing value: k"
```

## Regex-Induced Topic Corruption

When surgically removing YAML blocks, **regex greediness can destroy adjacent blocks**.

### What Happened (Therapy Feedback Agent, July 2026)

Original topic had three adjacent blocks at the same indentation:
```yaml
      fileSearchDataSource:
        searchFilesMode:
          kind: SearchSpecificFiles
          files:
            - cr53f_...file1
            - cr53f_...file2

      knowledgeSources:
        kind: SearchSpecificKnowledgeSources
        knowledgeSources:
          - cr53f_...Habit1...
          - cr53f_...Habit2...

      applyModelKnowledgeSetting: true
```

This regex was TOO GREEDY:
```python
re.sub(r'\n\s*fileSearchDataSource:\s*\n(?:\s+[^\n]*\n)*', '\n', yaml)
```

**Result:** Removed ALL THREE blocks (fileSearchDataSource + knowledgeSources + applyModelKnowledgeSetting). The agent had zero KB access → 0-4% scores.

### Correct: Line-by-Line Parsing

```python
lines = original.split('\n')
new_lines = []
skip = False
for line in lines:
    if 'fileSearchDataSource:' in line:
        skip = True
        continue
    if skip:
        # Stop skipping at known boundary keywords
        if any(kw in line for kw in ['knowledgeSources:', 'applyModelKnowledge', '- kind: EndDialog']):
            skip = False
            new_lines.append(line)
        elif line.startswith('      ') or line.startswith('        '):
            continue  # Still in fileSearchDataSource block
        else:
            skip = False
            new_lines.append(line)
    else:
        new_lines.append(line)
fixed = '\n'.join(new_lines)
```

### Verification After Patching

After every PATCH, verify the result:
```bash
curl -H "Authorization: Bearer $token" \
  "${org}/api/data/v9.2/botcomponents(${tid})?\$select=data" | \
  python3 -c "import sys,json; d=json.load(sys.stdin); print(len(d['data']), 'chars')"
```

Check for expected keywords:
- `knowledgeSources:` should be PRESENT
- `applyModelKnowledgeSetting` should be PRESENT
- `fileSearchDataSource` should be ABSENT (if removed)
- `SearchSpecificFiles` should be ABSENT (if removed)

## Knowledge Source Verification

Query all knowledge sources by type to verify they exist:
```bash
curl -H "Authorization: Bearer $token" \
  "${org}/api/data/v9.2/botcomponents?\$select=name,schemaname,componenttype&\$filter=_parentbotid_value eq 'BOT_ID' and (componenttype eq 14 or componenttype eq 16)"
```

**Type mapping:**
- Type 14: File knowledge sources (PDFs, documents)
- Type 16: Reference knowledge sources (Quick Reference guides)

**Pitfall:** Generic `$top=70` queries without type filtering bury KB sources among hundreds of type-19 evaluation cases. Always filter by componenttype.

### Schemaname Matching

Topic YAML references use schemanames like:
```yaml
knowledgeSources:
  - cr53f_TherapyDocumentationFeedbackB.topic.Habit1QuickReferencepdf_zLMH1UrCPRTmgTT3YdC2m
```

Verify these match actual KB source schemanames EXACTLY. If KB sources were re-uploaded, schemanames change and topic references break silently.
