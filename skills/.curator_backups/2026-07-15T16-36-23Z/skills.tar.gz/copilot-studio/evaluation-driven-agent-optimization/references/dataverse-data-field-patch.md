# Dataverse API: `data` Field PATCH Technique

**Key discovery (Jul 2026):** PATCHing the `data` field works (HTTP 204) for both topics and GPT instructions — unlike the `content` field which returns 400.

## Topic data vs content

For Copilot Studio botcomponents:
- `content` field: Usually null for topics. PATCH returns 400 "Unexpected character while parsing value: k" (tries to parse YAML as JSON).
- `data` field: Contains the actual YAML/instructions. PATCH works fine with HTTP 204.

## Pattern

```python
import json, urllib.request, re

# Get Dataverse token (NOT PPAPI token — different audience)
# az account get-access-token --resource "https://org<id>.crm.dynamics.com"
dv_token = "..."

org = "https://org532ca94a.crm.dynamics.com"
topic_id = "1141155d-46e9-493c-8b1a-0ef196b29421"

# 1. Read current data
url = f"{org}/api/data/v9.2/botcomponents({topic_id})?$select=data"
req = urllib.request.Request(url)
req.add_header("Authorization", f"Bearer {dv_token}")
req.add_header("Accept", "application/json")
with urllib.request.urlopen(req) as resp:
    current = json.loads(resp.read())

yaml = current["data"]  # Full topic YAML or GPT instructions text

# 2. Modify
fixed = re.sub(r"\n\s*fileSearchDataSource:\s*\n(?:\s+[^\n]*\n)*", "\n", yaml)

# 3. PATCH
patch_url = f"{org}/api/data/v9.2/botcomponents({topic_id})"
body = json.dumps({"data": fixed})
req = urllib.request.Request(patch_url, method="PATCH")
req.add_header("Authorization", f"Bearer {dv_token}")
req.add_header("Content-Type", "application/json")
req.add_header("OData-MaxVersion", "4.0")
req.add_header("OData-Version", "4.0")
req.data = body.encode()
# Returns HTTP 204 on success
```

## Verified

Jul 1, 2026 — Batch-patched 6 audit topics (removed `SearchSpecificFiles` blocks, ~1600 chars each) and GPT instructions on Therapy Documentation Feedback Agent (Prod). All returned HTTP 204.

## Post-patch

After PATCHing, publish the agent:
```bash
pac copilot publish --environment <org_url> --bot <bot_id>
```
Dataverse changes alone don't affect eval — publish is required.
