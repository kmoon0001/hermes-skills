# SearchSpecificFiles as Abstention Root Cause

**Pattern discovered Jul 2026 on Therapy Documentation Feedback Agent (Prod).**

## Symptom

Agent consistently scores ~16% on SR eval with `Abstention=Yes` on 84% of cases. The agent REFUSES to answer rather than giving wrong answers.

## Root Cause

All audit topics used `SearchSpecificFiles` in their `fileSearchDataSource` block:

```yaml
fileSearchDataSource:
  searchFilesMode:
    kind: SearchSpecificFiles
    files:
      - cr53f_...file1
      - cr53f_...file2
```

This locked the KB search to ONLY those specific files. When test case questions didn't match content in those files, the KB returned nothing → agent abstained per its SOURCE RESTRICTION guardrail.

Even though `knowledgeSources` with broader KB references were also present, `fileSearchDataSource` overrode them.

## Detection

Read topic `data` field via Dataverse API and check for `SearchSpecificFiles`:

```python
# Check all active topics
for topic in topics:
    if "SearchSpecificFiles" in topic["data"]:
        print(f"RESTRICTED: {topic['name']}")
```

## Fix

Remove the entire `fileSearchDataSource` block, keeping `knowledgeSources` and `applyModelKnowledgeSetting: true`:

```python
import re
fixed = re.sub(r'\n\s*fileSearchDataSource:\s*\n(?:\s+[^\n]*\n)*', '\n', yaml)
```

After: agent searches ALL knowledge sources, not just specific files.

## Also Check

- **GPT guardrails**: If SOURCE RESTRICTION says "explicitly state that the determination cannot be made" when KB doesn't match → this amplifies the SearchSpecificFiles problem. Pair topic-level fix with guardrail relaxation.
- **800-character limits**: Episode of Care had "Keep response under 800 characters" — remove for audit agents.
- **Connection ID**: Doesn't help if KB search is file-restricted. The connection ID provides auth, not broader search scope.

## Verified

Jul 1, 2026 — 6 audit topics fixed on Therapy Documentation Feedback Agent (Prod). All patched via Dataverse `data` field (HTTP 204). See `references/dataverse-data-field-patch.md`.
