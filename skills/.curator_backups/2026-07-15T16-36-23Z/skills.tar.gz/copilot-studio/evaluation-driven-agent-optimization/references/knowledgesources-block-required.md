# knowledgeSources Block — Required for SearchAndSummarizeContent

## Critical Discovery

`applyModelKnowledgeSetting: true` alone is NOT sufficient for `SearchAndSummarizeContent`
to search knowledge sources. The explicit `knowledgeSources` block is REQUIRED.

## What Happened

During a batch topic fix to remove `fileSearchDataSource`, the regex was too aggressive
and also removed the adjacent `knowledgeSources` block from all 6 audit topics:

```yaml
# BEFORE (working):
      fileSearchDataSource:
        searchFilesMode:
          kind: SearchSpecificFiles
          files: [...]
      knowledgeSources:          # ← ALSO REMOVED by aggressive regex!
        kind: SearchSpecificKnowledgeSources
        knowledgeSources:
          - cr53f_...Habit1...
          - cr53f_...Habit2...
      applyModelKnowledgeSetting: true

# AFTER (broken):
      # knowledgeSources GONE — only applyModelKnowledgeSetting remains
      applyModelKnowledgeSetting: true
```

## Effect on Eval Scores

| State | Score | KB Access |
|-------|-------|-----------|
| knowledgeSources present | 83% | ✓ KB found |
| knowledgeSources removed (only applyModelKnowledgeSetting) | 0-8% | ✗ KB not searched |

The agent scored 0-8% for 12 consecutive eval runs while knowledgeSources was removed,
despite `applyModelKnowledgeSetting: true` being set, and despite all 13 KB sources
being present and active in Dataverse.

## Fix

Restore the `knowledgeSources` block with the correct schemanames. Verify with Dataverse:

```python
# Confirm KB sources exist and schemanames match
filter_val = "_parentbotid_value eq '{botId}' and (componenttype eq 14 or componenttype eq 16)"
# Compare schemanames to what topics reference
```

## Verification

Always verify the `data` field of a patched topic contains:
- `knowledgeSources:` — PRESENT (essential)
- `applyModelKnowledgeSetting: true` — PRESENT
- `fileSearchDataSource` — REMOVED (file scope is too narrow for KB questions)

Never assume `applyModelKnowledgeSetting: true` alone handles KB search.
