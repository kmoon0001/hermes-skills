# Dataverse API Topic Creation — Pitfalls and Technique

## Overview

Topics can be created via Dataverse API POST to `botcomponents`, but require specific field handling for the topic to be visible in the Copilot Studio UI and function correctly in evals.

## Required Fields

| Field | Value | Purpose |
|-------|-------|---------|
| `name` | Topic display name | Shown in UI |
| `content` | Full topic YAML | The actual topic logic (AdaptiveDialog, triggerQueries, BeginDialog, etc.) |
| `data` | Minimal AdaptiveDialog shell (~121 chars) | Used by Copilot Studio engine for routing/matching |
| `schemaname` | `cr917_agent.topic.TopicName` | Unique identifier (immutable after creation) |
| `componenttype` | `9` | Identifies as topic component |
| `parentbotid@odata.bind` | `/bots(BOT_ID)` | Links to the bot |
| `statecode` | `0` | Active state |

## The `data` Field Trap

The `data` field is the #1 pitfall for API-created topics. Three states:

1. **`data` = null (not set):** Topic exists in Dataverse but is INVISIBLE in the Copilot Studio UI. The agent cannot route to it. PAC publish succeeds silently.

2. **`data` = full YAML content:** Topic appears in UI but causes MASSIVE eval regression. The Copilot Studio engine uses `data` for routing/matching — having full content in `data` confuses the routing engine. QM Coach V2 SR dropped from 95% to 23%.

3. **`data` = minimal shell (~121 chars):** CORRECT. Topic appears in UI and routes correctly.

## Minimal Shell Template

```
kind: AdaptiveDialog\r\nbeginDialog:\r\n  kind: OnRecognizedIntent\r\n  id: main\r\n  intent: {}\r\n\r\ninputType: {}\r\noutputType: {}
```

This is the same template that Copilot Studio creates when you make a "blank" topic in the UI.

## Working Topic Comparison

| Topic | content len | data len | Status |
|-------|------------|----------|--------|
| Escalate QM Concern (working) | 1301 | 121 | ✓ 95% SR |
| QM Driver Analysis (working) | 1390 | 121 | ✓ 95% SR |
| Coaching Corner (broken) | 1818 | 1818 | ✗ 23% SR |
| Accountability Matrix (broken) | 1529 | 1529 | ✗ 23% SR |

## Full Creation Script

```javascript
const { chromium } = require('playwright-core');

async function createTopic(page, ORG, BOT_ID, name, yaml, schemaName) {
  const shellYaml = 'kind: AdaptiveDialog\r\nbeginDialog:\r\n  kind: OnRecognizedIntent\r\n  id: main\r\n  intent: {}\r\n\r\ninputType: {}\r\noutputType: {}';
  
  // 1. Create topic with content + data
  const createResult = await page.evaluate(async ({name, yaml, shellYaml, schemaName, BOT_ID, ORG}) => {
    const resp = await fetch(`${ORG}/api/data/v9.2/botcomponents`, {
      method: 'POST',
      credentials: 'include',
      headers: {
        'Accept': 'application/json',
        'OData-MaxVersion': '4.0',
        'OData-Version': '4.0',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        name: name,
        content: yaml,
        data: shellYaml,
        componenttype: 9,
        schemaname: schemaName,
        'parentbotid@odata.bind': `/bots(${BOT_ID})`
      })
    });
    return { ok: resp.ok || resp.status === 204, status: resp.status };
  }, {name, yaml, shellYaml, schemaName, BOT_ID, ORG});
  
  if (!createResult.ok) throw new Error(`Create failed: ${createResult.status}`);
  
  // 2. Verify both fields
  // ... (query back and check contentLen + dataLen)
  
  // 3. Publish after all topics created
}
```

## Verification Checklist

After creating topics via API:
- [ ] Query topic back via API — verify `content` has full YAML
- [ ] Query topic back via API — verify `data` has minimal shell (~121 chars)
- [ ] Check topic count matches expected (API query)
- [ ] Publish the agent
- [ ] Navigate to Topics page in UI — verify topic appears
- [ ] Run eval to verify no regression

## Key Lessons

1. **Never set `data` to full YAML** — causes 95% → 23% SR regression
2. **Always set `data` to minimal shell** — required for UI visibility
3. **Publish after creation** — unpublished topics don't affect evals
4. **`schemaname` is immutable** — cannot be changed after creation
5. **`data` field is NOT the same as `content`** — `content` has the full logic, `data` has the routing shell
