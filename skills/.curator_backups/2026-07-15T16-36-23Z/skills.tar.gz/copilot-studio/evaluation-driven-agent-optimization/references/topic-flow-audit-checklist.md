# Topic Flow Audit — End-to-End Conversation Trace (July 2026)

## When to Use

When an agent's SR eval score is stuck at <20% despite correct instructions and knowledge sources. The most common root cause: a topic with Question nodes or missing EndDialog that intercepts all conversations and blocks intent-matching.

## The Checklist

Trace EVERY active topic from conversation start to end:

### 1. Start with Conversation Start / Greeting
- Does this topic have `kind: Question` nodes? → BLOCKER for SR eval (returns question instead of answer)
- Does it have `EndDialog` at the end? → If not, conversation hangs
- Does it have `CancelAllDialogs`? → May kill the conversation before other topics can fire
- Deactivate if it's purely an interactive wizard

### 2. Check EVERY custom topic
For each topic, verify:
- `EndDialog` with `clearTopicQueue: true` at the end
- No `kind: Question` nodes (unless it's OCR file upload)
- No `CancelAllDialogs` (use EndDialog instead)
- `SearchAndSummarizeContent` has `knowledgeSources` OR `applyModelKnowledgeSetting: true`

### 3. Check system topics
- `Multiple Topics Matched` → remove Question nodes, use SendActivity
- `Fallback` → ensure EndDialog, route to Escalate on 3rd retry
- `On Error` → add EndDialog
- `Reset Conversation` → replace CancelAllDialogs with EndDialog
- `Escalate` → add EndDialog
- `Goodbye` → remove Question nodes
- `Thank you` → add EndDialog

### 4. Check catch-all topic
- `Conversational boosting` (OnUnknownIntent, priority -1):
  - Must have `SearchAndSummarizeContent` with `applyModelKnowledgeSetting: true`
  - Must have `elseActions` fallback when KB returns nothing
  - Fallback should send helpful text, not stay silent

### 5. Verify knowledgeSources
- Query Dataverse: `componenttype in (14, 16)` to see what exists
- Check topic schemaname references match actual KB source schemanames
- If KB sources exist but schemanames don't match → topics can't find them

## Evidence

Therapy Documentation Feedback Agent (July 1, 2026):
- Conversation Start (OnConversationStart) with Question nodes → blocked all SR eval
- 6 audit topics had Question nodes in Greeting, Goodbye, Multiple Topics Matched, End of Conversation
- 4 topics had NO EndDialog
- 2 topics had CancelAllDialogs instead of EndDialog
- After fixing all 11 topics: 30% → 50% → 83%
