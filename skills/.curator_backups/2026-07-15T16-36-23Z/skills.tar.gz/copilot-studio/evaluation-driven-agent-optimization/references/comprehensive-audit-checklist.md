# Comprehensive Agent Audit Checklist

Pre-optimization structural audit for Copilot Studio agents. Run BEFORE any evaluation to catch design-level failures that no instruction tuning can fix.

## Dataverse Query Pattern

```python
# List ALL components for an agent, grouped by type
filt = f"_parentbotid_value eq '{bot_id}' and componenttype eq {ct}"
url = f"{org}/api/data/v9.2/botcomponents?$filter={urllib.parse.quote(filt)}&$select=botcomponentid,name,componenttype,statecode,statuscode,description,modifiedon,data&$top=500"
```

Component type reference:
| Type | Meaning | Typical count |
|------|---------|---------------|
| 9 | Topic | 10-25 |
| 14 | Knowledge Source | 5-15 |
| 15 | Instructions/GPT | 1 |
| 16 | Knowledge File | 5-30 |
| 19 | Conversation Starter / Test Case | 50-500 |

---

## 1. Topic Count & Coverage

Check: Are there enough topics to cover the test set questions?
- Agent has enough custom topics to match the diversity of test queries
- No unnecessary topic duplication
- System topics (End of Conversation, Escalate, Fallback, etc.) present and active

**Fixes:**
- Missing topic → create one
- Duplicate topic → deactivate one via PATCH `{"statecode": 1}`

---

## 2. Conversation Start — #1 SR Eval Killer

**Check:** Does the Conversation Start (OnConversationStart) topic contain `kind: Question` nodes?

Query:
```python
filt = f"_parentbotid_value eq '{bot_id}' and componenttype eq 9 and name eq 'Conversation Start'"
url = f"{org}/api/data/v9.2/botcomponents?$filter={urllib.parse.quote(filt)}&$select=botcomponentid,name,data"
```

**Why this kills SR evals:** OnConversationStart fires BEFORE any intent-matching topic. If it has a Question node (ClosedListEntity, FilePrebuiltEntity, etc.), every single SR test case gets that question prompt instead of an answer. Grader sees Abstention.

**Fixes:**
1. **Deactivate** Conversation Start via Dataverse PATCH: `PATCH /botcomponents({id}) {"statecode": 1}` (HTTP 204 = success)
2. OR strip all Question nodes from the YAML `data` field, keep only BeginDialog routing

**Also check:** Does the menu offer a text-question option (e.g. "Ask a Medicare compliance question")? If not, text-only questions have no routing path.

---

## 3. Review Topic File-Upload Gate

**Check:** For every review/audit topic, examine the FIRST action after `beginDialog`.

Query the `data` field of each review topic. If the first kind is `Question` with `entity: FilePrebuiltEntity`, the topic requires file upload before answering.

**Why this kills SR evals:** Text questions like "What are the CMS requirements for progress notes?" match the topic intent, then hit the file upload question → "Please upload the document" → grader sees Abstention.

Also affects conversational evaluations: user types a text question and gets a file upload prompt instead of an answer.

**Fix:** Add a ConditionGroup before the file Question:
```yaml
- kind: ConditionGroup
  id: check_if_text_question
  conditions:
    - id: has_document
      condition: |=True(First(System.Activity.Attachments))
      actions:
        # Original file upload flow here
        - kind: Question
          id: question_upload_doc
          ...
    # else → route text questions to SearchAndSummarizeContent
      elseActions:
        - kind: SearchAndSummarizeContent
          id: answer_text_question
          variable: Topic.Answer
          userInput: =System.Activity.Text
          knowledgeSources:
            kind: SearchAllKnowledgeSources
          additionalInstructions: >-
            Provide specific requirements with inline citations from the agent's knowledge sources.
            Format as a concise compliance advisory. Use 5-section format if appropriate.
        - kind: SendActivity
          activity: "{Topic.Answer}"
        - kind: EndDialog
          clearTopicQueue: true
```

---

## 4. SearchSpecificFiles vs SearchAllKnowledgeSources

**Check:** For each SearchAndSummarizeContent node, what search mode is used?

```yaml
# RESTRICTED mode — only searches specific files
fileSearchDataSource:
  searchFilesMode:
    kind: SearchSpecificFiles
    files:
      - pkg.file.FileName_hash

# UNRESTRICTED mode — searches all knowledge sources
# (no fileSearchDataSource block, or SearchAllKnowledgeSources)
knowledgeSources:
  kind: SearchAllKnowledgeSources
```

**Why this matters:** SearchSpecificFiles constrains KB retrieval to exactly the listed file schemanames. The agent cannot use any other knowledge source, even if relevant. Causes Groundedness failures when the right answer exists in a non-listed file.

**Fix:** Replace `SearchSpecificFiles` with `SearchAllKnowledgeSources` (or remove the `fileSearchDataSource` block entirely).

---

## 5. Topic modelDescription

**Check:** Does every topic have a `modelDescription:` line at the top of its `data` YAML?

Per MS Learn: *"Good descriptions = Describe what the topic does (functional). Bad descriptions = Describe what to say (conversational). The model's context includes topic descriptions — unclear ownership causes duplicate prompts or unexpected behavior."*

A good modelDescription includes:
- What the topic does (functional, not conversational)
- What data it collects (if any)
- What the model should NOT do (e.g., "Must not ask for document details — the topic handles that")

**System topics frequently missing modelDescription:** Fallback, Escalate, End of Conversation, Multiple Topics Matched, On Error, Reset Conversation

**Fix:** PATCH the `data` field to add `modelDescription: <text>` as the second line (after `kind: AdaptiveDialog`).

---

## 6. Topic description Field (Dataverse column)

**Check:** The `description` field on each botcomponent (visible in Copilot Studio Topics list).

This field helps human makers navigate the topic list. Often forgotten by makers. If empty, add a brief description.

**Fix:** PATCH `{"description": "..."}` on the botcomponent record.

---

## 7. Fallback Topic (OnUnknownIntent)

**Check:** Does the Fallback topic have `additionalInstructions` on its SearchAndSummarizeContent node?

**Without additionalInstructions,** the fallback produces generic, ungrounded answers → Groundedness=No failures.

Required additionalInstructions:
```yaml
additionalInstructions: >-
  Provide specific requirements with inline citations from the agent's knowledge sources.
  Never fabricate. If the knowledge sources do not contain the answer, say so clearly.
  Maintain consistency with previous responses in this conversation.
```

---

## 8. Greeting Topic Rerouting

**Check:** Does the Greeting topic use `BeginDialog` → `ConversationStart`?

If so, any greeting/hi/hello triggers the same Conversation Start menu/file-upload cycle.

**Fix:** Remove the `BeginDialog` redirect, or have Greeting route to Fallback (which handles text questions via SearchAndSummarizeContent).

---

## 9. Agent Instructions (Type 15)

**Extract:** Query componenttype=15, inspect the full `data` field.

**Checklist:**
| Aspect | What to verify |
|--------|---------------|
| ROLE | Clear persona defined |
| APPROVED KNOWLEDGE SOURCES | Listed explicitly |
| KNOWLEDGE HIERARCHY | Priority order specified |
| GUARDRAILS | Source grounding, no hallucination, citation rules |
| ROUTING LOGIC | Document review vs text question vs missing-document |
| CITATION RULES | Inline format required |
| OUTPUT FORMAT | 5-section audit with color ratings |
| RESPONSE FORMAT for SR | Concise answers (<900 chars) for text questions |
| No-caveat block | Must not ask for document when no document provided |
| Model selection | modelNameHint specified (Sonnet46, GPT5Chat, etc.) |

**Common missing items:**
- No RESPONSE FORMAT directive for evaluation mode (causes answer too long / truncation)
- No text-question path (causes agent to ask for document on every text input)
- MISSING-DOCUMENT REVIEW FORMAT that doesn't stop asking for the document

**Fix:** PATCH the `data` field on the componenttype=15 record.

---

## 10. Knowledge Source Completeness

**Check:** Do all referenced knowledge sources exist?

Query componenttype=14 and compare schemanames against:
- The approved sources list in the instructions
- Any `SearchSpecificFiles` file references in topics

**Missing KB sources** cause Groundedness failures because the agent cannot access the content it's told to use.

---

## Failure Pattern Summary

| Pattern | SR Impact | Conv Impact | Root Cause |
|---------|-----------|-------------|------------|
| Conv Start Question gate | Abstention on ALL | Blocks routing | OnConversationStart + Question node |
| File upload gate | Abstention | Asks for file first | Question + FilePrebuiltEntity at topic entry |
| SearchSpecificFiles | Groundedness | Groundedness | Constrained KB retrieval |
| Missing modelDescription | Topic routing | Topic routing | Orchestrator can't differentiate topics |
| Fallback no additionalInstructions | Groundedness | Groundedness | Generic ungrounded answers |
| Greeting→ConvStart redirect | Abstention | Menu loop | Redirect before intent matching |
| No text-question path in instructions | Abstention | Asks for file | Instructions only cover doc review |
