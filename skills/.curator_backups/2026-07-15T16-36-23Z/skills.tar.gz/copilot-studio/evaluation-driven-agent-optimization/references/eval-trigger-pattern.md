# Evaluation Trigger Pattern

Correct button sequence to trigger evaluations in Copilot Studio.

## Proven Method: Test Set Card → Details Page → Evaluate → Run (June 2026)

This is the most reliable method, validated against SLP agent with both Conv and SR test sets:

### Step-by-Step

1. Navigate to agent's evaluation page: `.../bots/<botId>/evaluation`
2. Wait 8-10s for SPA to load "Test sets" cards
3. **Click the test set card** in the "Test sets" section (NOT "Recent results"). Cards are `div` elements with `cursor: pointer`, width 200-600px, height 50-200px.
   - Conv card: contains "20 test cases" + "Conversation"
   - SR card: contains "100 test cases" + "Single response"
4. Card click navigates to `.../evaluation/configsDetails/<testSetId>`. Wait 5s.
5. **Click the "Evaluate" button** (top right of details page, NOT disabled)
6. "Manage profile and connections" dialog appears → **click "Run"**
7. Eval starts immediately, named with timestamp (e.g., `260616_2141`)

### Playwright Code (Proven)

```javascript
// Step 3: Find and click SR card
const srCard = await page.evaluate(() => {
    const divs = document.querySelectorAll('div');
    for (const d of divs) {
        const rect = d.getBoundingClientRect();
        const t = d.textContent || '';
        if (t.includes('100 test cases') && t.includes('Single response') &&
            rect.width > 200 && rect.width < 600 && rect.height > 50 &&
            getComputedStyle(d).cursor === 'pointer') {
            return { x: rect.x + rect.width/2, y: rect.y + rect.height/2 };
        }
    }
    return null;
});
await page.mouse.click(srCard.x, srCard.y);
await sleep(5000);

// Step 5: Click Evaluate
await page.evaluate(() => {
    const btns = Array.from(document.querySelectorAll('button'));
    const b = btns.find(b => b.textContent?.trim() === 'Evaluate' && !b.disabled);
    if (b) b.click();
});
await sleep(3000);

// Step 6: Click Run
await page.evaluate(() => {
    const d = document.querySelector('[role="dialog"]');
    const btns = d?.querySelectorAll('button') || [];
    for (const b of btns) {
        if (b.textContent?.trim() === 'Run') { b.click(); break; }
    }
});
```

### Pitfall: "New evaluation" button opens a different flow
The "New evaluation" button (top of page) opens a CSV upload / question generation flow. It requires creating new test cases. Use the test set card click method instead to reuse existing test sets.

### Pitfall: Results row "Evaluate" buttons open past results
The "Evaluate" buttons in the Recent results section (y > 400) open existing result details, NOT trigger new runs.

### Pitfall: Test set config page has Evaluate at the bottom
When you click the test set row (not the card), it opens the config page at `.../evaluation/configsDetails/<id>`. The "Save" and "Evaluate" buttons are at the BOTTOM of the page (y ~1100). Scroll down or use CDP coordinates to click. The page shows "Review your test cases (N)" with test case details — the Evaluate button is below all the test cases.

### Pitfall: SPA may open test pane instead of eval page
If navigating to `/evaluation` shows "Test your agent" instead of test set cards, the test pane is overlaying. Click the "Test" button in the header to toggle it closed, then click the Evaluation tab.

### CDP Fresh-Context Recovery
When CDP pages become stale (execution context destroyed, wrong environment), close all pages and open a fresh one:
```javascript
const context = browser.contexts()[0];
const existingPages = context.pages();
for (const p of existingPages) await p.close().catch(() => {});
const page = await context.newPage();
```
Auth cookies persist across pages within the same browser context.
