# QM Coach V2 Topic Audit — June 2026

## Topic Status After Injection

| Topic | Chars | Statecode | Issues |
|-------|-------|-----------|--------|
| HIPAA Guardrail | 2072 | 0 (active) | OK |
| DoR Summary | 3823 | 0 | **Question nodes (3) + AdaptiveCard + No EndDialog** |
| Sign in | 817 | 0 | System topic |
| Greeting | 825 | 0 | System topic |
| Escalate QM Concern | 1301 | 0 | OK — SendActivity + EndDialog |
| QM Driver Analysis | 1390 | 0 | OK |
| QM Data Upload & Decline Detection | 1485 | 0 | OK |
| Goodbye | 1340 | 0 | System topic |
| Escalate | 2860 | 0 | System topic |
| SNF - Clinical Intake Handoff Router | 1140 | 0 | OK |
| Thank you | 621 | 0 | System topic |
| End of Conversation | 2770 | 0 | System topic |
| Fallback | 1838 | 0 | SearchAndSummarizeContent + EndDialog |
| FacilityTrendReporter | 1407 | 0 | OK |
| QM Action Plan | 1416 | 0 | OK |
| Multiple Topics Matched | 1603 | 0 | System topic |
| Conversation Start | 670 | 0 | System topic |
| Reset Conversation | 731 | 0 | System topic |
| Resident Outlier Analysis | 4109 | 0 | **Question nodes (3) + ClosedListEntity** |
| On Error | 807 | 0 | System topic |

## Broken Topics (Caused 95% → 12% SR Regression)

### DoR Summary
- 3 Question nodes: facility selection, audience selection, focus selection
- AdaptiveCard with 3 buttons (DoR Only, Interdisciplinary Team, Executive Leadership)
- No EndDialog
- Fix: Replace with SearchAndSummarizeContent + EndDialog

### Resident Outlier Analysis
- 3 Question nodes: facility selection, coaching output, outlier pattern
- ClosedListEntity with 7 options
- ConditionGroup routing based on answers
- Fix: Replace with SearchAndSummarizeContent + EndDialog

## Clean Topics (7 Custom)
- Escalate QM Concern — SendActivity + EndDialog ✓
- QM Driver Analysis — OK ✓
- QM Data Upload & Decline Detection — OK ✓
- SNF - Clinical Intake Handoff Router — OK ✓
- FacilityTrendReporter — OK ✓
- QM Action Plan — OK ✓
- HIPAA Guardrail — OK ✓

## Eval History
- Yesterday 12:31 PM: 95% SR (best)
- Today 2:42 AM: 23% SR (after topic injection + publish)
- Today 3:12 AM: 12% SR (after data field fix + publish)
- After deleting new topics: 12% SR (broken topics still broken)
- After manual fix (user pasted): TBD (eval pending)

## Key Finding
The 95% → 12% regression was NOT caused by:
- New topic injection (deleted, still 12%)
- Platform/model changes
- Inactive guard topics (all 20 active)

It WAS caused by:
- DoR Summary interactive wizard (Question nodes)
- Resident Outlier Analysis interactive wizard (Question nodes)
- These topics were ALWAYS broken — the 95% was before they were triggered by eval test cases
