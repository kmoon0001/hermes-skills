# TDA Orchestration Production Readiness — Key Takeaways

From the Ensign Services TDA Orchestration Production Readiness Action Plan (2026-06-15).

## Stale Evidence Detection

If last evaluation date < last publish date, evidence is STALE. Re-run before diagnosing.
OT example: June 13 eval showing 91% with cite:1 failures was run BEFORE June 14-15 publishes.

## Cross-Signal Pattern

Multiple evaluation sets degrading simultaneously = single root cause.
Check platform/model updates, shared knowledge sources, or non-deterministic variance (5-10% normal).

## MS Learn Triage Order

1. Infrastructure health
2. Evaluation quality (grader may be wrong)
3. Expected answer stale
4. Agent behavior wrong
5. Platform limitation

## Duplicates

TDA_v2_MultiDiscipline and Therapy_Report_Prep_Assistant may confuse tests.
