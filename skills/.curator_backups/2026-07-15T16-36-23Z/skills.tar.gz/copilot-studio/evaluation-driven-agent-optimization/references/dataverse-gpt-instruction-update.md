# Dataverse API: Update GPT Instructions (componenttype 15)

## When to Use
When you need to update agent instructions programmatically without navigating the Copilot Studio UI.

## Find the GPT Component
```bash
# Query for componenttype 15
GET /api/data/v9.2/botcomponents?$select=botcomponentid,name,data&$filter=_parentbotid_value eq '{botId}' and componenttype eq 15
```

## Update Instructions via PATCH
```python
# Requires a Dataverse token (not PPAPI)
# Get Dataverse token via Azure CLI:
# az account get-access-token --resource "https://org<id>.crm.dynamics.com" --query accessToken -o tsv

url = f"{org_url}/api/data/v9.2/botcomponents({gpt_id})"
body = json.dumps({"data": full_instructions_yaml})

req = urllib.request.Request(url, method="PATCH")
req.add_header("Authorization", f"Bearer {dv_token}")
req.add_header("Content-Type", "application/json")
req.add_header("OData-MaxVersion", "4.0")
req.add_header("OData-Version", "4.0")
req.data = body.encode()
# Returns HTTP 204 on success
```

## Key Differences from Topic PATCH
- GPT instructions are in the `data` field (NOT `content`)
- PATCHing the `data` field works reliably (unlike topic `content` which returns 400 "Unexpected character k")
- The instructions format is YAML with `instructions: |-` block scalar

## Publish Required
After updating instructions in Dataverse, the agent must be PUBLISHED for changes to take effect in evaluations:
```bash
pac copilot publish --environment <org-url> --bot <bot-id>
```

## Token Requirements
- PPAPI token (from eval-api) does NOT work for Dataverse API — returns 401
- Dataverse token from Azure CLI works: `az account get-access-token --resource "{org_url}"`
- The user must be signed into Azure CLI with the same tenant

## Verification
After PATCH, verify the change took effect:
```bash
curl -H "Authorization: Bearer $dv_token" \
  "https://org<id>.crm.dynamics.com/api/data/v9.2/botcomponents({gpt_id})?\$select=data" \
  | python3 -c "import sys,json; d=json.load(sys.stdin); print('New guardrail present' if 'answer authoritatively' in str(d.get('data','')) else 'OLD guardrail')"
```

## Evidence
Therapy Documentation Feedback Agent (Prod, July 2026): Successfully updated GPT instructions via Dataverse PATCH (HTTP 204), verified via GET (5473 chars, new guardrail confirmed), published via PAC CLI. The PATCH took <2 seconds with no errors.
