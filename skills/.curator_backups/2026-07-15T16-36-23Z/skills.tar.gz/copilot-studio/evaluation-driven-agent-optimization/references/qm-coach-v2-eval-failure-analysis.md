# QM Coach V2 Eval Failure Analysis (June 2026)

## Agent Context
- Agent: SimpleLTC QM Coach V2
- Bot ID: ea52ad9c-8233-f111-88b3-6045bd09a824
- Environment: Therapy AI Agents Dev (a944fdf0)
- Eval: 100 single-response cases, 71% score (29 failures)
- 48 custom topics + 7 system topics
- Instruction cleanup had zero effect on score

## Failure Categories

### Category 1: Interactive Menus (20 failures, 69%)
Topics fire and return interactive wizards/cards instead of text answers.

| Question | Topic Response | Topic Name |
|----------|---------------|------------|
| summary email for DoR | EMAIL GENERATOR menu | QM - Email Generator |
| escalating a QM concern | ESCALATION MATRIX menu | QM - Escalation Matrix |
| escalation rules | ESCALATION MATRIX menu | QM - Escalation Matrix |
| workflow menu | Workflow card | QM - Workflow Menu |
| severity classifications | SEVERITY CLASSIFIER menu | QM - Severity Classifier |
| generate email for leadership | EMAIL GENERATOR menu | QM - Email Generator |
| workflow menu selection | Workflow card | QM - Workflow Menu |
| route clinical intake | INTAKE ROUTER menu | QM - Intake Router |
| reset conversation | "Are you sure?" prompt | QM - Reset |
| drivers behind QM performance | Driver Category menu | QM - Driver Analysis |
| human review of urgent QM | ESCALATION PROTOCOL menu | QM - HITL |
| classify severity | SEVERITY CLASSIFIER menu | QM - Severity Classifier |
| Regulatory Hub for compliance | Long generic answer | Regulatory Hub routing |
| route clinical intake | INTAKE ROUTER menu | QM - Intake Router |
| initiate QM orchestrator | Workflow menu | QM - Orchestrator |
| escalate to leadership | ESCALATION PROTOCOL menu | QM - HITL |
| workflow menu for SNF tasks | Workflow card | QM - Workflow Menu |
| analyze drivers | Driver Category menu | QM - Driver Analysis |
| QM red flag prescreen | INTAKE ROUTER menu | QM - Intake Router |
| QM workflow progress | Workflow card | QM - Workflow Menu |

### Category 2: System Errors (7 failures, 24%)
Topics throw "I hit a system error" — broken actions/connectors.

- Certification/recertification MDS alignment
- SNF AI Dashboard to monitor QMs (x2)
- SNF Command Center
- Escalate compliance exception
- QM single note compliance audit
- SNF AI Dashboard to track QM metrics

### Category 3: Misrouted to Greeting (2 failures, 7%)
- "HIPAA compliance when working with QM data" → Welcome message
- "QM processes are HIPAA compliant" → Welcome message

## Root Cause
The 48 custom topics are designed as interactive wizards. When the eval asks a general question, the topic fires and returns a menu/prompt instead of a text answer. The eval grader expects a direct answer and marks it as a failure.

## Key Lesson
When >50% of eval failures are topic-level (menus/errors/misroutes), instruction changes won't help. Fix topics first.
