# cua-driver for Live Copilot Studio UI Access (July 2026)

## Problem

PPAPI eval progress counter shows 0/25 even when e……」val is running. Token expires every 30 minutes. CDP browser scraping gets blocked by SPA overlays. The most reliable way to check eval results is to see the Copilot Studio UI directly.

## Solution: cua-driver Desktop Automation

cua-driver provides background desktop automation — clicking, typing, scrolling — without stealing the cursor, keyboard focus, or switching virtual desktops.

### Installation

```bash
hermes computer-use install
```

This installs `cua-driver.exe` and registers it as a Windows service (auto-start at logon).

### MCP Configuration

```bash
# Get the config snippet
"$USERPROFILE/.cua-driver/packages/current/cua-driver.exe" mcp-config --client hermes

# Add to config (the args must be a YAML list, NOT a JSON string)
hermes config set mcp_servers.cua-driver.command 'C:\Users\kevin\.cua-driver\packages\current\cua-driver.exe'

# Correct way to add args (use hermes mcp add, not hermes config set):
echo y | hermes mcp add cua-driver --command "C:\Users\kevin\.cua-driver\packages\current\cua-driver.exe"
```

### Common Pitfalls

**args as string not list:** `hermes config set` stores values as strings. Setting `args: '["mcp"]'` stores it as a JSON string, which fails MCP validation. Use `hermes mcp add` instead, which handles YAML-native list format.

**Desktop scope needed for full screenshots:** `get_desktop_state` requires `capture_scope: "desktop"`. Set it first:
```python
mcp_cua_driver_set_config(capture_scope="desktop")
```

**Scroll needs foreground mode on Chrome_WidgetWin_1:** Chromium windows reject background scroll. Use:
```python
mcp_cua_driver_bring_to_front(pid=34452)
mcp_cua_driver_scroll(direction="down", amount=10, delivery_mode="foreground")
```

**UIA tree only shows browser chrome, not page content:** `get_window_state` returns Edge UI elements (toolbar, tabs) but NOT the web page DOM. Use `get_desktop_state` + vision analysis to read page content.

**browser_console connects to managed browser, not user's Edge:** Hermes's `browser_console` and `browser_navigate` use a managed headless browser. They don't connect to the user's existing Edge session. Use cua-driver screenshots + vision for live UI access.

### Workflow for Checking Eval Results

1. Find Edge: `mcp_cua_driver_list_apps` → get PID
2. Bring to front: `mcp_cua_driver_bring_to_front(pid)`
3. Capture desktop: `mcp_cua_driver_get_desktop_state()`
4. Analyze with vision: `vision_analyze(image_url, question="Read eval scores...")`
5. Scroll if needed: `mcp_cua_driver_scroll(direction="down", delivery_mode="foreground")`

### When to Use What

| Need | Tool |
|------|------|
| Read eval scores from user's Edge | cua-driver screenshot + vision |
| Execute JS on user's Edge page | Not available (needs CDP port + auth) |
| Navigate to new Copilot Studio page | user's Edge via CDP (port 9223) |
| Start eval programmatically | PPAPI (token from CDP capture) |
| Monitor eval progress | cua-driver screenshot (PPAPI counter lies) |
