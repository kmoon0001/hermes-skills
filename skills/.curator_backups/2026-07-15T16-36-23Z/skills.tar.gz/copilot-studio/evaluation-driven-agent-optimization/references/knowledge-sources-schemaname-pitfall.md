# knowledgeSources Schemaname Verification + Dataverse Query Pitfalls (July 2026)

## The Pitfall: Removing knowledgeSources Because You Think They're Ghosts

When debugging low eval scores, it's tempting to remove `knowledgeSources` blocks from topics thinking the referenced schemanames are stale. **Do NOT remove them without verifying first.** The schemanames may match perfectly — the issue is your Dataverse query is paginated or using the wrong type filter.

## How We Got It Wrong

1. Queried Dataverse with `$top=70` and keyword filter → missed most knowledge sources
2. Saw only 4 of 8 expected knowledge sources → assumed the references were ghosts
3. Removed `knowledgeSources` from all 6 audit topics → scores went from 16% → 0-4%
4. The `applyModelKnowledgeSetting: true` alone does NOT search KB effectively
5. The explicit `knowledgeSources` block IS what makes `SearchAndSummarizeContent` work

## Correct Dataverse Knowledge Source Query

```python
# QUERY WITH TYPE FILTER, NOT KEYWORD FILTER
url = f"{org}/api/data/v9.2/botcomponents?$select=name,schemaname,componenttype&$filter=_parentbotid_value eq '{bot_id}' and (componenttype eq 14 or componenttype eq 16)&$top=20"
```

Type mapping:
- **Type 14** = File knowledge sources (PDFs, documents)
- **Type 16** = Reference knowledge sources (topic-linked references)
- **Type 19** = Evaluation test cases (NOT knowledge sources)

## Schemaname Verification

Topic YAMLs reference KB sources via schemanames like:
```yaml
knowledgeSources:
  kind: SearchSpecificKnowledgeSources
  knowledgeSources:
    - cr53f_TherapyDocumentationFeedbackB.topic.Habit1QuickReferencepdf_zLMH1UrCPRTmgTT3YdC2m
```

The schemaname in the topic MUST match the `schemaname` field of the botcomponent in Dataverse. Verify:
```python
# Read topic knowledgeSources
topic_kb_refs = [line.strip('- ') for line in topic_yaml if 'cr53f_' in line]

# Read actual KB source schemanames
for source in dataverse_kb_sources:
    schema = source['schemaname']
    if schema in topic_kb_refs:
        print(f"MATCH: {schema[:60]}")
    else:
        print(f"MISSING from topics: {schema[:60]}")
```

## Fix: Restore knowledgeSources (NOT Remove)

If schemanames match (they usually do if the KB was uploaded through Copilot Studio UI):
1. **Keep** `knowledgeSources` block with all schemaname references
2. **Remove** only `fileSearchDataSource` (the file-level search scope is too narrow)
3. **Keep** `applyModelKnowledgeSetting: true`

## Optimal Topic YAML Structure

```yaml
- kind: SearchAndSummarizeContent
  id: search_discharge_audit
  userInput: =System.Activity.Text
  additionalInstructions: |-
    Audit this discharge summary for [specific criteria].
    Use 2-3 concise bullets with inline citations.
  # REMOVED: fileSearchDataSource (too narrow)
  knowledgeSources:
    kind: SearchSpecificKnowledgeSources
    knowledgeSources:
      - cr53f_...Habit1...
      - cr53f_...Habit2...
      # ... all matching schemanames
  applyModelKnowledgeSetting: true
- kind: EndDialog
  id: end-topic
  clearTopicQueue: true
```

## Evidence

**Therapy Documentation Feedback Agent (July 2026):**
- All 13 knowledge sources existed in Dataverse with matching schemanames
- Query was using `$top=70` + keyword filter → missed 9 sources
- Removed knowledgeSources → 0-4% on KB-aligned test
- Restored knowledgeSources → **83%** on same test set
- Score jump: 4% → 83% (79-point improvement from this single fix)

## Dataverse Query Checklist

Before claiming KB sources are missing:
- [ ] Use explicit `componenttype eq 14 or componenttype eq 16` filter
- [ ] Use `$top=20` or higher (KB sources are listed before eval cases)
- [ ] Check schemaname mapping: topic reference → Dataverse schemaname
- [ ] Verify ALL topic knowledgeSources have matching components
