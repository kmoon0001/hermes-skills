# PPAPI Token Capture via CDP WebSocket

When the standard MSAL interactive OAuth flow fails with `AADSTS50011: redirect URI mismatch`, use Chrome DevTools Protocol (CDP) to capture the PPAPI Bearer token from the user's already-authenticated browser session.

## Why MSAL Interactive Fails

The Copilot Studio eval-api uses MSAL Node with a loopback server on a random port (`http://localhost:<random>`). The Azure app registration for client `96ff4394-9197-43aa-b393-6a41652e21f8` does not have `http://localhost` (without port) registered as a valid redirect URI. The dynamic port approach requires exact port matching which won't work unless every possible port is registered.

**Fix options:**
1. **Azure admin** — Add `http://localhost` to app registration redirect URIs (permanent fix, requires portal access)
2. **CDP capture** — Extract token from authenticated browser session (works immediately, no portal access needed)
3. **Device code** — May be blocked by tenant Conditional Access policy

## CDP Token Capture (Option 2)

### Prerequisites
```powershell
# Edge with remote debugging on port 9223
$args = '--remote-debugging-port=9223','--remote-allow-origins=*','--no-first-run','--user-data-dir=C:\Users\<user>\AppData\Local\Microsoft\Edge\User Data'
Start-Process 'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe' -ArgumentList $args
```

The `--user-data-dir` MUST point to the ORIGINAL Edge profile to preserve auth cookies. Using a fresh profile forces re-login.

### Capture Script (`cdp_simple.cjs`)

```javascript
const { chromium } = require('playwright-core');
const fs = require('fs');
const http = require('http');

const TOKEN_FILE = `${process.env.USERPROFILE}/.copilot-studio-cli/test-agent-token.txt`;

(async () => {
  // Find eval tab by URL pattern (NEVER hardcode tab IDs — they change on navigation)
  const pages = await new Promise(r => {
    http.get('http://127.0.0.1:9223/json/list', res => {
      let d='';res.on('data',c=>d+=c);res.on('end',()=>r(JSON.parse(d)));
    }).on('error', console.error);
  });
  
  const target = pages.find(p => p.url.includes('/evaluation'));
  if (!target) { /* Create via Target.createTarget, retry after 10s */ }

  const ws = new WebSocket(target.webSocketDebuggerUrl);
  let token = null;

  ws.on('message', raw => {
    const msg = JSON.parse(raw.toString());
    if (msg.method === 'Fetch.requestPaused' && !token) {
      const auth = msg.params.request.headers['Authorization'];
      if (auth && auth.startsWith('Bearer ')) {
        token = auth.replace(/^Bearer\s+/i, '');
        fs.writeFileSync(TOKEN_FILE, token);
        process.exit(0);
      }
      ws.send(JSON.stringify({id:9999, method:'Fetch.continueRequest', params:{requestId: msg.params.requestId}}));
    }
  });

  ws.on('open', () => {
    ws.send(JSON.stringify({id:1, method:'Fetch.enable', params:{patterns:[{urlPattern:'*'}]}}));
    ws.send(JSON.stringify({id:2, method:'Page.reload'}));
  });
})();
```

### Token Usage
```bash
token=$(cat "$USERPROFILE/.copilot-studio-cli/test-agent-token.txt")
curl -H "Authorization: Bearer $token" "https://api.powerplatform.com/copilotstudio/environments/..."
```

### Pitfalls

1. **Tab ID changes on navigation** — Always search by URL pattern. Never hardcode `AEF6788D...` style IDs.
2. **CDP connection exhaustion** — Close pages after each script. Accumulated connections cause `connectOverCDP` to hang.
3. **Edge vs Chrome** — User may use Edge (`msedge.exe`), not Chrome. Edge user data at `%LOCALAPPDATA%\Microsoft\Edge\User Data`.
4. **Token expiry** — PPAPI tokens last ~60 minutes. Re-capture when receiving 401.
5. **PowerShell quoting** — Node scripts via PowerShell need forward-slash paths: `node 'D:/path/script.cjs'`
