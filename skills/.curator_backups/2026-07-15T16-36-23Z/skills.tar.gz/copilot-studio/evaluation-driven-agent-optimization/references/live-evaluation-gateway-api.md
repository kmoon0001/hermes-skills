# Live Copilot Studio Evaluation Gateway API Notes

Use this when UI eval pages are slow or when multiple agents must be evaluated in a sweep.

## Auth/header capture pattern

1. Open the Copilot Studio Evaluation page in the already-authenticated browser.
2. Capture a request to the PowerVA gateway under:
   `https://powervamg.<region>.gateway.prod.island.powerapps.com/api/botmanagement/v2/environments/<envId>/bots/<botId>/makerevaluations...`
3. Reuse the SPA request headers for direct API calls. Important headers include:
   - `authorization`
   - `x-cci-tenantid`
   - `x-cci-bapenvironmentid`
   - `x-cci-organizationid`
   - `x-cci-cdsbotid`
   - `x-cci-botid`
   - `x-ms-client-session-id`
   - `x-ms-client-request-id` (generate a fresh UUID per call)
   - `x-ms-user-agent`
   - `x-cci-applicationsource`
   - `referer`

Raw cookies alone are not enough; missing `x-cci-*` routing headers commonly produces 400 responses.

## Useful endpoints

Base:
`{gateway}/api/botmanagement/v2/environments/{envId}/bots/{botId}`

List current runs:
`GET /makerevaluations?count=10`

Start a run:
`POST /makerevaluations`

Body:
```json
{
  "testSetId": "<testSetId>",
  "clientRequestedEvaluationRunName": "Evaluate <label> <timestamp>"
}
```

Fetch full run details:
`GET /makerevaluations/{runId}/details`

List test sets:
`GET /makerevaluations/testsets`

The test-set response may be nested under `testComponents`; current usable fields include:
- `component.id` = testSetId
- `evaluationSetType` = `SingleTurn` or `MultiTurn`
- `numberOfTestCases`
- `component.version`
- `component.auditInfo.createdTimeUtc`

## Rate limit behavior

Two separate quotas exist:

### Active-run limit (per agent)
One active evaluation run per agent. Different agents can have active runs simultaneously. If a second run is started for the same agent before the first completes, the API returns 422:

`fairusagepolicy.botactiverunquotaviolated`

Message:
`A test is already running for this agent. After it finishes, you can start another test.`

### Daily run limit (per agent)
20 runs per agent per 24-hour rolling window. When exceeded, the API returns 422:

`fairusagepolicy.botrunquotaviolated`

Message:
`The agent has been evaluated more than 20 times in the last 24 hours. Please wait before trying again.`

The window is rolling: each run drops off 24h after its `startTime`. To check how many runs remain, list recent runs and count those with `startTime` within the last 24h.

### Cancel an active run
```
PATCH /makerevaluations/{runId}/cancel
Body: { "evaluationRunId": "<runId>" }
```
Returns the updated run object with `state: "Cancelled"`. Useful when a run is stuck or you need to free the active-run slot immediately. A cancelled run still counts toward the daily 20-run quota.

### Workflow consequence
- Start SR/Conv for different agents in parallel when useful.
- For each individual agent, run SR then Conv (or Conv then SR) sequentially.
- After one agent's active run completes, immediately launch that agent's counterpart even if other agents are still running.
- Track run count per agent per 24h window; stop launching and record handoff when approaching 20.

## Details JSON parsing pitfall

Full details are shaped like:

```text
root
  aggregatedGraderResults[]
  details.testCases[]
    executionState
    order
    queries[]
      query
      answer
      queryResponseMetrics[]
```

Use `aggregatedGraderResults` for run totals:
- `totalSucceeded`
- `totalFailed`
- `totalInvalid`
- `totalErrors`

Do not infer failures by scanning metric properties for strings like `abstention: No`, `relevance: Yes`, `completeness: Yes`, or `groundedness: Yes`. Those are usually passing signals. Use each metric/test case `evaluationResult` plus `executionState` and `errorCodes`.

Hard failure signal:
- `executionState: ExecutionFailed`
- `unsupportedactivity.notextresponse`

## Current parser guidance

A reliable parser should:
1. Read `aggregatedGraderResults` for the score table.
2. Iterate `details.testCases`.
3. Mark a case bad only when the case or one of its query metrics has a failed/invalid/error evaluation result, or when `executionState` is not evaluated/succeeded.
4. Extract root-cause dimensions from failing metric explanations, not from all metric properties.
5. Preserve the user query and agent answer for only failing cases.