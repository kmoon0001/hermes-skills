# Surgical vs Full YAML Replacement

## The Regression
When fixing 800-char limits in Copilot Studio topic YAMLs, applying the ENTIRE YAML from an old template export caused scores to REGRESS from 94% down to 87-88% across OT and PT agents.

## Root Cause
The fix YAML files were generated from an older `pac copilot extract-template` export. When injected via Monaco's `setValue()`, they replaced the ENTIRE topic YAML — not just the `additionalInstructions` field. This removed post-export optimizations that had been made directly in the Copilot Studio UI:
- Updated trigger queries (added since template export)
- Model description hints (`modelDescription` field)
- Intent refinements
- Other per-topic tuning accumulated over weeks of optimization

## The Correct Approach: Surgical Line Removal

Do NOT replace the entire YAML. Only remove the specific offending line.

### Step-by-step:
1. Read the CURRENT topic YAML from Monaco DOM (not from a file)
2. Find the line containing `Keep response under 800 characters`
3. Delete ONLY that line
4. Optionally add `Be concise but complete. Prioritize accuracy over strict length limits.`
5. Inject the surgically modified YAML
6. Trigger React dirty state (view-line click + keyboard type) and Save

### Code pattern:
```javascript
// Read current YAML lines from Monaco DOM (not from old template file)
const lines = await page.evaluate(() => 
  Array.from(document.querySelectorAll('.monaco-editor .view-lines .view-line'))
    .map(l => l.textContent));

// Surgical: remove only lines containing "800"
const filtered = lines.filter(l => !/8[^a-zA-Z0-9]*0[^a-zA-Z0-9]*0/i.test(l));

// Only proceed if something changed
if (filtered.length === lines.length) return; // nothing to fix

// Inject the surgically modified YAML back
const newYaml = filtered.join('\n');
// (Proceed with injection + view-line click + keyboard type + Save)
```

## Why This Matters
- A full YAML replacement with old template versions can undo WEEKS of optimizations
- The 94% baseline included the 800-char limits STILL in place — meaning the guard topic activation was the primary improvement, not the 800-char removal
- Removing the limit surgically from the 94%-baseline topics should push from 94% → 95%+

## Evidence
- OT SR: 86% → 94% (guard activation + republish, 800-char still present)
- OT SR after full YAML replacement: 94% → 87% (lost optimizations)
- PT SR: 86% → 94% (same pattern, then regressed to 87-88%)
