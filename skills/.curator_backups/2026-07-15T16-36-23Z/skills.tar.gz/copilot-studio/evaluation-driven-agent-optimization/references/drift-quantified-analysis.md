# Quantified Drift Analysis — SLP, PT, TDA, OT

Source: 100 eval runs per agent scraped from Copilot Studio evaluation page, June 18 2026.
Environment: `Default-03cc92c3-986c-4cf4-ae27-1478cf99d17f`
Model: GPT-5 Chat (non-deterministic)

## Full Statistics

### PT (PT_Specialist)
- **Conversation** (53 runs): min 0%, max 100%, avg 83.5%, range 100%
- **Single Response** (47 runs): min 34%, max 99%, avg 87.2%, range 65%
- Instruction version: hybrid (60 lines, conditional RESPONSE FORMAT)
- Worst outlier: 0% (conversation), 21% (conversation), 34% (single response)
- Consecutive same-day swings: 95% → 82% (28 min gap, same instructions)

### SLP (SLP_Specialist)
- **Conversation** (56 runs): min 35%, max 100%, avg 85.9%, range 65%
- **Single Response** (44 runs): min 35%, max 100%, avg 88.3%, range 65%
- Instruction version: hybrid (59 lines, unconditional RESPONSE FORMAT)
- Worst outlier: 35% (both types)

### TDA (Therapy Documentation Audit Agent)
- **Conversation** (47 runs): min 35%, max 100%, avg 86.4%, range 65%
- **Single Response** (53 runs): min 73%, max 100%, avg 92.5%, range 27%
- Instruction version: fixed (28 lines, routing only, no RESPONSE FORMAT)
- **Most stable single-response scores** — simplest instructions

### OT (OT_Specialist) — for comparison
- **Conversation** (62 runs): min 5%, max 100%, avg 68.0%, range 95%
- **Single Response** (36 runs): min 56%, max 100%, avg 90.8%, range 44%
- Instruction version: established (unconditional RESPONSE FORMAT)
- **Worst conversation stability** despite best single-response ecosystem
- Recent conversation collapse: 100% → 5% → 5% → 15% → 10% (consecutive runs)

## Root Cause Layers

### Layer 1: Response Generation Non-Determinism
GPT-5 Chat uses stochastic sampling. Same prompt + same config → different output each time. This creates a ~5-10% variance floor that no instruction change can eliminate.

### Layer 2: Grader Non-Determinism
Copilot Studio's "General quality" evaluator is also an LLM. It evaluates 4 criteria (Relevance, Groundedness, Completeness, Abstention) with its own sampling variance. Borderline answers flip between pass/fail depending on grader mood.

**Compounding effect**: If response variance is ±5% and grader variance is ±5%, combined variance is ±7-10%. A "true 90%" agent scores anywhere from 80% to 100% on any given run.

### Layer 3: Conversation Context Accumulation
Multi-turn tests amplify errors: a non-deterministic turn 1 becomes turn 2's context, which compounds into turn 3. Single-response tests have zero accumulation.

**Quantified**: PT single-response range = 65%, conversation range = 100%. TDA single-response range = 27%, conversation range = 65%. The gap is the "context tax."

### Layer 4: Instruction Complexity as Variance Amplifier
Each instruction is a coin flip — the model might follow it or randomly skip it. More instructions = more coins = more variance.

| Agent | Lines | Conditional Logic? | SR Range | Conv Range |
|-------|-------|--------------------|----------|------------|
| TDA | 28 | No | 27% | 65% |
| SLP | 59 | No (unconditional) | 65% | 65% |
| PT | 60 | Yes (document-only format) | 65% | 100% |

PT's conditional format logic ("use RESPONSE FORMAT for document questions only") adds a branching decision the model must make correctly on every turn. Each wrong decision costs 1-2 test case points.

### Layer 5: Test Case Count Noise
Small test sets amplify variance:

| Run Size | PT Example Score | Reliability |
|----------|-----------------|-------------|
| 10 cases | 70% | Very noisy — 3 failures = 70% |
| 20 cases | 55%-100% | Noisy — 1 failure = 5% penalty |
| 100 cases | 82%-97% | Reliable — enough signal |

A single failed case on a 20-case set = 5% penalty. On a 100-case set = 1% penalty. Only 100-case runs are meaningful for trend analysis.

## What OT Does Differently

OT's 99% single-response comes from its ECOSYSTEM, not its instructions:
- 0 guard topics (no topic-level interference)
- 8 knowledge sources (rich grounding reduces hallucination)
- 5 purpose-built audit topics (direct test case matching)
- Topic-level additionalInstructions do the heavy lifting

**Proof**: Copying OT's instruction structure to SLP caused 90%→75% regression. The portable elements are behavioral patterns only:
- Ban weak phrases ("best-effort", "preliminary", "verification is limited")
- Single-response: always use RESPONSE FORMAT
- Conversation: adapt format per turn
- Conciseness (2-3 sentence limit per section)

## Practical Recommendations

1. **Use median of 5+ runs** as the "true score" for any optimization decision
2. **Use 100-case test sets only** for trend analysis (ignore 10/20-case noise)
3. **Don't chase single-run dips** below 85% — they're likely noise
4. **Focus on ecosystem** (knowledge sources, topics, topic-level instructions) rather than agent-level instruction tweaks past ~90%
5. **Simpler instructions = more stable scores** — every line added is a variance source
6. **PT's conditional format is a necessary evil** — unconditional drops avg from 94%→82% but reduces variance. Choose based on whether you optimize for ceiling or stability.
7. **TDA should stay minimal** — it's the most stable agent because it has the simplest instructions. Don't add RESPONSE FORMAT (drops 94%→92%).
