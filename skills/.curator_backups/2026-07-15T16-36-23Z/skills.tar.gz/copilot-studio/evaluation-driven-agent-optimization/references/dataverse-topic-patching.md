# Dataverse API Topic Patching Techniques

## PATCH `data` field: WORKS (HTTP 204)

```python
patch_url = f'{org}/api/data/v9.2/botcomponents({topic_id})'
body = json.dumps({'data': new_yaml_content})
req = urllib.request.Request(patch_url, method='PATCH')
req.add_header('Authorization', f'Bearer {dv_token}')
req.add_header('Content-Type', 'application/json')
req.add_header('OData-MaxVersion', '4.0')
req.add_header('OData-Version', '4.0')
req.data = body.encode()
```

**Success pattern:** When replacing `data` field on existing topics, the PATCH consistently returns 204. This works for GPT instructions (componenttype 15) and topics (componenttype 9).

## PATCH `content` field: FAILS (HTTP 400)

```
"Unexpected character encountered while parsing value: k. Path '', line 0, position 0."
```

The Dataverse API tries to parse YAML as JSON. The `data` field works; `content` does not.

## PATCH `statecode`: WORKS (HTTP 204)

```python
body = json.dumps({'statecode': 0})  # 0=active, 1=inactive
```

Use for batch topic activation/deactivation without touching YAML content.

## Batch Topic Editing Pattern

```python
# Read original YAML from local files (extracted via PAC or stored during audit)
# Apply surgical fixes (removing specific blocks, adding fields)
# PATCH each topic's data field via Dataverse API
# Publish via pac copilot publish --bot {id}
```

## Token Acquisition for Dataverse API

```bash
az account get-access-token --resource "https://org532ca94a.crm.dynamics.com" --query accessToken -o tsv > dv_token.txt
```

The PPAPI token does NOT work for Dataverse. Use `az cli` for Dataverse scope.
