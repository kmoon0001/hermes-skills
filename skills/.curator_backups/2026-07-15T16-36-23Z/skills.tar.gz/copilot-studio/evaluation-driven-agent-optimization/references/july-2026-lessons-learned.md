# July 2026 — Therapy Documentation Feedback Agent Audit Lessons

## Learning 1: Conversation Start Question-Node Trap

`OnConversationStart` topics with `kind: Question` nodes block ALL single-response eval.
The agent's first response is "What can I help you with today?" — grader sees Abstention=Yes.

**Detection:** Query Dataverse for `componenttype eq 9, statecode eq 0`, parse `data` for `kind: OnConversationStart` AND `kind: Question` in the same topic.

**Fix:** Replace with `SendActivity` + `EndDialog`, or deactivate via `PATCH statecode: 1`.

**Evidence:** Therapy Documentation Feedback Agent scored 16-22% until Conversation Start was deactivated. Exact same pattern on another agent (QM Coach V2) where DoR Summary had 3 Question nodes → SR 95%→12%.

## Learning 2: Regex Greedy Removal Destroys Adjacent YAML Blocks

When removing `fileSearchDataSource` blocks via regex, adjacent blocks at the same indentation level (like `knowledgeSources` and `applyModelKnowledgeSetting`) get removed too.

**Broken:** `re.sub(r'\n\s*fileSearchDataSource:\s*\n(?:\s+[^\n]*\n)*', '\n', yaml)`
**Fixed:** Line-by-line skip logic checking indentation depth.

**Evidence:** Score dropped from 22% to 4% after regex removed KB references. Restored from original YAML files using surgical line-by-line removal.

## Learning 3: Ghost Knowledge Source References

Topics may reference `SearchSpecificKnowledgeSources` that don't exist in Dataverse (componenttype 14/16).
Only 4 of 8 referenced KB sources existed, causing KB search to return nothing.

**Fix:** Query `componenttype in (14, 16)` and cross-reference schemanames with topic references. Remove missing references or rely on `applyModelKnowledgeSetting: true` instead.

## Learning 4: Dataverse API — PATCH `data` Field Works

Unlike `content` field (returns HTTP 400), the `data` field on `botcomponents` accepts YAML PATCH.
This works for topics (componenttype 9) and GPT instructions (componenttype 15).

## Learning 5: PPAPI Token Capture via CDP WebSocket

When MSAL localhost redirect fails (URI mismatch AADSTS50011), capture the Bearer token from the browser's existing Copilot Studio session via raw CDP WebSocket.

**Script pattern:** See `copilot-studio-run-eval` skill → `scripts/cdp-token-capture.cjs`

## Learning 6: PAC Publish "Failed" Display Bug

PAC CLI v2.7.4 displays "Failed to publish" but the logs show `PublishOutput` with success.
Always check PAC logs at `~/.dotnet/tools/.store/microsoft.powerapps.cli.tool/2.7.4/.../logs/pac-log.txt` for the actual publish result.

## Learning 7: applyModelKnowledgeSetting: true is Critical

When topics have `SearchAndSummarizeContent` without explicit `knowledgeSources` block,
`applyModelKnowledgeSetting: true` must be set for the node to search all available KB sources.
Without it, `SearchAndSummarizeContent` searches nothing and returns empty.
