# Topic Flow Audit — Pre-YAML Diagnostic

**Do this BEFORE any YAML, instruction, or eval analysis.** When eval scores are stuck at 0-22% across ALL test sets, the root cause is almost always a topic-level flow blocker.

## The Flow Audit Pattern

1. **Extract ALL active topic YAMLs** via Dataverse API (`componenttype eq 9 and statecode eq 0`)
2. **Trace the conversation flow** from the very first topic that fires
3. **Classify every topic** by trigger type: ConvStart, Intent, Unknown
4. **For EVERY topic, check:**
   - `kind: Question` nodes → these ask questions instead of answering → SR eval FAILS
   - Missing `EndDialog` → topic runs but produces no output → silent failure
   - `CancelAllDialogs` → cancels everything without answering → eval sees no response
   - `BeginDialog` references → verify the target exists and is clean
5. **Map the full flow path** for each query type
6. **Identify the EXACT topic** that blocks or silently exits

## Common Flow Blockers

| Pattern | Symptom | Fix |
|---------|---------|-----|
| ConvStart with Question nodes | Every conversation asks a question instead of answering | Deactivate or replace Question with SendActivity + EndDialog |
| Greeting with Question nodes | Same as above for greeting-triggered conversations | Same fix |
| Catch-all OnUnknownIntent with SearchAndSummarizeContent but no fallback | When KB returns nothing, topic exits silently → 0% | Add elseActions with SendActivity fallback |
| CancelAllDialogs in Reset/Error topics | Conversation cancelled without answer | Replace with EndDialog + clearTopicQueue |
| Missing EndDialog in system topics | Topic fires but no output closure | Add EndDialog at end |
| Multiple Topics Matched with Question | Asks user to pick → eval sees question | Replace with SendActivity + EndDialog |

## Dataverse API Patching

The `data` field patches successfully (HTTP 204) for both topics (componenttype 9) and GPT instructions (componenttype 15):

```python
patch_url = f'{org}/api/data/v9.2/botcomponents({tid})'
body = json.dumps({'data': corrected_yaml})
req = urllib.request.Request(patch_url, method='PATCH')
req.add_header('Authorization', f'Bearer {dv_token}')
req.add_header('Content-Type', 'application/json')
req.add_header('OData-MaxVersion', '4.0')
req.add_header('OData-Version', '4.0')
req.data = body.encode()
```

## Regex Pitfall

Removing one YAML block (e.g., `fileSearchDataSource`) can inadvertently remove adjacent blocks (e.g., `knowledgeSources`) if the regex is greedy. Always use line-by-line skip logic:

```python
lines = yaml.split('\n')
skip = False
for line in lines:
    if 'fileSearchDataSource:' in line:
        skip = True
        continue
    if skip:
        if line.startswith('      ') or line.startswith('        '):
            continue
        skip = False
        new_lines.append(line)
    else:
        new_lines.append(line)
```

## Ghost KB References

Topics often reference knowledge sources that don't exist in Dataverse. Query all KB components first:
```python
# Check what exists
filter_val = "_parentbotid_value eq '{botId}' and componenttype in (14, 16)"
```
Only 4 of 8 referenced KB sources existed for Therapy Documentation Feedback Agent. Missing sources cause SearchAndSummarizeContent to return nothing.

## Evidence (Therapy Documentation Feedback Agent, Jul 2026)

- 11 topics had Question nodes, missing EndDialog, or CancelAllDialogs blocking the flow
- After fixing all 11: score jumped from 4-22% → 50% on 20-case conversation set
- The catch-all topic had no fallback when KB returned nothing → silent exit → 0% SR
- Conversation Start deactivation alone wasn't enough — 10 other topics needed fixes
