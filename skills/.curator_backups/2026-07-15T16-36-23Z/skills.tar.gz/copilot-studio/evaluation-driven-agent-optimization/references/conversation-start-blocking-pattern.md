# Conversation Start / Greeting Question-Node Blocking Pattern

**Discovered:** July 1, 2026 — Therapy Documentation Feedback Agent (Prod)

## The Pattern

`OnConversationStart` topics and `OnRecognizedIntent` system topics (Greeting, Goodbye, etc.) with `kind: Question` nodes intercept every new conversation and block single-response evaluation.

### How It Breaks SR Eval

1. Each SR eval test case starts a NEW conversation
2. `Conversation Start` fires first (`OnConversationStart`)
3. The `Question` node asks "What can I help you with today?" with `ClosedListEntity` options
4. The eval test question is processed as a response to this Question
5. The user's actual question doesn't match any `ClosedListEntity` option
6. Falls through to "Other" → "I'm sorry, no other options are currently implemented"
7. Loops back to the first Question
8. Grader sees the Question/error as the agent's response → Abstention=Yes

### Topics Affected (verified Jul 2026)

| Topic | Type | Defect |
|-------|------|--------|
| Conversation Start | OnConversationStart + Question nodes | Blocks ALL conversations |
| Greeting | OnRecognizedIntent + Question nodes | Blocks "Hello"/"Hi" queries |
| Goodbye | OnRecognizedIntent + Question | Returns question instead of goodbye |
| Multiple Topics Matched | Question nodes | Returns question when topics conflict |
| End of Conversation | Question nodes | Returns question instead of ending |

### Fix

1. **Deactivate Conversation Start** entirely (PATCH statecode: 1 via Dataverse)
2. **Rewrite system topics** to use `SendActivity` → `EndDialog` instead of `Question` nodes
3. **Ensure catch-all** (Conversational boosting, OnUnknownIntent) has proper fallback

### Before/After (Therapy Documentation Feedback Agent)

- **Before:** 16-22% SR (84% abstention) — all system topics intact
- **After deactivating Conversation Start + fixing 8 system topics:** 50% on 20-case conversation eval

### Verification Script

```python
# Check for Question nodes in system topics
import re
for topic in active_topics:
    data = topic['data']
    name = topic['name']
    if 'kind: Question' in data:
        print(f'BLOCKING: {name} has Question nodes')
```
