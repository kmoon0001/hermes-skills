# Topic Cleanup Before Instruction Fixes (QM Coach V2, June 19 2026)

## Key Insight

When an agent has many topics (30+), **topic-level issues cause 90%+ of eval failures**, NOT instruction problems. Cleaning up topics FIRST avoids wasted instruction changes.

## QM Coach V2 Evidence

- Agent had 62 topics, 71% eval score
- After analysis, categorized failures:
  - 20 failures (69%) = Interactive menu topics returning cards, not text
  - 7 failures (24%) = System errors (broken action nodes)  
  - 2 failures (7%) = Misrouted to greeting (wrong triggers)
- Instruction cleanup (removing CRITICAL/NEVER, consolidating) had ZERO effect on score

## The Sequence That Works

When eval < 90%, run this diagnostic BEFORE touching instructions:

```
1. Count topics via Dataverse API
2. Extract topic YAMLs
3. Classify topics:
   - Stubs (< 300 chars, "under development")
   - Duplicates (same function, overlapping triggers)  
   - Broken (0 chars, wrong kind, bad refs)
   - Interactive menus (designed as wizards)
4. Delete stubs/duplicate/broken topics
5. Publish and re-eval
6. ONLY THEN fix remaining topic YAMLs or instructions
```

## Topic Cleanup Impact

QM Coach V2: 62 topics -> 31 topics deleted -> 95% eval

Deleting topics improves eval scores by:
- Removing stub responses that give unhelpful answers
- Eliminating routing confusion from duplicate topics
- Reducing the pool to fewer, cleaner responses
- Letting the agent fall back to knowledge-based answers

## Warning: Conversation Eval Breakage

After deleting topics, conversation evals often break because test cases reference deleted topics.

**Symptom:** Single-response eval works, conversation eval returns 0% "Error" on ALL cases. Agent response is "--" (empty).

**Root cause:** Conversation test cases ask questions that routed to deleted topics.

**Fix:**
1. Republish the agent (re-indexes topic list)
2. Check remaining topics for references to deleted names
3. Add alternative trigger phrases to remaining topics to cover deleted-topic gaps
4. Re-run conversation eval

## Preference: Text-First Topic Structure

For topics that may be interactive, structure as:

```yaml
actions:
  - kind: SendActivity
    id: text_answer
    activity: |
      [Direct text answer to the question]
      Would you like to walk through this interactively?
      
  - kind: Question  # optional follow-up
    # interactive flow continues here
    
  - kind: EndDialog
    id: end_topic
    clearTopicQueue: true
```

This satisfies both evals (text first) and real users (optional guided workflow).