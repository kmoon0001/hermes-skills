# Knowledge Source Schemaname Verification & Recovery

## Critical Discovery (July 2026)

When topic YAML `knowledgeSources` blocks are removed, the agent scores 0-4% even when ALL KB sources are present and `applyModelKnowledgeSetting: true` is set. **Explicit knowledgeSources references are REQUIRED** for `SearchAndSummarizeContent` to find KB content.

## Verification Workflow

### 1. Query KB sources from Dataverse

```javascript
// Get ALL KB source schemanames (types 14 and 16)
const filter = `_parentbotid_value eq '${botId}' and (componenttype eq 14 or componenttype eq 16)`;
const url = `/api/data/v9.2/botcomponents?$select=name,schemaname,componenttype&$filter=${encodeURIComponent(filter)}&$top=20`;
```

**Important:** Use type filter explicitly — KB sources (14/16) appear after evaluation cases (19) in unfiltered results.

### 2. Verify topic YAML references match schemanames

```python
topic_refs = re.findall(r'knowledgeSources:\n\s+- (\S+)', topic_yaml)
for ref in topic_refs:
    if ref not in dv_schemanames:
        print(f"MISMATCH: {ref}")
```

### 3. NEVER blindly remove knowledgeSources

Before removing `knowledgeSources` blocks, verify the schemanames are actually stale. If they match Dataverse, they MUST be kept. Removing valid references drops scores to 0-4%.

## Dataverse Pagination Pitfall

When querying without type filter, KB sources are buried under type-19 evaluation cases. Always add `$filter=componenttype eq 14 or componenttype eq 16`.

## Greedy Regex Pitfall

When surgically removing `fileSearchDataSource` blocks:

```python
# WRONG — greedy regex eats adjacent knowledgeSources:
re.sub(r'fileSearchDataSource:.*?(?=knowledgeSources:)', '', yaml, re.DOTALL)

# RIGHT — line-by-line:
lines = yaml.split('\n')
new_lines = []
skip = False
for line in lines:
    if 'fileSearchDataSource:' in line:
        skip = True; continue
    if skip:
        if line.strip().startswith('knowledgeSources:') or line.strip().startswith('- kind: EndDialog'):
            skip = False; new_lines.append(line)
        elif line.startswith('      ') or line.startswith('        '):
            continue
        else:
            skip = False; new_lines.append(line)
    else:
        new_lines.append(line)
```

## applyModelKnowledgeSetting Alone is Insufficient

The `applyModelKnowledgeSetting: true` flag on SearchAndSummarizeContent is NOT enough to enable KB search. Topics need explicit `knowledgeSources:` blocks with valid schemanames.
