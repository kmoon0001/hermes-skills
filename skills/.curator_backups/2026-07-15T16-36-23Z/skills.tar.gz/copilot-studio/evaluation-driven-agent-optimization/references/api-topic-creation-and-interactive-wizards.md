# API Topic Creation & Interactive Wizard Failures

## Creating Topics via Dataverse API

When creating topics via the Dataverse API (POST to `botcomponents`), TWO fields must be set for the topic to be visible in the Copilot Studio UI:

1. **`content`** — Full YAML with AdaptiveDialog, triggerQueries, actions, EndDialog
2. **`data`** — Empty shell template (NOT the full YAML)

### Correct `data` field value (empty shell):
```
kind: AdaptiveDialog\r\nbeginDialog:\r\n  kind: OnRecognizedIntent\r\n  id: main\r\n  intent: {}\r\n\r\ninputType: {}\r\noutputType: {}
```

### Why:
- The `content` field is what the Copilot Studio engine uses for topic execution
- The `data` field is what the Copilot Studio UI reads for display and routing
- Setting `data` to the full YAML causes eval regression (95% → 12%) — the engine uses `data` for matching instead of `content`
- Setting `data` to null makes the topic invisible in the UI

### Required fields for API creation:
```javascript
{
  name: 'Topic Name',
  content: fullYaml,           // Full topic YAML
  data: emptyShellYaml,        // Empty shell template
  schemaname: 'cr917_agent.topic.TopicName',  // Must match pattern
  'parentbotid@odata.bind': '/bots(BOT_ID)'   // FK binding
}
```

### Post-creation fix (if data was set wrong):
```javascript
PATCH /api/data/v9.2/botcomponents({id})
{
  data: emptyShellYaml  // Set to empty shell, NOT full content
}
```

## Interactive Wizard Topics Break SR Eval

Topics designed as interactive wizards (asking multiple questions before answering) cause single-response eval failures. The eval expects a text answer; the wizard responds with a question.

### Detection pattern:
```python
# Check for Question nodes in topic content
has_question = "kind: Question" in content
has_adaptive_card = "kind: AdaptiveCardPrompt" in content
has_closed_list = "kind: ClosedListEntity" in content
```

### Example (DoR Summary — BROKEN):
```yaml
actions:
  - kind: Question        # Asks "Which facility?"
  - kind: AdaptiveCardPrompt  # Shows button card for audience
  - kind: Question        # Asks "Which focus?"
  - kind: SearchAndSummarizeContent  # Finally answers
  - kind: EndDialog
```

In SR eval, the agent responds with "Which facility should this DoR summary cover?" → FAILS.

### Example (Escalate QM Concern — CORRECT):
```yaml
actions:
  - kind: SendActivity    # Direct text answer with escalation matrix
  - kind: EndDialog
```

### Fix pattern:
Restructure interactive topics to:
1. Provide a direct text answer FIRST via `SendActivity`
2. Offer the interactive wizard as a follow-up option
3. End with `EndDialog`

```yaml
actions:
  - kind: SendActivity
    activity: |
      [Direct text answer with useful content]
      
      Would you like me to customize this further? I can ask a few questions to tailor the output.
  - kind: EndDialog
```

### Why this works:
- SR eval gets a text answer → PASSES
- Real users get useful content + option for guided workflow
- Conversation eval can continue with the wizard if user wants

## Anti-Pattern: Blaming the Platform

When eval scores drop:
1. **NEVER** assume it's a platform/model issue first
2. **ALWAYS** check topic content for Question nodes, missing EndDialog, interactive menus
3. **ALWAYS** check guard topics (HIPAA, Fallback, Error) for broken logic
4. **ALWAYS** check for inactive topics (statecode != 0)

The root cause is almost always topic-level, not platform-level. This pattern has been confirmed across PT, OT, SLP, TDA, and QM Coach V2 agents.
