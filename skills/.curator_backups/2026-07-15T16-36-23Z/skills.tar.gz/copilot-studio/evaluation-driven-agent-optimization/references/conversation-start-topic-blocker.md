# Conversation Start Topic — SR Eval Blocker

## Problem

When a Copilot Studio agent has a topic with `kind: OnConversationStart` containing
`Question` nodes, every single-response evaluation test case fails. The Conversation Start
fires at the beginning of EVERY new conversation and returns a question instead of an answer.

## Detection

Check Dataverse for topics with `OnConversationStart` trigger type:

```python
# Query active topics
filter_val = "_parentbotid_value eq '{botId}' and componenttype eq 9 and statecode eq 0"
# Look for 'OnConversationStart' in the data field
```

Also check `Greeting` topics — they often mirror the Conversation Start pattern with
`Question` nodes that return "What can I help you with today?"

## Flow Trace

```
SR eval test case sends question
  ↓
Conversation Start fires (OnConversationStart)
  ↓
Question node: "What can I help you with today?"
  ↓
Eval grader sees this question as the agent's response → FAIL (abstention)
  ↓
The actual test question is never processed by any audit topic
```

Even with `interruptionPolicy: allowInterruption: true`, the Question is the FIRST
response the grader sees.

## Fix

**Deactivate the Conversation Start topic** (set statecode=1 via Dataverse API PATCH).
Also remove Question nodes from Greeting, Goodbye, Multiple Topics Matched, Start Over,
and End of Conversation topics — replace with direct `SendActivity` + `EndDialog`.

## Evidence

Therapy Documentation Feedback Agent (June 2026):
- With Conversation Start active: 16% pass rate (84% abstention)
- With Conversation Start deactivated + topic flow fixes: 50% pass rate
- Further fixes pushed to 83%

Without deactivating Conversation Start, the conversation boosting catch-all topic
(OnUnknownIntent with SearchAndSummarizeContent) can NEVER fire because every turn
is consumed by the Conversation Start's question loop.
