# Regex-Greed YAML Patching Pitfall (July 2026)

When surgically removing `fileSearchDataSource` blocks from topic YAML, a greedy regex also removed adjacent `knowledgeSources` and `applyModelKnowledgeSetting` blocks.

**Broken** — `re.sub(r'\n\s*fileSearchDataSource:\s*\n(?:\s+[^\n]*\n)*', ...)` consumed everything indented including knowledgeSources.

**Fix** — line-by-line parsing with state tracking: skip only lines at fileSearchDataSource indentation, stop at shallower indentation.

**Detection** — always check `has_kb = 'knowledgeSources:' in fixed` after surgical YAML edits.

**Evidence**: Therapy Feedback Agent scored 0-4% for 15 runs after regex nuked its knowledgeSources. Restored via line-by-line → 83% on next run.