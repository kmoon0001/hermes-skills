# SearchSpecificFiles Restriction Pitfall

## Symptom
Agent consistently abstains (Abstention=Yes) on 80%+ of eval cases despite correct instructions and active knowledge sources. Pass rate is 16-20% regardless of instruction changes.

## Root Cause
Topics using `SearchAndSummarizeContent` with `fileSearchDataSource.searchFilesMode.kind: SearchSpecificFiles` lock the KB search to ONLY named files. If eval test cases reference content not contained in those specific files, the KB returns nothing → agent abstains per SOURCE RESTRICTION guardrails.

## Detection
Check topic YAMLs for:
```yaml
fileSearchDataSource:
  searchFilesMode:
    kind: SearchSpecificFiles
    files:
      - cr53f_...file.Ensign7HabitsDocumentationFramework.txt_...
      - cr53f_...file.MedicareBenefitsPolicyManualChapter15.pdf_...
```

If ALL audit topics use `SearchSpecificFiles` with the same file list, any test question outside those files' content will fail.

## Fix
Change to broader search:
```yaml
fileSearchDataSource:
  searchFilesMode:
    kind: SearchAllFiles
```

Or add parallel `knowledgeSources` with `SearchSpecificKnowledgeSources` for broader coverage:
```yaml
knowledgeSources:
  kind: SearchSpecificKnowledgeSources
  knowledgeSources:
    - cr53f_...Habit1QuickReferencepdf_...
    - cr53f_...Habit2QuickReferencepdf_...
    # ... all KB sources
```

## Evidence
Therapy Documentation Feedback Agent (Prod, July 2026): 6 audit topics all used `SearchSpecificFiles` with the same 5-file list. GPT guardrail relaxation from "if not in sources, explicitly state cannot determine" to "answer authoritatively using KB when no document provided" had zero impact (16%→16%). The real blocker was topic-level search restrictions, not instruction-level guardrails.

## Why Instruction Changes Alone Don't Work
`SearchAndSummarizeContent` with `SearchSpecificFiles` restricts what the KB engine SEARCHES, not just what the model REFERENCES. If the search returns nothing (because the question's content isn't in those specific files), the model never sees any KB content to ground its answer — regardless of what the GPT instructions say.

## Related Findings
- GPT guardrails (SOURCE RESTRICTION) can cause abstention, but topic-level search restrictions override them
- Always check topic YAML `fileSearchDataSource` before modifying instructions
- The `knowledgeSources` parallel block can supplement file-based search with broader KB access
