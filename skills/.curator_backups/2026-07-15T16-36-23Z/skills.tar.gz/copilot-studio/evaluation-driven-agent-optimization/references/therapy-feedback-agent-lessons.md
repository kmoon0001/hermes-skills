# Therapy Documentation Feedback Agent — Proven Patterns (July 2026)

## Agent Identity
- **Name:** Therapy Documentation Feedback Agent
- **Env:** Therapy AI Agents Prod (6951ccc2-3791-ecf4-987f-3dab97bdc716)
- **Bot ID:** 83b5b3a8-35fc-47be-9f4e-c3658ce605e5
- **Org URL:** https://org532ca94a.crm.dynamics.com/
- **PAC name:** Therapy AI Agents Prod
- **Connection ID:** 7067789c8cb841c59b2d3837e9c78987

## Score Progression (July 1, 2026)

```
Baseline: 16% (KB inaccessible — knowledgeSources block was nuked by regex)
Stage 1:   8%  (GPT guardrails relaxed + SearchSpecificFiles removed)
Stage 2:  22%  (Topic flow fixes: Question nodes removed, EndDialog added)
Stage 3:  30%  (Greeting/Goodbye/Thanks/MultipleTopics flow fixes)
Stage 4:  50%  (Conversational boosting fallback added)
Stage 5:  83%  (knowledgeSources RESTORED — all 13 KB sources matched)
Stage 6:  TBD  (Groundedness fix — additionalInstructions with citations)
```

## Critical Root Cause Patterns

### #1: knowledgeSources must be EXPLICITLY referenced
`applyModelKnowledgeSetting: true` alone does NOT enable KB search. The `knowledgeSources` block with specific schemanames is REQUIRED. Removing it (even with applyModelKnowledgeSetting on) drops scores to 0-4%.

### #2: Question nodes break SR eval
Any topic with `kind: Question` returns a question instead of an answer in single-response evaluation. Must convert to `SendActivity` + `EndDialog` or `SearchAndSummarizeContent` + `EndDialog`.

### #3: OnConversationStart blocks all other topics
Topics with `kind: OnConversationStart` fire before any intent-matching happens. If they contain Question nodes, every SR test case gets a question response. Deactivate or restructure.

### #4: Groundedness=No is the next frontier after abstention
When Abstention=No, Relevance=Yes, Completeness=Yes but Groundedness=No — the agent answers correctly but without KB citations. Fix: add `additionalInstructions` requiring inline citations from knowledge sources.

### #5: Conversational boosting (OnUnknownIntent) is the catch-all for unmatched queries
Without it, queries that don't match any topic trigger fall through to the GPT model which may not answer at all. Must include `additionalInstructions` for KB-grounded responses.

### #6: Dataverse PATCH works for `data` field, NOT `content` field
PATCHing `botcomponents(id)` with `{ content: yaml }` returns 400. PATCHing `{ data: yaml }` works (HTTP 204). Topics store their YAML in the `data` field.

### #7: Topic deactivation via statecode
```python
PATCH /api/data/v9.2/botcomponents({id})
Body: {"statecode": 1}  # 0=active, 1=inactive
```

### #8: PAC publish display is unreliable
PAC v2.7.4 reports "Failed" but the log shows success. Check publish timestamp in Copilot Studio UI to confirm.

## Tools That Work

### Token Capture (when Azure redirect URI is missing)
```
Edge CDP on port 9223 → Playwright page.on('request') → intercept ppapims.powerplatform.com
Script: D:/my agents copilot studio/pipeline/scripts/cdp_simple.cjs
Token: %USERPROFILE%\.copilot-studio-cli\test-agent-token.txt
```

### Desktop Vision (when PPAPI quota hit)
```
cua-driver MCP → get_desktop_state → vision_analyze screenshot → read eval results
Install: hermes computer-use install
Config: hermes config set mcp_servers.cua-driver.command ...
Start: C:\Users\kevin\Desktop\start_edge_cdp.ps1
```

### Eval API (when PPAPI works)
```
Base: https://api.powerplatform.com/copilotstudio/environments/{envId}/bots/{botId}/api/makerevaluation
Start run: POST /testsets/{id}/run
Get run: GET /testruns/{id}
Daily limit: 20 runs/24hr per agent
```

## Topic Inventory (Active)
| Topic | GUID | Type | Issue |
|-------|------|------|-------|
| Discharge Summary Review | 1141155d... | Intent | Clean |
| Progress Report Review | a208ca31... | Intent | Clean |
| Episode of Care | 506820a6... | Intent | Clean |
| Treatment Encounter Note | 2c44bf17... | Intent | Clean |
| Eval & Plan of Care (Copy) | ba7483a1... | Intent | Clean |
| Recertification/UPOT | 945af516... | Intent | Clean |
| Conversational boosting | efdb3dc6... | Unknown | Fixed |
| Greeting | c762252e... | Intent | Fixed |
| Goodbye | 68c2af46... | Intent | Fixed |
| Thank you | fd050d6f... | Intent | Fixed |
| Multiple Topics Matched | 56690385... | Intent | Fixed |
| Conversation Start | 78e4624d... | ConvStart | DEACTIVATED |
