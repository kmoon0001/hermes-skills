# Power BI Connector for Copilot Studio Agents (June 2026)

Connecting Power BI dashboards to Copilot Studio agents via service principal auth.
Based on Microsoft Learn docs and QM Coach V2 implementation.

## Architecture

```
Copilot Studio Agent
  → Power BI Connector Action (Power Platform)
    → Power BI REST API (Execute Queries)
      → Semantic Model (dashboard)
        → DAX Query → JSON Response
```

## Prerequisites (User Must Do)

1. **Azure AD App Registration** (entra.microsoft.com)
   - Register app, save Client ID + Tenant ID
   - Create client secret, save the value
   - Add Power BI API permissions: Dataset.Read.All, Workspace.Read.All
   - Grant admin consent

2. **Power BI Tenant Settings** (admin.power.microsoft.com)
   - "Allow service principals to use Power BI APIs" = ON
   - "Dataset Execute Queries REST API" = ON
   - "Allow XMLA endpoints" = ON (if using Arrow API)

3. **Workspace Access**
   - Add service principal to Power BI workspace as Contributor
   - This grants access to the semantic model/dataset

4. **Workspace ID + Dataset ID**
   - From the Fabric URL or semantic model settings
   - Needed for the connector configuration

## Agent Config (Hermes Does)

Once user provides Client ID, Secret, Tenant ID, Workspace ID, Dataset ID:

1. Create Power Platform connection in the Copilot Studio environment
2. Configure connector action in the Power BI topic
3. Set up DAX queries for each query level
4. Add HIPAA guardrails to connector responses
5. Test the connection

## Query Design (Multi-Level)

### Level 1: Facility QMs Dropping
```dax
EVALUATE
FILTER(
  SUMMARIZE(
    'QualityMeasures',
    'QualityMeasures'[MeasureName],
    'QualityMeasures'[CurrentRate],
    'QualityMeasures'[PriorRate],
    'QualityMeasures'[Trend]
  ),
  'QualityMeasures'[CurrentRate] < 'QualityMeasures'[PriorRate]
)
```

### Level 2: Patient-Level Decline Detection
```dax
EVALUATE
TOPN(
  20,
  FILTER(
    'PatientOutcomes',
    'PatientOutcomes'[TotalDeclined] > 0
  ),
  'PatientOutcomes'[TotalDeclined], DESC
)
```

### Level 3: General QM Trends
```dax
EVALUATE
SUMMARIZE(
  'QualityMeasures',
  'QualityMeasures'[MeasureName],
  'QualityMeasures'[NationalAvg],
  'QualityMeasures'[FacilityRate],
  'QualityMeasures'[StarRating]
)
```

## ONE Clinical Protocol Integration

When declining QMs are detected, cross-reference with clinical protocols:

| Declining QM | Protocol to Reference |
|---|---|
| Functional decline (GG) | Low Vision, Contracture Management, Sensory Integration |
| Pressure ulcers | Wound care protocols |
| Antipsychotic use | Sensory Integration |
| Falls with injury | Low Vision, Contracture Management |
| Walking ability decline | Contracture Management |

## HIPAA Compliance

Per Microsoft Learn healthcare guidelines:
- Use aggregate facility data in general responses
- Patient-level data only through approved secure workflow
- Minimum necessary principle
- No PHI in chat responses
- Patient names/IDs masked in responses
- DRAFT label on all clinical recommendations
- Filter DAX queries to return minimum necessary data
- Limit patient-level queries to 20 rows max
- Log all data access for audit trail
- Require facility confirmation before patient-level queries

## Connector Response Limit

Per Microsoft Learn: connector responses over 500KB cause HTTP 400 errors.
Fix: Use DAX TOPN() and SUMMARIZE() to filter data before returning.

## Microsoft Learn References

- [Power BI service basics](https://learn.microsoft.com/power-bi/fundamentals/service-basic-concepts)
- [Execute Queries REST API (JSON)](https://learn.microsoft.com/en-us/rest/api/power-bi/datasets/execute-queries)
- [Execute DAX Queries REST API (Arrow)](https://learn.microsoft.com/power-bi/developer/execute-dax-queries-arrow/overview)
- [Connector request failure fix](https://learn.microsoft.com/troubleshoot/power-platform/copilot-studio/actions/connector-request-failure)
- [Healthcare agent service for Copilot Studio](https://learn.microsoft.com/azure/health-bot/quickstart-copilot-studio-integration)
- [Connector actions training](https://learn.microsoft.com/training/modules/create-connector-actions-microsoft-copilot-microsoft-365-copilot-studio/)
- [Best practices for DAX Queries API](https://learn.microsoft.com/power-bi/developer/execute-dax-queries-arrow/best-practices)
