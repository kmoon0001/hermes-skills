# Comprehensive Topic Flow Trace

**Methodology enforced by user correction (Jul 1, 2026).**

## User's Directive

> "did you go through the entire list of topics logically from the start of conversation through each next topic hitting all document types and ocr to see if all topics are complete and logically flowing without unexpected stops and all have proper endings to them and its comprehensive?"

## The Trace

Do NOT fix one topic at a time and test. Instead, enumerate EVERY active topic, map the full conversation flow, and fix ALL structural defects in one batch.

### Step 1: Dump All Active Topics

```python
import json, urllib.request, urllib.parse

org = 'https://org<id>.crm.dynamics.com'
filter_val = "_parentbotid_value eq '<botId>' and componenttype eq 9 and statecode eq 0"
url = f"{org}/api/data/v9.2/botcomponents?$select=botcomponentid,name,data&$filter={urllib.parse.quote(filter_val)}&$top=50"
```

### Step 2: Audit Every Topic for Structural Defects

| Check | Signal | Severity |
|-------|--------|----------|
| `kind: Question` | Topic asks question instead of answering | BLOCKING for SR eval |
| Missing `EndDialog` | Topic fires but conversation doesn't end cleanly | HIGH |
| `CancelAllDialogs` | Cancels all dialogs without producing output | HIGH |
| `BeginDialog` refs | References topics that may be inactive/deleted | MEDIUM |
| `SearchAndSummarizeContent` without `elseActions` | Silent exit when KB returns nothing | MEDIUM |
| `ConversationStart` trigger | Intercepts every new conversation | BLOCKING for SR eval |

### Step 3: Trace the Flow for Every Document Type

For each document type the agent handles (Eval, UPOC/Recert, Progress, Daily Note, Episode, Discharge, OCR):

1. Which topic fires first? (ConversationStart, Greeting, or direct intent match)
2. Does the topic have Question nodes that block the flow?
3. Does the topic properly route to the audit topic?
4. Does the audit topic have `SearchAndSummarizeContent` with proper KB configuration?
5. Does the topic end with `EndDialog` + `clearTopicQueue: true`?
6. Is there a fallback if `SearchAndSummarizeContent` returns nothing?

### Step 4: Fix All Defects in One Batch

```python
def patch_topic(tid, fixed_yaml):
    patch_url = f'{org}/api/data/v9.2/botcomponents({tid})'
    body = json.dumps({'data': fixed_yaml})
    req = urllib.request.Request(patch_url, method='PATCH')
    req.add_header('Authorization', f'Bearer {dv_token}')
    req.add_header('Content-Type', 'application/json')
    req.add_header('OData-MaxVersion', '4.0')
    req.add_header('OData-Version', '4.0')
    req.data = body.encode()
    with urllib.request.urlopen(req, timeout=15) as resp:
        return resp.status
```

**IMPORTANT — PATCH the `data` field, not `content`.** The `content` field returns 400 "Unexpected character encountered while parsing value: k" (the YAML `kind:`). The `data` field accepts YAML content and returns 204.

### Step 5: Publish and Re-Eval

```bash
pac copilot publish --environment <orgUrl> --bot <botId>
```

### Therapy Documentation Feedback Agent Example (Jul 2026)

**Before audit:**
- Conversation Start: Question nodes → blocked ALL conversations
- Greeting: Question nodes + CancelAllDialogs + NO EndDialog
- Goodbye: Question nodes + NO EndDialog
- Thank you: NO EndDialog
- Multiple Topics Matched: Question nodes
- End of Conversation: Question nodes
- Fallback: NO EndDialog
- On Error: CancelAllDialogs
- Reset Conversation: CancelAllDialogs
- Conversational boosting: no fallback when KB empty

**After fixing all 11 defects:**
- 20-case conversation eval: 30% → 50%
- All topics have proper EndDialog endings
- No Question nodes in system topics
- Conversational boosting has SendActivity fallback

### Aggressive Regex Pitfall

When surgically removing YAML blocks, line-based removal is safer than greedy regex:

```python
# WRONG — greedy regex consumes adjacent blocks:
fixed = re.sub(r'\n\s*fileSearchDataSource:\s*\n(?:\s+[^\n]*\n)*', '\n', yaml)
# This also consumed knowledgeSources and applyModelKnowledgeSetting blocks!

# CORRECT — line-based removal:
lines = yaml.split('\n')
new_lines = []
skip = False
for line in lines:
    if 'fileSearchDataSource:' in line:
        skip = True
        continue
    if skip:
        if line.startswith('      '):
            continue
        else:
            skip = False
            new_lines.append(line)
    else:
        new_lines.append(line)
fixed = '\n'.join(new_lines)
```

### KB Ghost Reference Detection

Check if `knowledgeSources` references in topic YAML actually exist in Dataverse:

```python
# Get actual knowledge source components
url = f"{org}/api/data/v9.2/botcomponents?$select=name,schemaname&$filter=_parentbotid_value eq '{botId}' and componenttype in (14,16)"
# Compare with topic references
for topic in topics:
    for ref in extract_kb_refs(topic['data']):
        if ref not in actual_schemanames:
            print(f'GHOST: {topic["name"]} references {ref} which does not exist')
```

**Evidence (Jul 2026):** Therapy Documentation Feedback Agent had 8 KB references in topics but only 4 existed in Dataverse. Habit 1, 2, 4, 5, and OperationalGuideline were ghosts.
