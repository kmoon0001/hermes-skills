# Conversation Flow Analysis — Complete Topic Trace

Systematic method for diagnosing "agent doesn't answer" evaluation failures by tracing the full topic execution chain.

## When to Use

When SR eval scores are unexpectedly low (0-30%) despite correct instructions and KB sources.

## Methodology

### Step 1: Dump All Active Topics

```bash
curl -H "Authorization: Bearer $token" \
  "${org}/api/data/v9.2/botcomponents?\$select=botcomponentid,name,data&\$filter=_parentbotid_value eq 'BOT_ID' and componenttype eq 9 and statecode eq 0&\$top=30"
```

### Step 2: Classify Each Topic

For each topic, check:
- **Trigger type**: `OnConversationStart`, `OnRecognizedIntent`, `OnUnknownIntent`, `OnError`, `OnSystemRedirect`, `OnEscalate`
- **Has Question nodes**: `kind: Question` — these will FAIL SR eval (returns a question instead of an answer)
- **Has EndDialog**: Topic should end with `EndDialog` + `clearTopicQueue: true`
- **Has CancelAllDialogs**: Should be replaced with `EndDialog`
- **Routes to**: `BeginDialog` references to other topics

### Step 3: Trace Query Flow

For a sample question from the test set, trace which topics fire:

```
Query: "What are CMS Ch.15 requirements?"
  ↓
Conversation Start [ConvStart] → Question node "What can I help you with?" → BLOCKS
  ↓ (if deactivated)
Greeting [Intent, triggers: "Hello"] → no match → SKIPS
  ↓
Audit topics [Intent, triggers: "audit discharge" etc] → no match → SKIPS
  ↓
Conversational boosting [Unknown, priority -1] → MATCHES
  ↓
SearchAndSummarizeContent → KB search → returns answer or empty
  ↓
If empty + no fallback → SILENT EXIT → grader sees abstention
```

### Step 4: Fix Priority

1. **Conversation Start Question nodes** (biggest blocker) — affects ALL conversations
2. **Missing EndDialog** — silent exits on unmatched queries
3. **Fallback quality** — when KB returns nothing, what does the agent say?
4. **Greeting duplicates** — if Conversation Start is deactivated but Greeting has same Question flow

## Common Flow Bugs Found (Therapy Feedback Agent)

| Topic | Bug | Impact |
|-------|-----|--------|
| Conversation Start | `OnConversationStart` + `Question` node + no EndDialog | Blocks ALL SR evals |
| Greeting | Question node mirror of Conversation Start | Secondary blocker |
| Conversational boosting | No fallback when KB search returns empty | Silent exit → abstention |
| Goodbye | Question node + no EndDialog | Blocks if triggered |
| Thank you | No EndDialog | Silent exit |
| Multiple Topics Matched | Question node | Returns question instead of answer |
| End of Conversation | Question node + no EndDialog | Blocks if triggered |
| Reset Conversation | `CancelAllDialogs` instead of `EndDialog` | Undefined state |
| On Error | `CancelAllDialogs` instead of `EndDialog` | Undefined state |
| Escalate | No EndDialog | Silent exit |
| Fallback | No EndDialog | Silent exit |

## Fix Templates

### Question Node → SendActivity
```yaml
# BEFORE (broken)
- kind: Question
  id: ask_user
  variable: init:Topic.navigation
  prompt: What can I help you with today?
  entity: ClosedListEntity...

# AFTER (fixed)
- kind: SendActivity
  id: greet_user
  activity: Hello, I can help with Medicare therapy documentation compliance. What would you like to know?
- kind: EndDialog
  id: end-topic
  clearTopicQueue: true
```

### CancelAllDialogs → EndDialog
```yaml
# BEFORE
- kind: CancelAllDialogs
  id: cancel_all

# AFTER
- kind: EndDialog
  id: end-topic
  clearTopicQueue: true
```

### Conversational boosting fallback
```yaml
- kind: ConditionGroup
  conditions:
    - condition: =!IsBlank(Topic.Answer)
      actions:
        - kind: EndDialog
          clearTopicQueue: true
  elseActions:
    - kind: SendActivity
      activity: I can provide guidance on Medicare therapy documentation per CMS Ch.15, Jimmo v Sebelius, and Ensign 7 Habits. Please ask a specific question.
    - kind: EndDialog
      clearTopicQueue: true
```
