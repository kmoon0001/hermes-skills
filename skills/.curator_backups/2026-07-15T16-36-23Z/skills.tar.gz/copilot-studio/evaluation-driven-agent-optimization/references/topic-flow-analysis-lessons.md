# Topic Flow Analysis — Lessons from Therapy Feedback Agent

## Context
Optimizing the Therapy Documentation Feedback Agent in Prod. Agent scored 16% SR initially with 84% abstention. After exhausting instruction fixes, KB configuration, and platform investigation, the real root cause was topic-level defects — specifically Question nodes blocking the conversation flow.

## The Full Topic Audit Methodology

### Step 1: List ALL active topics
Query Dataverse for all topics: `componenttype eq 9 and statecode eq 0`. Don't filter by name — you'll miss system topics.

### Step 2: Classify each topic
For every active topic, check:
- **Trigger type**: OnConversationStart, OnRecognizedIntent, OnUnknownIntent, OnError
- **Has Question nodes**: `kind: Question` — ANY topic with this will fail SR eval
- **Has proper ending**: `EndDialog` with `clearTopicQueue: true`
- **Has CancelAllDialogs**: This is an anti-pattern — replace with EndDialog
- **Has SearchAndSummarizeContent**: Does it have `knowledgeSources` block?

### Step 3: Trace the conversation flow
For a single-response eval test case:
```
User query → Conversation Start? → Greeting? → Intent topics? → OnUnknownIntent? → EndDialog
```
Map which topic fires for each type of query. Any topic that fires and returns a Question instead of a text answer will fail.

### Step 4: Batch-fix ALL defects
Fix ALL topics with issues in one pass — don't fix one, test, fix another. The interaction between topics means incremental testing is misleading.

## Common Defects Found

### 1. Conversation Start blocks everything
`OnConversationStart` + `kind: Question` nodes = every conversation starts with a question. For SR eval: 100% failure.
**Fix**: Deactivate OR replace Question nodes with `SendActivity` + `EndDialog`.

### 2. Greeting has Question nodes
Same pattern as Conversation Start but fires on trigger phrases only.
**Fix**: Replace Question nodes with `SendActivity` + `EndDialog`.

### 3. System topics have no EndDialog
Goodbye, Thank You, Fallback, End of Conversation — all missing EndDialog.
**Fix**: Add `EndDialog` with `clearTopicQueue: true` to every topic.

### 4. CancelAllDialogs used instead of EndDialog
On Error, Reset Conversation — use CancelAllDialogs which doesn't properly end the conversation.
**Fix**: Replace with `EndDialog` + `clearTopicQueue: true`.

### 5. Catch-all (Conversational boosting) has no fallback
When `SearchAndSummarizeContent` returns nothing, the ConditionGroup `!IsBlank(Topic.Answer)` is false, and the topic exits silently.
**Fix**: Add `elseActions` with a helpful `SendActivity` + `EndDialog`.

## The 11-Topic Fix Applied

| Topic | Before | After |
|-------|--------|-------|
| Conversation Start | Question nodes, routes to 6 audit topics | DEACTIVATED |
| Greeting | Question nodes, CancelAllDialogs, no EndDialog | SendActivity + EndDialog |
| Goodbye | Question nodes, no EndDialog | SendActivity + EndDialog |
| Thank you | No EndDialog | SendActivity + EndDialog |
| Multiple Topics Matched | Question nodes | SendActivity + EndDialog |
| End of Conversation | Question nodes, no EndDialog | SendActivity + EndDialog |
| Fallback | No EndDialog | Added EndDialog |
| Conversational boosting | No fallback when KB empty | elseActions with SendActivity |
| Reset Conversation x2 | CancelAllDialogs | EndDialog |
| On Error | No EndDialog | Added EndDialog |
| Escalate | No EndDialog | Added EndDialog |

## KB Source Verification

### The pagination trap
Querying `$top=60` with `$filter=componenttype eq 9` missed type 14/16 knowledge sources because type 19 evaluation cases dominated the first page. Always use `$filter=componenttype eq 14 or componenttype eq 16` for KB source queries.

### `knowledgeSources` blocks are essential
`applyModelKnowledgeSetting: true` alone does NOT enable KB search. Topics need explicit `knowledgeSources` blocks with schemanames matching the KB source components. Removing these blocks (thinking they're stale references) breaks KB access.

### Verify schemanames match
Before removing any `knowledgeSources` references, verify they match actual Dataverse schemanames. In this case, all 13 referenced schemanames matched existing components — the initial query was just paginated.

## Score Progression

| Fix | Score | Note |
|-----|-------|------|
| Original | 16% | 84% abstention on 50-case |
| KB-aligned test set | 4% | Questions match KB but topics can't search |
| 11 topic fixes | 30% | On 20-case conversation set |
| + KB references restored | 50% | On 20-case conversation set |

The jump from 4% to 50% was achieved entirely through topic-level fixes — no instruction changes, no KB content changes, no model changes.
