# KB Ghost Reference Detection

## Problem

Topics with `SearchAndSummarizeContent` reference knowledge sources via `knowledgeSources.knowledgeSources[]` arrays containing schemanames. If these schemanames point to non-existent components, the search returns nothing → agent abstains.

## Detection via Dataverse API

```python
# Get all knowledge source components (type 14 and 16)
url = f"{org}/api/data/v9.2/botcomponents?$select=name,schemaname,componenttype&$filter=_parentbotid_value eq '{bot_id}' and componenttype in (14,16)"

# Get all referenced KB schemanames from topics
for topic in topics:
    refs = re.findall(r'- (cr53f_\S+)', topic['data'])
    for ref in refs:
        if ref not in existing_schemanames:
            print(f"GHOST: {ref} referenced in {topic['name']} but does not exist")
```

## Evidence

**Therapy Documentation Feedback Agent (July 2026):**
- Topics referenced 8 knowledge sources
- Only 4 existed in Dataverse (Habits 3, 6, 7 + Medicare Part B CFR)
- Missing: Habits 1, 2, 4, 5 + Clinical Operations Guideline
- 5/8 (62.5%) of KB references were ghosts → search returned nothing

## Fix Options

1. **Remove ghost references** — PATCH topic `data` to remove `knowledgeSources` block, rely on `applyModelKnowledgeSetting: true`
2. **Upload missing KB sources** — User plans to add 7 Habits PDF
3. **Use SearchAllKnowledgeSources** — Change `kind: SearchSpecificKnowledgeSources` to broader search (if API supports)
