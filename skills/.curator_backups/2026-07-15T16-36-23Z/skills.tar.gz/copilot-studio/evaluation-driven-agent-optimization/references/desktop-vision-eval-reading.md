# Desktop Vision for Eval Reading (July 2026)

When PPAPI eval API is down (token expired, quota exhausted, or progress counter broken), use cua-driver MCP to read eval results directly from the Copilot Studio UI via desktop screenshots.

## Setup

```bash
# Install cua-driver
hermes computer-use install

# Add to Hermes MCP (answer 'y' to enable all 39 tools)
echo y | hermes mcp add cua-driver --command "C:\Users\kevin\.cua-driver\packages\current\cua-driver.exe"

# Reload MCP
/reload-mcp
```

## Reading Eval Results

```python
# Set desktop capture scope
mcp_cua_driver_set_config(capture_scope="desktop")

# Capture full desktop
mcp_cua_driver_get_desktop_state()  → returns screenshot PNG

# Read with vision
vision_analyze(image_url=screenshot_path, question="Read eval results...")
```

## Finding the Right Window

```python
# List all Windows apps
mcp_cua_driver_list_apps()  → find Edge PID

# List windows for that PID
mcp_cua_driver_list_windows(pid=34452)  → get window_id

# Check window URL
mcp_cua_driver_get_window_state(pid=34452, window_id=19139326, include_screenshot=False)
  → Address bar shows URL to confirm it's the eval page
```

## Interacting with Copilot Studio SPA

**Caveats:**
- `get_window_state` only returns UIA tree (browser chrome, NOT page content)
- `page.get_text` also returns only browser chrome text
- `page.execute_javascript` needs CDP port configured (export CUA_DRIVER_CDP_PORT=9223 before starting cua-driver)
- Chromium windows need `bring_to_front` then `delivery_mode:foreground` for scroll/click

**Scroll pattern:**
```python
mcp_cua_driver_bring_to_front(pid=34452)
mcp_cua_driver_scroll(pid=34452, direction="down", amount=10, delivery_mode="foreground")
mcp_cua_driver_get_desktop_state()
vision_analyze(image_url=..., question="What's visible after scrolling?")
```

**Click pattern:**
```python
mcp_cua_driver_click(pid=34452, x=600, y=520)  # pixel coordinates from screenshot
```

## When to Use vs Alternatives

| Method | When | Reliable? |
|--------|------|-----------|
| PPAPI | Token fresh, under quota | Best |
| CDP Playwright scrape | Edge CDP running, signed in | Good |
| Desktop vision | PPAPI down, quota hit | Works always |
| browser_navigate | Needs sign-in | Fails (managed browser has no auth) |

## Edge CDP Startup

PowerShell script at `C:\Users\kevin\Desktop\start_edge_cdp.ps1`:
- Kills existing Edge
- Restarts with `--remote-debugging-port=9223`
- Uses original user data dir (preserves auth cookies)
- Waits for CDP to be ready
