# KB Source and Conversation Start Pitfalls (June 2026)

Three critical root-cause patterns discovered during Therapy Documentation Feedback Agent
diagnosis — applicable to ANY Copilot Studio agent with knowledge sources and conversation-start
topics.

## Pitfall: OnConversationStart + Question Nodes Blocks ALL SR Eval

When `Conversation Start` (or any topic with `kind: OnConversationStart`) contains `kind: Question`
nodes, every single-response eval test case fails:

1. Each test case creates a new conversation
2. `OnConversationStart` fires FIRST, before any `OnRecognizedIntent` topic
3. The Question node returns a question to the user ("What kind of document?")
4. The grader sees a QUESTION, not an answer → **Abstention=Yes**

Even `interruptionPolicy: allowInterruption: true` on the Question node doesn't help — the
Question IS the first model response, and that's what the grader evaluates.

### Detection
```javascript
const yaml = topic.data;
const isBlocking = yaml.includes('kind: OnConversationStart') && yaml.includes('kind: Question');
// → DEACTIVATE if true
```

### Fix
Deactivate via Dataverse PATCH: `statecode: 0 → 1`

**Evidence:** 0-4% → functional routing after deactivation.

---

## Pitfall: Regex-Based YAML Removal Can Nuke Adjacent Blocks

A greedy regex removing `fileSearchDataSource` can also consume the adjacent `knowledgeSources`
and `applyModelKnowledgeSetting` blocks. Result: `SearchAndSummarizeContent` has zero KB sources
→ returns nothing → agent abstains on 100%.

### Correct Fix: Line-by-Line Surgical Removal
```python
skip = False
for line in lines:
    if 'fileSearchDataSource:' in line:
        skip = True; continue
    if skip:
        if any(kw in line for kw in ['knowledgeSources:', 'applyModelKnowledge', '- kind:']):
            skip = False; new_lines.append(line)
        elif line.startswith('      ') or line.startswith('        '):
            continue
        else:
            skip = False; new_lines.append(line)
    else:
        new_lines.append(line)
```

### Post-Removal Verification
```python
assert 'knowledgeSources:' in fixed, 'MISSING!'
assert 'applyModelKnowledgeSetting' in fixed, 'MISSING!'
assert 'fileSearchDataSource' not in fixed, 'NOT REMOVED!'
```

**Evidence:** 0-8% after regex consumed knowledgeSources. Restored via line-by-line → 83%.

---

## Pitfall: applyModelKnowledgeSetting Alone Doesn't Search KB

`SearchAndSummarizeContent` with ONLY `applyModelKnowledgeSetting: true` returns nothing during
evaluation. The node NEEDS explicit `knowledgeSources` with schemanames matching KB component
schemanames in Dataverse.

### Detection: Verify KB Sources Exist
```python
# Query ALL KB sources with explicit type filter
url = f"{org}/api/data/v9.2/botcomponents?" \
      f"$filter=_parentbotid_value eq '{bot_id}' and (componenttype eq 14 or componenttype eq 16)"
# Type 14 = file KB, Type 16 = reference KB
```

### Dataverse Query Gotchas
- `$top` limits truncate — use explicit type filters
- KB sources (type 14/16) get buried among type 19 eval cases without type filter
- Verify schemanames in topic YAML match actual component schemanames

**Evidence:** 0-4% → 83% after restoring knowledgeSources to all 6 audit topics.

---

## Quick Reference: Topic Flow Audit Checklist

1. **Conversation Start** — `OnConversationStart` — deactivate if Question nodes present
2. **Greeting** — `OnRecognizedIntent` — check for Question nodes
3. **Each audit topic** — `OnRecognizedIntent` — verify trigger phrases + EndDialog + KB refs
4. **Catch-all** — `OnUnknownIntent` — verify SearchAndSummarizeContent + KB sources exist
5. **Fallback** — check for proper EndDialog
6. **All topics** — EndDialog present, CancelAllDialogs absent, Question nodes removed
