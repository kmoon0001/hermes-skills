# knowledgeSources & Groundedness (July 2026)

## knowledgeSources Must Be Explicitly Referenced

`applyModelKnowledgeSetting: true` alone does NOT enable KB search during evaluation. The `knowledgeSources` block with specific schemanames matching KB sources in Dataverse is REQUIRED.

**Wrong (scores 0-4%):**
```yaml
- kind: SearchAndSummarizeContent
  userInput: =System.Activity.Text
  applyModelKnowledgeSetting: true
```

**Correct (scores 83%+):**
```yaml
- kind: SearchAndSummarizeContent
  userInput: =System.Activity.Text
  knowledgeSources:
    kind: SearchSpecificKnowledgeSources
    knowledgeSources:
      - cr53f_TherapyDocumentationFeedbackB.topic.Habit1QuickReferencepdf_...
      - cr53f_TherapyDocumentationFeedbackB.topic.Habit2QuickReferencepdf_...
      # ... all KB source schemanames
  applyModelKnowledgeSetting: true
```

**How to verify KB source schemanames:**
```python
# Dataverse query
filter = "_parentbotid_value eq '{botId}' and (componenttype eq 14 or componenttype eq 16)"
url = f"{org}/api/data/v9.2/botcomponents?$select=name,schemaname&$filter={urllib.parse.quote(filter)}"
# Each schemaname in the response must match what topics reference
```

**Pitfall:** Dataverse queries default to small page sizes. Use `$top=50` or higher to avoid truncation that makes KB sources appear missing.

## Groundedness=No Fix

When all four eval metrics show `Abstention=No, Relevance=Yes, Completeness=Yes, Groundedness=No` — the agent answers correctly but the grader can't match the answer to KB content.

**Root cause:** `SearchAndSummarizeContent` without `additionalInstructions` produces generic answers without proper KB citations.

**Fix — Add additionalInstructions with citation requirements:**
```yaml
additionalInstructions: |-
  Answer the question comprehensively using only the knowledge sources. 
  Provide specific CMS Chapter 15, Medicare Part B, Jimmo v Sebelius, 
  and Ensign 7 Habits requirements with inline citations. Structure the 
  response with the key regulatory requirements, documentation elements, 
  and compliance criteria. Be thorough — cover all relevant aspects from 
  the knowledge sources. Never fabricate requirements not found in the 
  knowledge sources.
```

**Where to apply:** The Conversational boosting topic (OnUnknownIntent, priority -1) — this is the catch-all for queries that don't match any audit topic's trigger phrases.

## Regex Removal Pitfall

When removing YAML blocks from topics, NEVER use regex. A regex that targets `fileSearchDataSource` will also consume the adjacent `knowledgeSources` block because they share indentation levels.

**Wrong:**
```python
re.sub(r'\n\s*fileSearchDataSource:\s*\n(?:\s+[^\n]*\n)*', '\n', yaml)
# Also removes knowledgeSources! Scores drop to 0-4%.
```

**Correct (line-by-line):**
```python
lines = yaml.split('\n')
new_lines = []
skip = False
for line in lines:
    if 'fileSearchDataSource:' in line:
        skip = True
        continue
    if skip:
        if line.startswith('      ') or line.startswith('        '):
            continue
        else:
            skip = False
            new_lines.append(line)
    else:
        new_lines.append(line)
```

## Dataverse PATCH Pattern

- `data` field: PATCH works (HTTP 204)
- `content` field: PATCH fails (HTTP 400 — parser tries to parse YAML as JSON)
- `statecode`: PATCH `{"statecode": 0}` activates, `{"statecode": 1}` deactivates
- Topics store their YAML in the `data` field, not `content`
