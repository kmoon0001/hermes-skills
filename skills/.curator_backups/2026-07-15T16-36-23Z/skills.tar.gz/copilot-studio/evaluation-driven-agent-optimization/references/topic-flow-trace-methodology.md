# Topic Flow Trace Methodology

## When to Use

When eval scores are stuck at 0-30% despite instruction fixes, the root cause is almost always topic-level flow blocking. This methodology traces the full conversation path from start to finish.

## The Trace

For each test case question, trace EVERY active topic in priority order:

```
1. Conversation Start (OnConversationStart) → fires first, blocks all
2. Greeting (OnRecognizedIntent) → trigger match?
3. Each audit topic (OnRecognizedIntent) → trigger match?
4. System topics (Goodbye, Thank you, etc.) → trigger match?
5. Conversational boosting (OnUnknownIntent, priority -1) → catch-all
6. Fallback (OnUnknownIntent) → last resort
7. GPT model direct response → only if NO topic matches
```

## Common Flow Blockers

### 1. OnConversationStart with Question Nodes (CRITICAL)
- **Signal:** Every SR eval returns 0-4%
- **Mechanism:** Conversation Start fires first, asks a question ("What can I help you with?"), eval sees question as response → abstention
- **Fix:** Deactivate Conversation Start, OR replace Question nodes with direct SendActivity + EndDialog

### 2. Question Nodes in Any Topic
- **Signal:** Agent asks questions instead of answering in SR eval
- **Topics:** Greeting, Goodbye, Multiple Topics Matched, Start Over, End of Conversation, OCR
- **Fix:** Replace `kind: Question` with `kind: SendActivity` + `kind: EndDialog`

### 3. CancelAllDialogs Instead of EndDialog
- **Signal:** Conversation terminates abruptly
- **Topics:** On Error, Reset Conversation
- **Fix:** Replace `CancelAllDialogs` with `EndDialog` + `clearTopicQueue: true`

### 4. Missing EndDialog
- **Signal:** Topic ends without proper cleanup
- **Topics:** Greeting, Goodbye, Thank you, Start Over, Fallback, Escalate
- **Fix:** Add `EndDialog` + `clearTopicQueue: true` as the LAST action

### 5. SearchAndSummarizeContent with No Fallback
- **Signal:** KB search returns empty, topic exits silently → abstention
- **Topic:** Conversational boosting
- **Fix:** Add `elseActions` to ConditionGroup with fallback SendActivity

### 6. Ghost KB References
- **Signal:** SearchAndSummarizeContent never finds content
- **Detection:** Query Dataverse for componenttype 14/16, compare to topic knowledgeSources references
- **Fix:** Remove missing references, set `applyModelKnowledgeSetting: true`

## Complete Audit Script

```python
# Check every active topic for issues
for topic in active_topics:
    data = topic['data']
    issues = []
    if 'kind: Question' in data: issues.append('Question-node')
    if 'CancelAllDialogs' in data: issues.append('CancelAllDialogs')
    if 'EndDialog' not in data: issues.append('NO-EndDialog')
    if 'OnConversationStart' in data: issues.append('ConvStart-blocker')
    if issues:
        print(f"BROKEN: {topic['name']} — {', '.join(issues)}")
```

## Evidence

**Therapy Documentation Feedback Agent (July 2026):**
- 12+ eval runs: 0-22% with KB-aligned questions
- Initial diagnosis: "Platform limitation — KB inaccessible during eval"
- User correction: "It's in the topics. The bug is in conversational start because it's stopping the flow."
- Actual root cause: Conversation Start with OnConversationStart + Question nodes blocked ALL queries
- After full topic flow trace: 11 topics needed fixes (Question nodes removed, EndDialogs added, CancelAllDialogs replaced, Conversational boosting fallback added)
- Post-fix: User reported 30% pass rate (pending full KB restoration with 7 Habits PDF)
