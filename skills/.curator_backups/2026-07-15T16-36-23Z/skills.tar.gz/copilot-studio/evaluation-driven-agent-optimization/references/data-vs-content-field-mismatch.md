# data vs content field mismatch: publish blocker

Use this when Dataverse API patches to `botcomponent.data` succeed but publish fails.

## Problem
The Dataverse API `PATCH` on `botcomponent.data` updates authoring YAML but does NOT sync to `content` (runtime/compiled YAML). Publishing reads from `content`. If `content` has broken YAML (missing `ExpressionText`, bad indentation, orphan nodes), publish fails with `MissingRequiredProperty` even though `data` is valid and verified.

## Symptom
- `pac copilot publish` returns errors like `MissingRequiredProperty 'ExpressionText'` on multiple topics.
- `data` field was patched and verified correct via GET.
- `synchronizationstatus` shows `Failed` with `PropertyError` diagnostic details.

## Fix
Edit the topic in Copilot Studio UI → Topics → click topic → More → Open code editor → fix YAML → Save. There is no API path to patch `content` directly.

## Detection
After patching `data`, always attempt publish. If it fails with property errors, the `content` field is stale. Query `synchronizationstatus` via `pac env fetch` with FetchXML to confirm.

## Prevention
Before patching `data`, GET the current `content` field and compare. If `content` and `data` diverge significantly, the safest path is to edit in the Copilot Studio UI code editor rather than patching via API.
