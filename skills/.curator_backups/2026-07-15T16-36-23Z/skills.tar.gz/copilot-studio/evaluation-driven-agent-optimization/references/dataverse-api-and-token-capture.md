# Dataverse API & Token Capture Techniques (July 2026)

## Dataverse API Topic Patching

**⚠️ The `data` field, NOT `content`, holds topic YAML.** When reading topics via Dataverse API (`componenttype eq 9`), the `content` field is null/empty. The actual YAML is in the `data` field. PATCHing `data` works reliably (HTTP 204) for both topics and GPT instructions (componenttype 15).

### Surgical Removal Pitfall

When removing `fileSearchDataSource` blocks from topic YAML, regex patterns like `r'\n\s*fileSearchDataSource:\s*\n(?:\s+[^\n]*\n)*'` can accidentally CONSUME adjacent blocks at the same indentation level (`knowledgeSources`, `applyModelKnowledgeSetting`). This leaves topics with NO search capability → 0% eval scores.

**Fix:** Use line-by-line state machine removal instead of regex:

```python
lines = yaml.split('\n')
new_lines = []
skip = False
for line in lines:
    if 'fileSearchDataSource:' in line:
        skip = True
        continue
    if skip:
        if line.startswith('      ') or line.startswith('        '):
            continue
        else:
            skip = False
            new_lines.append(line)
    else:
        new_lines.append(line)
fixed = '\n'.join(new_lines)
```

**Post-patch verification:** Always check that `knowledgeSources:` and `applyModelKnowledgeSetting` survived the operation.

## Ghost Knowledge Source References

Topics reference KB sources by schemaname (e.g., `cr53f_...topic.Habit1QuickReferencepdf_...`). If those KB components were deleted or never created, the reference is a GHOST. The agent silently returns nothing — no error, just abstention.

**Detection:**
```bash
# Query all KB components for a bot
curl "https://orgXXX.crm.dynamics.com/api/data/v9.2/botcomponents?\$select=name,schemaname,componenttype&\$filter=_parentbotid_value eq '{botId}' and componenttype in (14,16)" 
```

**Knowledge source componenttypes:**
- Type 14: File knowledge source
- Type 16: Topic-reference knowledge source (e.g., Quick Reference PDFs)

**Fix:** Remove stale `knowledgeSources` block and rely on `applyModelKnowledgeSetting: true` to use all available KB automatically. If that still fails, the KB sources themselves may be unindexed or the model doesn't support KB-grounded eval.

## Token Acquisition

### Dataverse API Token (via Azure CLI)
```bash
az account get-access-token --resource "https://org532ca94a.crm.dynamics.com" --query accessToken -o tsv
```

### PPAPI Token (via CDP WebSocket)
PPAPI tokens expire in ~1 hour. Reliable refresh pattern:
1. Restart Edge with `--remote-debugging-port=9223 --user-data-dir=C:\Users\kevin\AppData\Local\Microsoft\Edge\User Data`
2. Use WebSocket to connect to evaluation page tab
3. Enable `Fetch.enable` with `urlPattern: '*'`
4. Reload page — intercept `Fetch.requestPaused` for `powerplatform.com` requests
5. Extract `Authorization` header → save to `%USERPROFILE%\.copilot-studio-cli\test-agent-token.txt`

Reference script: `D:/my agents copilot studio/pipeline/scripts/cdp_simple.cjs`

## Eval Abstention Diagnosis Sequence

When agent abstains on >80% of eval cases:

1. **Verify GPT instructions** — Check for restrictive SOURCE RESTRICTION guardrails via Dataverse API (`componenttype eq 15`, `data` field)
2. **Check topic knowledge sources** — Query `botcomponents` for componenttype 14+16, verify references in topic `data` are valid
3. **Check topic data integrity** — Verify `applyModelKnowledgeSetting: true` exists and `knowledgeSources` block wasn't accidentally removed
4. **Test with KB-aligned questions** — Create test set with questions directly from KB domains
5. **If all config is correct but abstention persists** → Platform limitation (MS Learn Layer 5). KB may be unindexed, model may not support KB-grounded eval, or eval runtime lacks KB access.
