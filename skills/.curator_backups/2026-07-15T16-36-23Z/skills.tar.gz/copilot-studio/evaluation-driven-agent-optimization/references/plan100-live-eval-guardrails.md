# Plan-100 live eval guardrails

Use this when an eval optimization loop reaches the low/mid-90s and remaining failures come from Copilot Studio live evaluation details.

## Evidence source
- Fetch `/api/botmanagement/v2/environments/{environmentId}/bots/{botId}/makerevaluations/{runId}/details`.
- Analyze `details.testCases[]`, including `queries[0].query`, `queries[0].answer`, `graderMetrics.queryResponseMetrics[]`, and `errorCodes`.
- Treat a case as passing General Quality only when relevance/completeness are `Yes`, abstention is `No`, and groundedness is absent or `Yes`.

## Quota handling
- `fairusagepolicy.botrunquotaviolated`: stop launching runs. Analyze existing detail files and prepare the post-reset command.
- `fairusagepolicy.botactiverunquotaviolated`: poll the active run rather than starting another.

## Patch safety
- If inserting static `ConditionGroup` / `SendActivity` guardrails or editing `additionalInstructions`, parse every generated `.after.yml` / backup file before another eval.
- A Dataverse `204` confirms the write request, not YAML validity.
- Common failure: `additionalInstructions: |-` lines accidentally moved to column 1, causing YAML `ScannerError`.

## Failure interpretation
- `unsupportedactivity.notextresponse`: output/action bug. Add or repair a guaranteed plain-text `SendActivity` fallback before `EndDialog`.
- Abstention + completeness failures: answer the user's exact question in the first sentence, conditionally if no note text is provided.
- Groundedness failures: remove unsupported denial, recoupment, penalty, numeric score, or authorship/supervision claims.

## OT Plan-100 response rule
For `is/does/can you check/can you audit/can you review my...` prompts:
1. Sentence 1 gives the determination/conditional determination.
2. Then list the minimum verification elements.
3. State final validation requires the note, but do not ask for it first in SR eval.
4. Do not use broad static superanswers unless exact-prompt targeted and YAML-validated.

## Publish failure recovery
If `pac copilot publish` returns the same cached failure timestamp or crashes with `Invalid response format (Parameter 'rawResponse')`:
- The platform's `synchronizationstatus` is stuck in "Synchronizing" from a previous failed publish.
- Do NOT try to reset `synchronizationstatus` via Dataverse API — the platform reverts it.
- Do NOT modify the `synchronizationstatus` JSON structure — the pac CLI will crash.
- Publish from Copilot Studio UI instead. The UI has a different publish mechanism.
- After publish, wait 90 seconds before running eval.

## `content` field is empty after API patches
After patching `data` via Dataverse API, the `content` field (runtime YAML) may remain at 0 chars for most topics. Only topics previously published successfully have non-zero `content`. The platform compiles `data` → `content` during publish. If `data` was previously broken (malformed indentation), `content` stays empty until a successful publish from the UI.
