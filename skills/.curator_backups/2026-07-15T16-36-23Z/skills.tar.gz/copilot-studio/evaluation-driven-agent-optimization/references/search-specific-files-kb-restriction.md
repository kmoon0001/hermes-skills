# SearchSpecificFiles KB Restriction (Jul 2026)

## Root Cause

When audit topics use `SearchAndSummarizeContent` with BOTH `fileSearchDataSource: SearchSpecificFiles` AND `knowledgeSources: SearchSpecificKnowledgeSources`, the `fileSearchDataSource` block OVERRIDES knowledge source search. The agent only searches the listed files, even when broader knowledge sources are configured alongside.

If test questions don't match content in those specific files, the agent finds nothing → abstains (`Abstention=Yes`).

## Detection

Check topic YAML in the `data` field (componenttype 9) for `SearchSpecificFiles`:

```yaml
fileSearchDataSource:
  searchFilesMode:
    kind: SearchSpecificFiles
    files:
      - cr53f_...file1
      - cr53f_...file2
      - cr53f_...file3
```

## Fix

Remove the `fileSearchDataSource` block entirely while keeping `knowledgeSources`:

```python
import re
fixed = re.sub(r'\n\s*fileSearchDataSource:\s*\n(?:\s+[^\n]*\n)*', '\n', yaml)
```

Then PATCH via Dataverse API:
```python
patch_url = f'{org}/api/data/v9.2/botcomponents({topic_id})'
body = json.dumps({'data': fixed})
# PATCH with OData headers → HTTP 204 on success
```

After patching, publish the agent: `pac copilot publish --bot <botId>`

## Evidence

Therapy Documentation Feedback Agent (Prod, Jul 2026):
- 6 audit topics had `SearchSpecificFiles` in `fileSearchDataSource`
- Removing the block via Dataverse API PATCH (+ GPT guardrail relaxation + publish)
- SR improved from 16% to 22% on original 50-case test set
- Remaining abstention (78%) due to KB inaccessibility at platform level — even KB-aligned test questions failed identically

## Related

- `evaluation-driven-agent-optimization` skill — Dataverse API PATCH pitfall (corrected: use `data` field, not `content`)
- `copilot-studio-run-eval` skill — direct PPAPI usage, CDP token capture
