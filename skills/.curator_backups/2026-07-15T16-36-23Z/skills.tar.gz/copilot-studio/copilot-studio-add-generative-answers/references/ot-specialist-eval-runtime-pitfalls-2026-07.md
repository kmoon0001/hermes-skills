# OT Specialist eval/runtime pitfalls (July 2026)

Session learning from Ensign Default `OT_Specialist` repair. Apply as a class-level pattern for Copilot Studio SearchAndSummarizeContent topics when evals show text-output quality or capture failures.

## Symptoms observed

- Eval responses literally returned `=Topic.Answer` even though the YAML had `SendActivity activity: =Topic.Answer`.
- SearchAndSummarizeContent responses leaked markdown, bracket citations, `cite:` footers, and source metadata despite topic instructions asking for plain text.
- Follow-up turns produced both deterministic guardrail text and generative/cited text; the grader effectively scored the last user-visible text.
- Direct `userInput: =System.Activity.Text` in knowledge Q&A topics lost multi-turn context.

## Durable fixes

1. Use explicit SendActivity after SearchAndSummarizeContent and before EndDialog.
2. If `activity: =Topic.Answer` leaks literally in live/eval output, change to interpolation:

```yaml
- kind: SendActivity
  id: send-answer
  activity: "{Topic.Answer}"
```

3. For knowledge Q&A, add CreateSearchQuery before SearchAndSummarizeContent:

```yaml
- kind: CreateSearchQuery
  id: create-search-query
  userInput: =System.Activity.Text
  result: Topic.SearchQuery

- kind: SearchAndSummarizeContent
  id: search-content
  autoSend: false
  variable: Topic.Answer
  userInput: =Topic.SearchQuery.SearchQuery
```

4. If deterministic text is needed for eval stability, set `autoSend: false` on SearchAndSummarizeContent so the generative node does not auto-send an extra answer. Then send only the desired final text via SendActivity.
5. End every topic with:

```yaml
- kind: EndDialog
  id: end-topic
  clearTopicQueue: true
```

## Pitfalls

- Do not put forbidden literal examples like `cite:1`, `Citation-1`, `[1]`, or `Topic.Answer` inside additionalInstructions when trying to suppress them; those strings can still prime or leak into outputs. State the rule generically instead.
- Be careful when patching CreateSearchQuery: only the CreateSearchQuery node should use `userInput: =System.Activity.Text`; the SearchAndSummarizeContent node should use `=Topic.SearchQuery.SearchQuery`.
- Cancel stale eval runs after patching; partial results from pre-patch runs can contaminate diagnosis.
