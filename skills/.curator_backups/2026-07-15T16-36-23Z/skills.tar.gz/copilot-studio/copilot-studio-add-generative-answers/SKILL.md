---
name: copilot-studio-add-generative-answers
description: Add SearchAndSummarizeContent or AnswerQuestionWithAI nodes to Copilot Studio topics.
category: copilot-studio
---

# Add Generative Answers

Add SearchAndSummarizeContent or AnswerQuestionWithAI nodes to Copilot Studio topics.

## Important: Do You Even Need a Topic?
When knowledge sources are added, AI can directly search them without any topic for QnA-style queries. Dedicated topic with SearchAndSummarizeContent is useful when:
- Restrict search to subset of knowledge sources
- Control flow around answer (follow-up, formatting, adaptive cards)
- Process response before showing
- Use specific input other than user's last message

## SearchAndSummarizeContent vs AnswerQuestionWithAI vs SearchKnowledgeSources
| Node | Use When | Data Source | Output |
| SearchAndSummarizeContent | Grounded in knowledge sources | Agent's knowledge | AI-summarized |
| SearchKnowledgeSources | Verbatim/exact content (insurance, legal, HR) | Agent's knowledge | Raw results, no AI |
| AnswerQuestionWithAI | Conversation history + general model knowledge only | No external data | AI-generated |

## Key Rules
1. ALWAYS precede SearchAndSummarizeContent with CreateSearchQuery to preserve conversational context
2. NEVER pass =System.Activity.Text directly to SearchAndSummarizeContent **for knowledge-grounded Q&A** — use CreateSearchQuery instead (see rule 5)
3. Access result via Topic.<ResultVar>.SearchQuery
4. ALWAYS add a SendActivity after SearchAndSummarizeContent that sends the result variable. Default examples often use `activity: =Topic.Answer`, but if live/eval output shows the literal string `=Topic.Answer`, switch that topic to interpolation form `activity: "{Topic.Answer}"` and verify with a fresh eval. Without an explicit SendActivity, the eval framework reports `unsupportedactivity.notextresponse` because it can't capture Topic.Answer as a text response. The SendActivity should be the last action before EndDialog.
5. For knowledge-grounded Q&A topics, do not pass `=System.Activity.Text` directly to SearchAndSummarizeContent. Use `CreateSearchQuery` first (`userInput: =System.Activity.Text`, `result: Topic.SearchQuery`), then set SearchAndSummarizeContent `userInput: =Topic.SearchQuery.SearchQuery`.
6. **EXCEPTION — SR Eval Unblocking:** When replacing Question nodes to unblock Search/Summarize/Rerank evaluation (the Question node asks user for input that blocks automated eval), passing `=System.Activity.Text` directly to SearchAndSummarizeContent IS correct. These are NOT knowledge Q&A flows — they're intake/document-processing topics where the user's last message IS the input to process. See the "Unblocking SR Eval" section below.
7. Do NOT add `autoSend: false` to SearchAndSummarizeContent unless the schema has been validated for that exact agent/runtime. In OT_Specialist (Jul 1 2026), adding `autoSend: false` produced topic errors because the node schema rejected the property. If SearchAndSummarizeContent auto-sends verbose/cited text in addition to SendActivity, first try supported patterns (tight additionalInstructions, topic-level direct-answer rule, normal SendActivity + EndDialog) and validate/publish one topic before batch patching.

## Knowledge Source References
When using knowledgeSources to restrict search:
- Knowledge source must already exist (add with add-knowledge first)
- Find filename in knowledge/ directory
- Reference WITHOUT .mcs.yml extension
```yaml
knowledgeSources:
  kind: SearchSpecificKnowledgeSources
  knowledgeSources:
    - cre3c_agent.topic.MyDocs_abc123
```

## Patterns
For full YAML examples see the templates at:
- D:/my agents copilot studio/pipeline/templates/topics/search-topic.topic.mcs.yml

Additional field notes:
- `references/ot-specialist-eval-runtime-pitfalls-2026-07.md` — eval/runtime fixes for literal `=Topic.Answer`, CreateSearchQuery wiring, `autoSend: false`, and citation/markdown leakage.

## Unblocking SR Eval: Question → SearchAndSummarizeContent Replacement

When a Copilot Studio topic uses `Question` nodes that block Search/Summarize/Rerank (SR) evaluation — the eval framework cannot answer interactive prompts, so the question acts as a dead end and the topic never reaches its SendActivity. The fix is to replace blocking `Question` nodes with `SearchAndSummarizeContent` nodes.

### Signal
- Eval shows the topic timing out or failing with no text response
- Topic has Question nodes at the beginning asking for user input (note type, discipline, note content, etc.)
- The Question's purpose is intake/document-processing, not multi-turn conversation

### Pattern

**Before (blocking SR eval):**
```yaml
- kind: Question
  id: Question_noteType
  variable: Topic.NoteType
  prompt: What is the note type?
  entity:
    kind: EmbeddedEntity
    definition:
      kind: ClosedListEntity
      items:
      - id: eval
        displayName: Evaluation
      - id: progress
        displayName: Progress Note
- kind: Question
  id: Question_noteContent
  variable: Topic.NoteContent
  prompt: Please provide the content of your note.
  entity: StringPrebuiltEntity
```

**After (SR eval unblocked):**
```yaml
- kind: SearchAndSummarizeContent
  id: SearchAndSummarizeContent_noteType
  userInput: =System.Activity.Text
- kind: SearchAndSummarizeContent
  id: SearchAndSummarizeContent_noteContent
  userInput: =System.Activity.Text
```

### Important Distinctions
| Pattern | CreateSearchQuery needed? | userInput | Use case |
|---------|---------------------------|-----------|----------|
| Knowledge Q&A | YES | `=Topic.SearchQuery.SearchQuery` | Searching agent's knowledge sources |
| Structured data → note | NO | `=Concatenate(...)` | Generating from form/AdaptiveCard data |
| **SR eval unblocking** | **NO** | **`=System.Activity.Text`** | **Replacing Question intake nodes** |

### Pitfalls
- This pattern converts the topic from interactive (waiting for user input) to passive (processing whatever text the user last sent). If the topic needs specific structured data, use AdaptiveCardPrompt instead of Question nodes.
- Do NOT use this for knowledge-grounded Q&A flows — those still need CreateSearchQuery to preserve multi-turn context.
- The SearchAndSummarizeContent result is stored in `Topic.Answer` by default. Add a SendActivity after to send it.

### Verification
1. Replace all blocking Question nodes with SearchAndSummarizeContent(userInput: =System.Activity.Text)
2. Keep the final SendActivity (which sends the result or an adaptive card)
3. Keep EndDialog with `clearTopicQueue: true`
4. Run SR eval — the topic should now complete without blocking
5. Validate YAML with js-yaml before publishing

## Document Upload → Generative Answers (No OCR Flow Needed)

When a topic needs to accept a user-uploaded document and analyze it against knowledge sources (CMS manuals, Ensign habits, etc.), you can use a **Question (File upload) → SearchAndSummarizeContent** pipeline without any OCR flow or AI Builder model.

**MS Learn verified:** Copilot Studio's generative answers node can process uploaded documents (PDF, DOCX, TXT up to 512MB) natively when configured with knowledge sources. The `SearchAndSummarizeContent` searches the agent's knowledge sources using the query — no separate OCR extraction step is needed for text-based document review/audit topics.

### Pattern

```yaml
actions:
  # Step 1 — Ask user to upload the document
  - kind: Question
    id: upload_doc
    variable: init:Topic.UploadedDoc
    prompt: Please upload the document for review.
    entity: FilePrebuiltEntity
    valueType:
      kind: FileType

  # Step 2 — Use generative answers (no flow, no AI Builder)
  - kind: SearchAndSummarizeContent
    userInput: "=Concatenate(\"Review the uploaded document for compliance. Document content: \", Topic.UploadedDoc.Content, \". Provide structured audit findings based on your knowledge sources.\")"

  # Step 3 — Display results
  - kind: SendActivity
    activity: "=Topic.Answer"

  - kind: EndDialog
    id: end-topic
    clearTopicQueue: true
```

### When to Use This vs OCR Flow

| Scenario | Use | Reason |
|----------|-----|--------|
| Document is text-based (DOCX, PDF, TXT) | **SearchAndSummarizeContent** — no flow needed | Copilot Studio natively reads these formats via generative answers |
| Document is a scanned image/photo of text | **InvokeFlowAction (OCR flow)** — AI Builder needs extracted text | Images are not supported by generative answers file ingestion |
| User pastes text directly | **SearchAndSummarizeContent** — no flow needed | Text is already extracted |

**Key distinction:** The 5 Feedback B Prod audit topics (Progress, Recert, Discharge, Episode of Care, Treatment Encounter) already use this SASC-only pattern and work correctly. The separate OCR flow (flowId `c71672f2`) is only needed for the Large_Document_OCR topic which handles scanned images.

### Verification
1. Check if the topic handles scanned images → needs OCR flow
2. Check if it handles native text documents → SASC is sufficient
3. If SASC, verify knowledge sources are configured at the agent level or in the node

## Structured Data → Note Generation Pattern

When SearchAndSummarizeContent is used to generate clinical notes from structured data (not knowledge search), CreateSearchQuery is NOT needed. Pass structured data directly via Concatenate():

```yaml
    - kind: SearchAndSummarizeContent
      id: gen_note
      userInput: "=Concatenate(\\"Generate a skilled NOTE_TYPE. Use only provided data. VAR1 \\", Text(Topic.var1), \\" VAR2 \\", Text(Topic.var2), \\".\\")"
```

**When to skip CreateSearchQuery:**
- Generating notes from AdaptiveCard-collected data
- Processing user-pasted document content
- Any flow where the input is structured clinical data, not a knowledge search query

**When to use CreateSearchQuery:**
- Knowledge-grounded Q&A (searching agent's knowledge sources)
- When you need to restrict search to specific knowledge sources
- Conversational context preservation for multi-turn knowledge queries

**YAML Quoting:** userInput with Concatenate() MUST be double-quoted with escaped inner quotes. Unquoted form breaks on colons/braces.

Verified: TheraDoc Workbench Card topics (Jun 30 2026) — 17 Card topics generate clinical notes from AdaptiveCard data without CreateSearchQuery.

## Generative Orchestration
When GenerativeActionsEnabled: true:
- Prefer Pattern 2 (Orchestrator): use topic inputs/outputs
- When false: use Pattern 1 (Direct Response) with autoSend: false + manual SendActivity
- Verbatim content needed: Pattern 4 (Precision Search) with SearchKnowledgeSources + CreateSearchQuery
