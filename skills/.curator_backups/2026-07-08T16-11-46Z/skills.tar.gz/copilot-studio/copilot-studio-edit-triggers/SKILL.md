---
name: copilot-studio-edit-triggers
description: Modify topic triggers — trigger phrases (triggerQueries) and model description (modelDescription) in Copilot Studio topic YAML files.
---

# Edit Topic Triggers

Modify how a topic gets triggered: trigger phrases (triggerQueries) and model description (modelDescription).

## Instructions

1. Auto-discover agent directory: Glob **/agent.mcs.yml. NEVER hardcode.

2. Find target topic: Glob <agent-dir>/topics/*.topic.mcs.yml

3. Read topic file and identify what to change.

4. Check settings.mcs.yml for GenerativeActionsEnabled — determines which mechanism matters most.

## Model Description (modelDescription)
Natural language description at root of AdaptiveDialog telling generative orchestrator when to route to this topic. When GenerativeActionsEnabled: true, this is the PRIMARY routing mechanism.

```yaml
kind: AdaptiveDialog
modelDescription: This topic helps users order a pizza by collecting their preferred size, toppings, and delivery address.
beginDialog:
  kind: OnRecognizedIntent
  id: main
```

### Best Practices
- Write clear, specific sentence describing what the topic does and when to use it
- Focus on user's intent: "Use this topic when the user asks for..."
- Include key scenarios the topic covers
- Keep concise but complete
- Avoid vague descriptions like "This topic handles requests"

### When to Add/Edit
- ALWAYS add modelDescription to OnRecognizedIntent topics when GenerativeActionsEnabled: true
- Update when topic purpose/scope changes
- System triggers (OnError, OnUnknownIntent, OnConversationStart) don't need modelDescription

## Dual Description Pattern (mcs.metadata.description + root modeldescription)

For generative orchestration, Copilot Studio requires TWO separate description fields with the SAME text:

```yaml
mcs.metadata:
  componentName: My Topic
  description: |-                           # Inside mcs.metadata block
    This description tells the AI about this topic.
kind: AdaptiveDialog
modeldescription: |-                         # Root-level sibling of kind:
  This description tells the AI about this topic.
beginDialog:
  kind: OnRecognizedIntent
  id: main
```

PITFALL: `modeldescription` is a root-level key (sibling of `kind:`), NOT inside `mcs.metadata`. The `description` IS inside `mcs.metadata` as a key of the `mcs.metadata` mapping. They must share identical text value. Missing one or having mismatched text causes the topic to have incomplete metadata that the orchestrator may not read correctly.

## Description Quality Standards (Microsoft Learn Best Practices)

Microsoft Learn prescribes specific quality standards for topic descriptions in generative orchestration. Every custom topic description should meet these criteria:

| Criteria | MS Learn Guideline | Example |
|---|---|---|
| Active voice, present tense | "Use active voice and present tense" | "Audits documentation for Medicare Part B compliance" (not "A topic that handles...") |
| 1-2 sentences | "Short and informative summary" | 1-2 concise sentences, not 3+ verbose |
| States user benefit | "How it benefits the user" | "Returns structured findings with issue, standard, and citation" |
| Indicates negative scope | "What they can't do" prevents ambiguity | "Does not review daily treatment notes or initial evaluations" |
| Descriptive componentName | "Use a descriptive and unique name" | "Discharge Summary Audit" (not "Topic1") |

**Template for audit/compliance topics:**
```
Audits {Note Type} for {compliance standard} denial risk, evaluating {focus area} using {sources}.
Returns structured findings with issue, standard, and citation.
Does not {out of scope items}.
```

**Verification checklist:**
1. Is `mcs.metadata.description` present with active voice?
2. Is root-level `modeldescription` present and identical to description?
3. Is componentName descriptive and unique?
4. Does the description state what the topic does NOT handle to prevent orchestrator misrouting?
5. Is the description 1-2 sentences? (Over 300 chars risks being too long.)
6. Does the description start with an action verb? (Audits, Extracts, Reviews, Generates, Routes, Handles.)
7. Are triggerQueries present and relevant even for generative orchestration (helps disambiguation)?

## Trigger Phrases (triggerQueries)
Used for intent recognition. Live inside beginDialog.intent.triggerQueries.
Only OnRecognizedIntent topics have editable trigger phrases.

### Operations
- Add phrases: append to triggerQueries
- Remove phrases: delete from triggerQueries
- Replace phrases: swap old for new
- Rewrite all: replace entire triggerQueries array

### Best Practices
- Use 5-10 phrases per topic
- Cover synonyms and variations
- Include different sentence structures (questions, statements, keywords)
- Avoid overlap between topics
- Keep phrases short and natural
- Mix formal and informal phrasing

### Example
```yaml
kind: AdaptiveDialog
modelDescription: This topic helps users with greeting and introduction.
beginDialog:
  kind: OnRecognizedIntent
  id: main
  intent:
    displayName: Greeting
    triggerQueries:
      - Hello
      - Hi
      - Hey
      - Good morning
      - Good afternoon
```

## Limitations
- Cannot change trigger TYPE (e.g., OnRecognizedIntent to OnConversationStart) — requires recreating topic
- Cannot add triggers to system topics that don't use OnRecognizedIntent

## YAML Surgery Pitfalls (Dataverse PATCH Context)

When editing topic descriptions or triggers by PATCHing the `data` field of live `botcomponents`, watch for:

### Duplicate Action Blocks from Broad Regex Replacement
PowerShell/Python regex replacement on YAML data can easily duplicate entire action blocks if the regex matches too broadly. Example: a regex targeting `modeldescription: |-\n    ...` that overlaps with `beginDialog:` boundaries can produce 2x copies of `InvokeFlowAction`, `ConditionGroup`, `SendActivity`, etc.

**Detection:** Query live data and count key node occurrences — each should be exactly 1:
```powershell
[regex]::Matches($data, "InvokeFlowAction").Count   # should be 1
[regex]::Matches($data, "invokeAIBuilderModelAction").Count  # should be 1
[regex]::Matches($data, "send_audit_results").Count  # should be 1
```

**Prevention:** Generate the complete YAML as a fresh string from a template function rather than doing regex replacement on live data. Use PowerShell `Here-String` or Python f-strings to build the YAML, then PATCH the entire `data` field.

### InvokeFlowAction Input Binding Format
OCR flow input bindings must use proper Power Fx syntax:
- `file_content: "=Topic.TopicUploadedDoc.Content"` (NOT `TopicUploadedDoc.Content`)
- `file_name: "=Topic.TopicUploadedDoc.Name"` (NOT `=Topic.TopicUploadedDoc`)
See `references/ocr-flow-audit-topic-pattern.md` in `copilot-studio-author-topic` for full details.

## References
- `references/ms-learn-description-standards.md` — Full MS Learn description quality standards with examples and verification checklist. Consult this when writing or auditing topic descriptions.
- `copilot-studio-author-topic` skill → `references/ocr-flow-audit-topic-pattern.md` — InvokeFlowAction binding patterns for AI Builder + OCR flows.
