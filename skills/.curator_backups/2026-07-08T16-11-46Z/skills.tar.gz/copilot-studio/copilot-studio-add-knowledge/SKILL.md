---
name: copilot-studio-add-knowledge
description: Add knowledge sources to a Copilot Studio agent — Public Website, SharePoint, Custom API, or UI-uploaded files.
category: copilot-studio
---

# Add Knowledge Source

Add a knowledge source to a Copilot Studio agent. Supports Public Website, SharePoint, and Custom API sources.

## Instructions

1. Auto-discover agent directory: Glob **/agent.mcs.yml. NEVER hardcode.

2. Parse arguments to extract URL and optional name/description.

3. Determine source type:
- URL contains sharepoint.com -> SharePointSearchSource (normalize URL first)
- User wants custom search API -> OnKnowledgeRequested (YAML-only, no UI)
- Otherwise -> PublicSiteSearchSource

4. SharePoint URL normalization:
| Pattern | Action |
| --- | --- |
| Direct path /sites/.../Shared%20Documents/... | Use as-is |
| AllItems.aspx with ?id= param | Extract and decode the id query parameter |
| Sharing link /:f:/s/... | Cannot convert — ask user for direct URL |

Spaces must be encoded as %20.

5. Generate YAML:

**Public Website:**
```yaml
# Name: <Name>
# <Description>
kind: KnowledgeSourceConfiguration
source:
  kind: PublicSiteSearchSource
  site: https://www.example.com/docs
```
Note: PublicSiteSearchSource uses Bing search, max depth 2 levels beyond domain.

**SharePoint:**
```yaml
# Name: <Name>
# <Description>
kind: KnowledgeSourceConfiguration
source:
  kind: SharePointSearchSource
  site: https://contoso.sharepoint.com/sites/MySite/Shared%20Documents/MyFolder
```

6. Save to agent's knowledge/<descriptive-name>.knowledge.mcs.yml

## Custom API via OnKnowledgeRequested (YAML-only)

For proprietary search APIs not natively supported:

1. Create topic with OnKnowledgeRequested trigger
2. Use System.SearchQuery as input to API call
3. Transform results to schema: Content, ContentLocation, Title
4. Set System.SearchResults with transformed results

Template: templates/topics/custom-knowledge-source.topic.mcs.yml

## Dynamic Knowledge URLs with Global Variables

Knowledge source URLs support {VariableName} placeholders:

```yaml
kind: KnowledgeSourceConfiguration
source:
  kind: SharePointSearchSource
  site: =$"${Global.UserKBURL}"
```

Variable must contain clean direct URL (not AllItems.aspx). Spaces OK in variable value.

## triggerCondition (YAML-only feature)

Works at runtime but not visible in UI. UI only exposes on/off toggle. Arbitrary Power Fx expressions work (e.g., =Global.UserDepartment = "HR").

## Uploaded Files (UI-only — no API)

File uploads (PDFs, DOCX) require the Copilot Studio UI. No API or YAML exists for uploading files.

Reference: `references/live-ui-uploaded-file-knowledge.md` has the verified live-UI workflow for uploaded PDFs, source description rewrites, Official source toggles, and verification.

### Writing Knowledge Source Descriptions and Official Source Flags

After uploading files, rewrite each source's name/description in the **live Copilot Studio UI**. Good descriptions improve retrieval accuracy, and for live agents the UI is the source of truth for these fields.

Pattern:

- **Name:** `<Authoritative Body> <Topic> <Source Type>` (e.g., "ASHA Adult Dysphagia Practice Portal"). Prefer clean display names over raw filenames so the user does not need to fix names later in the UI.
- **Description:** One sentence on what it covers, one on why it's authoritative, one on clinical use cases. Include specific retrieval terms the agent should ground on (CPT codes, assessment names, framework levels, instrument names, condition names).
- **Official source:** turn the toggle on when the file is authoritative. Copilot Studio displays an "Update agent instructions? (preview)" confirmation; click **Got it** only after verifying this is the intended official source behavior. Then click **Save** and verify Save becomes disabled.

Example:
```
Name: ASHA Adult Dysphagia Practice Portal
Description: Authoritative clinical practice guidelines for adult dysphagia 
assessment and treatment from ASHA. Covers MBSS/FEES interpretation, IDDSI 
diet levels, compensatory strategies, therapeutic exercises, and skilled 
service justification per CMS Chapter 15.
```

**Pitfall:** Vague descriptions like "ASHA information" or "Dysphagia guide" cause poor retrieval. Be specific about what's IN the document.

### Download Web Pages as PDFs for Upload

When you need to add web content as uploaded knowledge (e.g., ASHA Practice Portal pages):

1. Create a target folder: `mkdir -p ~/Desktop/<agent>-knowledge-pdfs`
2. Use Playwright headless Chromium to download each URL as PDF:
```javascript
const { chromium } = require('playwright-core');
const browser = await chromium.launch({ headless: true });
const page = await browser.newPage();
await page.goto(url, { waitUntil: 'networkidle', timeout: 60000 });
await page.waitForTimeout(3000);
await page.pdf({ path: 'output.pdf', format: 'A4', printBackground: true,
  margin: { top: '20mm', bottom: '20mm', left: '15mm', right: '15mm' } });
```
3. Upload all PDFs via UI: Knowledge → Add knowledge → Upload files
4. Deactivate old PublicSiteSearchSource versions after upload

**Why uploaded files over PublicSiteSearchSource:** PublicSiteSearchSource relies on real-time web crawling = non-deterministic retrieval. Uploaded files = always available, consistent retrieval. PT/OT agents use file-only knowledge and score 98-100%.

### Migration Pattern: PublicSiteSearchSource → Uploaded Files

1. Download target pages as PDFs (see above)
2. Upload PDFs via UI
3. Deactivate old sources via Dataverse PATCH (statecode=1, statuscode=2):
```bash
curl -X PATCH "https://<org>.crm.dynamics.com/api/data/v9.2/botcomponents(<componentId>)" \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{"statecode":1,"statuscode":2}'
```
4. Verify new uploaded files appear on the Knowledge page and under the **Files** filter.

**Pitfall:** Copilot Studio's Knowledge table behavior changes by release/tenant. Do not assume the **All** view hides files: in the live Ensign tenant, All showed Public website, SharePoint, and Files together. Use the **Files** filter only when you need to isolate uploaded PDFs or avoid touching old web/SharePoint sources.

## Limitations

**Can create:** Public Website, SharePoint, Custom API.

**Must use UI for:** Dataverse tables, Uploaded files, AI Search, SQL Server.
