# Common Pitfalls

Each pitfall maps to a known Copilot Studio failure mode. Cross-reference with `taxonomy-rules.md` for the full rule and `topic_lint.cjs` for automated detection.

## Structural

- `botcomponent` table `componenttype` = 9 (Topic V2). Older payloads used 0.
- `schemaname` field is REQUIRED on create. Pattern varies per agent: check the agent-specific skill.
- `parentbotid` uses OData-bound syntax: `'parentbotid@odata.bind': '/bots(BOT_ID)'`.
- Empty `beginDialog.actions` triggers R3 → publish crashes.
- Orphan Question nodes (no `property` and no `actions`) trigger R4 → SR collapses.
- Trigger overlap > 60% Jaccard across topics → topic routing drift, eval variance jumps.
- Every `InvokeConnectedAgentTaskAction` must have correct `botSchemaName` — verify against actual bot's `schemaname` field before publishing. Wrong schema → "Error" in eval (validated: TDA had PT/OT routing to SLP).
- Never mix "NOT JSON" and "Return exactly one valid JSON" in same `additionalInstructions` — causes model confusion.

## Topic Configuration

- `clearTopicQueue: false` on EndDialog triggers R9 → topic stacking (validated: PT conv 55→40%).
- `allowLatencyMessage: true` triggers R10 → misleads AI grader, "irrelevant" failures.
- `SearchSpecificFiles` or `fileSearchDataSource` triggers R11 → restricts search, groundedness failures.
- `knowledgeSources: kind: SearchAllKnowledgeSources` triggers R12 → invalid field, runtime errors.
- `applyModelKnowledgeSetting: false` triggers R13 → knowledge gaps, score collapse.

## dump_agent_full.cjs Auth Limitation (validated 2026-07-04)

The `dump_agent_full.cjs` script uses auth that only works against Ensign Default (`org3353a370.crm.dynamics.com`). When run against Therapy AI Dev (`orgbd048f00.crm.dynamics.com`) or any other environment, it returns `topicCount: 0, knowledgeCount: 0` with empty instructions/topics/knowledge arrays — even when the agent is live and published.

**Root cause:** The script's bearer token or auth chain is scoped to Ensign Default's Dataverse environment. Therapy Dev agents have different credentials.

**Workaround:** Prefer local source audit (read topic YAMLs directly from the workspace). For live state queries against Therapy Dev, use direct Dataverse API calls against `orgbd048f00.crm.dynamics.com/api/data/v9.2` instead of the dump script.

**Do NOT:** Interpret "0 components" as "agent doesn't exist" — it only means the script couldn't authenticate against that environment.

## Eval

- **Eval endpoint 404 (PUBLIC PREVIEW, regional rollout).** Even with valid bearer token, `api.powerplatform.com/copilotstudio/.../makerevaluation/...` returns 404 on some tenants. Treat as endpoint-not-yet-available, NOT auth failure. eval_bot.cjs tags such rows `source=unavailable`.

## Pac CLI Stuck Publish State (validated Jul 1 2026)

When `pac copilot publish` shows the old failed result timestamp and won't trigger a new publish, the platform's `synchronizationstatus` is stuck in `"state":"Synchronizing"`. API patches to this field get reverted by the platform immediately.

**Root cause:** A prior failed publish left the internal state machine in "Synchronizing". The pac CLI reads this status and reports the last failed result instead of triggering a new publish.

**Fix:** Publish from Copilot Studio UI. The UI has a different publish mechanism that clears the stuck state. After a successful UI publish, the pac CLI works again.

**Do NOT:**
- Patch `synchronizationstatus` via Dataverse API — the platform reverts it
- Clear pac auth and re-authenticate — won't help
- Wait for timeout — can take hours

**Detection:** `pac copilot publish` output shows `"Failed [timestamp]"` with the SAME timestamp on repeated attempts, and `pac env fetch` shows `"state":"Synchronizing"`.

## YAML Quoting

- **SearchAndSummarizeContent userInput with Concatenate()** containing colons, braces, or Power Fx expressions MUST use double-quoted string with escaped inner quotes. Unquoted form breaks YAML parsing because `:` and `{` are YAML-special characters.
  - Correct: `userInput: "=Concatenate(\\\\\"text: item 1\\\\\", Text(Topic.var), \\\\\"more text\\\\\")"`
  - Wrong: `userInput: =Concatenate("text: item 1", Text(Topic.var), "more text")`
  - Validated: TheraDoc Workbench 17 Card topics (Jun 30 2026)
- **SendActivity with {Topic.Variable}** in block scalar (`|-`) is safe. In quoted strings, braces may need escaping depending on context.

## GPT Instruction Corruption

- **Oversized instructions** cause response truncation in eval. Healthy ranges: PT/OT 3,000-5,500 | SLP 1,800-3,000 | TDA 4,000-7,000 | QM Coach 2,000-6,000. Query `botcomponents` where `componenttype eq 15` to check.
- **Ghost components** — empty 0-char GPT components sitting next to the real one. Delete them.
- **Duplicate section headers** — "RESPONSE LENGTH" appearing >1x means instructions are duplicated. Run anti-corruption checklist.
- **Verbose knowledge source lists** in GPT instructions waste instruction budget. The model already has access to configured knowledge sources — don't list them in instructions.
