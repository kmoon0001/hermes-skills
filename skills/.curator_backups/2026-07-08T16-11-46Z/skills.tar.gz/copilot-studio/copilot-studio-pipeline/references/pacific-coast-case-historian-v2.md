# Pacific Coast Case Historian V2 — Agent Reference

## IDs
| Field | Value |
|-------|-------|
| Bot ID | `ad635500-cf47-f111-bec5-70a8a5b1c3a3` |
| Schema | `auto_agent_XRF5I` |
| Environment | Therapy AI Agents Dev (`a944fdf0-0d2e-e14d-8a73-0f5ffae23315`) |
| Org | `https://orgbd048f00.crm.dynamics.com` |
| Tenant | `03cc92c3-986c-4cf4-ae27-1478cf99d17f` |
| Pipeline config | `pipeline/agents/pacific_coast_case_historian_v2.json` |
| Model | GPT5Chat |
| Web browsing | OFF |
| Channels | Teams, Microsoft365Copilot |

## Topic Inventory (22 custom + 13 system)
Custom topics (.mcs.yml format):
- PT Clinical Analysis, OT Clinical Analysis, SLP Clinical Analysis, Nursing Clinical Analysis
- Clinical Analysis, Clinical Evidence, Clinical Evidence Extraction and Relevance Mapping
- SBAR Handoff Generator, MDS 3.0 Crosswalk, Multi-Discipline Summary
- Output Generation, Discharge Summary Support, Progress Note and Recertification Support
- Advance Care Planning Documentation, SNF Therapy Documentation Review
- Document Intake, OCR Text Extraction, OCR Failure Fallback, PHI Scrubbing
- Freeform Documentation Support, Clinical Safety Boundaries, StartOver

System topics (DO NOT MODIFY):
- ConversationStart, EndofConversation, Escalate, Fallback, Goodbye, Greeting, MultipleTopicsMatched, OnError, ResetConversation, Signin, ThankYou, WelcomeandDisclaimer, Search

## Knowledge Sources (11)
CMS MDS 3.0 RAI User's Manual, CMS Medicare Ch.15 Therapy Coverage, APTA Physical Therapy Guidelines, ASHA SLP Clinical Resources, AOTA OT Practice Framework, IDDSI Global Standards, 42 CFR Part 483 Subpart B, Jimmo v. Sebelius Settlement, CMS PDPM Classification, PointClickCare FHIR API, AI Fleet Knowledge

## Connected Agents
| Agent | Bot ID | Relationship |
|-------|--------|-------------|
| SNF Command Center V2 | 9f3e370c-a747-f111-bec6-0022480b6bd9 | Hub — orchestrator |
| SNF AI Dashboard V2 | bd570423-cf47-f111-bec5-70a8a5b1c3a3 | Peer — data viz |
| TheraDoc Workbench | e09954e1-4af8-47c6-8ef4-d1d9335bf2e6 | Peer — therapy docs |
| QM Coach V2 | ea52ad9c-8233-f111-88b3-6045bd09a824 | Peer — quality measures |

## GPT Instructions
- Length: ~4,200 chars (healthy) — under 6000 ✓
- No duplication, no corruption ✓
- Few-shot examples: PT and SLP
- Sparse evaluation handling: enabled (informal no-caveat behavior present at line 21, but lacks branded `EVAL NO-CAVEAT STANDARDS CHECK` header)
- Grounding: SNF/post-acute only (no outpatient/ASC/CPT)
- Web browsing: OFF

### Instruction Issues Found (2026-07-03 Full Audit)
1. **Self-contradictory length guidance**: Line 37 says "prioritize completeness and structure over an arbitrary length cap" while line 53 says "Keep responses under 800 characters and 4 sentences" — the model oscillates between these two directives, causing eval score instability.
2. **Unconditional no-formatting restriction**: Line 41 bans markdown headers, emoji, and decorative formatting unconditionally — forces plain text even when structured formatting would improve conversational eval readability. Known 5-10% Conv score drop pattern.
3. **800-char hard truncation**: Line 53 hard limit is a known eval failure pattern ("Seems incomplete"). Should be removed or made conditional.
4. **Citation preservation instruction**: Line 38 "preserve citation tags exactly and cite inline" — instructing citation behavior contradicts MS Learn best practice. Citations should be managed by platform settings, not instructions.
5. **Missing EVALUATION-SAFE ORCHESTRATION section**: No explicit eval-safe block to define direct-answer behavior during test runs. Other therapy agents (OT, PT, SLP, TDA) have this.

### Connected Agent Routing Gap (2026-07-03)
All 4 connected agents are configured in settings/manifest but **zero topics** contain `InvokeConnectedAgentTaskAction` blocks. Cross-agent routing is declared but never invoked at the topic level. This may be by design (platform-level orchestration) or a gap — confirm with the user.

### Fix-Ready Status (2026-07-03)
`fix-ready: false` — 5 P0 instruction-level issues (self-contradiction, unconditional format ban, hard 800-char truncation, citation override, missing eval-safe section) must resolve before entering the eval-driven debug loop.

## Fixes Applied (2026-06-26)
1. BOM stripped from agent.mcs.yml
2. 11 orphan Question nodes removed (ConditionGroup+Question pattern)
3. OutputGeneration populated (was empty dead topic)
4. DocumentIntake completed (was stub)
5. ClinicalSafetyBoundaries consolidated (4 SendActivity → 1)
6. OCRTextExtraction EndDialog added
7. 4 exact trigger overlaps deduplicated
8. ClinicalAnalysis trigger overlap reduced
9. AdvanceCarePlanningDocumentation rewritten answer-first
10. StartOver simplified (removed confirmation Question)

## Lint Status (post-fix)
- 175 errors (all false positives: R1 on .mcs.yml extension, R3/R7 on system topics)
- 114 warnings (mostly R4w on system topics, R5 trigger overlap between discipline topics at 67% which is expected)
- 0 real errors on custom topics

## Pending
- Launch eval for baseline scores
- Run eval-driven optimization loop
