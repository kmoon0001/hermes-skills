---
name: copilot-studio-live-sync-backup
description: Pull all topic YAMLs from a live Copilot Studio agent via Dataverse REST API and sync local files to match. Live UI = source of truth; local = backup.
tags: [copilot-studio, dataverse, backup, sync, live]
---

# Copilot Studio Live Sync Backup

Make local YAML topic files match the live Copilot Studio agent. The live UI is the source of truth; this script overwrites local with live data.

## Prerequisites

- `az` CLI authenticated to the target tenant
- Bot ID (GUID from Copilot Studio URL or pac copilot list)
- Environment org URL (e.g. `https://orgxxx.crm.dynamics.com`)
- Local workspace path with topic `.mcs.yml` files

## Script

Save the following as `sync_live_to_local.py` and run with `python`:

```python
#!/usr/bin/env python3
import subprocess, json, urllib.request, sys, os, re
from urllib.parse import quote

# CONFIGURE THESE
BOT_ID = 'YOUR_BOT_GUID'
BASE   = 'https://YOUR_ORG.crm.dynamics.com/api/data/v9.2'
LOCAL_DIR = r'D:\path\to\topics'

# Auth
result = subprocess.run(
    ["powershell.exe", "-Command", 
     "az account get-access-token --resource '<org_url>' --query accessToken -o tsv"],
    capture_output=True, text=True, timeout=30
)
token = result.stdout.strip()
if not token:
    sys.exit("No token. Run az login first.")

headers = {
    'Authorization': f'Bearer {token}',
    'Accept': 'application/json',
    'OData-MaxVersion': '4.0',
}

# Fetch all botcomponents (componenttype=9 = topic)
filt = f"_parentbotid_value eq '{BOT_ID}' and componenttype eq 9"
url = f"{BASE}/botcomponents?$filter={quote(filt)}&$top=100"
req = urllib.request.Request(url, headers=headers)
data = json.loads(urllib.request.urlopen(req, timeout=60).read())
components = data['value']
print(f"Fetched {len(components)} live components")

def name_to_filename(name):
    import re
    fn = name.strip()
    fn = fn.replace('/', ' or ')
    fn = re.sub(r"[()'\"]", '', fn)
    fn = re.sub(r'\s+', '_', fn)
    fn = re.sub(r'_+', '_', fn).strip('_')
    return fn + '.mcs.yml'

os.makedirs(LOCAL_DIR, exist_ok=True)
written = set()
for c in components:
    name = c.get('name', 'Unknown')
    data_field = c.get('data', '')
    if not data_field:
        continue
    filename = name_to_filename(name)
    fpath = os.path.join(LOCAL_DIR, filename)
    with open(fpath, 'w', newline='\n') as f:
        f.write(data_field)
    written.add(filename.lower())
    print(f"  WRITE {filename}")

# Remove stale files
removed = []
for fname in os.listdir(LOCAL_DIR):
    if not fname.endswith('.mcs.yml'):
        continue
    if fname.lower() == 'agent.mcs.yml' or fname.startswith('.'):
        continue
    if fname.lower() not in written:
        os.remove(os.path.join(LOCAL_DIR, fname))
        removed.append(fname)
        print(f"  REMOVE {fname} (stale)")

print(f"\nWritten: {len(written)}, Removed: {len(removed)}")
```

## Also Sync GPT Instructions

Per Microsoft Learn, agent GPT instructions are stored in `botcomponents` with `componenttype=15` (Custom GPT). To extract:

```python
filt = f"_parentbotid_value eq '{BOT_ID}' and componenttype eq 15"
url = f"{BASE}/botcomponents?$filter={quote(filt)}&$select=botcomponentid,name,data"
```

Parse the `data` field YAML — extract the `instructions:` block (indented under `instructions: |-`).

## PPAPI Eval Token (for draft evals without publishing)

After syncing local from live, you may want to run evaluations on the draft agent (no publish needed). See `references/cdp-eval-token-capture.md` for the full CDP token capture + PPAPI eval workflow.

Key points:
1. Launch Chrome with `--remote-debugging-port=9223` (preserving user data dir for session)
2. Navigate to Copilot Studio eval page via raw CDP WebSocket
3. Run `cdp_capture_token.cjs` to capture PPAPI Bearer token
4. Use token against `https://api.powerplatform.com/copilotstudio/environments/{envId}/bots/{agentId}/api/makerevaluation`

## Known Pitfalls

- The `bots` entity's instruction fields (`overwriteinstructions`, `instructionstext`) may require different query syntax — test with `$select=botid,name&$top=5` first
- The Copilot Studio URL bot GUID IS the Dataverse bot ID for this environment — no translation needed
- Always `git status` after sync to see what changed
- Commit the backup state to git for traceability
