---
name: copilot-studio-chat-test
description: Test published Copilot Studio agents by sending chat messages and receiving responses via DirectLine or M365 SDK.
---

# Chat Test Agent

Test published Copilot Studio agents by sending messages and receiving responses.

## Step 1: Detect Auth Mode

```bash
node "D:/my agents copilot studio/pipeline/scripts/chat-with-agent.bundle.js" --detect-only [--agent-dir <path>]
```

Parse JSON output:
- **directline** mode (authenticationmode 1 or 3): no auth needed, use chat-directline
- **m365** mode (authenticationmode 2): integrated auth, use chat-sdk

### Missing `.mcs/conn.json` fallback
If `chat-with-agent.bundle.js --detect-only` fails with `No .mcs/conn.json found`, do not abandon the chat test if live metadata is already known. Create a minimal `<agent>/.mcs/conn.json` from trusted local manifest/Dataverse values, then re-run detect-only:

```json
{
  "EnvironmentId": "<environment-guid>",
  "AgentId": "<bot-guid>",
  "DataverseEndpoint": "https://<org>.crm.dynamics.com/",
  "AccountInfo": {
    "TenantId": "<tenant-guid>",
    "Username": "<signed-in-user-upn>"
  }
}
```

After creating it, run a focused ad-hoc verification with a temporary `hermes-verify-*.py` under the OS temp directory: validate JSON/expected IDs and run `chat-with-agent.bundle.js --detect-only --agent-dir <agent>`. Report this as ad-hoc verification, not full suite green, and clean up the temp script.

## Step 2a: DirectLine Chat (no auth / manual auth)

```bash
node "D:/my agents copilot studio/pipeline/scripts/directline-chat.bundle.js" send --workspace <path> --message <text> [--conversation-id <id>]
```

Multi-turn: reuse `conversation-id` from response in subsequent calls.

## Step 2b: M365 SDK Chat (integrated auth)

Requires Azure App Registration:
- Platform: Public client / Native
- Redirect URI: `http://localhost`
- API permissions: Power Platform API → `CopilotStudio.Copilots.Invoke`

Correct current bundled syntax is positional message + `--agent-dir`:
```bash
node "D:/my agents copilot studio/pipeline/scripts/chat-with-agent.bundle.js" "<message>" \
  --agent-dir <path> \
  --client-id <id> \
  [--conversation-id <id>]
```

Do not use `send --workspace ... --message ...` unless the script has been updated to support that syntax; older bundles parse it incorrectly and may select `pipeline/templates/agents`.

### Integrated-auth permission blocker
If the user cannot complete Microsoft/device-code sign-in or says they do not have access, stop generating repeated device codes. First verify detect-only, then diagnose permissions. Existing PAC/Azure tokens may list/patch/publish the bot but still fail live chat invocation with `InsufficientDelegatedPermissions` because the app/caller lacks delegated `CopilotStudio.Copilots.Invoke`.

Detailed raw-endpoint diagnostic and message wording: `references/integrated-auth-invoke-permissions.md`.

When the user asks for a workaround because the UI worked previously, use the decision tree in `references/integrated-auth-workaround-decision-tree.md`: prefer Copilot Studio UI/evaluation/test-pane automation with a real browser session; only do a temporary auth/channel flip after explicit approval and with a rollback plan.

Repair boundary:
- Try to inspect/create an app registration only if the user asks to fix invocation permissions.
- If `az ad app create` fails with `Insufficient privileges to complete the operation`, do not keep trying local workarounds; the fix requires an Entra admin or an existing app registration with the Power Platform API delegated `CopilotStudio.Copilots.Invoke` scope.
- Do not silently switch a live integrated-auth bot to no-auth/DirectLine for testing. That changes security posture; require explicit user approval and a rollback plan.

## Error Handling
  --client-id <id> \
  [--conversation-id <id>]
```

If the workspace was not cloned by the VS Code extension and is missing `.mcs/conn.json`, create the minimal metadata file from the manifest/live bot data, then verify with `--detect-only`. See `references/m365-chat-auth-and-conn-json.md`.

If localhost browser auth stalls, seed the `test-agent` cache with the device-code helper from `copilot-studio-run-eval` using a PTY-backed process, then rerun the chat command. Device codes expire quickly; restart the helper for a fresh code rather than troubleshooting an expired one.

## Verification

After adding `.mcs/conn.json` or changing local chat metadata, and when no canonical test/lint suite exists, create a temporary `hermes-verify-*.py` script under the OS temp directory. It should validate the JSON fields and run `chat-with-agent.bundle.js --detect-only --agent-dir <agentDir>`. Clean up the temp script and report the result as **ad-hoc verification**, not suite green.

## Error Handling
  --agent-dir "<agent workspace>" \
  --client-id <id> \
  [--conversation-id <id>]
```

If this starts a localhost interactive login, run it with a PTY/background process while the browser sign-in completes. Preserve the full auth URL query string when opening it; if it hangs or Microsoft login strips parameters, seed the `test-agent` MSAL cache with the device-code helper from `copilot-studio-run-eval` and retry the chat command.

## Reference Details

- `references/m365-chat-conn-json-and-auth.md` — tested fallback for reconstructing `.mcs/conn.json`, correct M365 chat command syntax, device-code/PTY auth pitfalls, and ad-hoc verification expectations.

## Error Handling

| Error | Cause | Resolution |
|---|---|---|
| No `agent.mcs.yml` | No agent in workspace | Clone agent first |
| No `.mcs/conn.json` | Not cloned via VS Code | Clone with VS Code Copilot Studio extension |
| Token expired | Auth token expired | Re-authenticate |
| `No .mcs/conn.json found` | Workspace was not cloned through VS Code extension or metadata file is missing | Create minimal `.mcs/conn.json` from known tenant/environment/agent/Dataverse values, then run detect-only as ad-hoc verification |
| Command selects `pipeline/templates/agents` | Used unsupported `send --workspace` syntax with older bundled script | Use positional message + `--agent-dir <agent path>` |
| Raw chat endpoint returns `403 InsufficientDelegatedPermissions` | Caller/app can access Dataverse/PAC but lacks delegated invoke permission for integrated-auth chat | Stop auth loops; require account/app with `CopilotStudio.Copilots.Invoke`, or test through UI/Teams/DirectLine alternative |
