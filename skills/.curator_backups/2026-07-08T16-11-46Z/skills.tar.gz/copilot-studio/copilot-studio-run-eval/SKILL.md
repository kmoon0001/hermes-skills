---
name: copilot-studio-run-eval
description: "Run evaluations against Copilot Studio agent's DRAFT via PPAPI — no publish needed. List test sets, start runs, poll, fetch results, propose fixes."
version: 1.0.0
author: Copilot Studio Pipeline
license: MIT
platforms: [windows, linux, macos]
metadata:
  hermes:
    tags: [copilot-studio, evaluation, ppapi, draft-eval]
    homepage: https://learn.microsoft.com/microsoft-copilot-studio/
---

# Run Evaluation (PPAPI)

Run evaluations against Copilot Studio agent's DRAFT — no publish needed.
Requires --client-id and --workspace. If no client ID, tell caller to run test-auth first.
All eval-api commands normally run in foreground. If a command prints `No cached token — starting interactive login`, use a PTY-backed interactive run so the local redirect listener stays alive while the user signs in directly in the browser. Do not ask the user to paste credentials or MFA codes in chat. If backgrounding is required to keep working while auth waits, use `pty=true` and poll the process; non-PTY background auth can fail with `stdin is not a tty`.

## Practice Notes (Updated Jul 6 2026)

**Two viable auth paths exist for PPAPI in this tenant:**
1. **Manage-agent MSAL cache (preferred)** — `@azure/msal-node-extensions` `PersistenceCreator` silently decrypts the DPAPI-encrypted `manage-agent.cache.json`. No browser, no CDP, no interactive login. Runs from the pipeline `node_modules` directory. See "Auth via Manage-Agent MSAL Cache" below.
2. **CDP WebSocket capture (fallback)** — Captures Bearer token from an already-authenticated browser tab via Chrome DevTools Protocol. Used when the manage-agent cache is unavailable.

Old OBO flows that still fail with specific errors:
- Interactive redirect: `AADSTS50011` (redirect URI mismatch on app `96ff4394-9197-43aa-b393-6a41652e21f8`)
- Device code: blocked by tenant Conditional Access
- Azure CLI / VS Code tokens: 403 `InsufficientDelegatedPermissions`

### CDP Chrome Launch Pattern (preferred for fresh PPAPI token capture)

When no browser is running with `--remote-debugging-port`, launch a separate Chrome instance:
1. `mcp_cua_driver_launch_app(path="C:\\Users\\kevin\\AppData\\Local\\Google\\Chrome SxS\\Application\\chrome.exe", additional_arguments=["--remote-debugging-port=9223"])`
2. Verify CDP: `curl -s http://127.0.0.1:9223/json/version`
3. Navigate to eval page via CDP `Page.navigate` → wait ~10s → `node scripts/cdp_capture_token.cjs`
4. Token at `~/.copilot-studio-cli/test-agent-token.txt`

**PITFALL — Use default Chrome Canary user data dir to preserve Copilot Studio sessions.** Path: `C:\\Users\\kevin\\AppData\\Local\\Google\\Chrome SxS\\User Data`. A fresh `--user-data-dir` requires re-auth.

**PITFALL — `cdp_capture_token.cjs` searches for "evaluation" in the URL.** Navigate to the eval page directly, not the topics or overview tab.

**PITFALL — `browser_navigate` truncates long OAuth URLs** (drops `&scope=` → `AADSTS900144`). Use `browser_console` with `window.location.href` or CDP `Page.navigate` instead.

**PITFALL — `cdp_ws_capture.cjs` has a hardcoded TARGET_ID** that only works on the machine it was captured on. Use `scripts/cdp_capture_token.cjs` — finds eval tab by URL pattern, not hardcoded ID.

**PITFALL — CDP Chrome launch: when no browser is running with `--remote-debugging-port`, launch a separate Chrome instance with the flag. Use `mcp_cua_driver_launch_app` with `--remote-debugging-port=9223` and a fresh `--user-data-dir=...` profile. The existing Chrome instance is unaffected. Verify with `curl -s http://127.0.0.1:9223/json/version`.

**PITFALL — `browser_navigate` truncates long OAuth URLs with query params.** The tool drops everything after the first `&` in some cases, producing `AADSTS900144: The request body must contain the following parameter: 'scope'`. Fix: use `browser_console` to set `window.location.href = '<full URL>'` instead. The full URL including all `&scope=`, `&state=`, `&code_challenge=` params must be preserved.

**PITFALL — CDP token capture requires an EVAL tab, not just any Copilot Studio tab.** The `cdp_capture_token.cjs` script searches for tabs with "evaluation" in the URL. If the browser only has a Topics or Overview tab open, the capture fails with "Eval tab not found." Fix: navigate any Copilot Studio CDP tab to the evaluation page URL first, wait for SPA to load (~30s), then run the capture.

**PITFALL — PPAPI token expiry is ~15 minutes in practice, not 1 hour.** Strategy: capture the token, run ALL test set list operations immediately, then start runs, then poll — re-capture if a 401 appears before polling completes. Re-capture via CDP is fast (~15s).

**PITFALL — SPA text returns 0 chars when SPA hasn't finished hydrating.** Wait 60s after navigation before reading. Don't use Fetch interception for SPA extraction — use a clean tab.

**PITFALL — Unconditional eval instruction blocks cause Conv regression.** "Respond directly" and "Don't ask follow-ups" as unconditional rules drop conversational scores ~20pp. Eval instructions MUST be conditional per MS Learn. Re-run both SR+Conv after changing eval instructions.

**PITFALL — SR and Conv for the same agent must be sequential.** PPAPI enforces one active run per agent at a time. Different agents CAN run simultaneously.

### Auth fallback: device-code cache seeding
If localhost redirect/browser auth gives Microsoft sign-in errors, query parameters get dropped, or the user reports trouble signing in, do not keep looping the same URL. Two fallback paths exist:

**Path A (recommended): CDP WebSocket token capture from browser** — See `references/cdp-ppapi-token-capture.md`. Captures the live Bearer token from an already-authenticated browser tab via Chrome DevTools Protocol. Faster than device-code and bypasses tenant Conditional Access blocks. Requires browser running with `--remote-debugging-port=9223`.

**Path B: Device-code MSAL cache seeding** — Use the bundled helper script.

**PITFALL — redirect URI mismatch (AADSTS50011):** The interactive localhost redirect can fail with `AADSTS50011: The redirect URI 'http://localhost:<port>' specified in the request does not match the redirect URIs configured for the application`. MSAL Node's LoopbackClient chooses a random port, but the Azure app registration may only have specific ports or no localhost URIs. If you see this, the interactive flow is dead for that client — do not retry with different ports (they all fail the same way).

**PITFALL — tenant Conditional Access blocks device-code flow:** If `https://login.microsoft.com/device` returns "you don't have access", the tenant policy blocks device-code authentication. The device-code helper will sit at `device_code` status forever — kill it. Do not retry device code after a tenant-access denial.

**PITFALL — both localhost redirect AND device-code blocked:** When both interactive redirect (AADSTS50011) and device-code (Conditional Access) fail, all automated OAuth paths for the PPAPI client are exhausted. Fall back to manual token capture (see below). Do not loop retrying either flow.

### Automated CDP WebSocket token capture (use `scripts/cdp_capture_token.cjs`)

When both `eval-api.bundle.js` interactive login AND device-code seeding are blocked, use the CDP WebSocket script to capture the token automatically from the user's already-signed-in browser:

```bash
node scripts/cdp_capture_token.cjs
```

**PITFALL — do NOT use `cdp_ws_capture.cjs` or `cdp_simple.cjs`:** Both have hardcoded identifiers from a previous session. `cdp_capture_token.cjs` finds the eval tab by URL pattern instead.

With the token, call PPAPI endpoints directly via `curl` or Python `urllib`. Do NOT attempt to write into the DPAPI-encrypted MSAL cache file. Token expires after ~1 hour.

**Verified**: Jul 1, 2026 — Chrome 149, 4487-char token, Therapy Documentation Feedback Agent (Prod).

### Manual browser DevTools token capture (fallback)

If CDP isn't available, ask the user to extract the Bearer token manually:

1. Have the user open the Copilot Studio Evaluation page in their signed-in browser:
   `https://copilotstudio.microsoft.com/environments/<envId>/bots/<botId>/evaluation`
2. Press F12 → Network tab
3. Refresh the page (F5)
4. Filter by `makerevaluation`
5. Click any request, go to Headers → Request Headers
6. Copy the full `Authorization: Bearer eyJ...` header value
7. Paste the token back to the agent

With the raw token, call PPAPI endpoints directly:
```bash
curl -H "Authorization: Bearer <token>" \
  "https://api.powerplatform.com/copilotstudio/environments/<envId>/bots/<botId>/api/makerevaluation/testsets?api-version=2024-10-01"
```
## Practice Notes (Updated Jul 6 2026)

**Two viable auth paths exist for PPAPI in this tenant:**
1. **Manage-agent MSAL cache (preferred)** — `@azure/msal-node-extensions` `PersistenceCreator` silently decrypts the DPAPI-encrypted `manage-agent.cache.json`. No browser, no CDP, no interactive login. Runs from the pipeline `node_modules` directory. See "Auth via Manage-Agent MSAL Cache" below.
2. **CDP WebSocket capture (fallback)** — Captures Bearer token from an already-authenticated browser tab via Chrome DevTools Protocol. Used when the manage-agent cache is unavailable.

Old OBO flows that still fail with specific errors:
- Interactive redirect: `AADSTS50011` (redirect URI mismatch on app `96ff4394-9197-43aa-b393-6a41652e21f8`)
- Device code: blocked by tenant Conditional Access
- Azure CLI / VS Code tokens: 403 `InsufficientDelegatedPermissions`

### CDP Chrome Launch Pattern (preferred for fresh PPAPI token capture)

When no browser is running with `--remote-debugging-port`, launch a separate Chrome instance:
1. `mcp_cua_driver_launch_app(path="C:\\Users\\kevin\\AppData\\Local\\Google\\Chrome SxS\\Application\\chrome.exe", additional_arguments=["--remote-debugging-port=9223"])`
2. Verify CDP: `curl -s http://127.0.0.1:9223/json/version`
3. Navigate to eval page via CDP `Page.navigate` → wait ~10s → `node scripts/cdp_capture_token.cjs`
4. Token at `~/.copilot-studio-cli/test-agent-token.txt`

**PITFALL — Use default Chrome Canary user data dir to preserve Copilot Studio sessions.** Path: `C:\\Users\\kevin\\AppData\\Local\\Google\\Chrome SxS\\User Data`. A fresh `--user-data-dir` requires re-auth.

**PITFALL — `cdp_capture_token.cjs` searches for "evaluation" in the URL.** Navigate to the eval page directly, not the topics or overview tab.

**PITFALL — `browser_navigate` truncates long OAuth URLs** (drops `&scope=` → `AADSTS900144`). Use `browser_console` with `window.location.href` or CDP `Page.navigate` instead.

**PITFALL — `cdp_ws_capture.cjs` has a hardcoded TARGET_ID** that only works on the machine it was captured on. Use `scripts/cdp_capture_token.cjs` — finds eval tab by URL pattern, not hardcoded ID.

**PITFALL — CDP Chrome launch: when no browser is running with `--remote-debugging-port`, launch a separate Chrome instance with the flag. Use `mcp_cua_driver_launch_app` with `--remote-debugging-port=9223` and a fresh `--user-data-dir=...` profile. The existing Chrome instance is unaffected. Verify with `curl -s http://127.0.0.1:9223/json/version`.

**PITFALL — `browser_navigate` truncates long OAuth URLs with query params.** The tool drops everything after the first `&` in some cases, producing `AADSTS900144: The request body must contain the following parameter: 'scope'`. Fix: use `browser_console` to set `window.location.href = '<full URL>'` instead. The full URL including all `&scope=`, `&state=`, `&code_challenge=` params must be preserved.

**PITFALL — CDP token capture requires an EVAL tab, not just any Copilot Studio tab.** The `cdp_capture_token.cjs` script searches for tabs with "evaluation" in the URL. If the browser only has a Topics or Overview tab open, the capture fails with "Eval tab not found." Fix: navigate any Copilot Studio CDP tab to the evaluation page URL first, wait for SPA to load (~30s), then run the capture.

**PITFALL — PPAPI token expiry is ~15 minutes in practice, not 1 hour.** Strategy: capture the token, run ALL test set list operations immediately, then start runs, then poll — re-capture if a 401 appears before polling completes. Re-capture via CDP is fast (~15s).

**PITFALL — SPA text returns 0 chars when SPA hasn't finished hydrating.** Wait 60s after navigation before reading. Don't use Fetch interception for SPA extraction — use a clean tab.

**PITFALL — Unconditional eval instruction blocks cause Conv regression.** "Respond directly" and "Don't ask follow-ups" as unconditional rules drop conversational scores ~20pp. Eval instructions MUST be conditional per MS Learn. Re-run both SR+Conv after changing eval instructions.

**PITFALL — SR and Conv for the same agent must be sequential.** PPAPI enforces one active run per agent at a time. Different agents CAN run simultaneously.

### Auth fallback: device-code cache seeding
If localhost redirect/browser auth gives Microsoft sign-in errors, query parameters get dropped, or the user reports trouble signing in, do not keep looping the same URL. Two fallback paths exist:

**Path A (recommended): CDP WebSocket token capture from browser** — See `references/cdp-ppapi-token-capture.md`. Captures the live Bearer token from an already-authenticated browser tab via Chrome DevTools Protocol. Faster than device-code and bypasses tenant Conditional Access blocks. Requires browser running with `--remote-debugging-port=9223`.

**Path B: Device-code MSAL cache seeding** — Use the bundled helper script.

Use the bundled helper in this skill as a template/copy target:
`scripts/device-code-auth.cjs`

When running the device-code helper through Hermes/background process tooling, use a PTY (`pty=true`). Without a TTY the helper can exit immediately with `stdin is not a tty`. Prefer a tracked background process with `notify_on_complete=true`, then poll for the JSON payload containing `verificationUri` and `userCode`.

Important cache details:
- `eval-api.bundle.js` with explicit `--client-id` uses cache slot `test-agent`.
- Cache path is `%USERPROFILE%\\.copilot-studio-cli\\test-agent.cache.json`.
- Scope for PPAPI evals is `https://api.powerplatform.com/.default`
- If the helper is copied to `%TEMP%`, normal `require()` may not resolve the pipeline's `node_modules`; use the script's optional final argument pointing at the pipeline `package.json` (or use `createRequire('D:/.../pipeline/package.json')`).
- Device codes expire quickly, usually in 15 minutes. If the process exits with `device_code_expired`, do not troubleshoot the old code; immediately restart the helper and give the user the fresh `verificationUri` + `userCode`.

### Auth fallback: CDP WebSocket token capture (when ALL MSAL flows are blocked)

If ALL MSAL-based flows fail — interactive redirect gives `AADSTS50011` (redirect URI mismatch on app `96ff4394-9197-43aa-b393-6a41652e21f8`), device-code shows "You don't have access" (tenant Conditional Access), and VS Code/Azure CLI tokens return 403 `InsufficientDelegatedPermissions` — use CDP WebSocket capture to extract the token directly from the user's signed-in browser.

**The evaluation-rest-api skill has the full recipe** (`skill_view('evaluation-rest-api')`, Method B section) and the working script at `scripts/cdp_ws_capture.cjs`. Summary:

1. Verify CDP is available: `curl -s http://127.0.0.1:9223/json/version`
2. Find the Copilot Studio eval tab: `curl -s http://127.0.0.1:9223/json/list | python -c "..."` 
3. Run the capture script via PowerShell: `powershell.exe -NoProfile -Command "node <skill-dir>/scripts/cdp_ws_capture.cjs"`
4. Token lands at `%USERPROFILE%\\.copilot-studio-cli\\test-agent-token.txt`
5. Use the token directly with PPAPI: `Authorization: Bearer <token>` against `https://api.powerplatform.com/copilotstudio/environments/<env>/bots/<agent>/api/makerevaluation/...`

Do NOT keep retrying `eval-api.bundle.js` or device-code when these specific error codes appear. Go directly to CDP capture.
- If the helper is copied to `%TEMP%`, normal `require()` may not resolve the pipeline's `node_modules`; use the script's optional final argument pointing at the pipeline `package.json` (or use `createRequire('D:/.../pipeline/package.json')`).
- Device codes expire quickly, usually in 15 minutes. If the process exits with `device_code_expired`, do not troubleshoot the old code; immediately restart the helper and give the user the fresh `verificationUri` + `userCode`.

Example from the pipeline checkout:
```bash
cd "D:/my agents copilot studio/pipeline"
node "C:/Users/kevin/AppData/Local/hermes/profiles/coding-profile/skills/copilot-studio/copilot-studio-run-eval/scripts/device-code-auth.cjs" \
  <tenant-id> \
  96ff4394-9197-43aa-b393-6a41652e21f8 \
  https://api.powerplatform.com/.default \
  test-agent \
  "D:/my agents copilot studio/pipeline/package.json"
```
Give the user only `verificationUri` and `userCode`; never ask for passwords or MFA codes in chat. When the helper prints `status: ok`, rerun `list-testsets` or `start-run`; it should use the cached token.

## Step 1: List test sets

**PITFALL — missing IDs when no `.mcs/conn.json`:** `eval-api.bundle.js` needs `--agent-id`, `--tenant-id`, and `--environment-id` if the workspace lacks `.mcs/conn.json`. Without them it fails sequentially with "Cannot determine agent/tenant/environment ID". Provide all three explicitly. Find the environment GUID with `pac env list` (look for the org name in the "Display Name" column). Find the agent Copilot ID with `pac copilot list`.

### Direct PPAPI via Python (preferred over eval-api.bundle.js)

When the CDP token is captured to `test-agent-token.txt`, skip `eval-api.bundle.js` entirely and call the PPAPI directly. This avoids ALL MSAL auth issues (redirect URI mismatch, device-code blocks, interactive login timeouts).

**PITFALL — `GET /testruns/{id}` detail endpoint may return 404 `RouteNotFound`:** The PPAPI `api.powerplatform.com/copilotstudio/environments/.../api/makerevaluation/testruns/{id}` detail endpoint returns RouteNotFound for some tenants/regions (known public-preview regional rollout issue). The LIST endpoint (`?$top=3`) works fine, but getting scores via the detail endpoint fails. When this happens:
- Accept that per-case detail is unavailable
- Fall back to SPA eval score extraction via CDP `Runtime.evaluate` (see section above)
- Do NOT mistake "no API access" for "scored 0%"

```python
import json, urllib.request, pathlib, os

token = pathlib.Path(os.path.expandvars(r'%USERPROFILE%\\.copilot-studio-cli\\test-agent-token.txt')).read_text().strip()
env_id = "<environment-guid>"
agent_id = "<bot-guid>"
api_ver = "2024-10-01"
base = f"https://api.powerplatform.com/copilotstudio/environments/{env_id}/bots/{agent_id}/api/makerevaluation"

# List test sets
url = f"{base}/testsets?api-version={api_ver}"
req = urllib.request.Request(url)
req.add_header("Authorization", f"Bearer {token}")

with urllib.request.urlopen(req, timeout=30) as resp:
    data = json.loads(resp.read())
for ts in data.get('value', []):
    print(f"  {ts['displayName']} | {ts['totalTestCases']} cases | ID: {ts['id']}")

# Start run
testset_id = "<testset-id>"
url2 = f"{base}/testsets/{testset_id}/run?api-version={api_ver}"
body = {"runOnPublishedBot": False, "mcsConnectionId": "<connection-id>"}  # omit mcsConnectionId if none
req2 = urllib.request.Request(url2, method="POST")
req2.add_header("Authorization", f"Bearer {token}")
req2.add_header("Content-Type", "application/json")
req2.data = json.dumps(body).encode()

with urllib.request.urlopen(req2, timeout=30) as resp:
    run = json.loads(resp.read())
print(f"Run: {run['runId']} | State: {run['state']}")

# Poll until complete
run_id = run['runId']
for i in range(15):
    time.sleep(30)
    url3 = f"{base}/testruns/{run_id}?api-version={api_ver}"
    req3 = urllib.request.Request(url3)
    req3.add_header("Authorization", f"Bearer {token}")
    with urllib.request.urlopen(req3, timeout=30) as resp:
        d = json.loads(resp.read())
    if d['state'] in ('Completed', 'Failed', 'Cancelled'):
        results = d.get('testCasesResults', [])
        passed = sum(1 for x in results if x['metricsResults'][0]['result']['status'] == 'Pass')
        failed = len(results) - passed
        abstains = sum(1 for x in results if x['metricsResults'][0]['result'].get('data',{}).get('abstention') == 'Yes')
        print(f"DONE: {passed}P/{failed}F = {passed*100/len(results):.0f}% | Abstains: {abstains}/{len(results)}")
        break
    print(f"  {(i+1)*30}s: {d['state']}")
```

**Key advantage:** No Node.js dependency, no MSAL cache, no redirect URI issues. 

**PITFALL — PPAPI token expiry is ~15 minutes in practice, not 1 hour.** Verified Jul 3 2026 in Therapy AI Dev: the token captured via CDP expired within ~15 minutes, returning 401 `TokenExpired`. The documented ~1 hour lifetime may apply to production environments only. Strategy: capture the token, run ALL test set list operations immediately (fast), then start runs, then poll — re-capture if a 401 appears before polling completes. Re-capture via CDP is fast (~15 seconds) as long as the Copilot Studio eval tab is still open in the browser.

**Token expiration handling:** If PPAPI returns 401 `TokenExpired`, re-run the CDP capture script to get a fresh token. The Copilot Studio eval tab in the user's browser must still be open.

Verification pitfall: after eval/push-related YAML edits, if there is no canonical test suite, create and run a temporary `hermes-verify-*.py` verifier under the user's temp directory, validate changed YAML plus the active workspace, clean it up, and report it as ad-hoc verification rather than suite green. See `references/live-auth-url-and-verification.md`.

Active-agent/connection pitfall: before push/eval, verify the live active/provisioned agent rather than trusting `.mcs/conn.json`; local connection files may point at a managed/inactive/deprovisioned legacy agent or fail due to BOM JSON parsing. See `references/stale-conn-active-agent-eval-push.md`.

### Interactive auth URL handling pitfall
When opening the Microsoft auth URL from tool/browser automation, preserve the full query string. If the browser opens a Microsoft error such as `AADSTS900144: The request body must contain the following parameter: 'scope'`, the URL was truncated or `&scope=...` was dropped. Retry by assigning the full URL through page JavaScript (`window.location.href = '<full URL>'`) or by opening it in the user's local default browser (`os.startfile(url)` on Windows) while the PTY auth listener remains running. Do not ask the user to paste credentials; have them complete sign-in/MFA directly in the browser, then poll the eval process for completion.

## Step 1: List test sets
```bash
node "D:/my agents copilot studio/pipeline/scripts/eval-api.bundle.js" list-testsets --workspace <path> --client-id <id>
```
- No test sets: tell user to create one in Copilot Studio (Evaluate tab > New evaluation). Stop.
- One test set: tell user which one and proceed.
- Multiple: show all and ask user to pick.

## Step 2: Ask about authenticated execution — MANDATORY
Ask user: Does your agent use authenticated knowledge sources or connector actions?
If so, they need a connection ID from https://make.powerautomate.com -> Connections -> Microsoft Copilot Studio connection -> copy connection ID from URL.
Without connection ID, eval runs anonymously and tools/knowledge will NOT be used.
Do NOT proceed until user responds.

**PITFALL — connection ID doesn't always fix abstention:** Even with a valid connection ID from Power Automate, pass rates may not improve if the test set questions fall outside the agent's KB scope. The agent's guardrails (e.g., SOURCE RESTRICTION) will still cause it to abstain when questions don't match KB content. If connection-ID and no-connection-ID runs produce identical pass rates (verified Jul 2026: Therapy Documentation Feedback Agent, 16% both ways), the root cause is test set/agent scope misalignment, not missing auth. Investigate test case content before retrying with different connection IDs.

## Step 3: Start the run
```bash
node "D:/my agents copilot studio/pipeline/scripts/eval-api.bundle.js" start-run --workspace <path> --client-id <id> --testset-id <id> --run-name "Draft eval <date>"
```
Add --connection-id <id> if user provided one. Add --published only if user explicitly asked.

## Step 4: Poll until complete
```bash
node "D:/my agents copilot studio/pipeline/scripts/eval-api.bundle.js" get-run --workspace <path> --client-id <id> --run-id <runId>
```
Poll every 15-30 seconds. Report progress. Stop when state is Completed, Failed, Abandoned, or Cancelled.

### SPA eval score extraction via CDP (when PPAPI detail endpoint is broken)

When `GET /testruns/{id}` returns 404 `RouteNotFound` (known regional PPAPI rollout issue — the list endpoint works but detail fails), scores are still visible in the Copilot Studio Evaluation SPA. Extract them via CDP `Runtime.evaluate`:

1. Open the evaluation page in a CDP-enabled browser (port 9223)
2. Run this from a Node.js environment:
```javascript
const http = require('http');
const WebSocket = require('ws');

http.get('http://127.0.0.1:9223/json/list', res => {
  let d = '';
  res.on('data', c => d += c);
  res.on('end', () => {
    const pages = JSON.parse(d);
    const target = pages.find(p => p.url && p.url.includes('copilotstudio') && p.url.includes('evaluation'));
    if (!target) { console.log('Eval tab not found'); return; }
    const ws = new WebSocket(target.webSocketDebuggerUrl);
    ws.on('open', () => {
      ws.send(JSON.stringify({id:1, method:'Runtime.evaluate',
        params:{expression:'document.body.innerText'}}));
    });
    ws.on('message', raw => {
      const msg = JSON.parse(raw.toString());
      if (msg.id === 1) {
        const text = msg.result?.result?.value || '';
        // Parse scores: look for "N%" near "single response" or "conversation" markers
        const lines = text.split('\n');
        lines.forEach(l => console.log(l));
        ws.close();
      }
    });
  });
});
```
3. Parse the output — each run row has: `{name} | {cases} cases • Data type: {SR|Conv} | {author} | {score}%`

See `references/cdp-spa-eval-extraction.md` for full details and score parsing patterns.

**Limitation:** SPA extraction gives score-level data only (General Quality %). Per-case failure details and aiResultReason strings require the PPAPI detail endpoint — accept score-level data when the API is broken.

### Auth via Manage-Agent MSAL Cache (no browser needed)

The `manage-agent.cache.json` at `~/.copilot-studio-cli/manage-agent.cache.json` is populated by `pac auth` and the VS Code Copilot Studio extension. It can be read by `@azure/msal-node-extensions` `PersistenceCachePlugin` to silently acquire tokens for BOTH PPAPI and Dataverse scopes. This bypasses all CDP, redirect-URI, and device-code auth headaches.

**PITFALL — This only works for the same Windows user that ran `pac auth create`.** The cache is DPAPI-encrypted per-user.

```javascript
const { PublicClientApplication } = require('@azure/msal-node');
const { PersistenceCreator, PersistenceCachePlugin, DataProtectionScope }
  = require('@azure/msal-node-extensions');

const CACHE = path.join(os.homedir(),'.copilot-studio-cli','manage-agent.cache.json');
const TENANT = '<tenant-guid>';
const CLIENT = '51f81489-12ee-4a9e-aaae-a2591f45987d'; // Power Platform CLI

async function getToken(scope) {
  const p = await PersistenceCreator.createPersistence({
    cachePath: CACHE, dataProtectionScope: DataProtectionScope.CurrentUser,
    serviceName: 'copilot-studio-cli', accountName: 'manage-agent',
    usePlaintextFileOnLinux: true
  });
  const app = new PublicClientApplication({
    auth: { clientId: CLIENT, authority: `https://login.microsoftonline.com/${TENANT}` },
    cache: { cachePlugin: new PersistenceCachePlugin(p) }
  });
  const accs = (await app.getTokenCache().getAllAccounts())
    .filter(a => a.tenantId === TENANT);
  const r = await app.acquireTokenSilent({ scopes: [scope], account: accs[0] });
  return r.accessToken;
}
```

**Get PPAPI token (for eval gateway via PowerVA gateway — must use this scope):**
```javascript
const ppapiToken = await getToken('api://96ff4394-9197-43aa-b393-6a41652e21f8/.default');
```

**PITFALL — Scope MUST be `api://96ff4394-.../.default` for gateway API calls.** Using `https://api.powerplatform.com/.default` triggers `AADSTS500131: Assertion audience does not match` (400 Bad Request). The manage-agent cache's refresh token was issued for the `96ff4394` (Power Virtual Agents) application, not the broader PPAPI audience.

**Get Dataverse token (for PATCHing instructions & topic YAML):**
```javascript
const dvToken = await getToken('https://<org>.crm.dynamics.com/.default');
// Use with: Authorization: Bearer <dv_token> against https://<org>.crm.dynamics.com/api/data/v9.2
```

**Why both are needed:** The PPAPI scope works for eval/gateway endpoints. The Dataverse scope works for PATCHing `botcomponent.data` (instructions, topic YAML). Neither scope covers the other, and CDP-captured tokens are only PPAPI-scoped.

**Run from pipeline context** so `node_modules` resolves. `node -e` works directly for silent MSAL (no `echo "" |` prefix needed — that's only for OBO/interactive flows):
```bash
cd "D:/my agents copilot studio/pipeline"
node -e "...inline script..."
**PITFALL — publish via Gateway REST API returns 404.** The endpoint `POST .../publish` on the PowerVA gateway returns 404 for all publish operations. Use `pac copilot publish --bot <bot-id>` instead — it works reliably. Verify with `pac copilot list` to check PublishedOn timestamp. Active eval runs block publish — either wait for completion or cancel via `PATCH .../makerevaluations/{runId}/cancel` first.ting from the live Copilot Studio Evaluation UI, use the PowerVA gateway API:
- Capture the live Evaluation page's `authorization` and `x-cci-*` headers via CDP WebSocket.
- **ALL requests require X-CCI routing headers** — see `references/gateway-eval-api-recipe.md` for exact values and copy-paste curl commands.
- `GET /makerevaluations/testsets` lists test sets.
- `GET /makerevaluations?count=10` lists runs (returns JSON array, not `{value: [...]}`). Use this as the durable polling fallback: start a run, then poll the list endpoint and match by `id`/`runId` when direct run endpoints fail.
- `POST /makerevaluations` starts a run by `testSetId`.
- Scores via `aggregatedGraderResults[]` — `MakerEvaluationRunCountMetric` objects with `name` (totalSucceeded/totalFailed/...) and `count`.
- `GET /makerevaluations/{runId}/details` fetches full case details and is the preferred source for progress/result analysis. If a custom poller gets `405 Method Not Allowed`, switch to `/details` rather than continuing to retry the failing endpoint.
- In `/details`, score General Quality from `details.testCases[].graderMetrics.queryResponseMetrics[]`: pass only when relevance=Yes, completeness=Yes, abstention=No, and groundedness is absent or Yes.
- `PATCH /makerevaluations/{runId}/cancel` cancels an active run. Body: `{ "evaluationRunId": "<runId>" }`. Response returns the updated run object with state=Cancelled. After canceling, verify with GET — queue is clear when no InProgress runs remain.
- Eval queue management (validated Jul 5 2026): When stale evals queue up, cancel ALL InProgress runs, verify clear, then start ONE fresh eval.
- PITFALL — pac CLI caches publish failures permanently. After a publish fails, pac copilot publish returns the SAME failure timestamp forever even with fresh auth. Verify actual publish state with GET /bots/{id}?$select=publishedon on Dataverse.

Also see `references/live-gateway-details-quota-and-guardrails.md` for quota handling and guardrail validation.

Important quota nuances:
- Active-run limit is per agent. SR and Conv for the same agent must be sequential, but different agents can have active runs at the same time.
- Active-run block error: `fairusagepolicy.botactiverunquotaviolated`.
- Daily quota block error: `fairusagepolicy.botrunquotaviolated` with message similar to `The agent has been evaluated more than 20 times in the last 24 hours. Please wait before trying again.` Stop launching and record handoff when this appears; do not burn time retrying until the 24-hour window resets.

Guardrail-patch validation:
- When inserting static `ConditionGroup` / `SendActivity` guardrails or replacing `additionalInstructions`, validate generated `.after.yml` backups before running another eval. A common regression is malformed indentation under `additionalInstructions: |-`, causing YAML `ScannerError` and potentially invalid topic data. See `references/live-gateway-details-quota-and-guardrails.md`.

Eval-set migration and connector-free draft eval pitfall:
- When copying evals between bots, copy both `EvaluationSet` rows and case rows, then link cases with the exact Dataverse navigation property `ParentBotComponentId@odata.bind`; otherwise gateway shows 0-case set shells. See `references/eval-set-migration-and-connector-free-draft-evals.md`.
- If `/details` shows `Let's get you connected first...`, `FlowNotFound`, or later multi-turn queries falling into Greeting/Fallback/Conversational Boosting, patch connector-free in-scope responses across those interceptors before spending more quota. First-turn fixes alone do not solve multi-turn evals.

## Step 5: Fetch and analyze results
```bash
node "D:/my agents copilot studio/pipeline/scripts/eval-api.bundle.js" get-results --workspace <path> --client-id <id> --run-id <runId>
```
Present summary table (total, passed, failed, errors). For failures:
| Metric | What to check |
| GeneralQuality Fail | Which of relevance/completeness/groundedness/abstention failed |
| ExactMatch Fail | Score 0.0-1.0 |
| CapabilityUse Fail | missingInvocationSteps |
| Error status | errorReason — often test set config issue |

## Step 6: Propose fixes
For YAML authoring failures: find relevant topic, read it, propose specific edits. Wait for user approval.
After applying: offer to push and re-run (go back to Step 3).
