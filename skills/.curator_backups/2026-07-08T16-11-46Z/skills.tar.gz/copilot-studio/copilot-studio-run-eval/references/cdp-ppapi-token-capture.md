# CDP WebSocket PPAPI Token Capture

When device-code flow is blocked by tenant policy and localhost redirect fails (AADSTS50011), capture the PPAPI token from an already-authenticated browser via Chrome DevTools Protocol WebSocket.

## Prerequisites

Browser must be running with remote debugging enabled:
```powershell
# Edge (preserves user profile auth cookies):
Start-Process 'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe' -ArgumentList '--remote-debugging-port=9223','--remote-allow-origins=*','--no-first-run','--user-data-dir=C:\Users\kevin\AppData\Local\Microsoft\Edge\User Data'
```

## When the Eval Tab Is NOT Open

`cdp_capture_token.cjs` searches tabs for a URL containing "/evaluation". If none exists (e.g., only Overview/Knowledge/Topics tabs are open), it fails with "Eval tab not found."

**Create the eval tab via CDP first, then capture:**

```bash
# Step 1: Create a new tab pointing to the eval page
curl -s -X PUT "http://localhost:9223/json/new?url=https://copilotstudio.microsoft.com/environments/<envId>/bots/<botId>/evaluation"
# Returns: { "id": "...", "url": "about:blank", ... }

# Step 2: Navigate the new tab via CDP WebSocket (the URL param in step 1 doesn't always apply)
node -e "
const WebSocket = require('ws');
const http = require('http');
const evalUrl = 'https://copilotstudio.microsoft.com/environments/<envId>/bots/<botId>/evaluation';

// Step 1: Create tab
const req = http.request('http://localhost:9223/json/new?' + new URLSearchParams({url: evalUrl}), {method: 'PUT'}, (res) => {
  let d = '';
  res.on('data', c => d += c);
  res.on('end', () => {
    const tab = JSON.parse(d);
    // Step 2: Navigate it
    const ws = new WebSocket(tab.webSocketDebuggerUrl);
    ws.on('open', () => ws.send(JSON.stringify({id:1, method:'Page.navigate', params:{url: evalUrl}})));
    ws.on('message', raw => {
      const msg = JSON.parse(raw);
      if (msg.id === 1) { ws.close(); process.exit(0); }
    });
  });
});
req.end();
"
```

**PITFALL — `PUT /json/new?url=...` creates the tab but the URL may stay at `about:blank`.** Always follow it with `Page.navigate` via the tab's WebSocket. Wait 45-60s after navigation for the SPA to hydrate before running the capture script.

**PITFALL — `Page.navigate` may return `net::ERR_ABORTED`** on an existing Copilot Studio tab. This is the SPA's client-side router intercepting the navigation — the page still loads and fires PPAPI calls. Check `curl -s http://localhost:9223/json/list` to confirm the URL changed, then run the capture script.

## Capture Script Pattern

```javascript
const WebSocket = require('ws');
const fs = require('fs');
const http = require('http');

// 1. Find the eval page tab by URL
const pages = await fetch('http://127.0.0.1:9223/json/list').then(r => r.json());
const target = pages.find(p => p.url.includes('/evaluation'));

// 2. Connect WebSocket
const ws = new WebSocket(target.webSocketDebuggerUrl);
let token = null;

ws.on('message', (raw) => {
  const msg = JSON.parse(raw.toString());
  if (msg.method === 'Fetch.requestPaused' && !token) {
    const auth = msg.params.request.headers['Authorization'];
    if (auth && (msg.params.request.url.includes('powerplatform.com'))) {
      token = auth.replace(/^Bearer\s+/i, '');
      console.log('TOKEN CAPTURED');
    }
    ws.send(JSON.stringify({id:9999, method:'Fetch.continueRequest', params:{requestId:msg.params.requestId}}));
  }
});

ws.on('open', () => {
  // Enable Fetch interception + reload to trigger PPAPI calls
  ws.send(JSON.stringify({id:1, method:'Fetch.enable', params:{patterns:[{urlPattern:'*'}]}}));
  ws.send(JSON.stringify({id:2, method:'Page.reload'}));
});

// Save token to eval cache location
// C:\Users\kevin\.copilot-studio-cli\test-agent-token.txt
```

## Token Storage

The eval-api.bundle.js reads tokens from:
- MSAL cache: `%USERPROFILE%\.copilot-studio-cli\test-agent.cache.json` (DPAPI encrypted)
- Raw token file: `%USERPROFILE%\.copilot-studio-cli\test-agent-token.txt` (plain text)

For direct PPAPI calls via Python, read from the raw token file:
```python
token = open(os.path.expandvars(r'%USERPROFILE%\.copilot-studio-cli\test-agent-token.txt')).read().strip()
```

## Token Expiry

PPAPI tokens expire quickly (~1 hour). When you get 401, re-run the capture script. The Edge browser with CDP preserves auth cookies, so no re-login needed.

## Why This Works

- Device-code flow is blocked by tenant Conditional Access policy
- Localhost redirect fails because app registration doesn't have `http://localhost:<random-port>` registered
- The browser ALREADY has a valid session with Copilot Studio
- CDP intercepts the actual PPAPI requests the SPA makes, capturing the live Bearer token
