# Therapy Agent Component IDs & Direct Patching Reference

## Component IDs

| Agent | Bot ID (parentbotid) | Instruction Component ID (botcomponentid) | Model | Notes |
|-------|---------------------|-------------------------------------------|-------|-------|
| OT | `73b45e98-af7a-443a-aa12-6d8a05118530` | `28c4402c-2a2b-45d7-888d-e3ef81b2f401` | GPT5Chat | OT_Specialist - Occupational Therapy |
| PT | `593407f3-539b-490f-84ac-d74e13216c81` | `a6575469-8269-41ae-9e6e-dabd14e8ca63` | GPT5Chat | PT_Specialist - Physical Therapy |
| SLP | `6e437a77-a5dc-4984-90eb-4924eab10006` | `9a5e1289-baf3-44be-bb76-ce9d410c91dc` | Sonnet46 | SLP_Specialist - Speech-Language Pathology |
| TDA | `4d0ed0d3-30f6-f011-8406-000d3a37eba2` | `ff00b80a-321b-44be-80a4-40c78072ffe3` | GPT5Chat | Therapy Documentation Audit Agent (orchestrator) |

Environment: `org3353a370.crm.dynamics.com` (Ensign Services default)
GW: `https://powervamg.us-il106.gateway.prod.island.powerapps.com`

## Test Set IDs (from start_agent_eval.cjs)

| Agent | SR Test Set | Conv Test Set |
|-------|------------|---------------|
| OT | `2834097c-26e6-4727-ac73-c54340eaa097` | `a3f12152-a026-4eb3-934c-cab484d7be98` |
| PT | `471261a6-...` (old) or `4fe3bc0f-5f5b-40bf-a9e0-956242e10dc0` (current) | `cbeab0bd-1e8a-429f-92b1-78fb39b07775` |
| SLP | `45fccc95-85fc-4491-a270-bfc4a3ed1848` (current) | (not configured) |
| TDA | `4e8a0991-27a0-4aa4-9649-f8ecd3bb2c11` | `066a2908-2aa6-4bdd-aeed-fb5529d26c4c` |

## Direct PATCH Template (No CDP Required)

```javascript
const https = require('https');
const { execSync } = require('child_process');
const fs = require('fs');

async function patchDV(org, entity, id, body, token) {
  const url = `https://${org}.crm.dynamics.com/api/data/v9.2/${entity}(${id})`;
  return new Promise((resolve, reject) => {
    const d = JSON.stringify(body);
    const req = https.request(url, {
      method: 'PATCH',
      headers: {
        'Authorization': 'Bearer ' + token,
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(d),
        'Accept': 'application/json',
        'If-Match': '*'
      }
    }, resp => {
      let b = '';
      resp.on('data', c => b += c);
      resp.on('end', () => resolve({ status: resp.statusCode, body: b }));
    });
    req.on('error', reject);
    req.write(d);
    req.end();
  });
}

async function main() {
  const token = execSync(
    'az account get-access-token --resource "https://org3353a370.crm.dynamics.com" --query accessToken -o tsv',
    { encoding: 'utf8' }
  ).trim();
  
  // Change these for your target agent:
  const compId = 'a6575469-8269-41ae-9e6e-dabd14e8ca63'; // PT
  const instructions = fs.readFileSync('D:/my agents copilot studio/pipeline/live_agent_dump/PT_instructions.txt', 'utf8');
  
  const result = await patchDV('org3353a370', 'botcomponents', compId, { data: instructions }, token);
  console.log(`PATCH: ${result.status} ${result.status === 204 ? 'OK' : 'FAILED'}`);
  if (result.status !== 204) console.log(result.body.slice(0, 500));
}
main().catch(e => console.error(e));
```

## Finding Unknown Component IDs

Search the scripts directory for patterns:

```bash
# Search for known component IDs in scripts
grep -rn "compId\|instrId\|botcomponentid" "D:/my agents copilot studio/pipeline/scripts/" --include="*.cjs" --include="*.js"

# Or find by bot ID
grep -rn "593407f3" "D:/my agents copilot studio/pipeline/scripts/" --include="*.cjs"
```

Known component ID locations in scripts:
- OT `28c4402c`: `fix_ot_instructions.cjs`, `update_ot_instructions_conditional.cjs`, `revert_ot_all.cjs`
- SLP `9a5e1289`: `fix_slp_instructions.cjs`
- TDA `ff00b80a`: `restore_tda_original.js`, `patch_tda_original_node.js`

## API Pitfalls

1. **Never use bash/curl with `$filter`** — shell escaping of `$` and single quotes makes queries unreliable. Use Node.js `https` module instead.
2. **Don't use `$select`** on Dataverse endpoints — it's often unsupported. Fetch the full entity and filter client-side.
3. **Token resource** must match the target environment: `https://org3353a370.crm.dynamics.com` for default; `https://orgbd048f00.crm.dynamics.com` for Therapy AI Agents Dev.
4. **HTTP 204 = success** for PATCH operations. No body is returned.
