---
name: copilot-studio-agent-instructions
description: Procedures for retrieving and setting the original instructions (componenttype 15) of a deployed Copilot Studio agent using live agent dump and Dataverse PATCH operations.
---
# Copilot Studio Agent Instructions

This skill provides a reliable way to extract the original instructions (the `instructions` field of the componenttype 15 Bot Component) from a deployed Copilot Studio agent and to restore them if needed.

## Why This Is Needed

When editing an agent via the Copilot Studio web UI, the underlying Bot Component record in Dataverse can be modified directly. Sometimes, automated scripts or unintended edits alter the instructions in ways that break evaluation scores or agent behavior. Having a method to retrieve the known-good original instructions and restore them is essential for maintaining agent stability.

## Prerequisites

- Google Chrome (or Chromium-based) installed and accessible via the command line.
- The agent must be deployed in a Power Platform environment accessible via the gateway URL (e.g., `https://orgXXXXXXXX.crm.dynamics.com`).
- You must be authenticated to the environment (via Azure CLI or cached token from prior Copilot Studio CLI use).

## Procedure

### Step 1: Enable Remote Debugging in Chrome

Launch Chrome with remote debugging enabled on port 9223. Use a temporary user data directory to avoid interfering with your regular browsing session.

```bash
start chrome --remote-debugging-port=9223 --user-data-dir="%LOCALAPPDATA%\Google\Chrome\User Data" "https://org3353a370.crm.dynamics.com/"
```

> **Note**: Replace the URL with your environment's base URL. Keep this Chrome instance running for the duration of the procedure.

### Step 2: Dump the Agent's Live Components

Run the `dump_live_components.cjs` script to fetch the current state of all bot components (including actions, topics, and metadata) for the agents of interest (OT, PT, SLP, TDA). This script uses the active Chrome DevTools Protocol connection to query the Dataverse API via the browser's authenticated session.

```bash
node "D:/my agents copilot studio/pipeline/scripts/dump_live_components.cjs"
```

This creates a timestamped JSON file in `D:/my agents copilot studio/pipeline/live_agent_dump/` for each agent, named like `TDA_components_response.json`.

### Step 3: Extract the Original Instructions

Each agent's JSON file contains a top-level `value` array of components. Locate the object where `componenttype` equals `15` (metadata/instructions). The `data` field of this object contains the original instructions in YAML format.

You can extract this manually or use a helper script. For example, to view the TDA agent's instructions:

```bash
node -e "
const fs = require('fs');
const path = require('path');
const file = 'D:/my agents copilot studio/pipeline/live_agent_dump/TDA_components_response.json';
const json = JSON.parse(fs.readFileSync(file, 'utf8'));
const comp = json.value.find(c => c.componenttype === 15);
if (comp) {
  console.log('--- BEGIN INSTRUCTIONS ---');
  console.log(comp.data);
  console.log('--- END INSTRUCTIONS ---');
} else {
  console.error('Componenttype 15 not found');
}
"
```

### Step 4: Backup and Restore (Optional)

If you intend to modify the instructions and want to be able to revert, first back up the current `data` field:

1. Copy the `data` value from the componenttype 15 object to a safe location (e.g., a text file).
2. Make your changes to the `data` field (e.g., add evaluation-safe orchestration guidelines).
3. Use a PATCH script (like `apply_tda_eval_fix.cjs`) to send the updated `data` back to the Dataverse API via the browser session.

To restore the original instructions, simply set the `data` field back to the backed-up value using the same PATCH method.

## Direct API PATCH (No Browser Required)

When Chrome CDP is unavailable, you can patch agent instructions directly via the Dataverse API using Node.js `https` module with an Azure CLI token. This is more reliable than the CDP method and doesn't require a running browser.

### Component IDs (Therapy Agents)

| Agent | Bot ID | Instruction Component ID | Model |
|-------|--------|--------------------------|-------|
| OT | `73b45e98-af7a-443a-aa12-6d8a05118530` | `28c4402c-2a2b-45d7-888d-e3ef81b2f401` | GPT5Chat |
| PT | `593407f3-539b-490f-84ac-d74e13216c81` | `a6575469-8269-41ae-9e6e-dabd14e8ca63` | GPT5Chat |
| SLP | `6e437a77-a5dc-4984-90eb-4924eab10006` | `9a5e1289-baf3-44be-bb76-ce9d410c91dc` | Sonnet46 |
| TDA | `4d0ed0d3-30f6-f011-8406-000d3a37eba2` | `ff00b80a-321b-44be-80a4-40c78072ffe3` | GPT5Chat |

### Finding Component IDs

If you don't know a component ID, search the scripts directory for the bot ID or partial component ID:

```bash
grep -r "28c4402c\|compId\|componenttype" "D:/my agents copilot studio/pipeline/scripts/" --include="*.cjs" --include="*.js"
```

Look for patterns like `const compId='...'` or `const instrId='...'` in fix scripts.

### Patching Template

Create a Node.js script that uses `https.request` with PATCH method:

```javascript
const https = require('https');
const { execSync } = require('child_process');

async function patchDV(org, entity, id, body, token) {
  const url = `https://${org}.crm.dynamics.com/api/data/v9.2/${entity}(${id})`;
  return new Promise((resolve, reject) => {
    const d = JSON.stringify(body);
    const req = https.request(url, {
      method: 'PATCH',
      headers: {
        'Authorization': 'Bearer ' + token,
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(d),
        'Accept': 'application/json',
        'If-Match': '*'
      }
    }, resp => {
      let b = '';
      resp.on('data', c => b += c);
      resp.on('end', () => resolve({ status: resp.statusCode, body: b }));
    });
    req.on('error', reject);
    req.write(d);
    req.end();
  });
}

async function main() {
  const token = execSync('az account get-access-token --resource "https://org3353a370.crm.dynamics.com" --query accessToken -o tsv', { encoding: 'utf8' }).trim();
  const compId = '28c4402c-2a2b-45d7-888d-e3ef81b2f401'; // OT
  const instructions = fs.readFileSync('path/to/instructions.txt', 'utf8');
  const result = await patchDV('org3353a370', 'botcomponents', compId, { data: instructions }, token);
  console.log(`PATCH: ${result.status} (${result.status === 204 ? 'OK' : 'FAILED'})`);
}
main().catch(e => console.error(e));
```

### Pitfall: API Query via Bash

Do not try to query the Dataverse API via bash/curl with `$filter` — shell escaping of `$` and single quotes makes it unreliable. Always use Node.js `https` module (as above) or the CDP-based scripts. The `$select` query parameter is also not supported on some Dataverse endpoints; omit it and filter client-side.

## Fixing Common Evaluation Failures

The three most common evaluation failure patterns and their fixes:

### 1. "Ask for document" error → No-caveat standards check
Add a block telling the agent to give standards-based answers when note text is missing, not to ask for the document:
```
AGENT NO-CAVEAT STANDARDS CHECK
- For eval-style questions without note text, give a direct standards-based compliance screen.
- State: "Compliant only if the [discipline] note includes..." then list required elements.
- Do not ask first for the note, do not use mock-audit framing, do not make missing source the main answer.
```

### 2. Missing RESPONSE FORMAT → Ensure the format is unconditional
Add: "When ANY document is referenced ... ALWAYS provide the full RESPONSE FORMAT immediately. Never defer. Never ask for the document."

### 3. First-sentence truncation → Explicit completeness directive
Add: "Be thorough and complete. Cover all key documentation elements. Do NOT truncate answers to fit character limits — the grader values completeness."

### Model Selection
SLP uses `modelNameHint: Sonnet46` (better instruction-following). OT and PT use `GPT5Chat`. If an agent consistently underperforms with GPT5Chat, switch to Sonnet46.

See `references/eval-failure-fixes.md` for the full no-caveat block templates and examples.

## Automation Scripts

The following scripts are available in `D:/my agents copilot studio/pipeline/scripts/` to assist with this process:

- `dump_live_components.cjs` – Dumps live components for all four therapy agents (OT, PT, SLP, TDA). Requires Chrome CDP on port 9223.
- `apply_tda_eval_fix.cjs` – Example of how to patch the TDA agent's instructions with evaluation-safe orchestration guidance (requires CDP).
- `restore_tda_original.js` – Example script that restores the original TDA instructions from a backup file.
- `fix_slp_instructions.cjs` – Works without CDP — uses direct API PATCH for SLP with known component ID and Sonnet46 instructions. Reference implementation for the direct-patch pattern.
- `patch_pt_slp_instructions.cjs` – (Created Jul 2) Patches PT and SLP instructions via direct API (no CDP). Can be adapted for any agent.
- `patch_ot_nocaveat.cjs` – (Created Jul 2) Patches OT with no-caveat standards check + stronger "never ask for document" language. Uses direct API PATCH.

See `references/agent-component-ids.md` for the full component ID table, test set IDs, and a reusable direct-patch code template. See `references/eval-failure-fixes.md` for the complete no-caveat block templates.

## Example: Restoring TDA Original Instructions

1. Save the original TDA instructions (from Step 3) to a file:
   ```bash
   node -e "
   const fs = require('fs');
   const path = require('path');
   const file = 'D:/my agents copilot studio/pipeline/live_agent_dump/TDA_components_response.json';
   const json = JSON.parse(fs.readFileSync(file, 'utf8'));
   const comp = json.value.find(c => c.componenttype === 15);
   if (comp && fs.existsSync('D:/my agents copilot studio/pipeline/tda_original_instructions.txt')) {
     // Already backed up
   } else if (comp) {
     fs.writeFileSync('D:/my agents copilot studio/pipeline/tda_original_instructions.txt', comp.data);
     console.log('Backup saved to tda_original_instructions.txt');
   }
   "
   ```

2. To restore, run the `restore_tda_original.js` script (which reads the backup file and PATCHs it back to the agent). Ensure the Chrome debugging session is still active.

## Important Notes

- The `data` field may contain YAML frontmatter (e.g., `kind: GptComponentMetadata`, `displayName: ...`) followed by the `instructions:` block. Preserve the entire `data` value when backing up and restoring.
- Always verify that the Chrome debugging session is active before running any script that interacts with the agent via CDP.
- If you encounter `connect ECONNREFUSED 127.0.0.1:9223`, restart Chrome with the remote debugging flag.
- If Chrome becomes unresponsive or you see repeated connection failures, you may need to terminate existing Chrome processes first:
  ```bash
  taskkill /im chrome.exe /f  # Windows
  pkill -f chrome             # macOS/Linux
  ```
  Then relaunch Chrome with the remote debugging flag.
- This procedure works for any agent (OT, PT, SLP, TDA) by changing the agent identifier in the scripts or extraction logic.

## Related Skills

- `copilot-studio-development-workflow`: The overarching workflow for developing, testing, and deploying Copilot Studio agents.
- `copilot-studio-edit-agent`: For editing agent metadata via the manage-agent.bundle.js LSP binary.
- `copilot-studio-run-eval`: For running evaluations against agent drafts without publishing.