# Dataverse PATCH workflow for Copilot Studio topic YAML updates

## Why .ps1 over bash/python

- Single-line bash piped through `az account get-access-token` has unreliable token passing
- PowerShell `Invoke-RestMethod` with `$filter`/`$select` requires careful escaping but works reliably in .ps1 files
- `$filter=` + `$select=` URL encoding must use `[System.Uri]::EscapeDataString()` — raw `%24filter` breaks in bash

## Token Capture

```powershell
# Always capture fresh per batch — token expires in ~15 min
$token = az account get-access-token --resource "https://<org>.crm.dynamics.com" --query accessToken -o tsv
```

## URL Encoding Pattern (works consistently)

```powershell
$filter = [System.Uri]::EscapeDataString("_parentbotid_value eq 'b0346795-...' and componenttype eq 9")
$select = [System.Uri]::EscapeDataString("name,schemaname,data")
$url = "$ORG/api/data/v9.2/botcomponents?`$filter=$filter&`$select=$select&`$top=50"
```

Note the backtick before `$filter`/`$select` in the string — PowerShell treats `$filter` as a variable reference, so `$filter` without backtick would expand to empty string. Always escape `$` in OData query parameter names inside PowerShell strings.

## PATCH Pattern

```powershell
$patchUrl = "$ORG/api/data/v9.2/botcomponents($cid)"
$headers = @{Authorization = "Bearer $token"; Accept = "application/json"; "Content-Type" = "application/json"; "OData-Version" = "4.0"; "OData-MaxVersion" = "4.0"}
$body = @{ data = $yaml_string }
Invoke-RestMethod -Uri $patchUrl -Method Patch -Headers $headers -Body ($body | ConvertTo-Json -Depth 100 -Compress) | Out-Null
```

- Always use `ConvertTo-Json -Depth 100 -Compress` — the `data` field is YAML as a string, need depth for nested objects in the body wrapper
- HTTP 204 = success. Always re-GET to verify the patch landed.
- GET pattern: `botcomponents($cid)?$select=data` with same headers

## Pitfall: YAML Duplication via Regex Replace

When doing find-and-replace on the `data` YAML string in PowerShell, regex patterns can match multiple times, creating duplicate sections. **Always rebuild the full YAML string for complex edits** rather than doing regex-based find-and-replace on the live `data` field.

**Diagnosis tip:** After a PATCH, if `InvokeFlowAction` or `InvokeAIBuilderModelAction` appears more than once in the data, you have a duplicate. Count occurrences:

```powershell
$count = [regex]::Matches($data, "InvokeFlowAction").Count
```

**Fix:** Rebuild the YAML from scratch as a clean string and PATCH again.

## Pitfall: `$filter` + `$select` Query Param Duplication

When using both `$filter` and `$select` in a Dataverse query from PowerShell, the `$` must be escaped with a backtick inside double-quoted strings. Otherwise PowerShell tries to interpolate `$filter` as a variable:

```powershell
# WRONG — $filter is treated as variable (empty string)
$url = "https://org.crm.dynamics.com/api/data/v9.2/botcomponents?$filter=..."

# CORRECT - backtick escapes the $
$url = "https://org.crm.dynamics.com/api/data/v9.2/botcomponents?`$filter=..."
```

## Full Working Template

See the `C:\Users\kevin\temp\fix_blob.ps1` script from Jul 2026 for the complete pattern: token capture, schemaname→componentID mapping, batch PATCH with fresh token per call, and verification loop.
