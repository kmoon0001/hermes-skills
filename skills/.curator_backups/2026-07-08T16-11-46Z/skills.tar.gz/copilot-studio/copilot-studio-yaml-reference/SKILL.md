---
name: copilot-studio-yaml-reference
description: "Complete YAML reference for Copilot Studio authoring — file types, triggers, actions, entities, variables, Power Fx, MCP actions, connector patterns, and YAML-only features."
version: 1.0.0
author: Copilot Studio YAML Reference
license: MIT
platforms: [windows, linux, macos]
metadata:
  hermes:
    tags: [copilot-studio, yaml, reference, mcs-yaml, actions, triggers, variables, power-fx, mcp]
    homepage: https://learn.microsoft.com/microsoft-copilot-studio/
---

# Copilot Studio YAML Reference

## When to Use
- Reading, writing, or editing any .mcs.yml file in a Copilot Studio agent project
- Building topics, actions, knowledge sources, variables, or child agents from scratch
- Understanding the structure of exported Copilot Studio YAML
- Debugging YAML that fails validation or doesn't behave as expected
- Working with connector actions, MCP actions, or Power Fx expressions

## Prerequisites
- Copilot Studio environment access (or exported .mcs.yml files)
- Familiarity with YAML syntax
- Basic understanding of Copilot Studio concepts (topics, actions, variables)

---

# Core File Types

| File | Purpose | kind |
|------|---------|------|
| `agent.mcs.yml` | Agent metadata — name, description, display name | `GptComponentMetadata` |
| `settings.mcs.yml` | Agent settings and configuration (orchestration mode, language, etc.) | N/A |
| `connectionreferences.mcs.yml` | Connector references (SharePoint, Dataverse, etc.) | N/A |
| `topics/*.mcs.yml` | Conversation topics — triggers, nodes, actions | `AdaptiveDialog` |
| `actions/*.mcs.yml` | Connector-based actions (standalone reusable) | `TaskDialog` |
| `knowledge/*.mcs.yml` | Knowledge sources (URLs, files, SharePoint, etc.) | `KnowledgeSourceConfiguration` |
| `variables/*.mcs.yml` | Global variables (conversation-scoped) | `GlobalVariableComponent` |
| `agents/*.mcs.yml` | Child agents (agent-to-agent delegation) | `AgentDialog` |

## Minimal Topic File Structure

```yaml
kind: AdaptiveDialog
beginDialog:
  kind: OnConversationStart
  actions: []
```

## Minimal Action File Structure

```yaml
kind: TaskDialog
inputs: []
outputs: []
action:
  kind: InvokeConnectorTaskAction
  connectionReference: <connection-id>
  operationId: <operation>
```

---

# Trigger Types

Every topic needs exactly one trigger. The trigger determines when the topic activates.

| Trigger | Purpose | Key Properties |
|---------|---------|----------------|
| `OnRecognizedIntent` | Fires when NLU matches an intent | `intent`, `modelDescription` (generative), `triggerQueries` (classic) |
| `OnConversationStart` | Fires at conversation start | None (automatic) |
| `OnUnknownIntent` | Fallback when no intent matches | None (one per agent) |
| `OnEscalate` | Fires on system escalation event | None |
| `OnError` | Fires on system error | None |
| `OnSystemRedirect` | Fires on redirect from another topic | `redirectTopicId` |
| `OnSelectIntent` | Fires when user picks from intent disambiguation | `intents` list |
| `OnSignIn` | Fires after OAuth sign-in completes | `operationId` |
| `OnToolSelected` | Fires when generative orchestration selects this topic as a tool | None |
| `OnKnowledgeRequested` | Fires when knowledge retrieval is triggered | None |
| `OnGeneratedResponse` | Fires when generative orchestration produces a response | None |
| `OnOutgoingMessage` | **NON-FUNCTIONAL as of 2026-03-15** — does not fire | None |

### Intent Triggers: Generative vs Classic

```yaml
# Generative orchestration — modelDescription tells the LLM when to use this topic
kind: OnRecognizedIntent
intent:
  id: "MyIntent"
  modelDescription: "Use this when the user wants to reset their password"

# Classic orchestration — triggerQueries are keyword/phrases for NLU matching
kind: OnRecognizedIntent
intent:
  id: "MyIntent"
  triggerQueries:
    - "reset password"
    - "forgot my password"
    - "can't log in"
```

---

# Action Types

All actions go inside a `actions: []` array within a trigger, condition, or other action node.

| Action | Purpose | Key Properties |
|--------|---------|----------------|
| `SendActivity` | Send a message to the user | `activity` (supports Power Fx) |
| `Question` | Ask the user a question and capture response | `variable`, `prompt`, `entity`, `outputFormat` |
| `SetVariable` | Set a variable value | `variable`, `value` (Power Fx expression) |
| `SetTextVariable` | Set a text variable with interpolation | `variable`, `value` |
| `ConditionGroup` | Branching logic (if/else) | `conditions` array |
| `BeginDialog` | Launch another topic/action | `dialog` (topic ID) |
| `ReplaceDialog` | Replace current dialog with another | `dialog` (topic ID) |
| `EndDialog` | End the current topic | `outputVariables` |
| `CancelAllDialogs` | Cancel all active dialogs | None |
| `ClearAllVariables` | Reset all variables to defaults | None |
| `SearchAndSummarizeContent` | Search knowledge and summarize | `searchQuery`, `knowledgeSources` |
| `AnswerQuestionWithAI` | Use AI to answer from knowledge | `question`, `knowledgeSources` |
| `EditTable` | Manipulate table data | `table`, `operation`, `rows` |
| `CSATQuestion` | Customer satisfaction survey question | `variable`, `prompt` |
| `LogCustomTelemetryEvent` | Log custom analytics event | `eventName`, `properties` |
| `OAuthInput` | Prompt user for OAuth sign-in | `connection`, `operationId` |
| `SearchKnowledgeSources` | Search specific knowledge sources | `searchQuery`, `knowledgeSources` |
| `CreateSearchQuery` | Create a search query from context | `query`, `source` |
| `AdaptiveCardPrompt` | Show Adaptive Card and capture input | `card`, `variable` |

### Example: SendActivity with Power Fx

```yaml
- kind: SendActivity
  activity: "= \"Hello \" & Topic.UserName & \"! How can I help?\""
```

### Example: Question with Entity

```yaml
- kind: Question
  variable: Topic.UserEmail
  prompt:
    kind: SendActivity
    activity: "What is your email address?"
  entity:
    kind: EMailPrebuiltEntity
  outputFormat: String
```

### Example: ConditionGroup

```yaml
- kind: ConditionGroup
  conditions:
    - condition: "= Topic.UserAge >= 18"
      actions:
        - kind: SendActivity
          activity: "You are eligible."
    - else: true
      actions:
        - kind: SendActivity
          activity: "You must be 18 or older."
```

---

# Connector Actions (TaskDialog)

Connector actions invoke external services (SharePoint, Dataverse, custom connectors, etc.). They can be standalone files (`actions/*.mcs.yml`) or inline in topics.

## Standalone TaskDialog File Structure

```yaml
kind: TaskDialog
inputs:
  - kind: AutomaticTaskInput
    name: query
    type: String
    isRequired: true
    modelDisplayName: Search Query
    modelDescription: "The search query to find items"
  - kind: ManualTaskInput
    name: filter
    type: String
    modelDisplayName: Filter
    modelDescription: "OData filter expression"
outputs:
  - name: results
    type: Table
    modelDisplayName: Results
action:
  kind: InvokeConnectorTaskAction
  connectionReference: <connection-reference-id>
  connectionProperties:
    mode: Maker    # Maker = runs as bot maker, Invoker = runs as end user
  operationId: <operation-id>
  parameters:
    query: "= inputs.query"
    filter: "= inputs.filter"
  outputMode: Single    # Single or FirstOrDefault
```

### Input Types

| Input Kind | Purpose |
|------------|---------|
| `AutomaticTaskInput` | Discovered by generative orchestration; the LLM fills it automatically |
| `ManualTaskInput` | Must be explicitly set by the topic author in calling code |

### Connection Modes

| Mode | Behavior |
|------|----------|
| `Maker` | Action runs with the bot maker's credentials |
| `Invoker` | Action runs with the end user's credentials (requires auth) |

## $-Prefixed Property Names (SharePoint/OData)

SharePoint and OData connectors use `$`-prefixed property names. YAML parsers treat `$` specially, so wrap these in double+single quotes:

```yaml
parameters:
  "'$filter'": "= \"Status eq 'Active'\""
  "'$select'": "Title,Id,Status"
  "'$top'": "10"
  "'$orderby'": "Created desc"
```

## InvokeConnectorAction Inline in Topics

When a connector action is called inline within a topic (not as a standalone TaskDialog), parameters use a `parameters/` prefix:

```yaml
actions:
  - kind: InvokeConnectorAction
    connectionReference: <connection-id>
    operationId: <operation-id>
    parameters:
      parameters/query: "= Topic.SearchTerm"
      parameters/'$filter'": "= \"Title eq 'test'\""
```

---

# MCP Actions (Model Context Protocol)

MCP actions connect to external agent servers that implement the Model Context Protocol. Unlike standard connector actions, MCP does NOT use `AutomaticTaskInput` — the MCP server handles tool discovery dynamically.

## MCP Action Structure

```yaml
kind: TaskDialog
inputs: []
outputs:
  - name: result
    type: String
    modelDisplayName: Result
action:
  kind: InvokeExternalAgentTaskAction
  externalAgentMetadata:
    kind: ModelContextProtocolMetadata
    serverUrl: "https://your-mcp-server.example.com/mcp"
    toolName: "your_tool_name"
    # Optional: authentication configuration
    authentication:
      kind: OAuth2
      # ... auth config
  parameters:
    param1: "= Topic.SomeVariable"
  outputMode: Single
```

### Key Differences from Standard Connector Actions

| Aspect | Standard Connector | MCP Action |
|--------|-------------------|------------|
| `action.kind` | `InvokeConnectorTaskAction` | `InvokeExternalAgentTaskAction` |
| Metadata | `connectionReference` + `connectionProperties` | `externalAgentMetadata` with `ModelContextProtocolMetadata` |
| Inputs | `AutomaticTaskInput` / `ManualTaskInput` | Empty `inputs: []` (MCP discovers tools dynamically) |
| Discovery | Static — defined at design time | Dynamic — MCP server advertises available tools |

---

# System Variables

Built-in, read-only variables available in all topics. Access via `System.<name>`.

| Variable | Type | Description |
|----------|------|-------------|
| `System.Bot.Name` | String | Display name of the bot |
| `System.Activity.Text` | String | Raw text of the user's last message |
| `System.Conversation.Id` | String | Unique conversation identifier |
| `System.Conversation.InTestMode` | Boolean | `true` if running in test canvas |
| `System.FallbackCount` | Number | Number of consecutive fallback triggers |
| `System.Error.Message` | String | Error message (available in OnError) |
| `System.Error.Code` | String | Error code (available in OnError) |
| `System.SignInReason` | String | Reason for sign-in (available in OnSignIn) |
| `System.Recognizer.IntentOptions` | Table | Available intent options for disambiguation |
| `System.Recognizer.SelectedIntent` | String | Intent selected by user in disambiguation |
| `System.SearchQuery` | String | Current search query |
| `System.KeywordSearchQuery` | String | Keyword-based search query |
| `System.SearchResults` | Table | Search results from knowledge sources |
| `System.ContinueResponse` | Boolean | Whether to continue generating response |
| `System.Response.FormattedText` | String | Formatted version of the bot's response |

---

# Variable Scopes

## Scope Reference

| Scope | Prefix | Lifetime | Defined In |
|-------|--------|----------|------------|
| Topic | `Topic.<name>` | Current topic only | Topic YAML (implicit) |
| Global | `Global.<name>` | Entire conversation | `variables/<Name>.mcs.yml` |
| System | `System.<name>` | Built-in, read-only | N/A (provided by runtime) |

## Defining Global Variables

Create a file in `variables/` with the `GlobalVariableComponent` kind:

```yaml
# variables/UserContext.mcs.yml
kind: GlobalVariableComponent
schema:
  type: Object
  properties:
    UserName:
      type: String
    UserEmail:
      type: String
    UserAge:
      type: Number
aIVisibility: UseInAIContext
```

### AI Visibility Options

| Value | Effect |
|-------|--------|
| `UseInAIContext` | Variable is visible to generative orchestration (LLM can read/write) |
| `Hidden` | Variable is NOT visible to generative orchestration |

---

# Prebuilt Entities

Entities extract structured data from user input. Use these built-in entity types:

| Entity | Type | Extracts |
|--------|------|----------|
| `BooleanPrebuiltEntity` | Boolean | Yes/no, true/false values |
| `NumberPrebuiltEntity` | Number | Numeric values (integers, decimals) |
| `StringPrebuiltEntity` | String | Free-text strings |
| `DateTimePrebuiltEntity` | DateTime | Dates and times |
| `EMailPrebuiltEntity` | String | Email addresses |

### Entity Usage in Questions

```yaml
- kind: Question
  variable: Topic.UserEmail
  prompt:
    kind: SendActivity
    activity: "What is your email?"
  entity:
    kind: EMailPrebuiltEntity
  outputFormat: String
```

### Entity Usage in Trigger Recognition

```yaml
kind: OnRecognizedIntent
intent:
  id: BookFlight
  modelDescription: "User wants to book a flight"
  entities:
    - name: Destination
      kind: StringPrebuiltEntity
    - name: TravelDate
      kind: DateTimePrebuiltEntity
```

---

# Power Fx Expression Reference

Copilot Studio uses a subset of Power Fx for expressions in variables, conditions, and message interpolation.

## Syntax Basics

| Feature | Syntax | Example |
|---------|--------|---------|
| Expression prefix | `=` (must start with =) | `= 2 + 2` |
| String interpolation | `{expression}` inside strings | `"Hello {Topic.Name}!"` |
| Variable init (first assignment) | `init:` prefix | `init: "default value"` |
| Variable reference | `Topic.Var`, `Global.Var` | `= Topic.Count + 1` |
| String concatenation | `&` | `= "Hi " & Topic.Name` |

## Supported Functions

### Math
`Abs`, `Average`, `Count`, `CountA`, `CountIf`, `CountRows`, `Int`, `Max`, `Min`, `Mod`, `Rand`, `Round`, `Sum`, `SumIf`, `Sequence`

### Text
`Char`, `Concat`, `Concatenate`, `EndsWith`, `Exact`, `Find`, `First`, `FirstN`, `GUID`, `Hex`, `Index`, `IsBlank`, `IsEmpty`, `IsMatch`, `IsNumeric`, `Last`, `LastN`, `Left`, `Len`, `Lower`, `Mid`, `PlainText`, `Proper`, `Replace`, `Right`, `Split`, `StartsWith`, `Substitute`, `Text`, `Trim`, `TrimEnds`, `Upper`, `Value`

### Date/Time
`Date`, `DateAdd`, `DateDiff`, `DateTime`, `DateTimeValue`, `Day`, `Hour`, `Minute`, `Month`, `Now`, `Second`, `Time`, `TimeValue`, `Today`, `Weekday`, `Year`

### Logical
`And`, `Coalesce`, `Error`, `If`, `IfError`, `IsBlank`, `IsEmpty`, `IsError`, `IsMatch`, `IsNumeric`, `Not`, `Or`, `Switch`

### Table
`AddColumns`, `Column`, `Distinct`, `DropColumns`, `Filter`, `First`, `FirstN`, `ForAll`, `GroupBy`, `Index`, `Last`, `LastN`, `LookUp`, `Patch`, `RenameColumns`, `ReorderColumns`, `ShowColumns`, `Sort`, `SortByColumns`, `Table`, `UngroupBy`

### Aggregate
`Average`, `Count`, `CountA`, `CountIf`, `CountRows`, `Max`, `Min`, `Sum`, `SumIf`, `VarP`, `StdevP`

### Type Conversion
`AsType`, `Boolean`, `Char`, `Date`, `DateTime`, `DateTimeValue`, `DateValue`, `Decimal`, `Float`, `GUID`, `Hex`, `Int`, `Number`, `Text`, `Time`, `TimeValue`, `Value`

### Other
`Blank`, `Collect`, `DataSourceInfo`, `Defaults`, `EditForm`, `Field`, `IsType`, `Notify`, `Options`, `Parent`, `Remove`, `Reset`, `SubmitForm`, `ThisItem`, `User`

## Important Rules

- **Only use functions from the supported list above** — unsupported functions will cause runtime errors
- **All expressions must start with `=`** — without the prefix, it's treated as a literal string
- **String interpolation `{}` only works inside double-quoted strings**
- **`init:` prefix** — only on the first assignment of a variable in a topic; subsequent assignments drop the prefix
- **No semicolons** — use commas for function argument separation

## Common Patterns

```yaml
# Conditional message
activity: "= If(Topic.Score > 80, \"Great job!\", \"Keep trying!\")"

# String formatting
activity: "= Concatenate(\"Order #\", Topic.OrderId, \" is \", Topic.Status)"

# Date formatting
activity: "= \"Today is \" & Text(Today(), \"dddd, mmmm d, yyyy\")"

# Null-safe value
value: "= Coalesce(Topic.UserInput, \"No input provided\")"

# Filter a table
value: "= Filter(Global.Items, Status = \"Active\")"

# Count matching rows
value: "= CountIf(Global.Tickets, Priority = \"High\")"
```

---

# Available Templates

These templates can be used when creating new topics or actions in Copilot Studio:

| # | Template Name | Purpose |
|---|---------------|---------|
| 1 | `Blank` | Empty topic with no trigger or actions |
| 2 | `Call an Action` | Invoke a Power Automate flow or connector action |
| 3 | `Conversational` | Multi-turn conversation with question/answer flow |
| 4 | `Custom` | Custom topic with configurable trigger |
| 5 | `End of Conversation` | Standard conversation ending with survey |
| 6 | `Escalation` | Transfer to human agent |
| 7 | `Fallback` | Default response when no intent matches |
| 8 | `Greeting` | Welcome message and initial routing |
| 9 | `Message` | Simple one-shot message |
| 10 | `Multiple Choice Options` | Present options for user selection |
| 11 | `OAuth Connection` | Handle OAuth authentication flow |
| 12 | `Question` | Single question with entity extraction |
| 13 | `Redirect` | Redirect to another topic |
| 14 | `Survey` | Multi-question survey flow |
| 15 | `Topic with Generative AI` | AI-powered topic using knowledge sources |
| 16 | `Variable Management` | Set and manipulate variables |
| 17 | `Webhook` | Trigger external webhook and handle response |

---

# YAML-Only Features

These features work at runtime but are NOT visible in the Copilot Studio UI. They can only be configured by editing YAML directly.

## triggerCondition on Knowledge Sources

Add a `triggerCondition` to a knowledge source to control when it's queried. This works at runtime but is invisible in the UI:

```yaml
# knowledge/MySource.mcs.yml
kind: KnowledgeSourceConfiguration
displayName: Internal FAQ
triggerCondition: "= Topic.Category = \"Technical\""
sources:
  - kind: Url
    url: "https://contoso.com/faq"
```

The knowledge source will only be searched when the condition evaluates to `true`. The UI will show the knowledge source as always active, but the runtime respects the condition.

## Other YAML-Only Capabilities

- **Inline `InvokeConnectorAction`** with `parameters/` prefix — the UI shows these as regular actions but doesn't expose the prefix-based parameter syntax
- **`$`-prefixed parameters** in connector actions — the UI may not properly display these
- **Custom `modelDescription`** on intents — can be more detailed than what the UI allows
- **`aIVisibility: Hidden`** on global variables — UI shows the variable but not the AI visibility setting

---

## Power Fx on FilePrebuiltEntity Blobs

**PITFALL — FilePrebuiltEntity variables are BLOB values, not objects.** You cannot use `.Content` or `.Name` on a Topic variable declared with `entity: FilePrebuiltEntity`. The `.` operator on a Blob value produces `The '.' operator cannot be used on Blob values.`

**Correct patterns:**

| Intent | Wrong | Correct |
|--------|-------|---------|
| Pass file to AI Builder | `=Topic.TopicUploadedDoc.Content` | `=Topic.TopicUploadedDoc` (blob ref) |
| Check if file uploaded | `=!IsBlank(Topic.TopicUploadedDoc.Content)` | `=!IsBlank(Topic.TopicUploadedDoc)` |

AI Builder models that accept the file input handle the blob natively — they auto-decode and OCR the content. You do NOT need to pass `.Content` or `.Name`.

**PITFALL — InvokeFlowAction with OCR flow IS needed when files are PDFs/scanned images.** The AI Builder Prompty model (the reasoning/audit model) does NOT auto-OCR. It receives the raw file blob and for native text files (TXT, DOCX) this works, but for PDFs and scanned images it cannot extract text reliably. Insert an `InvokeFlowAction` that calls a Power Automate OCR flow between the file Question and the audit InvokeAIBuilderModelAction. See `manage-agent` skill's `references/ocr-flow-integration.md` for the YAML pattern.

## MS Learn Topic Description Guidelines

When writing `description` and `modelDescription` for generative AI topics:

1. **Active voice, present tense** — Start with a verb. "Audits..." not "This tool audits..."
2. **1-2 sentences** — Under 300 characters. Concise, specific to the topic's purpose.
3. **State what it DOES** — The specific note type, frameworks (CMS Chapter 15, Jimmo, Ensign 7 Habits), and output format.
4. **State what it DOES NOT do** — Negative scope prevents wrong LLM routing. "Does not review daily treatment notes."
5. **Descriptive componentName** — Unique, identifies the note type and function.
6. **Identical description and modelDescription** — Both fields should contain the same text to stay in sync.

## Pitfalls

1. **ConditionGroup formula block scalars cause `Incompatible type` errors.** Using YAML `|-` (strip block scalar) syntax for `condition:` values can introduce invisible whitespace/newlines that break Power Fx parsing at runtime:

    ```yaml
    # WRONG — "Incompatible type" error at runtime
    - kind: ConditionGroup
      conditions:
        - id: status_completed
          condition: |-
            ="Status: Completed" in Topic.ocr_payload

    # CORRECT — single-quoted inline string
    - kind: ConditionGroup
      conditions:
        - id: status_completed
          condition: '="Status: Completed" in Text(Topic.ocr_payload)'
    ```

    The fix: (a) use single quotes `'...'` instead of `|-` for inline formulas, (b) wrap string variables in `Text()` to guarantee the type is resolved as String at runtime. The `Text()` function is especially important when the variable could be interpreted as a Blob, Object, or untyped value — the `in` operator requires both sides to be explicitly typed as String. Validated: Progress Report Review topic for Therapy Documentation Feedback Agent, July 2026.

## Quick Reference: Full Minimal Topic** Using YAML `|-` (strip block scalar) syntax for `condition:` values can introduce invisible whitespace/newlines that break Power Fx parsing at runtime:

    ```yaml
    # WRONG — "Incompatible type" error at runtime
    - kind: ConditionGroup
      conditions:
        - id: status_completed
          condition: |-
            ="Status: Completed" in Topic.ocr_payload

    # CORRECT — single-quoted inline string
    - kind: ConditionGroup
      conditions:
        - id: status_completed
          condition: '="Status: Completed" in Text(Topic.ocr_payload)'
    ```

    The fix: (a) use single quotes `'...'` instead of `|-` for inline formulas, (b) wrap string variables in `Text()` to guarantee the type is resolved as String at runtime. The `Text()` function is especially important when the variable could be interpreted as a Blob, Object, or untyped value — the `in` operator requires both sides to be explicitly typed as String. Validated: Progress Report Review topic for Therapy Documentation Feedback Agent, July 2026.

2. **`SearchAndSummarizeContent.userInput` with Concatenate** — when the Concatenate expression contains colons, braces, or other YAML-special characters, the entire value MUST be wrapped in double quotes with escaped inner quotes: `userInput: \\\"=Concatenate(\\\\\\\\\\\"text with colons: item\\\\\\\\\\\", Text(Topic.var), \\\\\\\\\\\"more\\\\\\\\\\\")\\\"`. Unquoted `userInput: =Concatenate(...)` breaks YAML parsing. The generated note is stored in `Topic.Answer`.

3. **`OnOutgoingMessage` trigger is non-functional** (as of 2026-03-15) — it exists in the schema but does NOT fire at runtime. Do not use it.

4. **`$`-prefixed property names** must use the double+single quote pattern: `\"'$filter'\"` — YAML treats `$` as a special character in some parsers.

5. **`init:` prefix** is only for the FIRST assignment of a variable in a topic. Using it again resets the variable.

6. **`AutomaticTaskInput` vs `ManualTaskInput`** — AutomaticTaskInput is discovered by the LLM in generative orchestration. ManualTaskInput must be explicitly set by the author.

7. **MCP actions use empty `inputs: []`** — do NOT add AutomaticTaskInput/ManualTaskInput to MCP actions; the MCP server handles tool schema discovery.

8. **Power Fx expressions MUST start with `=`** — without it, the value is treated as a literal string, not an expression.

9. **`triggerCondition` on knowledge sources** works at runtime but is invisible in the UI — if someone edits the knowledge source in the UI, the condition may be lost.

10. **Connection mode `Invoker`** requires end-user authentication — if no auth is configured, the action will fail.

11. **`outputMode: Single`** returns one row; `outputMode: FirstOrDefault` returns the first row or null. Choose based on whether you expect one result or potentially zero.

12. **Only use supported Power Fx functions** — unsupported functions cause silent failures or runtime errors.

13. **Duplicate YAML properties are silently accepted — LAST occurrence wins.** YAML parsers (both PyYAML and js-yaml) accept duplicate keys and use the LAST value. Detect with: `grep -n applyModelKnowledgeSetting topics/*.mcs.yml | cut -d: -f1 | sort | uniq -d`

14. **`SendActivity.activity` accepts string or block scalar, NOT a dict with `value`/`text`.** The nested dict form parses without error but produces no visible output at runtime. The correct form is a flat string or block scalar.

15. **`InvokeFlowAction` output binding type mismatch.** When using the OCR Text Extraction flow (or any flow that returns integer-typed fields), binding an integer output to a topic variable can cause a `FlowActionBadRequest` at runtime. For the OCR Text Extraction flow (`c71672f2`), only bind `extracted_text`, `processing_status`, and `error_message` — never `char_count`.

---

## Quick Reference: Full Minimal Topic

```yaml
# topics/Greeting.mcs.yml
kind: AdaptiveDialog
beginDialog:
  kind: OnConversationStart
  actions:
    - kind: SendActivity
      activity: "Welcome! How can I help you today?"
```

## Quick Reference: Connector Action Call from Topic

```yaml
# topics/SearchItems.mcs.yml
kind: AdaptiveDialog
beginDialog:
  kind: OnRecognizedIntent
  intent:
    id: SearchItems
    modelDescription: "User wants to search for items"
  actions:
    - kind: Question
      variable: Topic.SearchTerm
      prompt:
        kind: SendActivity
        activity: "What are you looking for?"
      entity:
        kind: StringPrebuiltEntity
    - kind: BeginDialog
      dialog: actions/SharePointSearch
      input:
        query: "= Topic.SearchTerm"
```

## Quick Reference: Global Variable File

```yaml
# variables/UserSession.mcs.yml
kind: GlobalVariableComponent
schema:
  type: Object
  properties:
    IsAuthenticated:
      type: Boolean
      default: false
    CartItems:
      type: Table
      default: "[]"
aIVisibility: UseInAIContext
```

## Quick Reference: MCP Action

```yaml
# actions/ExternalTool.mcs.yml
kind: TaskDialog
inputs: []
outputs:
  - name: response
    type: String
    modelDisplayName: Tool Response
action:
  kind: InvokeExternalAgentTaskAction
  externalAgentMetadata:
    kind: ModelContextProtocolMetadata
    serverUrl: "https://mcp.example.com/sse"
    toolName: "get_data"
  parameters:
    query: "= Topic.UserQuery"
  outputMode: Single
```
