# Auto-Poll Async Job Status Pattern

Eliminates manual "check status" user typing by polling an async job automatically after submission.

## When to Use
- Topic submits an async job (OCR, document processing, Power Automate flow)
- User currently has to type a separate command to check status
- Perceived as "manual" or "broken" by users

## YAML Pattern

```yaml
# ── After InvokeFlowAction submit ──────────────────────────
- kind: SetVariable
  id: setVariable_poll_count
  variable: Topic.poll_count
  value: "0"

- kind: GotoAction
  id: goto_first_poll
  actionId: action_poll_status

- kind: InvokeFlowAction
  id: action_poll_status
  input:
    binding:
      job_id: =Topic.async_job_id
  output:
    binding:
      found: Topic.poll_found
      job_id: Topic.poll_job_id
      job_json: Topic.ocr_payload
  flowId: <your-flow-id>

- kind: SetVariable
  id: setVariable_poll_increment
  variable: Topic.poll_count
  value: "=Topic.poll_count + 1"

- kind: ConditionGroup
  id: conditionGroup_poll_completed
  conditions:
    - id: condition_poll_completed
      condition: ="Status: Completed" in Topic.ocr_payload
      actions:
        - kind: SendActivity
          id: sendActivity_completed
          activity: "Job complete. Report: {Topic.report}"
        - kind: EndDialog
          id: endDialog_completed

  elseActions:
    - kind: ConditionGroup
      id: conditionGroup_poll_again
      conditions:
        - id: condition_poll_continue
          condition: =Topic.poll_count < 3
          actions:
            - kind: SendActivity
              id: sendActivity_poll_status
              activity: |
                Document still processing (check {Topic.poll_count}/3).
                Checking again now...
            - kind: GotoAction
              id: goto_poll_again
              actionId: action_poll_status

      elseActions:
        - kind: SendActivity
          id: sendActivity_poll_timeout
          activity: |
            Still processing after multiple automatic checks.
            Job ID: {Topic.async_job_id}
            Say "check OCR job status" to retry — I have your Job ID saved.
        - kind: EndDialog
          id: endDialog_timeout
```

## Pitfalls

1. **Counter must be initialized BEFORE the first `GotoAction`** — otherwise the first poll has no counter value.
2. **`GotoAction` target (`actionId`) must be the `id` of a node AFTER the `GotoAction` in YAML order** — can't target a node before itself.
3. **Condition expressions need `=` prefix** — `="Status: Completed" in Topic.ocr_payload` works; without `=`, Copilot Studio treats it as a string literal.
4. **Save Job ID to global variable for "Check Status" topic** — after timeout, set `System.Var.AgentName.async_job_id = Topic.async_job_id` so the separate "Check Status" topic can use it without re-prompting.

## Companion: "Check Status" Topic

The separate "check status" topic should also use the saved Job ID automatically:

```yaml
- kind: ConditionGroup
  id: conditionGroup_use_saved
  conditions:
    - id: condition_has_saved
      condition: =!IsBlank(System.Var.AgentName.async_job_id)
      actions:
        - kind: SetVariable
          id: setVariable_use_saved
          variable: Topic.async_job_id
          value: "=System.Var.AgentName.async_job_id"
        - kind: SendActivity
          id: sendActivity_using_saved
          activity: Using your saved Job ID: {Topic.async_job_id}. Checking...
  elseActions:
    - kind: Question
      id: question_job_id
      variable: init:Topic.async_job_id
      prompt: Please enter the OCR Job ID.
```
