---
name: evaluation-rest-api
description: "Access Copilot Studio evaluation results programmatically via the Power Platform REST API. Primary path: az login → @azure/identity DefaultAzureCredential chain (zero browser, headless OK). Fallback: CDP-sniff from a Chrome session (legacy path from 2026-06+ before `auth_helper.cjs` shipped). When the API returns RouteNotFound, the endpoint is in public-preview regional rollout — record source=unavailable and move on."
version: 1.4.0
author: Copilot Studio
license: MIT
platforms: [windows, linux, macos]
metadata:
  hermes:
    tags: [copilot-studio, dataverse, evaluation, api, auth, oauth, cdp]
    homepage: https://learn.microsoft.com/microsoft-copilot-studio/whats-new
---

# Evaluation REST API — Programmatic Access

> **Migration note (2026-06-22):** Primary auth path is now the `@azure/identity` `DefaultAzureCredential` chain (reuses Kevin's existing `az login` session). Zero browser, headless OK, works for both Power Platform and Dataverse scopes. CDP-sniff is preserved below as a fallback only. See `D:/my agents copilot studio/pipeline/auth_helper.cjs` for the canonical implementation and `references/preferred-auth.md` in `copilot-studio-pipeline` for the decision procedure.

## The Problem

The Copilot Studio Evaluation page SPA is extremely slow to render — often taking 60+ seconds or never loading completely via CDP/Playwright. The grid, detail view, and test case results are unreliable via browser automation.

## The Solution

The **Evaluation REST API** at `api.powerplatform.com/copilotstudio` returns evaluation results as JSON. Fast, reliable, scriptable. No SPA needed.

## Step 0: Auth (preferred — az login chain, headless, no browser)

```javascript
// Pipeline folder: D:/my agents copilot studio/pipeline/
const { getBearerToken, KNOWN_SCOPES } = require('./auth_helper.cjs');

const pp = await getBearerToken(KNOWN_SCOPES.powerplatform);
// pp.token is the bearer; pp.source reports 'az-cli-or-pac-cache' or 'interactive-browser'
```

Why this path is preferred (vs the CDP-sniff approach below):
- **Headless.** No Playwright/Chrome attached, no chromium CDPsocket to keep alive, no Notepad-Open-Profile dance.
- **Both scopes from one chain.** Power Platform *and* Dataverse both mint off the same `az login` token via AzureCliCredential.
- **No "Pick an account" dance.** The CDP path required the user to manually reauth via visible browser every few hours. This path doesn't.
- **Survives restart.** `az login` sessions persist for ~90 days; CDP tokens expire on browser restart.

End-to-end probe pattern that proves the path works:

```javascript
const { probe, KNOWN_SCOPES, lastProbeOk } = require('./auth_helper.cjs');
await probe([
  KNOWN_SCOPES.powerplatform,
  KNOWN_SCOPES.dataverse('https://orgbd048f00.crm.dynamics.com'),
]);
if (!lastProbeOk()) {
  throw new Error('auth chain not live — run `az login` or pass `{ allowInteractive: true }` to getBearerToken()');
}
```

If the chain fails, the helper offers `{ allowInteractive: true }` — opens a browser popup, **the user clicks "Sign In"**. Never asks the user for a password in chat. See `references/preferred-auth.md` (in `copilot-studio-pipeline` skill) for the decision procedure.

## Step 0b: Auth (legacy — CDP-sniff fallback)

**Use ONLY when the chain and the browser-popup both fail.** Specifically: machine reimaged, `az login` revoked, browser popup blocked by corporate policy, captive portal, or any combination. If you find yourself reaching for this, document why in a `## Why CDP-sniff` comment in your script.

The persistent auth state at `.playwright-auth/state.json` expires after ~hours. When Copilot Studio returns "Pick an account" (105-char body), refresh:

1. Launch Playwright in **headed mode** (`headless: false`)
2. Navigate to any Copilot Studio page
3. User signs in through the visible browser window
4. Save: `await page.context().storageState({ path: authPath })`
5. Switch back to `headless: true`

**Windows note:** Scripts MUST run in foreground (`background=false`).
Background mode fails with `"stdin is not a tty"`.

**SPA timing:** After `page.goto()`, wait 25-30s before reading body text.
The React SPA needs this long to hydrate — 10-15s returns shell-only (105 chars).

### Step 0c: Dismiss Copilot Studio Popups (CDP path only)

**CRITICAL — do this first before any navigation.** Copilot Studio shows "What's New" feature modals that block the entire UI. Without dismissing them: page body returns empty, tabs are unclickable, API calls never fire (no token captured), and SPA navigation silently fails.

Procedure:
1. Press Escape × 5 with 500ms delays
2. Click any visible button with `aria-label="Close"` or `title="Close"`
3. Click buttons whose trimmed textContent is in `['Got it', 'Skip', 'Dismiss', 'Close', 'OK', 'Confirm', 'Next']`
4. After ANY navigation that opens a panel (e.g. Open code editor), repeat step 1

## Step 1: Capture a Bearer Token (CDP path — legacy)

**Token is READ-only** — GET only for evaluation data, NO POST/PATCH. The evaluation page token (`/bots/BOTID/evaluation`) has `makerevaluation` scope. The overview page token (`/bots/BOTID/overview`) does NOT — it returns RouteNotFound. If the evaluation SPA fails to trigger API calls, navigate to overview first to warm up then to evaluation.

**Headless mode works** for token capture — `headless: true` in a foreground terminal command survives normal timeouts. No need to launch headed mode.

**SharePoint limitation:** The Copilot Studio auth state (`.playwright-auth/state.json`) contains Power Platform cookies only — NO SharePoint cookies (`FedAuth`, `rtFa`). You cannot access SharePoint documents directly via Playwright with this auth. SharePoint (`ensignservices.sharepoint.com`) is a different domain from Copilot Studio (`copilotstudio.microsoft.com`). To access SharePoint, the user must authenticate separately or you need a token from `login.microsoftonline.com` with SharePoint scopes.

Two capture methods — Playwright (preferred) or raw WebSocket CDP.

### Method A: Playwright + Persistent Auth (CDP path only — legacy)

Requires `.playwright-auth/state.json` from a prior Copilot Studio login.

```javascript
const { chromium } = require('playwright-core');
const fs = require('fs');

const browser = await chromium.launch({
  headless: true,
  executablePath: 'C:/Program Files/Google/Chrome/Application/chrome.exe',
});
const ctx = await browser.newContext({
  storageState: 'D:/my agents copilot studio/.playwright-auth/state.json'
});
const page = await ctx.newPage();
const cdp = await page.context().newCDPSession(page);
await cdp.send('Network.enable');

let token = null;
cdp.on('Network.requestWillBeSent', (params) => {
  const h = params.request.headers;
  if (h.Authorization?.startsWith('Bearer ') && params.request.url.includes('makerevaluation')) {
    token = h.Authorization.replace('Bearer ', '');
    fs.writeFileSync('pp_token.txt', token);
    console.log('Eval token captured:', token.length, 'chars');
  }
});

await page.goto('https://copilotstudio.microsoft.com/environments/.../bots/BOTID/evaluation', { timeout: 30000, waitUntil: 'domcontentloaded' });
await page.waitForTimeout(15000);
```

### Method B: Raw WebSocket CDP (PROVEN — use when Playwright fails or stdin-is-not-a-tty blocks headed mode)

This method was validated 2026-07-01 against Therapy Documentation Feedback Agent in Prod. It uses only `ws` (no Playwright dependency), connects directly to an already-open Chrome/Edge tab, and captures the Bearer token from `Fetch.requestPaused` events on reload. See `scripts/cdp_ws_capture.cjs` for the full script.

**Prerequisites:** Chrome/Edge must be running with `--remote-debugging-port=9223`. Verify: `curl -s http://127.0.0.1:9223/json/version` returns JSON.

**How it works:**
1. `GET http://127.0.0.1:9223/json/list` — find the Copilot Studio Evaluation tab by URL match
2. `new WebSocket(target.webSocketDebuggerUrl)` — connect to its DevTools session
3. `Fetch.enable({ patterns: [{ urlPattern: '*' }] })` — intercept ALL fetch requests
4. `Page.reload()` — trigger fresh PPAPI calls
5. On `Fetch.requestPaused` with `Authorization` header on `powerplatform.com` URL → capture token
6. `Fetch.continueRequest` to let the page continue working
7. Save token to `%USERPROFILE%\.copilot-studio-cli\test-agent-token.txt`

**Key design decisions (from hard-won debugging):**
- Use ONE `on('message')` handler — never replace it mid-session (causes lost responses)
- Use `Fetch.requestPaused` NOT `Network.requestWillBeSent` — the latter doesn't include headers
- Run via PowerShell wrapper: `powershell.exe -NoProfile -Command "node 'script.cjs'"` when bash terminal lacks GUI support (avoids "stdin is not a tty" errors)
- The script connects to existing browser — no need for persistent auth state, no headed/headless toggle

**Auth pitfalls encountered during token acquisition:**

| Method | Result | Symptom |
|--------|--------|---------|
| PPAPI interactive (MSAL localhost redirect) | FAILS | `AADSTS50011`: redirect URI `http://localhost:<random-port>` not registered on app `96ff4394-9197-43aa-b393-6a41652e21f8` |
| PPAPI device-code flow | BLOCKED | Device page shows "You don't have access" — tenant Conditional Access policy |
| VS Code MSAL cache (client `51f81489...`) | TOKEN OK, PERMISSIONS NO | Silent refresh works but returns 403 `InsufficientDelegatedPermissions: [CopilotStudio.MakerOperations.Read]` |
| Azure CLI `az account get-access-token` | TOKEN OK, PERMISSIONS NO | Token minted but for wrong client — same 403 as VS Code |
| `@azure/identity` `DefaultAzureCredential` | TOKEN OK, PERMISSIONS NO | Same as Azure CLI — reuses az login session, wrong client |
| **CDP WebSocket Fetch capture** | **WORKS** | Connects to user's existing signed-in browser tab, intercepts SPA token that HAS PPAPI permissions |
```

## Step 2: List Evaluation Runs (WITH scores)

**CRITICAL:** The API version is `2024-10-01`, NOT `1`. The `state` field is a STRING (`"NotStarted"`, `"InProgress"`, `"Completed"`, `"Failed"`) — NOT numeric. `testCasesResults[]` requires calling the detail endpoint WITH `$expand=testCasesResults`. The list endpoint does NOT embed results.

```javascript
const token = fs.readFileSync('pp_token.txt', 'utf8').trim();
const envId = 'Default-03cc92c3-986c-4cf4-ae27-1478cf99d17f';
const botId = '73b45e98-af7a-443a-aa12-6d8a05118530';

// Step A: List runs
const path = encodeURI(
  `/copilotstudio/environments/${envId}/bots/${botId}/api/makerevaluation/testruns?$orderby=startTime%20desc&$top=3&api-version=2024-10-01`
);
// Returns: { value: [{ id, name, startTime, state, totalTestCases, ... }] }
// NO testCasesResults here — need detail call for scores

// Step B: Get scores for a specific run
const detailPath = encodeURI(
  `/copilotstudio/environments/${envId}/bots/${botId}/api/makerevaluation/testruns/${runId}?api-version=2024-10-01`
);
// Returns: { id, state, testCasesResults: [{ testCaseId, testCase: { name }, metricsResults: [...] }] }
```

**Response structure:**
```javascript
// Run list response (NO testCasesResults — scores require separate detail call):
{
  value: [{
    id, name, startTime,
    state: "NotStarted"|"InProgress"|"Completed"|"Failed",  // STRING, not numeric
    totalTestCases: 20,
    // testCasesResults NOT present — call detail endpoint
  }]
}

// Run detail response (WITH testCasesResults):
// GET /testruns/{id}?$expand=testCasesResults&api-version=2024-10-01
{
  id, state: "Completed",
  testCasesResults: [{
    testCaseId,
    state: "Completed",
    testCase: { name },
    metricsResults: [{
      type: "GeneralQuality",
      result: {
        status: "Pass"|"Fail"|"Error",
        data: { abstention, relevance, groundedness, completeness },
        aiResultReason: "..."    // ONLY present for Conversation failures
      }
    }]
  }]
}
```

## Step 3: Parse Scores (Requires Detail Call Per Run — use `$expand`)

```javascript
// Must fetch detail for EACH run to get scores
async function getScore(runId) {
  const detailPath = encodeURI(
    `/copilotstudio/environments/${envId}/bots/${botId}/api/makerevaluation/testruns/${runId}?$expand=testCasesResults&api-version=2024-10-01`
  );
  // Fetch detail...
  const detail = JSON.parse(response);
  const tcs = detail.testCasesResults || [];

  let passes = 0, fails = 0, refuses = 0, incomplete = 0, ungrounded = 0;
  for (const tc of tcs) {
    const m = tc.metricsResults?.[0];
    const status = m?.result?.status;
    const reason = m?.result?.aiResultReason || '';
    const data = m?.result?.data || {};

    if (status === 'Pass') passes++;
    else {
      fails++;
      if (reason.includes('refuses to help')) refuses++;
      if (data.completeness === 'No') incomplete++;
      if (data.groundedness === 'No') ungrounded++;
    }
  }

  const total = passes + fails;
  return { pass: passes, fail: fails, rate: Math.round(passes/total*100), refuses, incomplete, ungrounded };
}

// Usage:
for (const run of runs.value) {
  if (run.state === 'Completed') { // STRING, not numeric
    const s = await getScore(run.id);
    console.log(`${s.pass}/${s.total} = ${s.rate}% (${s.refuses} refusal, ${s.incomplete} incomplete)`);
  }
}
```

**IMPORTANT:** Single-response (SR) evaluations do NOT return `aiResultReason`.
The grader only provides detailed reasons for conversation (multi-turn) failures.
SR failures return `"(no reason)"` or null. For SR failure analysis, use the
Copilot Studio UI evaluation detail page.

**Failure pattern recognition from API data:**
- `data.completeness: "No"` + `data.groundedness: "No"` + no aiResultReason = likely "knowledge sources not cited" false negative. Fix: Compare meaning grading at 0.50 threshold (see copilot-studio-development-workflow skill).
- `aiResultReason includes "refuses to help"` = CB fallback refusal. Fix: update CB activity text.
- `data.relevance: "No"` + reason mentions "record_id" = test case uses Dataverse lookup that can't resolve. Evaluation setup issue — accept as known limitation or rewrite test case with inline text.

**Token scope:** CDP-token was historically read-only and scoped to the agent's page. The new chain path (`auth_helper.cjs`) lifts both limitations *within the user's existing RBAC*. Tokens from the chain can do POST/PATCH to Dataverse if your RBAC allows.

**Known working UI run path for an existing test set:** the top-card icon with
`aria-label="Evaluate test set"` can be a no-op in headless automation. Use:
1. Evaluation page → click the test-set card itself (`role="link"`, e.g. the left
   Conversation card containing `Data type: Conversation`).
2. On `/evaluation/configsDetails/{configId}`, click the bottom/right `Evaluate`
   button.
3. Copilot opens `Manage profile and connections`; click the final `Run` button.
4. Verify launch by the `/evaluation/runsDetails/{runId}/{configId}` URL and then
   poll Recent results until the new timestamped row gets a score.

## API Endpoints (all use `api-version=2024-10-01`)

| Operation | Endpoint | Notes |
|-----------|----------|-------|
| List test sets | `GET /testsets` | |
| List runs | `GET /testruns?$top=3&$orderby=startTime%20desc` | Returns metadata only (state, name, startTime). Scores require separate detail call. |
| Get run detail | `GET /testruns/{id}` | Returns testCasesResults with scores, aiResultReason, grader data |
| Start evaluation | `POST /testsets/{id}/run` | Token must have write scope (chain-path token does; CDP-token does not). |

## Token Scope (legacy CDP path)

The Bearer token captured from Copilot Studio's network traffic was **READ-only** for evaluation data AND scoped to `api.powerplatform.com` only.

- **CDP captured:** GET only, single agent, no Dataverse.
- **az-cli chain (current default, see auth_helper.cjs):** both read AND write within user's RBAC, both Power Platform AND Dataverse. This is the new primary.

For Dataverse operations under the chain path, you get both scopes from one `az login` — no need to capture separate tokens for each domain.

## RouteNotFound — API Gateway Changed (June 2026)

**CRITICAL:** The `api.powerplatform.com/copilotstudio/environments/.../api/makerevaluation/testruns` endpoint returned **HTTP 404 RouteNotFound** across all 4 agents (OT, PT, SLP, TDA) on June 12, 2026. Same root cause still active on June 22, 2026 in dev env a944fdf0 (QM Coach V2). The API gateway injects tenant/user routing prefixes (`/3b9e3496-.../134256874753037884/`) from the token claims, producing a path the server no longer recognizes. This is **public-preview regional rollout** — the endpoint is not yet available in this tenant's region, NOT an auth or schema failure.

For the chain path: when the REST call returns 404, fetch the error body. If message includes "does not match any known API routes", treat as endpoint-unavailable, not as auth failure. Record `source=unavailable` so we never mistake "no API access" for "scored 0%." Future sessions retry the endpoint — when rollout lands, rows auto-upgrade.

See `references/api-endpoints-verified.md` (in `copilot-studio-pipeline` skill) for what we *have* verified as of 2026-06-22.

**The SPA still uses a different gateway:** `powervamg.us-il106.gateway.prod.island.powerapps.com`
with path `/api/botmanagement/v2/environments/.../bots/...`. Tokens captured from
SPA network requests work against this gateway but the endpoint shape is different
from the documented `makerevaluation` API.

**When the REST API returns 404:** fall back to SPA body text extraction (below).

## SPA Body Text Fallback (When REST API Is Unavailable)

When the REST API returns RouteNotFound, extract evaluation scores from the
Copilot Studio evaluation SPA page body text. This is slower but reliable.

## Running Conversation Evaluations from the UI

When starting Copilot Studio conversation/SNF evaluation runs through the SPA, do **not** click only the top test-set card's small `Evaluate test set` icon and assume it launched. That icon may no-op or only focus/open controls, especially with Copilot Studio welcome overlays/backdrops present.

Reliable workflow:
1. Navigate to `/bots/{botId}/evaluation` and wait 60-65 seconds for the Evaluation SPA to hydrate.
2. Dismiss or remove blocking welcome/What’s New overlays before clicking (`Escape`, `Skip`, `Got it`, and if needed remove `[data-portal-node="true"]` / `.fui-DialogSurface__backdrop` only when it is the welcome modal overlay).
3. Identify the left/top test-set card whose body includes `Data type: Conversation` and click the **card link itself**, not just the icon. This opens `/evaluation/configsDetails/{configId}`.
4. On the config detail page, verify `Data type: Conversation` and `Review your test cases (20)` or equivalent test-case count.
5. Click the bottom-right `Evaluate` button.
6. Copilot Studio then opens a `Manage profile and connections` step. Click the final `Run` button. This is the step that actually starts the run.
7. Verify success by landing on `/evaluation/runsDetails/{runId}/{configId}` and/or polling the Evaluation page until a new run row appears, e.g. `Evaluate PT_Specialist YYMMDD_HHMM` with `20 test cases • Data type: conversation`.
8. Poll recent results every 2-3 minutes; some runs show an empty score while still processing. Do not report success/failure until the new run row appears; report `running/no score yet` if it remains blank after repeated polls.

User preference for this class of task: give periodic progress updates during slow Evaluation page loads and handle the whole fleet together (OT, SLP, PT, TDA) unless explicitly scoped narrower.

```javascript
// Navigate to evaluation page, wait 25-30s for grid render
await page.goto(
  `https://copilotstudio.microsoft.com/environments/${envId}/bots/${botId}/evaluation`,
  { timeout: 30000, waitUntil: 'domcontentloaded' }
);
await page.waitForTimeout(30000);
await page.keyboard.press('Escape'); // dismiss overlays
await page.waitForTimeout(2000);

const text = await page.evaluate(() => document.body.innerText);
```

The body text contains a structured grid:
```
Name
Test Set
Tested by
Results
Evaluate OT_Specialist 260612_0228
20 test cases • Data type: conversation
Evaluate
Evaluate OT_Specialist
MK
Moon, Kevin
2:28 AM today
General quality
End of interactive chart.
90%
```

**Parsing pattern:** Each run row has: `name` → `test cases • Data type: {single response|conversation}` → `test set link` → `author` → `timestamp` → `grading method` → `score%`.

**CRITICAL regex fix:** Run names have a SPACE between agent name and timestamp: `Evaluate OT_Specialist 260612_0405`. Do NOT use `\w+_\d{6}_\d{4}` (expects underscore between name and timestamp). Use:
```javascript
/^Evaluate\s+.+\s+\d{6}_\d{4}$/
//               ^ space, not underscore
```

Extract with:
```javascript
// Split by lines, find percentages near "conversation"/"single response" markers
const lines = text.split('\n');
for (let i = 0; i < lines.length; i++) {
  if (lines[i].includes('Data type:')) {
    const isSR = lines[i].includes('single response');
    // Score is typically 5-7 lines after "Data type:" line
    for (let j = i; j < Math.min(i + 10, lines.length); j++) {
      const pct = lines[j].trim().match(/^(\d+)%$/);
      if (pct) {
        console.log(`${runName} | ${isSR ? 'SR' : 'Conv'} | ${pct[1]}%`);
        break;
      }
    }
  }
}
```

**Token capture still works** via the same Playwright method — the SPA still fires
API calls to the new gateway. See Step 1 above. Captured tokens are ~2868 chars
from `powervamg.us-il106.gateway.prod.island.powerapps.com`.

## Priority

1. **Default: chain path via auth_helper.cjs.** Fastest, headless, both scopes. If RouteNotFound:
2. **Fall back to Playwright SPA extraction** — see `references/playwright-spa-fallback.md` for complete auth refresh + eval parsing patterns.
3. **For per-case failure analysis**: the SPA body text may not include individual
   test case details without clicking into each run. Accept score-level data when
   per-case API data is unavailable.

See `references/spa-fallback-extraction.md` for the complete parsing pattern and
JavaScript extraction code.

See `references/kb-dedup.md` for the full KB deduplication guide (including the complete 4-agent source inventory).
See `references/kb-description-detection.md` for detecting generic/empty descriptions and the SharePoint folder naming workaround.
`scripts/detect_generic_descriptions.cjs` — auto-scan all 4 agents for empty/generic descriptions.
`scripts/compare_all_knowledge.cjs` — auto-scan all 4 agents and print source list for cross-comparison.

## Failure Pattern Diagnosis

### Compare Meaning — Single Response Only

**Compare meaning grading at 0.50 ONLY works for Single Response test sets.** Conversation test sets have NO Compare meaning option — only General quality (keyword match). This is a Copilot Studio platform limitation. Do not look for it in Conversation editors — it is not there.

**Strategy:** SR failures → fix with Compare meaning (Test Set editor). Conv failures → fix with KB quality (descriptions, dedup) or accept per MS Learn 80-90% target.

### Quick Reference — API Data to Root Cause

| API Data Pattern | Root Cause | Fix | Target |
|-----------------|------------|-----|--------|
| `completeness:No + groundedness:No` (no aiResultReason, SR) | KB quality: blank descriptions or duplicate sources crowding context | KB audit → descriptions + dedup | SR |
| `completeness:No + groundedness:No` (no aiResultReason, Conv) | Multi-turn truncation or KB quality | KB audit first; if KB clean, accept per MS Learn | Conv |
| `abstention:Yes` | CB fallback triggered (agent says "I can help with..." without giving info) | Update CB YAML activity string + additionalInstructions | Both |
| `completeness:No + "refuses" in aiResultReason` | CB fallback refusal | Update CB activity text | Conv |
| `relevance:No + "record_id" in aiResultReason` | Test case uses Dataverse lookup that can't resolve in eval mode | Rewrite test case with inline text OR accept as known limitation | Both |
| `completeness:No + aiResultReason mentions truncation/third response` | Platform multi-turn response buffer overflow | Accept per MS Learn 80-90% target | Conv |

### Key Rules

- **Compare meaning** at 0.50 is ONLY available for Single Response test sets. Conversation always uses General quality.
- **completeness:No + groundedness:No** (SR, no aiResultReason) → KB audit first: descriptions blank? duplicates exist? Fix those. Only if KB is clean does this become an agent config issue.
- **abstention:Yes** → evidence the CB fallback (SendActivity) was reached — agent redirected without providing content. Fix: CB YAML activity string + additionalInstructions.
- **completeness:No + "refuses to help"** in aiResultReason → classic CB refusal. Fix: CB activity text to redirect to compliance framework instead of asking for the document.
- **completeness:No + "truncation" / "third response"** → multi-turn buffer overflowed. Platform limitation per MS Learn — accept at 80-90% target.
- **relevance:No + "record_id"** → test case simulates a Dataverse lookup that can't resolve. Evaluation setup issue, not agent issue.
- **MS Learn target:** "Aim for a realistic pass rate of 80-90%. 95%+ conversation requires clean agent AND clean evaluation setup."

### Detection Script

`scripts/detect_generic_descriptions.cjs` scans all 4 agents' Knowledge pages for empty or Microsoft-auto-generated descriptions. Run it when troubleshooting ungrounded failures to check Layer 1.5 (KB quality) before touching agent config.

`scripts/compare_all_knowledge.cjs` scans all 4 agents' Knowledge pages and prints the full source list for cross-agent comparison. Use it to identify duplicate sources (same file in multiple agents) and find which agents are missing shared docs (e.g., Joint Consensus in OT).
