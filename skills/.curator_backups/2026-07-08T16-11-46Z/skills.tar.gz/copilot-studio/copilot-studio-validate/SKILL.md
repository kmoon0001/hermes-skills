---
name: copilot-studio-validate
description: "Validate Copilot Studio agent YAML files — schema validation (local) and LSP-based validation (environment-aware). Use before publishing or after editing."
version: 1.0.0
author: Copilot Studio Pipeline
license: MIT
platforms: [windows, linux, macos]
metadata:
  hermes:
    tags: [copilot-studio, validation, yaml, schema, lsp]
    homepage: https://learn.microsoft.com/microsoft-copilot-studio/
---

# Validate Agent YAML

Validate Copilot Studio agent YAML files using two complementary methods.

## Method 1: Schema Validation (local, no auth needed)
```bash
node "D:/my agents copilot studio/pipeline/scripts/schema-lookup.bundle.js" validate <path-to-yml-file>
```
Checks structural correctness: action kinds, property placement, required fields.

## Method 2: LSP-based Validation (needs .mcs/conn.json)
```bash
node "D:/my agents copilot studio/pipeline/scripts/manage-agent.bundle.js" validate --workspace <path-to-agent-folder> --tenant-id <tenantId> --environment-id <envId> --environment-url <envUrl> --agent-mgmt-url <mgmtUrl>
```
Checks: YAML structure, Power Fx expressions, schema validation, cross-file references, environment-specific checks.
Connection details come from .mcs/conn.json.

## Workflow
1. Locate agent workspace (directory containing .mcs/conn.json)
## Workflow
1. Locate agent workspace (directory containing .mcs/conn.json). If no `.mcs/conn.json` exists, use explicit tenant/environment/agent IDs from the local manifest or project source-of-truth rather than inventing defaults.
2. Run schema validation first (fast, local)
3. Run LSP validation if conn.json exists (comprehensive)
4. Parse JSON output:
   - valid: true -> all files pass (may have warnings)
   - valid: false + summary.errors > 0 -> report as FAIL
   - summary.warnings > 0 -> report as WARN
5. If `pac copilot publish` fails after local validation passes, query the bot row's `synchronizationstatus.lastFinishedPublishOperation.diagnosticDetails` before guessing. The publish diagnostics can identify the exact topic/action and schema error even when the UI shows many topic errors. Example durable pattern: `MissingRequiredProperty ApiVersion` plus `DataSources cannot be empty` on a `SearchAndSummarizeContent` action usually means an unsupported datasource block was inserted into that node; remove the unsupported block and revalidate.
6. If the system requires fresh verification after edits and there is no canonical test/lint/build command, create a focused temporary verifier under the OS temp directory using `tempfile` with a `hermes-verify-` filename prefix. Run it against the changed behavior, clean it up when possible, and explicitly report it as ad-hoc verification rather than suite green. For repair/audit script changes, follow `references/ad-hoc-verification-after-repair-scripts.md`. For Copilot Studio YAML/Power Fx scalar quoting failures (`:`, `{}`, embedded quotes, `=...` formulas), see `references/copilot-yaml-powerfx-scalar-pitfalls.md`.
7. Report findings:
8. Report findings:
```
Validation Results for: <agent-name>
[PASS] <filename> — no issues
[FAIL] <filename> — <error message> (line X)
[WARN] <filename> — <warning message> (line X)
Summary: X files checked, Y errors, Z warnings
```

## Quick YAML Parse Check (js-yaml)

Before running full schema or LSP validation, do a fast parse check on all modified files:

```bash
node -e "const y = require('js-yaml'), fs = require('fs'); \
  process.exitCode = fs.readdirSync('topics').filter(f => f.endsWith('.mcs.yml')).every(f => { \
    try { y.load(fs.readFileSync('topics/'+f,'utf8')); return true; } \
    catch(e) { console.log('INVALID: '+f+': '+e.message); return false; } \
  }) ? 0 : 1"
```

This catches YAML syntax errors (indentation, bad escapes, trailing dots, bare quotes) without needing the schema bundle or LSP server. Run AFTER every edit pass, BEFORE schema validation.

**Alternative — PyYAML (Python):** When Node.js is not available or you're already running a Python script (batch EndDialog fix etc.), use PyYAML for the same quick parse check:
```python
import yaml, os, sys
errors = []
for f in os.listdir('topics'):
    if not f.endswith('.mcs.yml') or f.endswith('.bak'):
        continue
    path = os.path.join('topics', f)
    with open(path, 'rb') as fh:
        content = fh.read()
    if not content.strip():
        continue  # empty stub
    try:
        yaml.safe_load(content)
    except yaml.YAMLError as e:
        errors.append(f"{f}: {e}")
if errors:
    for e in errors:
        print(f"FAIL: {e}")
    sys.exit(1)
else:
    print("ALL PASS")
```

Read files as bytes (`'rb'`) and check for empty content before `safe_load` — this handles both 0-byte stubs and files with BOM/control characters that would crash a text-mode read.

**PITFALL — Corrupted byte detection:** If `yaml.safe_load` fails with `unacceptable character #x008f: special characters are not allowed`, the file has C1 control characters (0x80-0x9f bytes) from double-encoded emoji. Detect with:
```python
with open(path, 'rb') as f:
    data = f.read()
bad = [i for i, b in enumerate(data) if 0x80 <= b <= 0x9f]
```
Fix by stripping 0x80-0x9f bytes from the raw buffer before parsing. See `copilot-studio-topic-yaml-fixes` skill for the cleanup pattern.

**PITFALL — "YAML valid" ≠ "Content clean."** A file may parse successfully with `yaml.safe_load` but still contain garbled mojibake text in its string values. This happens when the fix only changes the YAML scalar style (e.g., `|-` block scalar → quoted scalar) to make parsing succeed, without actually cleaning the corrupted byte sequences from the content. After YAML validation passes, verify content cleanliness:

```python
import yaml, os, glob, re

# Common mojibake patterns from double-encoded emoji  
MOJIBAKE_PATTERNS = [
    r'ðŸ[^\s]',      # Garbled emoji prefix (U+1F... range)
    r'ï¸�',           # Variation selector-16 mojibake
    r'\\ufffd',       # Replacement character
    r'\\xef\\xbf\\xbd', # UTF-8 encoding of replacement char
]

for path in glob.glob('topics/*.mcs.yml'):
    if path.endswith('.bak'):
        continue
    try:
        with open(path, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
    except Exception as e:
        print(f'YAML FAIL: {path} — {e}')
        continue

    # Walk all string values in the parsed YAML tree
    issues = []
    def walk_strings(obj, path_ctx='root'):
        if isinstance(obj, dict):
            for k, v in obj.items():
                walk_strings(v, f'{path_ctx}.{k}')
        elif isinstance(obj, list):
            for i, v in enumerate(obj):
                walk_strings(v, f'{path_ctx}[{i}]')
        elif isinstance(obj, str):
            for pat_idx, pat in enumerate(MOJIBAKE_PATTERNS):
                m = re.search(pat, obj)
                if m:
                    start = max(0, m.start() - 20)
                    end = min(len(obj), m.end() + 40)
                    context = repr(obj[start:end])
                    issues.append((path_ctx, pat_idx, context))
    
    walk_strings(data)
    if issues:
        for fp, pat_idx, ctx in issues:
            print(f'MOJIBAKE: {path} @ {fp} — pattern {MOJIBAKE_PATTERNS[pat_idx]}')
            print(f'  Context: {ctx}')
    else:
        print(f'CLEAN: {path}')
```

Report any mojibake findings in the QA report even when YAML validation passes — the agent may produce garbled output at runtime.

**PITFALL**: `Can't find top-level schema for kind: Foo` is a SCHEMA error, not a YAML parse error. The parse check passes but schema validation will fail. Run both.

**PITFALL — Multi-line Power Fx expressions without block scalar crash YAML parse.** When a key like `value:` uses a multi-line `=Concatenate(...)` expression containing colons (`:`) in string literals, the YAML parser interprets those colons as mapping key delimiters on continuation lines. Error: `while scanning a simple key / could not find expected ':'`.

**Broken pattern (plain scalar, multi-line, colons in literals):**
```yaml
- kind: SetVariable
  variable: init:Topic.ErrorEnvelope
  value: =Concatenate(          # ← no block scalar
    "{",
    "\"status\":\"error\"",     # ← colon here triggers parse fail
    ...
  )
```

**Fix:** Add `|-` block scalar so YAML treats the whole expression as literal text:
```yaml
- kind: SetVariable
  variable: init:Topic.ErrorEnvelope
  value: |-
    =Concatenate(
    "{",
    "\"status\":\"error\"",
    ...
    )
```

Apply to `value:`, `text:`, `activity:`, `condition:`, or any key with multi-line Power Fx containing colons. Always use `|` or `|-` for these — plain-scalar multi-line breaks.

**PITFALL — Bare YAML scalars with colons/braces break before Copilot can evaluate Power Fx.** Do NOT blindly unquote `"=..."` formulas. YAML quoting is often required for one-line Power Fx that contains `:`, `{}`, or embedded quotes. Examples seen in live topics:

**WRONG** (YAML parses the colon/braces as mapping syntax):
```yaml
activity: Using your saved OCR Job ID: {Topic.async_job_id}. Checking status now...
file: ={ contentBytes: First(System.Activity.Attachments).Content, name: First(System.Activity.Attachments).Name }
```

**CORRECT** (quote simple one-line values that contain `:`/`{}`):
```yaml
activity: 'Using your saved OCR Job ID: {Topic.async_job_id}. Checking status now...'
file: '={ contentBytes: First(System.Activity.Attachments).Content, name: First(System.Activity.Attachments).Name }'
```

Rule: before any publish or patch success claim, parse the exact live `data` YAML and inspect the parsed scalar value. `YAML parse PASS` is the first gate; Copilot schema/LSP validation is the second.

**PITFALL — `|-` block scalar on one-line `condition:` breaks Power Fx with `in` operator.** The block scalar appends a trailing newline/whitespace that Power Fx's formula parser chokes on, causing "Incompatible type" errors at runtime in the Copilot Studio UI:

**WRONG** (block scalar adds unwanted whitespace to the formula string):
```yaml
condition: |-
  ="Status: Completed" in Topic.ocr_payload
```

**CORRECT** (single-quoted string — YAML keeps the formula clean):
```yaml
condition: '="Status: Completed" in Text(Topic.ocr_payload)'
```

**Rule of thumb:**
- Simple one-line `condition:` → use quoted string (`'...'` or `"..."`), NEVER block scalar
- Multi-line `value:`, `activity:` containing colons → use `|-` block scalar
- `Text()` wrapper required when `in` operator checks a topic variable (`Topic.ocr_payload`) — forces explicit string context

## For Additional Context on Errors
```bash
node "D:/my agents copilot studio/pipeline/scripts/schema-lookup.bundle.js" resolve <kind>
```

## Both Validations Are Complementary
- Schema: structural correctness (action kinds, property placement)
- LSP: Power Fx expressions, cross-file references, environment-specific rules
If either fails, fix issues before reporting success.

## When to Use
- After authoring or editing topic YAML files
- Before pushing changes to Dataverse
- When debugging publish failures
- As a gate in the publish pipeline
