---
name: copilot-studio-manage-agent
description: Push, pull, clone, publish, and validate Copilot Studio agent content via manage-agent.bundle.js LSP binary.
tags: [copilot-studio, dataverse, push, pull, clone, publish, validate]
---

# Manage Agent

Push, pull, clone, publish, and validate Copilot Studio agent content via the VS Code extension's LanguageServerHost LSP binary.

## IMPORTANT: Do Not Modify Scripts
manage-agent scripts are pre-built bundles. If script fails:
1. Report error as-is
2. Do not attempt to fix
3. Direct user to https://github.com/microsoft/skills-for-copilot-studio/issues
4. Fall back to direct Dataverse REST API (see "Direct Dataverse Push/Create Workflow" below)

## CRITICAL: Source of Truth — Live UI Wins

**Live UI = source of truth. Local files = backup snapshots only.**
**NEVER push local→live without explicit user direction. Live-only editing.**

When Kevin is editing in Copilot Studio UI, do NOT sync local YAML to live.
Local is a read-only backup pulled FROM live, never the other direction.

**User stop signal:** If Kevin says “don’t do anything,” “stop,” or asks to “just figure out the root cause,” switch to read-only mode immediately: Dataverse GET/query, local parse/validation, and explanation only. Do not PATCH, publish, push, or run repair scripts until he explicitly re-authorizes changes. In this mode, make the final answer bottom-line first: root cause, exact topic/line, and why it happened; avoid broad remediation unless asked.

### Sync Local From Live (backup)

When Kevin finishes a UI editing session and wants the local backup updated:

1. Get Dataverse token: `az account get-access-token --resource 'https://<org>.crm.dynamics.com'`
2. Query botcomponents where `_parentbotid_value eq '<botId>' and componenttype eq 9` → write each `data` field to `.mcs.yml`
3. Query where `componenttype eq 15` → extract GPT instructions from `instructions:` block
4. Remove local files with no live match
5. `git status`, commit as backup snapshot

See skill `copilot-studio-live-sync-backup` for the full script.

### When Pushing IS Appropriate (rare — user must opt in)

Only push local→live when Kevin explicitly says so. The pattern:
1. Pull live first (ensure you're not overwriting newer live changes)
2. Edit local .mcs.yml files  
3. Validate locally with schema-lookup
4. Push to Dataverse via manage-agent push (LSP) OR direct REST API fallback
5. **Query live Dataverse to confirm changes took effect**
6. Publish the agent

## Prerequisites
1. Copilot Studio VS Code extension installed (ms-copilotstudio.vscode-copilotstudio)
2. Environment details from .mcs/conn.json (tenant ID, environment ID, environment URL, agent management URL)

## Auth
Two auth flows:
- Push/pull/clone/changes/list-agents: interactive browser login, tokens cached 90 days
- Auth command: device code flow for chat/test token

No separate auth step needed before push/pull. Commands handle token acquisition automatically.

## Commands

### Pull (download remote changes)
```bash
node "D:/my agents copilot studio/pipeline/scripts/manage-agent.bundle.js" pull --workspace <path> --tenant-id <id> --environment-id <id> --environment-url <url> --agent-mgmt-url <url>
```

### Push (upload local changes)
ALWAYS pull before push to get fresh row versions (avoids ConcurrencyVersionMismatch).
Push auto-validates all .mcs.yml files before pushing. Add --force to bypass (not recommended).
```bash
node "D:/my agents copilot studio/pipeline/scripts/manage-agent.bundle.js" push --workspace <path> --tenant-id <id> --environment-id <id> --environment-url <url> --agent-mgmt-url <url>
```

**PITFALL: `push` can fail with `Cannot find module 'vscode-jsonrpc/node'`** — the same LSP dependency issue documented for `validate` also affects `push`. When this happens, fall back to direct Dataverse REST API for PATCH (existing topics) and POST (new topics) — see "Direct Dataverse Push/Create Workflow" below. Do NOT attempt to fix the bundle.

### Clone (download agent to new local folder)
Requires --agent-id or --url. Uses Island API token automatically.
With URL (recommended):
```bash
node "D:/my agents copilot studio/pipeline/scripts/manage-agent.bundle.js" clone --workspace <path> --tenant-id <id> --url <copilotStudioUrl>
```

### Validate (check YAML before pushing)
Validates all .mcs.yml files using LSP binary's full diagnostics.
```bash
node "D:/my agents copilot studio/pipeline/scripts/manage-agent.bundle.js" validate --workspace <path> --tenant-id <id> --environment-id <id> --environment-url <url> --agent-mgmt-url <url>
```
Returns JSON: { valid: true|false, summary: { errors: N, warnings: N }, files: [...] }

### Publish via Gateway publishv2-operations API (bypasses pac cache)

When `pac copilot publish` is stuck with a cached failure (same timestamp every retry), use the PowerVA gateway API directly. This bypasses the LSP binary entirely and does not require interactive login — works with token from `az`.

**Auth:** Get a token scoped to the PVA resource `96ff4394-9197-43aa-b393-6a41652e21f8`:
```bash
TOKEN=$(powershell -Command "az account get-access-token --resource '96ff4394-9197-43aa-b393-6a41652e21f8' --query accessToken -o tsv" 2>/dev/null)
```

**Endpoint:** `POST /api/botmanagement/v1/environments/{envId}/bots/{botId}/publishv2-operations`
**Gateway URL:** `https://powervamg.us-XXX.gateway.prod.island.powerapps.com` (region varies: us-il106, us-il107, etc.)

**Required headers:**
- `Authorization: Bearer <token>`
- `X-CCI-TenantId: <tenant-guid>`
- `x-cci-applicationsource: Web`
- `Accept: application/json`

**Trigger publish (POST):**
```python
publish_url = f"{GATEWAY}/api/botmanagement/v1/environments/{ENV_ID}/bots/{BOT_ID}/publishv2-operations"
req = urllib.request.Request(publish_url, data=b"{}", method="POST")
# Returns { "state": "Queued", "isInFinalState": false, ... }
```

**Poll for completion (GET — same URL):**
```python
req = urllib.request.Request(publish_url, method="GET")
# Poll every 5s. When isInFinalState=true:
#   state="Finished" → SUCCESS
#   state="FinishedWithUserErrors" → validation failure (check exceptionType/exceptionMessage)
```

**Known failure modes:**
- `StorageUnitNotAssigned` on GET (404) — no operation in progress, POST first
- `ValidationFailedException` on state `FinishedWithUserErrors` — the agent has a validation problem (blank conversation starters, stale knowledge references, etc.) that must be fixed before publish. The gateway API does NOT expose diagnostic details — use the Copilot Studio UI Publish button to see them.
- Publish returns too fast (next poll already `FinishedWithUserErrors`) — validation failed immediately, no model training occurred

**Power Platform token expiry (HTTP 403 "Unable to validate token"):** The gateway uses a Power Platform-scoped token (`96ff4394-9197-43aa-b393-6a41652e21f8` / `PowerVirtualAgents.Components.ReadWrite`), NOT the Dataverse-scoped `az` token. When the PPAPI token expires mid-session:
- The Dataverse `az account get-access-token` token is still valid for Dataverse PATCH/POST
- But the gateway rejects it with 403
- The saved token file at `~/.copilot-studio-cli/powerplatform-env-token.txt` may be stale
- **Fix:** Launch Chrome with CDP (`chrome.exe --remote-debugging-port=9223`), navigate to Copilot Studio, then extract a fresh PPAPI token by capturing a `botcomponents` API call's `Authorization` header from within the browser session (via CDP Network.enable). The token is valid for ~60-90 minutes.

**When the gateway API also fails:** The issue is likely a validation error in the agent's configuration, not the publish mechanism. Publish via the Copilot Studio UI to see the specific error messages.
### Publish (make draft agent live)
ALWAYS confirm with user before publishing (makes agent live for all shared users).
```
pac copilot publish --environment <orgUrl> --bot <botId>
```
The `--bot` flag accepts the bot GUID. Use `--bot-id` if a PAC command rejects `--bot` (varies by PAC CLI version).

**PITFALL: cached publish failure.** If `pac copilot publish` returns the same failed timestamp on every retry, the Dataverse has a cached failure. DO NOT attempt to clear `synchronizationstatus` on the Bot entity — this can crash `pac` with `System.ArgumentException` and may not resolve the issue. Instead:

  1. **Gateway publishv2-operations API** (recommended) — see `references/gateway-publish-api.md`. This bypasses both `pac` and LSP entirely, works with `az` tokens, and is the most reliable programmatic publish path.
  2. **Copilot Studio UI** — always shows the specific validation error when the gateway API returns `FinishedWithUserErrors` without diagnostics.

### List Agents
```bash
node "D:/my agents copilot studio/pipeline/scripts/manage-agent.bundle.js" list-agents --tenant-id <id> --environment-url <url> [--no-owner]
```

### List Environments
```bash
node "D:/my agents copilot studio/pipeline/scripts/manage-agent.bundle.js" list-envs --tenant-id <id>
```

## Direct Dataverse Push/Create Workflow (when LSP push fails)

When `manage-agent.bundle.js push` fails with the `vscode-jsonrpc/node` error, use the Dataverse REST API directly via `az account get-access-token` + Python/curl. The `pac` CLI auth works where the LSP interactive login does not.

### Prerequisites
- `az` CLI authenticated: `az account get-access-token --resource <orgUrl>` works
- Environment details from `agent.manifest.json` or `.mcs/conn.json`
- Bot ID, org URL, tenant ID

### Auth
```bash
TOKEN=$(powershell -Command "az account get-access-token --resource 'https://<org>.crm.dynamics.com' --query accessToken -o tsv" 2>/dev/null)
```

### Find botcomponent IDs for all topics

Batch-query all topics in one call to build a local-to-live schema name mapping:
```python
filt = f"_parentbotid_value eq '{bot_id}' and componenttype eq 9"
url = f"{base}/botcomponents?$filter={urllib.parse.quote(filt)}&$select=botcomponentid,name,schemaname&$top=100"
```

**PITFALL: schema name casing differs between local and live.** The live agent's `schemaname` field may be lowercase when your local YAML `dialog` references are mixed-case. E.g. local `pcca_theradocworkbench.topic.PTProgressNoteCard` → live `pcca_theradocworkbench.topic.ptprogressnotecard`. Always use the live schemaname from the query result when PATCHing or referencing in BeginDialog.

### Query existing botcomponents
```bash
# List all topics for a bot
curl -s -H "Authorization: Bearer $TOKEN" -H "Accept: application/json" \
  "https://<org>.crm.dynamics.com/api/data/v9.2/botcomponents?\
\$filter=_parentbotid_value eq '<botId>' and componenttype eq 9&\
\$select=botcomponentid,name,schemaname,\$top=100"
```

### PATCH existing topic metadata
Use REST API PATCH on the `data` field of an existing botcomponent to update YAML content (modeldescription, description, trigger changes, etc.).

**RECOMMENDED: Use `az rest` (not Python urllib) for PATCH.** Python `urllib` frequently fails with OData filter quoting issues (control characters in URLs cause `InvalidURL` errors). `az rest` handles all OData encoding internally and is the most reliable method.

#### Method 1: `az rest` PATCH (recommended)

```bash
# Inline body (required for PATCH — --body @file fails with "Stream was not readable")
BODY='{"data": "kind: AdaptiveDialog\nmodelDescription: ..."}'
az rest --method PATCH \
  --resource "https://<org>.crm.dynamics.com/" \
  --url "https://<org>.crm.dynamics.com/api/data/v9.2/botcomponents(<topicId>)" \
  --body "$BODY"
# Exit 0 = success (HTTP 204)
```

**CRITICAL PITFALL: `az rest --body @file` fails for PATCH.** The `@file` syntax works for GET/POST but returns `Error 0x80048d19: Stream was not readable` on PATCH. Always pass the JSON body inline as a quoted string.

#### Method 2: Python urllib (only if `az` unavailable)

```python
import urllib.request
payload = {"data": yaml_content_string}
req = urllib.request.Request(f"{base}/botcomponents({comp_id})",
    data=json.dumps(payload).encode(), method="PATCH")
req.add_header("Authorization", f"Bearer {token}")
req.add_header("Content-Type", "application/json")
req.add_header("OData-MaxVersion", "4.0")
req.add_header("OData-Version", "4.0")
with urllib.request.urlopen(req, timeout=30) as resp:
    assert resp.status == 204  # 204 = success
```

**PITFALL: OData filter quoting in Python.** Building OData filter URLs in Python `urllib` often introduces control characters (e.g., smart quotes from copy-paste, or `\n` in f-strings). Use `az rest` instead to avoid this class of error entirely.

**KEY RULES for PATCH:**
- Always back up the live `data` field first (query full record before PATCH)
- PATCH only the `data` field — do NOT touch `content` (contains Markdown headers that break the parser)
- HTTP 204 = success. Any other status = failure.
- ALWAYS verify by re-querying the record and checking the field.
- **CRITICAL: CRLF line endings.** The `data` field YAML uses `\r\n` (CRLF), NOT `\n`. Python `str.replace()` with `\n`-only patterns silently succeeds (HTTP 204) but never matches. Use regex `re.sub()` or explicit `\r\n` in replace strings. See `references/dataverse-direct-push-create.md` for full examples.

### POST new topic (create a new botcomponent)
Use the correct OData payload format. Both `componenttype` (as int) AND `parentbotid@odata.bind` are required:

```python
payload = {
    "schemaname": "pcca_agent.topic.NewTopicName",
    "name": "Display Name",
    "componenttype": 9,                            # int, NOT @odata.bind
    "parentbotid@odata.bind": f"/bots({bot_id})",  # entity reference syntax
    "data": yaml_content_string,
}
req = urllib.request.Request(f"{base}/botcomponents",
    data=json.dumps(payload).encode(), method="POST")
req.add_header("Prefer", "return=representation")
# HTTP 201 = created
```

**PITFALLS for POST:**
- Do NOT use `_parentbotid_value` (GUID string) — OData rejects it with "PrimitiveValue" error
- Do NOT use `componenttype@odata.bind` — use `componenttype: 9` (integer)
- Do NOT include `displayname` — it's not a valid OData property on `botcomponents`
- The POST returns a full entity with `botcomponentid` — extract and save it
- Verify by re-querying with `$filter=schemaname eq '...'`

### Verify changes stuck
Always re-query after PATCH/POST to confirm. A PATCH that returns 204 can still fail to write the data. **Do NOT trust the return code alone — verify by reading back:**
```python
filt = f"_parentbotid_value eq '{bot_id}' and componenttype eq 9 and schemaname eq '{sn}'"
url = f"{base}/botcomponents?$filter={urllib.parse.quote(filt)}&$select=botcomponentid,name,data"
# Check raw 'data' field for expected strings
# HTTP 200 + non-empty 'value' array = present in live
assert len(vals) > 0, f"Topic {sn} not found in live agent!"
assert "modeldescription:" in live_data, "modeldescription patch did not stick"
```

### Publish after push
After successful PATCH/POST, publish to make live. See `references/gateway-publish-api.md` for the full gateway workflow. Priority order:
1. **Gateway publishv2-operations API** — most reliable when `pac` is broken (see reference file)
2. **`pac copilot publish --environment <orgUrl> --bot <botId>`** — if gateway unavailable
3. **Direct PvaPublish API** — `POST bots({botId})/Microsoft.Dynamics.CRM.PvaPublish` with empty body (no asyncPublish param). Note: returns 200 with empty `PublishedBotContentId` even on silent failure — verify by checking bot's published state or UI.
4. **Copilot Studio UI Publish button** — fallback when all API paths fail

### Flow Schema Injection via Dataverse PATCH

When `InvokeFlowAction` YAML fails with `BindingIncorrectTypeError: File vs String`, the flow's trigger schema needs adjustment. The schema lives in the `workflows` entity's `clientdata` field:

```python
# Get flow definition
url = f"{org}/api/data/v9.2/workflows({flow_id})?$select=clientdata"
cd = json.loads(json.loads(urllib.request.urlopen(url, headers=headers).read())["clientdata"])

# Remove "type": "string" from file_name and file_content
schema = cd["properties"]["definition"]["triggers"]["manual"]["inputs"]["schema"]
for field in ["file_name", "file_content"]:
    schema["properties"][field].pop("type", None)

# PATCH back
patch_url = f"{org}/api/data/v9.2/workflows({flow_id})"
payload = json.dumps({"clientdata": json.dumps(cd)})
# HTTP 204 = success
```

This avoids needing to open Power Automate's Code view. See `references/invokeflowaction-file-type-pitfall.md`.

## Power Automate Management REST API

The management plane at `api.flow.microsoft.com` supports GET and PATCH of flow definitions. Use this as an ALTERNATIVE to Dataverse PATCH when you need to modify the full `definition` object (not just `clientdata`). The flow definition's `properties.definition` field follows the Logic Apps Workflow Definition JSON schema.

**Auth:** Token scoped to `https://service.powerapps.com/` (NOT the Dataverse org URL).

### ⚠️ Critical pitfall: ActiveUnpublished draft state

PATCH via the management API fails if the flow has an existing unpublished draft. The error is:

```
CurrentState=ActiveUnpublished ... context.IsModified=False
```

This happens because the flow's Dataverse `workflow` entity has a draft row that was never published. The management API only targets the published version, and Dataverse blocks the update when `IsModified=False` and a draft exists.

**Resolution options** (in priority order):
1. **Use Dataverse `workflows` entity PATCH on `clientdata`** instead — `copilot-studio-manage-agent` already covers this above
2. **Discard the existing draft via Power Automate UI** — open the flow in the maker portal and discard the draft, then the management API PATCH succeeds
3. **Use the Power Automate maker portal browser UI** directly to make edits

See `references/powerautomate-management-api.md` for full API patterns, payload structure, and the draft-state workaround.

## InvokeFlowAction Integration (OCR Preprocessing Pipeline)

When agent topics accept file uploads (PDFs, scanned images) for audit/review, the raw file often can't be processed by Prompty models directly. Insert a Power Automate flow step between the file question and the AI Builder audit call.

### Pattern Per Topic

**Full pipeline (AI Builder exists):**
```
Question (file upload) → InvokeFlowAction [OCR flow] → SetVariable (extracted text) → InvokeAIBuilderModelAction [audit] → SendActivity
```

**Simplified pipeline (AI Builder model missing — common for copied agents):**
```
Question → Condition (file check) → GotoAction (retry) → InvokeFlowAction [OCR flow] → [agent GPT auto-responds]
```
No SetVariable, SendActivity, InvokeAIBuilderModelAction, or EndDialog needed. The agent's GPT reads `Topic.xxx_doc_extracted` and responds per its Instructions. ~2,000 chars vs ~6,000.

### Finding Flow Schemas

Power Automate flows live in the Dataverse `workflows` entity (`category=5`). The trigger and I/O schemas are in the `clientdata` field:

```python
filt = urllib.parse.quote(f"contains(name, 'OCR') or contains(name, 'Extract')")
url = f"{org}/api/data/v9.2/workflows?$filter={filt}&$select=workflowid,name,clientdata&$top=50"
```

Look for `triggers.manual.kind: "VirtualAgent"` — only these work with Copilot Studio InvokeFlowAction. The response action defines the output bindings. See `references/ocr-flow-integration.md` for the full YAML pattern.

### Patching Topics

1. Get current `data` field from the topic's botcomponent
2. Find the GotoAction end (last line of file-retry loop)
3. Insert InvokeFlowAction YAML block there
4. Change the AI Builder model's `poc_doc` binding from the raw file variable to the extracted text variable (e.g., `Topic.eval_doc_extracted`)
5. PATCH via Dataverse REST API, verify by re-querying

### Flow Selection

- **Standard docs** (eval, progress, discharge, note, recert): use an OCR text extraction flow with AI Builder Document Intelligence
- **Large docs** (100+ pages, Episode of Care): use a flow with size-aware chunking/truncation

## Sync Local From Live (when manage-agent pull or pac clone fails)

When `manage-agent.bundle.js pull` requires interactive LSP login that can't be completed, or `pac copilot clone` is unavailable (v2.7.4 bug), use the direct Dataverse REST API to download all topics and GPT instructions:

See skill `copilot-studio-live-sync-backup` for the full script.

Key steps:
1. Get Dataverse token: `az account get-access-token --resource 'https://<org>.crm.dynamics.com'`
2. Query botcomponents where `_parentbotid_value eq '<botId>' and componenttype eq 9` for topics
3. Query where `componenttype eq 15` for GPT instructions
4. Write each `data` field to a `.mcs.yml` file
5. Remove local files with no live match
6. Git status, commit the backup state

## References
- `references/dataverse-data-only-topic-repair.md` — Minimal targeted data field repair
- `references/dataverse-full-topic-replacement.md` — Full YAML replacement via data PATCH
- `references/dataverse-direct-push-create.md` — Python implementation of PATCH/POST/verify
- `references/gateway-publish-api.md` — Gateway publishv2-operations API (recommended programmatic publish)
- `references/powerautomate-management-api.md` — Power Automate Management REST API (GET/PATCH), draft-state pitfall, and Compose action patterns
- `references/pvapublish-api.md` — PvaPublish API details and pitfalls
- `references/ocr-flow-integration.md` — Inserting Power Automate OCR flows between file upload and AI Builder audit steps in document processing topics

## Direct Dataverse Repair Fallback

If the user cannot complete the Copilot Studio API/LSP interactive login but `pac`/Azure auth can access the Dataverse environment, use the targeted Dataverse `botcomponents` repair workflow instead of repeatedly asking the user to sign in.

See `references/dataverse-data-only-topic-repair.md` for the tested pattern.
See `references/dataverse-direct-push-create.md` for the full Python implementation of PATCH/POST/verify against the `botcomponents` table.

If normal CLI/MSAL/pac auth is blocked but an authenticated Copilot Studio browser session exists, use `references/browser-token-dataverse-publish-fallback.md` for the CDP token-capture + Dataverse PATCH + gateway `publishv2-operations` workflow.

**PITFALL: `pac org fetch` crashes on `botcomponents` entity (pac CLI v2.7.4+).** Any FetchXML query against `botcomponents` causes a .NET stack overflow regardless of filter, page size, or attributes. Use the Dataverse REST API directly via `auth_helper.cjs` + `fetch()` instead. The `bot` entity works fine with `pac org fetch`.

## Error Handling (referenced content)
Key rules:
- Query `botcomponents` with `_parentbotid_value eq '<botId>' and componenttype eq 9` and back up exact live records before patching.
- Prefer minimal `data` field patches for YAML/metadata repairs; avoid whole-record replacement.
- **Full topic replacement is also possible via `data` PATCH** — replace the entire `data` field with new YAML content. This works for Fallback/Conversational Booster replacements and topic-wide fixes. The `data` field stores raw YAML as a string; PATCH it with the complete new YAML.
- **Deactivate topics by setting componentstate=2 and statecode=1** via PATCH on the botcomponent record. This removes the topic from the active agent without deleting the record. Useful for disabling overlapping Clinical Inquiry topics.
- Be careful with `content`: it may contain a leading `# Topic Name` header and PATCHing it can fail with `Unexpected character encountered while parsing value: #`. If that happens, patch only `data` and verify by re-querying.
- Publish afterward with `pac copilot publish --environment <orgUrl> --bot <botId>`.
- Verify with `pac copilot list --environment <orgUrl>` if `pac copilot status` fails.

## Error Handling Table
| Error | Cause | Resolution |
| Extension not found | VS Code extension not installed | Install from marketplace |
| ConcurrencyVersionMismatch | Push without fresh versions | Pull first, then push |
| Token expired + refresh failed | Refresh token expired (~90 days) | Re-auth |
| PvaPublish failed | Insufficient permissions | Verify publish permissions |
| `Cannot find module 'vscode-jsonrpc/node'` during LSP validate | Local VS Code extension/runtime dependency not available to the bundle | Do a local YAML syntax sanity check, then use direct Dataverse repair only for targeted fixes; do not edit bundled scripts |
| Dataverse PATCH says `Unexpected character encountered while parsing value: #` | Attempted to PATCH a field containing a leading Markdown/header line, commonly `content` | Stop whole-record/content patch attempts; patch only the minimal `data` field change and verify by re-querying |
| `pac copilot publish` returns same failed timestamp on every retry (e.g. `Failed [7/3/2026 7:26:12 AM]`) | Persistent cached publish failure in Dataverse; timestamp never changes | Use the gateway publishv2-operations API (post then poll GET) — see `references/gateway-publish-api.md`. Do NOT clear synchronizationstatus on Bot entity — this can crash pac CLI. If gateway API returns `FinishedWithUserErrors` without diagnostics, publish from Copilot Studio UI to see validation errors. If UI also fails, check for blank conversation starters, stale knowledge references, or BeginDialog targeting deleted topics. |
| Publish fails with topic validation errors ("We failed to publish your agent" dialog with error counts) | Topics have YAML binding errors — type mismatches, missing AI model refs, invalid property paths | Click "Show raw" on each error entry in the publish dialog for full diagnostic JSON. Common patterns: `BindingIncorrectTypeError` (file_content type mismatch — fix: remove `"type": "string"` from flow trigger schema via Code view or Dataverse PATCH), `InvalidReferenceError: AIModel not found` (pre-existing, affects all topics — remove InvokeAIBuilderModelAction nodes), `InvalidPropertyPath: predictionOutput` (cascading from missing model), `ExpressionError: Topic.xxx.text not recognized` (cascading). Compare error count between modified and unmodified topics to isolate your changes. See `references/invokeflowaction-file-type-pitfall.md`. |
| PATCH returns 204 but YAML replacement didn't take effect | CRLF mismatch — `str.replace()` used `\n` but data uses `\r\n` | Use `re.sub()` or explicit `\r\n` in replace strings. Always verify by re-querying. See `references/dataverse-direct-push-create.md`. |\n| PvaPublish API / gateway returns 404 `Does Not Exist` | Bot GUID from Copilot Studio URL (e.g. `4d0ed0d3-30f6-f011-8406-000d3a37eba2`) is NOT the same as the Dataverse `bots` entity `botid` | Query `/api/data/v9.2/bots?$select=botid,name` to find the actual Dataverse bot ID. The Copilot Studio URL GUID is internal and won't match Dataverse entity IDs. When querying `botcomponents`, `_parentbotid_value` also uses the Dataverse bot ID, not the URL GUID. |
| Gateway returns HTTP 400 `BadRouting` / `ErrorCode: 4002` | Environment ID format is wrong — used the `Default-<guid>` prefix from the browser URL instead of the short GUID | Use the short environment GUID from `.mcs/conn.json`. The SPA URL format `environments/Default-03cc92c3-...` does NOT work with the gateway API — strip the `Default-` prefix. See `references/gateway-publish-api.md`. |
| Gateway returns HTTP 400 `BadRouting` / `ErrorCode: 4002` | Environment ID format is wrong — used the `Default-<guid>` prefix from the browser URL instead of the short GUID | Use the short environment GUID from `.mcs/conn.json`. The SPA URL format `environments/Default-03cc92c3-...` does NOT work with the gateway API — strip the `Default-` prefix. See `references/gateway-publish-api.md`. |
| PATCH returns 204 but YAML replacement didn't take effect | CRLF mismatch — `str.replace()` used `\n` but data uses `\r\n` | Use `re.sub()` or explicit `\r\n` in replace strings. Always verify by re-querying. See `references/dataverse-direct-push-create.md`. |\n| PvaPublish API / gateway returns 404 `Does Not Exist` | Bot GUID from Copilot Studio URL (e.g. `4d0ed0d3-30f6-f011-8406-000d3a37eba2`) is NOT the same as the Dataverse `bots` entity `botid` | Query `/api/data/v9.2/bots?$select=botid,name` to find the actual Dataverse bot ID. The Copilot Studio URL GUID is internal and won't match Dataverse entity IDs. When querying `botcomponents`, `_parentbotid_value` also uses the Dataverse bot ID, not the URL GUID. |
| `pac copilot status` complains about `componentstate_Property` | PAC status-command quirk in some tenants/CLI versions | Use successful publish output plus `pac copilot list --environment <orgUrl>` to verify Published/Active state |

## Output Format
All commands output JSON with status field. status: "ok" for success, status: "error" for failure.
