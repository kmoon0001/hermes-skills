---
name: copilot-studio-analyze-evals
description: "Analyze exported evaluation results from Copilot Studio Evaluate tab. Parses CSV, identifies failures by category, proposes YAML fixes. No API or published agent required."
category: copilot-studio
---

# Analyze Copilot Studio Evaluation Results

Analyze evaluation results exported from the Copilot Studio UI as CSV.

## Phase 1: Get Results
Ask the user for the CSV file path. The in-product evaluation CSV has columns: question, expectedResponse, actualResponse, testMethodType_1, result_1, passingScore_1, explanation_1.

## Phase 2: Analyze
Focus on failed evaluations (result_N = Fail). Use explanation column:
- "Question not answered" — missing topic or knowledge source
- "Knowledge sources not cited" — check SearchAndSummarizeContent nodes
- "Seems incomplete" — early exits, missing branches
- Runtime errors (GenAIToolPlannerRateLimitReached) — transient, flag to retry

## Phase 3: Propose Fixes
For each failure, identify relevant YAML files by matching test utterance against trigger phrases. Propose specific changes, present as diff. Wait for user to accept/reject, then apply via Edit tool.