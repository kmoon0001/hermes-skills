---
name: windows-cua-driver
description: "Windows desktop automation patterns via cua-driver MCP tools — fallback when computer_use returns 0x0, WinForms quirks, app launch/restore, click delivery modes, Chromium workarounds."
version: 1.0.0
platforms: [windows]
metadata:
  hermes:
    tags: [cua-driver, windows, desktop-automation, mcp, winforms]
    category: computer-use
---

# Windows cua-driver MCP Patterns

When the Hermes `computer_use` tool returns 0x0 captures (empty screens, no elements),
fall back to the `mcp_cua_driver_*` MCP tools directly. They are lower-level but work
reliably on Windows. This skill covers patterns learned operating Windows desktop apps:
Edge, Chrome, WinForms, ClickOnce launchers, and UWP-packaged apps.

## When to Use This Skill

- `computer_use` returns 0x0 consistently on Windows
- You need to drive a WinForms desktop app (DataGridView, scrollbars)
- You need to launch/restore/click Windows apps in the background
- You hit Chromium input routing issues (PostMessage dropping keystrokes)

## Quick Health Check

```
mcp_cua_driver_health_report()
```
`"overall": "ok"` = UIA + DXGI both reachable. You're good.

## Discovery → Capture → Act Pipeline

1. **List everything:** `mcp_cua_driver_get_accessibility_tree()` — returns all processes and visible windows with PIDs and window_ids
2. **Capture a window:** `mcp_cua_driver_get_window_state(pid, window_id)` — returns screenshot + UIA tree with numbered elements
3. **Act by element index:** `mcp_cua_driver_click(element_index=N, pid, window_id)` — use `element_index` > pixel coords

After any state change, re-capture. Window IDs are ephemeral — always re-enumerate if `get_window_state` returns "No window with window_id X exists".

## Launching Windows Apps

```python
# Prefer `path` over `name` or `aumid`
# name/aumid activation often fails on packaged apps (Edge, Calculator, etc.)
mcp_cua_driver_launch_app(
    path="C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
    start_minimized=True
)
# Returns: pid, windows array with window_ids ready for capture
```

## Restoring Minimized Windows

Minimized windows cannot be captured. Restore first:

```python
import ctypes
SW_RESTORE = 9
hwnd = <window_id from list_windows>
ctypes.windll.user32.ShowWindow(hwnd, SW_RESTORE)
```

Use `list_windows(pid)` to get the HWND (window_id field).

## Click Delivery Modes — CRITICAL

| Mode | Use Case |
|------|---------|
| `delivery_mode: "background"` (DEFAULT) | Try FIRST for everything. Win32, UWP, UIA-capable elements |
| `delivery_mode: "foreground"` | ONLY after receiving `background_unavailable` error |

**NEVER guess foreground preemptively.** The driver decides when background is impossible.
A guessed foreground click steals the user's focus needlessly.

## Chromium/Electron Address Bar Navigation

Chromium drops `PostMessage(WM_KEYDOWN, VK_RETURN)` in the address bar. To navigate:

1. `set_value` on the address bar `Edit` element
2. Click the autocomplete suggestion `ListItem` that appears below
3. Do NOT send `return`/`enter` — it won't register

## WinForms DataGridView Scrolling

WinForms grid scrollbars have broken UIA patterns:
- Page Up/Page Down buttons are NOT indexed (unlabeled siblings in the scrollbar tree)
- `set_value` on the scrollbar is silently ignored
- Line Down clicks work but are 1-row per click

**Workaround:** Send `pagedown` key directly:
```python
mcp_cua_driver_press_key(key="pagedown", pid=<pid>, delivery_mode="foreground")
```

## Pitfalls

- **Window IDs expire** after window recreation (session timeout, restart). Always re-list before capture.
- **Element indices are snapshot-scoped** — a new `get_window_state` replaces the index map.
- **WinForms `DataGrid` scrollbar** `set_value` is ignored; prefer keyboard paging.
- **`bring_to_front` doesn't restore minimized windows** — use `ShowWindow` first.
- **`start_minimized` in `launch_app` works for ShellExecuteEx apps** but may not for packaged (UWP) apps.

## Chrome CDP Port Binding on Windows — Known Pitfall

Launching Chrome with `--remote-debugging-port=N` (e.g. port 9223) for `execute_javascript` does NOT reliably work on Windows.

**Symptoms:**
- `netstat -ano | Select-String ':9223'` returns empty after launch
- `Get-WmiObject Win32_Process` shows `--remote-debugging-port=9223` on child/renderer processes, but the main browser process never binds the port
- `curl http://127.0.0.1:9223/json/version` returns connection refused
- `mcp_cua_driver_page(action='execute_javascript', ...)` errors: "relaunch the browser with --remote-debugging-port=N"

**Root cause:** On Windows, the Chrome process model shares a single browser process per user data directory. The `--remote-debugging-port` flag is inherited by child processes (renderer, GPU, utility) but the parent browser process that actually opens the TCP socket ignores it. Even `taskkill //F //IM chrome.exe` doesn't fully reset the shared browser process state.

**Attempted workarounds that didn't reliably work:**
- `taskkill //F //IM chrome.exe` then fresh launch with `--remote-debugging-port=9223`
- `cmd /c "start \"\" \"chrome.exe\" --remote-debugging-port=9223"`
- `Start-Process` with `--remote-debugging-port` from PowerShell
- `--user-data-dir=<fresh-dir>` (forces new profile but still CEF may detach)
- `mcp_cuda_driver_launch_app` with `additional_arguments`

**Workarounds when CDP isn't available:**
1. **`query_dom(css_selector)`** — UIA-based read-only DOM queries. Supports simple tags: `button`, `a`, `input`, `h1-h6`, `p`, `span`, `select`, `textarea`, `li`, `img`; also `tag#id` and `[role=…]`. No CDP needed.
2. **`get_text()`** — UIA TextPattern read (fails on some Chromium pages that don't expose it).
3. **Bookmark workaround** — Create a bookmark named `cua-driver-eval` in Chrome's Favorites bar. The driver overwrites its URL on first use, enabling `execute_javascript` without CDP.
4. **UIA enter-key workaround** — Chromium drops `PostMessage(WM_KEYDOWN, VK_RETURN)` in the address bar. Use `set_value` on `Edit` element to type URL, then click the Reload button (element index) rather than pressing Enter.
5. **`az` CLI fallback** — For Copilot Studio auth, use `az account get-access-token --resource '<resource>' --query accessToken -o tsv` via `powershell -Command` instead of browser CDP. This is the most reliable auth path for Dataverse REST API and gateway API.

## Reference Files

- `references/nethealth-optima.md` — NetHealth Rehab Optima (Care Operations Manager): architecture, installation, reports console, automation strategy, key reports for SLP CMI detection
- `references/pcc-api.md` — PointClickCare EHR REST API v2: endpoints, auth, ICD-10 swallowing codes, access tiers, data limitations
- `references/monitoring-browser-ai-agents.md` — Polling and verifying completion of browser-based AI agents (Gemini, Copilot) in Chrome. Covers: Chrome crash recovery + conversation history restoration, Power Automate flow testing and node search, Dataverse "Invalid Character" documentbody fix, and all known pitfalls for Chromium automation on Windows.
- `references/project-flow-mapping.md` — Project-specific flow-to-topic mapping for Therapy AI Agents Dev environment. Lists all 8 topics that reference the OCR Text Extraction flow, their binding patterns, and the flow input resolution chain. Useful when debugging flow failures or verifying topic correctness.
