---
name: copilot-debug
description: General Microsoft Copilot Studio debugging and evaluation repair workflow. Use when a user invokes /copilot-debug or asks to improve any Copilot Studio agent's evaluation scores, inspect root causes, fix topics/instructions/knowledge/test cases, publish, verify synchronizationstatus, sync live UI changes back to local source, or loop until score thresholds are met.
---

# Copilot Debug

Use this workflow for any Microsoft Copilot Studio agent. Treat the live Copilot Studio UI and live Dataverse records as source of truth unless the user says otherwise.

## Ground Truth

**PITFALL — Wrong agent**: Always verbally confirm the agent name, bot ID, and environment with the user before starting analysis. Do not assume a local repo or a previously opened agent matches the one the user is asking about. Copilot Studio tenants often have multiple agents with similar-sounding names (e.g., "TheraDoc Workbench" vs "Therapy Documentation Audit Agent"). If the user corrects you, stop immediately, find the right agent via the Copilot Studio agents list, and restart the analysis from scratch.

This skill plugs into the `copilot-studio-development-workflow` umbrella skill (step 6: debug loop). Use that skill for the full YAML-first development lifecycle.

1. Identify the environment URL, bot ID, schema name, and latest publish status. If the agent has no local source files (cloud-only), discover it by navigating the Copilot Studio UI: open the agents list in the correct environment, find the agent by name, and extract the bot ID from the URL (`.../bots/<botId>/overview`).
2. Verify publish state from `pac copilot list` (preferred) or `bot.synchronizationstatus`. Note: `pac copilot status --bot-id` is broken in v2.7.4 (throws `componentstate_Property` error). `pac copilot extract-template` also has a known bug with knowledge sources (`AddKSComponent` crash).
3. Pull live bot components with Dataverse (when available). For cloud-only agents with no local source, use the Copilot Studio UI's code editor to inspect topic YAML, instructions, and knowledge sources.
   - `componenttype=15`: GPT/instructions
   - `componenttype=9`: topics and connected-agent topic components
   - `componenttype=14` or `16`: knowledge sources
   - evaluation cases where data starts with `kind: EvaluationData` or `kind: MultiTurnEvaluationCase`
4. **Get evaluation results programmatically** (preferred over waiting for the slow SPA grid): use the Power Platform Evaluation REST API. See the `passagenttesting` skill section "Automated Evaluation via REST API" for endpoints and auth. Base URL: `https://api.powerplatform.com/copilotstudio/environments/{envId}/bots/{botId}/api/makerevaluation?api-version=1`
5. Screenshot or export the relevant live UI pages before changing them: Overview, Topics, Knowledge, Evaluation scores, and failed cases.
6. Do not log PHI, secrets, tenant tokens, or raw patient records. Use synthetic or de-identified test text only.

## Root Cause Loop

For every failed test case, follow Microsoft Learn's triage order:

**Layer 1.5 — KB quality FIRST.** Always audit knowledge sources before touching agent config. Most failures are KB gaps, not logic bugs.

1. If the agent response is acceptable, fix the evaluation case or grader.
2. If the expected answer is wrong or stale, fix the evaluation case.
3. If a concrete configuration defect exists, fix the agent.
4. If a fix does not persist or cannot be configured, document it as a platform limitation.
### Cross-Agent KB Comparison

When troubleshooting a specific agent, compare its knowledge sources against all other agents. Sources duplicated across agents (same content in multiple KBs) should be consolidated into a single shared SharePoint source. Sources missing from one agent that exist in others (e.g., AOTA-APTA-ASHA Joint Consensus in PT+TDA but not OT) should be added.

**SharePoint folder naming**: SharePoint sources do NOT have editable description fields. The folder name IS the description. Rename SharePoint folders to ~100 chars with keyword-rich content for GPT routing.

**⚠️ Tools page SPA issue**: The `/tools` URL sometimes loads the Topics page instead. Navigate via the overflow menu (+N) → Tools, or click the Tools tab from within the Topics page.

**⚠️ SharePoint KB dedup causes fleet-wide regression**: Consolidating individual KB files into SharePoint folders WITHOUT renaming the folders is the #1 systemic regression trigger. Generic folder names (e.g., "Core Clinical Manuals") fail GPT retrieval routing, causing ALL agents sharing that folder to drop. Evidence (June 2026): PT SR dropped 95%→75%, SLP SR dropped 96%→92% after KB consolidation. Fix: rename SharePoint folders FIRST (keyword-rich names), THEN remove duplicates from agent KBs. Never dedup before renaming.

**⚠️ Platform-level failure diagnosis**: When ALL agents return "Error" simultaneously (including untouched ones), it's NOT an agent config issue — it's the evaluation service. Run eval on an untouched agent to confirm. Diagnostic steps: (1) Check if untouched agent also returns 0% — if yes, platform issue confirmed. (2) Verify agents work in Test pane (draft version) — if yes, eval service auth is broken. (3) Check pac copilot list — if bots show Active/Provisioned, environment is healthy. (4) Query Dataverse botcomponents API — if returns data, API layer works. (5) Wait 5-10 min and retry — if still 0%, not rate limiting. (6) Check for recent Microsoft outages (June 11, 2026: faulty deployment broke eval auth). See `references/platform-level-failure-diagnosis.md` for the full diagnostic workflow and known outage patterns.

**⚠️ Playwright CANNOT inject Copilot Studio instructions**: The Overview page's contentEditable editor resists all programmatic approaches — `fill()`, clipboard paste, `page.keyboard.type()`, and `execCommand`. Playwright reports success (text appears, Ctrl+S dispatched) but the save does NOT persist on reload. The ONLY proven method is CDP `Input.insertText` (see `cdp-instructions-injection` skill). If CDP unavailable, deliver instructions as a text file for manual paste.

See `references/sharepoint-folder-naming.md` for folder naming patterns, `references/knowledge-source-descriptions.md` for individual file descriptions, `references/sharepoint-kb-regression.md` for the full regression case study, `references/power-bi-integration.md` for Power BI connector setup, and `references/qm-coach-v2-agent.md` for QM Coach V2 agent details.

**Browser lifecycle on Windows**: Terminal timeout kills Node process → kills Chrome. Use headless: false with 180-300s terminal timeout. Never call browser.close() unless user asks. Background mode doesn't keep processes alive on Windows Git Bash.

Then pattern-analyze at least five failures:

- `80%+ same root cause`: fix the category, not individual cases.
- `score flat after fix`: re-triage; the root cause was probably wrong.
- `one score improves while another regresses`: inspect instruction conflicts and topic routing.
- `single response fails but conversation passes`: check prompt-first topics, strict graders, and ambiguous expected answers.
- `conversation fails but single response passes`: check context retention, topic stacking, and reference conversation design.

## System Analysis from Agent Instructions (No Evaluation Access)

When evaluation data is unavailable, analyze the agent's instructions and topic structure for systemic failure patterns. These patterns reliably predict evaluation failures:

1. **Instruction self-contradictions:** e.g., "STRICT JSON ONLY" in a conversational text agent, or citation tag `[^x_y^]` preservation requirements that produce non-human-readable output.

2. **Unenforceable constraints:** e.g., "never exceeding 800 characters per section" — models have no character-count enforcement mechanism.

3. **Child agent routing complexity:** If the agent routes to sub-agents with "Translate any JSON from child agents" instructions, a single sub-agent failure cascades to the parent's response.

4. **Disabled features:** Topics toggled Off, Web Search disabled, model knowledge disabled — these create gaps that evaluation test cases may depend on.

5. **Upload-vs-paste routing gaps:** If the primary audit topic triggers "ONLY when the user uploads a document", pasted clinical text bypasses the routing entirely.

6. **Missing EndDialog:** Topics without EndDialog + clearTopicQueue cause context bleeding in multi-turn evaluations.

7. **Agent warnings:** Check the Overview page for licensing or sharing warnings that may indicate configuration issues.

8. **Unconditional RESPONSE FORMAT on conversation agents:** Instructions that say \"Always use the RESPONSE FORMAT for ALL audit requests\" or \"use for ALL audit requests\" force the full 6-section structured output on every query — including general clinical questions. This causes 10%+ conversation score drops because general inquiries get unnecessary rigid formatting that graders penalize. Fix: Use conditional format matching PT's proven pattern — \"For full document audits only (evaluation, daily note, progress note, recertification, discharge): use RESPONSE FORMAT. For general clinical questions or specific element checks: give a focused natural answer.\" Evidence: PT conversation recovered 80%→95% after switching. SLP stuck at 85% Conv with unconditional format while PT/OT at 90-95% with conditional (June 2026).

## Agent Fix Checklist

Apply the smallest live UI/API-supported change that resolves the proven root cause.

- Every `SearchAndSummarizeContent` topic ends with `EndDialog` and `clearTopicQueue: true`.
- Never use `clearTopicQueue: false`.
- Use `applyModelKnowledgeSetting: true` or omit it; never set it to `false`.
- Remove `SearchSpecificFiles`, `fileSearchDataSource`, and `SearchSpecificKnowledgeSources` unless the user explicitly wants a narrow-source topic.
- Do not add `knowledgeSources: kind: SearchAllKnowledgeSources`; omit the block.
- Remove latency message text and keep `allowLatencyMessage: false`.
- Do not mix prose instructions with "Return exactly one valid JSON" unless the endpoint is intentionally backend JSON-only.
- Avoid broad `OnActivity type: Message` or generic trigger phrases that hijack all input.
- Convert prompt-first audit/help topics to answer-first search when the user's current message already contains enough context.
- Prefer General quality for open-ended compliance/knowledge evaluations; use Compare meaning only when an expected answer is truly required.
- **Verify all leaf topics end with `EndDialog`**: topics that display output and fall through without `EndDialog` cause context bleeding and multi-turn evaluation failures.
- **Watch for "STRICT JSON ONLY" guardrails in conversational/dialogue topics**: these contradict the topic's actual text output and degrade response quality.
- **Editing instructions on the Overview page**: The Instructions section uses a `div[contenteditable]` inside a `[role=textbox]`. Click the Edit button to make it editable (`contentEditable=true`), then use `Ctrl+A` to select all, paste new text via clipboard, and `Ctrl+S` to save. See `playwright-hermes` skill for automation details.
- **Citation tag `[^x_y^]` in instructions causes evaluation failures**: The instruction "preserve all tags in the format [^x_y^]" conflicts with evaluation scoring. Replace with human-readable citation guidance.
- **Topic YAML `kind` varies by environment**: Production agents typically use `kind: AdaptiveDialog`, but dev environment agents (e.g., a944fdf0) may require `kind: TaskDialog`. If you get "Invalid kind, expected 'TaskDialog' but got 'AdaptiveDialog'", switch to `kind: TaskDialog`. Both use the same `beginDialog:` structure underneath. Always check the existing topic's kind before pasting YAML.
- **YAML indentation is strict in Copilot Studio code editor**: The Monaco editor parser rejects YAML with incorrect indentation. Common mistake: pasting content with wrong indent levels. Fix: use 2-space indentation, verify each `kind:` key is at the correct nesting level.
- **User preference: always provide full complete YAML blocks for paste** — never partial snippets. When preparing topic fixes, give the user the complete `kind: AdaptiveDialog` through `outputType: {}` block they can Ctrl+A → paste directly. Partial snippets require the user to figure out where to insert them, which causes errors.

**User preference: Notepad formatting for manual paste files** — When writing files for the user to open in Notepad and paste into Copilot Studio:
- No markdown headers (#) — use plain text section headers with blank lines
- Each numbered instruction as its own paragraph (not running together)
- Blank lines between all sections
- Clean plain text that reads well without markdown rendering
- The user will Ctrl+A → Ctrl+C from Notepad → paste into the editor
- Prefer General quality for open-ended compliance/knowledge evaluations; use Compare meaning only when an expected answer is truly required.
- Remove citation tag preservation instructions: "Preserve all tags in the format [^x_y^]" causes evaluation failures because internal knowledge-source tracking tags should not appear in user-facing responses. Replace with "Cite knowledge sources by natural source name. Do not output cite:1, Citation-1, or metadata tags."
- **TOPIC-LEVEL 800-char limit is the #1 Conv failure root cause** (June 2026 validated): NOT agent instructions. The topic `additionalInstructions` in each audit topic YAML contained `Keep response under 800 characters.` This caused incomplete responses across ALL agents. Fix: replace with `Be concise but complete.` and add natural citation instruction to each topic. Proof: OT Conv 85%→90% after v9 instructions, PT SR 96% after same pattern, SLP topic fix pending.
- **REMOVE 800-character limits entirely** from topic `additionalInstructions`. The phrase "Keep response under 800 characters" or "never exceeding 800 characters per section" truncates audit responses mid-sentence, causing the grader to mark them incomplete. Replace with "Be concise but complete. Prioritize accuracy over strict length limits." This was the root cause of Conv failures across OT (85%→90%), PT (75%), and SLP (85%) in June 2026.
- Explicitly include pasted text in routing triggers: add "pasted content" alongside "uploaded file" in topic trigger descriptions so that users who paste clinical text get the same audit workflow as file uploads.
- **Unconditional RESPONSE FORMAT kills conversation scores**: \"Always use RESPONSE FORMAT for ALL audit requests\" forces structured output on general inquiries, causing 10%+ drops. Replace with conditional — \"For full document audits: use RESPONSE FORMAT. For general questions: give focused natural answer.\" Proven: PT 80%→95%.

## Publish, Test, And Sync

1. Publish the agent from Copilot Studio or `pac copilot publish`.
2. Wait for publish and retrieval propagation.
3. Verify `synchronizationstatus.lastFinishedPublishOperation.status == "Succeeded"`.
4. Rerun evaluations using the **Power Platform Evaluation REST API** (see `passagenttesting` skill for full API reference). List test sets, trigger a run, poll for completion, then get per-case results. This is faster and more reliable than waiting for the SPA evaluation grid.
5. If either score is below threshold, export failures and repeat the root-cause loop.
6. If thresholds are met, run a regression pass against previously passing cases.
7. Sync live back to local:
   - Pull live topics, knowledge metadata, GPT instructions, and active evaluation cases.
   - Remove stale local components only inside the target agent's managed local folders.
   - Write a manifest with environment, bot ID, component IDs, component types, modified timestamps, and output files.

## Microsoft References

- Evaluation triage overview: https://learn.microsoft.com/microsoft-copilot-studio/guidance/evaluation-triage-overview
- Triage agent failures: https://learn.microsoft.com/microsoft-copilot-studio/guidance/evaluation-triage-failure
- Pattern analysis: https://learn.microsoft.com/microsoft-copilot-studio/guidance/evaluation-triage-pattern
- Remediation strategies: https://learn.microsoft.com/microsoft-copilot-studio/guidance/evaluation-triage-remediation
- Edit test cases: https://learn.microsoft.com/microsoft-copilot-studio/analytics-agent-evaluation-edit-cases
- Evaluation methods: https://learn.microsoft.com/microsoft-copilot-studio/analytics-agent-evaluation-overview
- Evaluation REST API: https://learn.microsoft.com/microsoft-copilot-studio/analytics-agent-evaluation-rest-api
- Automate evaluation with Evaluation APIs: https://techcommunity.microsoft.com/blog/copilot-studio-blog/automate-agent-evaluation-with-the-evaluation-apis/4511653
