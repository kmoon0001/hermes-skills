---
name: license-verification
description: "Professional license/credential verification for compliance and litigation support. Scrape state licensing boards, cross-reference facility/admin lists, generate color-coded compliance reports with email alerts. Modular per-state scrapers using Playwright + REST APIs. Fully automated (11): Alabama, Arizona, California, Colorado (CIM API), Idaho, Kansas (KSDADS), Nebraska, Oregon, Texas, Washington (Socrata API), Wisconsin. Blocked (6): Alaska (DataDome CAPTCHA), Iowa (JS verification), Nevada (no lookup), SC (reCAPTCHA), TN (AJAX form), UT (reCAPTCHA). CMS staffing/penalty data integration for executive defense."
version: 0.1.0
author: Hermes Agent
tags: [compliance, license-verification, scraping, playwright, healthcare, reporting]
---

# License Verification System

Verify whether professionals hold active state licenses. Designed for compliance audits, litigation protection, and recurring monitoring. Default implementation targets nursing home administrators (NHA) but the architecture works for any state-licensed profession.

## Architecture

```
Input (Excel with hidden admin names | SharePoint List)
    ↓
State Scraper (Playwright — one per state)
    ↓
Compliance Report (Excel: color-coded flags) + Email Alert
```

**Key design decisions:**
- Licenses are by PERSON, not by facility. An admin licensed in CA can work at any CA facility.
- Source of truth = user's Excel/SharePoint List. Admins should not need to re-enter names.
- Adding a facility = adding a row. No code changes.
- Monthly cadence catches expirations before compliance issues.
- For litigation: timestamped evidence + source URL required.
- **User preference: "without over complicating or causing regression"** — prefer adding features as separate scripts/functions, not rewriting existing code. Simple, incremental changes.
- **User preference: auto-open reports** — `os.startfile()` after saving, not just saving to disk.
- **User preference: "simple but powerful and actionable"** — charts should be clean and tell a story in 30 seconds, not complex dashboards.
- **User preference: "non-coding tools"** — user wants interactive CLI tools (prompts, forms) not scripts they have to edit. The Streamlit frontend and `add_facility.py` were built because user said "can it be through non coding like an option that prompts you to enter the name?".
- **User preference: "be objective on the probability of success"** — before building a feature, assess honestly whether it's feasible and what the risks are. Don't overpromise.
- **User preference: sharp scope control** — user said "anything not related to [licensing/staffing defense] or the sequelae of that I don't want." Only add data/features that directly serve the compliance defense use case. No general-purpose dashboards.

**Data source priority when a state portal has CAPTCHA:**
1. Open data API (Socrata, CKAN) — free, no CAPTCHA, often includes expiration dates
2. PDF roster — free, updated periodically
3. Paid data download — cheap per-record
4. Semi-auto browser — user solves one CAPTCHA per session
5. Manual verification — last resort

Always check for open data APIs BEFORE marking a state as blocked. Colorado (CIM) and Washington (Socrata) both have free APIs that made scrapers fully functional without Playwright.

## Folder Layout

```
D:/license-verification/
├── config.json              # Email, paths, state scraper map
├── verify_licenses.py       # Main script: read → verify → report → email
├── states/                  # One scraper per state
│   ├── california.py        # CDPH NHA — validated
│   ├── texas.py             # TULIP — validated, returns expirations
│   ├── arizona.py           # stub
│   └── ...
├── reports/                 # Output Excel reports
└── cms_data/                # Cached CMS Provider of Services file
```

## Reading Excel with Hidden Columns

openpyxl reads hidden columns/rows automatically — no special flags needed.

```python
import openpyxl
wb = openpyxl.load_workbook('file.xlsx', data_only=True)
ws = wb['Sheet']
for row in ws.iter_rows(min_row=2, values_only=False):
    admin = row[5].value   # Column F — reads hidden column
    state = row[8].value   # Column I
```

**Config key mismatch pitfall:** If config.json uses `excel_sheet`, the code must read `config["excel_sheet"]`, not `config["sheet_name"]`. Keep them aligned.

## Data Source Preference

Prefer **SharePoint List** over Excel for ongoing data entry:

- Auto-detection of new rows via Power Automate triggers ("item created or modified")
- No file locking when multiple people edit
- Cleaner integration with Copilot Studio agents
- Excel acceptable for local prototyping, but do not build permanent infra around an Excel file if SharePoint is available

When using a SharePoint List as the source, Power Automate can trigger on new items and call an HTTP endpoint that runs the verification script.

## Email Configuration

SMTP credentials should be loaded from environment variables, with fallback to config.json:

```python
smtp_user = os.environ.get("SMTP_USER") or email_config.get("smtp_user")
smtp_password = os.environ.get("SMTP_PASSWORD") or email_config.get("smtp_pass")
```

This allows the same config file to be committed to source control without secrets.

**Config key consistency:** Email config lives under `email` in config.json. Always access via `config["email"].get("smtp_user")` — never hardcode `config["smtp_user"]`.

## California CDPH NHA Scraper Pattern (FULLY FUNCTIONAL — Detail Pages for Expiration)

**Site:** https://cvl.cdph.ca.gov/SearchPage.aspx

California’s results page only shows Name | Type | Number | Status. **To get expiration dates, the scraper must navigate to each result’s detail page** (`DetailPage.aspx?cert_holder_id=...`), parse `Expiration Date:`, and return it.

### Search flow

```python
page.check('#ContentPlaceHolderMiddleColumn_rdoLastStart')
page.fill('#ContentPlaceHolderMiddleColumn_txtLastNameStart', last_name)
page.click('#ContentPlaceHolderMiddleColumn_btnSearch2')
```

The **Last Name Starting With** search is more reliable than **Last Name, First Name** for CDPH. Use `rdoLastStart` + `txtLastNameStart` as primary search. Fall back to `rdoLastFirst` + `txtLastName`/`txtFirstName` if needed.

### Extracting results via JavaScript

Use `page.evaluate` to extract all table rows and `DetailPage.aspx` links in one shot — this avoids fragile Playwright locator loops:

```python
data = page.evaluate('''() => {
    const rows = [];
    const links = {};
    document.querySelectorAll('tr').forEach(tr => {
        const cells = Array.from(tr.querySelectorAll('td'));
        if (cells.length >= 4) {
            const text = cells.map(c => c.innerText.trim()).join('\\t');
            rows.push(text);
        }
    });
    document.querySelectorAll('a[href*="DetailPage.aspx"]').forEach(a => {
        const m = a.href.match(/cert_holder_id=(\\d+)/);
        if (m && a.innerText.trim()) links[a.innerText.trim()] = m[1];
    });
    return {rows, links};
}''')
```

Rows are tab-delimited: `NAME \t TYPE \t NUMBER \t STATUS`.

### Detail page fetch for expiration

Once the best matching result is selected, open its detail page and parse:

```python
detail_url = f"https://cvl.cdph.ca.gov/DetailPage.aspx?cert_holder_id={cert_holder_id}"
page.goto(detail_url, timeout=30000)
text = page.inner_text("body")
exp_match = re.search(r"Expiration Date:\\s*([^\\n]+)", text, re.IGNORECASE)
if exp_match:
    expiration = exp_match.group(1).strip()
```

Detail page also shows `Effective Date:` and `Status:` — use those for richer notes and status mapping.

### Status mapping from detail page

CDPH detail page statuses:
- `ACTIVE, EMPLOYABLE` → `Active` (PASS)
- `DENIED, NOT EMPLOYABLE` → `Denied` (FAIL)
- `INACTIVE` → `Inactive`
- `EXPIRED`, `REVOKED`, `SUSPENDED` → capitalized

### Name matching

CDPH result names are `LASTNAME, FIRSTNAME M.`. The `matches_name_score` helper uses `rapidfuzz.token_sort_ratio` with bonuses for substring matches. Threshold 60 is sufficient.

**Pitfall:** Do not use the “Last Name, First Name” name format (`rdoLastFirst`) for the initial search unless strictly necessary. The empty result for exact-name searches is a known limitation when the CDPH index stores names as `Last, First` and exact matching is applied inconsistently. `rdoLastStart` avoids this.

## Expiration Date Calculation Across All States

States that return parseable expiration strings but do not compute `days_until_expiry` are **under-counted** in expiration alerts. Apply this pattern to any state scraper that returns a non-empty `expiration` string:

```python
from datetime import datetime

days_until = None
if expiration:
    for fmt in ["%m/%d/%Y", "%B %d, %Y", "%Y-%m-%d", "%d-%b-%Y", "%m-%d-%Y"]:
        try:
            exp_date = datetime.strptime(expiration.strip(), fmt)
            days_until = (exp_date - datetime.now()).days
            break
        except ValueError:
            continue
```

This was applied to:
- **Alabama** — parses `Renewal Date:` and `Licensure:` but never converted to days.
- **Idaho** — parses `10-Feb-2028` but left days as `None`.
- **Wisconsin** — regex captured `\d{4}-\d{2}-\d{2}` as `granted` date (group 7 in old pattern) but threw it away. Now stores it and computes days.

**Result:** Alert logic in `verify_all.py` (`EXPIRES IN X DAYS` for 0–60 days, `EXPIRED` for negative) now triggers correctly for these states too.

## Texas TULIP Scraper Pattern (FULLY FUNCTIONAL)

**Site:** https://tulip.hhs.texas.gov/TULIP/s/public-search
**Verified:** Robert Smith Active #NFA007578, expires 2027-06-14

Texas TULIP uses Lightning Web Components with nested shadow DOM. The form has `lightning-select` and `lightning-input` components inside a custom LWC `c-rs_-public-search-l-w-c`.

### Key technique: Native select piercing

Playwright's `page.locator("select").all()` **pierces shadow DOM** and returns the native `<select>` elements inside Lightning components. This is the only reliable way to interact with the form:

```python
selects = page.locator("select").all()  # Returns 8 selects inside shadow DOM
selects[0].select_option(label="Nursing Facility Administrator")  # Program Type
page.wait_for_timeout(500)  # Wait for form re-render after selection

# RE-QUERY selects after selection — page may re-render and invalidate old references
selects = page.locator("select").all()
selects[1].select_option(label="Equals")  # First Name match type
selects[2].select_option(label="Equals")  # Last Name match type

inputs = page.locator('input[type="text"]').all()
inputs[0].fill(first_name)
inputs[1].fill(last_name)
```

### Submit button — critical gotcha

The Submit button is inside the LWC shadow DOM. Standard `page.locator('button:has-text("Submit")').click()` does NOT trigger the form submission. Use `get_by_text` which pierces shadow DOM:

```python
page.get_by_text("Submit", exact=True).first.click(force=True)
```

### Race condition retry

The LWC form sometimes doesn't fully render before interaction. Add retry logic:

```python
for attempt in range(2):
    result = _try_texas_search(...)
    if result.get("status") not in ("ERROR", "NOT FOUND"):
        return result
    if attempt == 0:
        time.sleep(1)
```

Results are tab-delimited: Last Name | First Name | NFA License Status | License Number | License Issue Date | License Initial Date | License Expiration Date | Unemployable

**Bulk search** is available (max 900 records) but requires SSN + DOB — not useful.

## State Scraper Interface

Every scraper must match this signature:

```python
def verify_<state>(admin_name: str) -> dict:
    return {
        "status": "Active|Inactive|Expired|NOT FOUND|ERROR|SKIPPED|LIMITED",
        "expiration": "MM/DD/YYYY|YYYY-MM-DD|",
        "url": "https://...",
        "note": "...",
        "days_until_expiry": int | None
    }
```

**Expiration date formats:** Accept both `%m/%d/%Y` (CA/states) and `%Y-%m-%d` (TX). Parse with a fallback format list instead of hardcoding one.

## Existing State Scraper Status

| State | Status | Notes | Board URL |
|-------|--------|-------|-----------|
| Alabama | ✅ Functional | ACTIVE, license #2353, renewal 10/31/2026. Parses Renewal Date + Licensure with days calculation. ASP.NET WebForms. | http://www.alboenha.alabama.gov/licensees.aspx |
| Alaska | 🚫 Blocked | DataDome CAPTCHA on CBPL search page (returns 403 with captcha-delivery.com). No free alternative found. Form field is `OwnerEntityName` (single field). | https://www.commerce.alaska.gov/cbp/main/Search/Professional |
| Arizona | ✅ Functional | NCIA Board at Thentia Cloud. Active #NCA-002062, expires 2028-02-14. | https://aznciab.portalus.thentiacloud.net/webs/portal/register/#/ |
| California | ✅ Functional | CDPH NHA search. Opens DetailPage.aspx for expiration dates. Active #00007647, expires 2027-01-21. ASP.NET WebForms. | https://cvl.cdph.ca.gov/SearchPage.aspx |
| Colorado | ✅ Functional | CIM open data API (no CAPTCHA, free). Returns expiration dates. License types: NHA, MSNHA, NHATPE, TNHAP. | https://data.colorado.gov/resource/7s5z-vewr.json |
| Idaho | ✅ Functional | edopl.idaho.gov Name field #Dd-11. Active #NHA-1492, expires 10-Feb-2028. Parses expiration + days calculation. Name-only search works without board selection. | https://edopl.idaho.gov/OnlineServices/?link=PubSearch |
| Iowa | 🚫 Semi-automated | Amanda Portal requires JS verification. Use `semi_auto.py` — opens browser, user solves JS challenge once. | https://amanda-portal.idph.state.ia.us/ibpl/portal/#/dashboards/index |
| Kansas | ✅ Functional | KSDADS glsuite portal (no CAPTCHA). Detail pages show expiration + status. License type: "Adult Care Home Administrator". | https://ksdadsv7prod.glsuite.us/glsuiteweb/Clients/ksdads/public/verification/LicVerification.aspx |
| Nebraska | ✅ Functional | PDF roster with admin names. Free, updated monthly. | https://dhhs.ne.gov/licensure/Documents/LTCRoster.pdf |
| Nevada | ⏸️ On hold | Board site has no public license lookup. CMS Provider Data can be used for facility cross-reference. | https://www.beltca.nevada.gov/ |
| Oregon | ✅ Functional | OHLO search. Active #P-10229922, expires 2/28/2027. Tab-delimited results. | https://elite.hlo.state.or.us/OHLOPublicR |
| South Carolina | 🚫 Semi-automated | SC LLR requires reCAPTCHA. Find button is visibility:hidden until CAPTCHA solved. Use `semi_auto.py`. | https://verify.llronline.com/LicLookup/LTC/LTC.aspx?div=35 |
| Tennessee | 🚫 Blocked | Licensure Reports portal has complex AJAX form (jQuery dynamic dropdowns, CSRF tokens). Only 11 facilities. No CAPTCHA but form submission doesn't work via Playwright. | https://internet.health.tn.gov/LicensureReports/ |
| Texas | ✅ Functional | TULIP LWC shadow DOM. Active #NFA012571, expires 2027-01-26. | https://tulip.hhs.texas.gov/TULIP/s/public-search |
| Utah | 🚫 Semi-automated | DOPL License Lookup requires reCAPTCHA. Paid data download available ($0.01/record). Use `semi_auto.py` or paid download. | https://secure.utah.gov/llv/search/index.html |
| Washington | ✅ Functional | WA Open Data Socrata API (no CAPTCHA, free). Returns expiration dates. Dataset: qxh8-f4bd. | https://data.wa.gov/resource/qxh8-f4bd.json |
| Wisconsin | ✅ Functional | DSPS License Lookup. Active #4062-65, Brianna L Klemp, granted 2019-08-02. **No expiration date shown** — WI only shows Granted date. Status (Active/Inactive) is reliable. | https://license.wi.gov/s/license-lookup |

## Report Format (3-Tab Excel)

The verification output is a 3-tab Excel workbook:

### Tab 1: Executive Summary (opens first — tells the story in 30 seconds)
- **Key Metrics:** Total verified, PASS/FAIL/Manual counts, expired licenses, expiring within 60 days, missing admins
- **CMS Staffing & Compliance:** Average star rating, low staffing count, penalty count, abuse flags
- **Flagged Items Table:** Sorted by CRITICAL → MEDIUM → LOW severity
  - CRITICAL: expired license, abuse flag, license not verified
  - MEDIUM: expiring soon (≤60d), low CMS staffing rating (1-2 stars), 3+ penalties
  - LOW: high RN turnover (>50%), blocked states
- **Recommended Actions:** Priority-coded action items (CRITICAL/HIGH/MEDIUM/LOW)

### Tab 2: Charts (visual for presentations)
- **Pie Chart:** License Verification Status (PASS/FAIL/Manual Review %)
- **Bar Chart:** CMS Overall Star Rating Distribution (1-5 stars)
- **Bar Chart:** CMS Staffing Rating Distribution (1-5 stars)
- **Horizontal Bar:** License Expiration Timeline (Expired → 30d → 60d → 90d → 180d → 365d → 1yr+)

### Tab 3: Detailed Results (raw data for drilling down)
All facilities with every data column (license + CMS). Color-coded:
- **Green fill:** PASS (active license)
- **Red fill:** FAIL (not found, expired, errors)
- **Yellow fill:** NEEDS MANUAL REVIEW (blocked states)
- **Bold red:** Expiration alerts (≤60 days or expired)

### Output filename
Use timestamped filenames (`verification_YYYY-MM-DD_HHMMSS.xlsx`) to avoid `PermissionError` when the previous report is still open in Excel.

## Auto-Detection of New Facilities

Compare row count against stored snapshot. New rows → auto-process.

When SharePoint is the source, Power Automate triggers on item creation. When using Excel, a watcher script detects file modifications and re-runs.

## Alabama ALBONEHA Scraper Pattern (VALIDATED)

**Site:** http://www.alboenha.alabama.gov/licensees.aspx

Classic ASP.NET WebForms. Search by name, then parse the result page.

```python
page.check("#ctl00_ContentPlaceHolder1_UserInputGen_rdoSearchByName")
page.fill("#ctl00_ContentPlaceHolder1_UserInputGen_txtLastName", last_name)
page.fill("#ctl00_ContentPlaceHolder1_UserInputGen_txtFirstName", first_name)
page.click("#ctl00_ContentPlaceHolder1_UserInputGen_btnSearch")
page.wait_for_load_state("networkidle", timeout=15000)
text = page.inner_text("body")
```

Parsing uses regex on the result text:
- License Number: `re.search(r"License Number:\s*(\d+)", text, re.IGNORECASE)`
- Status: look for "Active" / "Inactive" / "Expired"
- Renewal Date: parse after "Renewal Date:" label

**Pitfall:** The result text contains non-breaking spaces (`\xa0`) and mixed line breaks. Use `\s*` in regex and strip whitespace from captures.

## Arizona NCIA Board Scraper Pattern (FULLY FUNCTIONAL)

**Site:** https://aznciab.portalus.thentiacloud.net/webs/portal/register/#/
**Verified:** Conner Monks Active #NCA-002062, expires 02/14/2028

**Critical discovery:** AZ Care Check (`azcarecheck.azdhs.gov`) searches FACILITIES, not individual NHA administrators. The correct source is the **NCIA Board** (Nursing Care Institution Administrators and Assisted Living Facility Managers) at the Thentia Cloud portal.

The NCIA Board site is a single-page app (Thentia Cloud). Search works by entering a name and clicking Search — no login required:

```python
page.goto("https://aznciab.portalus.thentiacloud.net/webs/portal/register/#/")
page.wait_for_load_state("networkidle", timeout=15000)
page.wait_for_timeout(2000)

# Select Individual License (radio button)
page.locator('input[name="registerType"]').first.click()
page.wait_for_timeout(500)

# Fill search
page.locator('input[name="keywords"]').fill(admin_name.strip())
page.wait_for_timeout(200)

# Click Search
page.locator('button:has-text("Search")').click()
page.wait_for_load_state("networkidle", timeout=15000)
page.wait_for_timeout(2000)
```

Results are tab-delimited: License Number | First Name | Last Name | License Type | License Status | License Expiration Date | Disciplinary Action

## Oregon OHLO Scraper Pattern (FULLY FUNCTIONAL)

**Site:** https://elite.hlo.state.or.us/OHLOPublicR
**Verified:** David Horn Active #P-10229922, expires 2/28/2027

Classic ASP.NET WebForms with specific element IDs:

```python
page.locator("#CPH1_txtsrcApplicantLastName").fill(last_name)
page.locator("#CPH1_txtsrcApplicantFirstName").fill(first_name)
page.locator("#CPH1_btnGoFind").click()
page.wait_for_load_state("networkidle", timeout=15000)
```

Results are tab-separated. Column layout (0-indexed):
- 0: (empty)
- 1: Licensee Name (format: "LASTNAME, FIRSTNAME M")
- 2: License No.
- 3: Status (Active/Inactive/Expired)
- 4: Active Through (expiration date, format M/D/YYYY)
- 5: City, State, Zip
- 6: License Type (e.g., "P - Permanent - Nursing Home Administrator")
- 7: Board

**Parser:** Skip header row (Licensee Name). Filter for "Active" status. Prefer NHA license type. Expiration format is `M/D/YYYY` (no leading zeros).

## Wisconsin DSPS Scraper Pattern (FULLY FUNCTIONAL — NO EXPIRATION DATE)

**Site:** https://license.wi.gov/s/license-lookup
**Verified:** Brianna L Klemp Active #4062-65, granted 2019-08-02

**CRITICAL: WI does NOT show expiration dates.** The portal shows a "Granted" date, which is when the license was first issued. Do NOT use this as the expiration date — it will show licenses as "expired from 2019" when they're actually active. Set `expiration = ""` and `days_until_expiry = None`.

Salesforce Lightning-style grid with custom combobox for search type.

### Search flow:
1. Click "Select Search By" text to open dropdown
2. Click "Individual Name" option
3. Fill `lastName` and `firstName` inputs (appear after selection)
4. Click Search button

```python
page.get_by_text("Select Search By").click()
page.wait_for_timeout(1000)
page.get_by_text("Individual Name").click()
page.wait_for_timeout(1000)
page.locator('input[name="lastName"]').fill(last)
page.locator('input[name="firstName"]').fill(first)
page.get_by_role("button", name="Search").click()
```

### Result parsing — regex pattern

The page uses `\r\n\t\r\n` as field separators (each field on its own line with tabs). Use regex:

```python
pattern = (
    r'(\d+\s*-\s*\d+)\s*\n'
    r'Nursing Home Administrator\s*\n'
    r'(\w+)\s*\n'
    r'([^\n]+)\s*\n'
    r'([^\n]*)\s*\n'
    r'([^\n]+)\s*\n'
    r'([^\n]+)\s*\n'
    r'(\d+)\s*\n'
    r'(\d{4}-\d{2}-\d{2})\s*\n'
    r'(Active|Inactive|Expired|Revoked|Suspended)'
)
```

Groups: 0=LicenseNum, 1=Type, 2=Name, 3=DBA, 4=City, 5=State, 6=Zip, 7=Granted, 8=Status

**Note:** WI doesn't show expiration date in the listing, only Granted date.

## Colorado CIM Open Data API Pattern (FULLY FUNCTIONAL — NO PLAYWRIGHT)

**API:** https://data.colorado.gov/resource/7s5z-vewr.json
**Dataset:** Professional and Occupational Licenses for Colorado
**Verified:** Emily Amschel Active #3010, exp 2027-02-28; Eddy Boyles Active #1867

Colorado's DORA license lookup has CAPTCHA, but the state publishes all license data via the Colorado Information Marketplace (CIM) — a free Socrata open data API. No Playwright needed.

### Query pattern

```python
import urllib.parse, urllib.request, json

NHA_TYPES = ("NHA", "MSNHA", "NHATPE", "TNHAP")
type_clause = " OR ".join(f"licensetype='{t}'" for t in NHA_TYPES)
where = f"({type_clause}) AND upper(lastname)='{last_name.upper()}'"
params = urllib.parse.urlencode({"$where": where, "$limit": "20"})
api_url = f"https://data.colorado.gov/resource/7s5z-vewr.json?{params}"

req = urllib.request.Request(api_url, headers={"Accept": "application/json"})
with urllib.request.urlopen(req, timeout=15) as resp:
    data = json.loads(resp.read().decode())
```

### Response fields
- `lastname`, `firstname`, `middlename`, `entityname`
- `licensetype` (NHA, MSNHA, NHATPE, TNHAP)
- `licensenumber`
- `licenseexpirationdate` (ISO: `2027-02-28T00:00:00.000` — slice to `[:10]` for date)
- `licensestatusdescription` (Active, Expired, Revoked, Suspended)
- `city`, `state`
- `linktoverifylicense` (URL object)

### Key notes
- The `in()` clause does NOT work with Socrata — use `OR` instead.
- NHA license types are coded: `NHA`, `MSNHA`, `NHATPE`, `TNHAP`.
- All active NHAs expire on the same date (2027-02-28 in current data).
- No rate limiting observed, but keep `$limit` reasonable.

**Lesson:** When a state portal has CAPTCHA, check if the state has an open data portal (Socrata, CKAN, etc.) with license data. This pattern may work for other states.

## Washington Open Data Socrata API Pattern (FULLY FUNCTIONAL — SUPERSEDES HELMS)

**API:** https://data.wa.gov/resource/qxh8-f4bd.json
**Dataset:** Health Care Provider Credential Data (2.42M rows, daily updates)
**Verified:** Matthew Payne Active #NHA.NH.61348152, exp 09/22/2026

Washington's HELMS portal has reCAPTCHA, but the state publishes all healthcare provider credential data via a Socrata open data API. Same pattern as Colorado CIM.

### Query pattern

```python
import urllib.parse, urllib.request, json

where = f"upper(credentialtype) like '%NURSING HOME%' AND upper(lastname)='{last_name.upper()}'"
params = urllib.parse.urlencode({"$where": where, "$limit": "20"})
api_url = f"https://data.wa.gov/resource/qxh8-f4bd.json?{params}"

req = urllib.request.Request(api_url, headers={"Accept": "application/json"})
with urllib.request.urlopen(req, timeout=15) as resp:
    data = json.loads(resp.read().decode())
```

### Response fields
- `credentialnumber` — License number (e.g., NHA.NH.61348152)
- `lastname`, `firstname`, `middlename`
- `credentialtype` — "Nursing Home Administrator License"
- `status` — Active/Expired/Revoked
- `expirationdate` — MM/DD/YYYY format
- `firstissuedate`, `lastissuedate`
- `actiontaken` — Disciplinary action indicator

### Key notes
- Credential type is "Nursing Home Administrator License" (not just "NHA")
- Expiration dates are in MM/DD/YYYY format (not ISO)
- Bonus score for Active status when matching names
- Same Socrata SODA 3.0 API as Colorado — reusable pattern

## Kansas KSDADS glsuite Portal Pattern (FULLY FUNCTIONAL)

**Portal:** https://ksdadsv7prod.glsuite.us/glsuiteweb/Clients/ksdads/public/verification/LicVerification.aspx
**Verified:** Ethan Dean Active #4280, exp 06/30/2028

Kansas prolicenseverify.ks.gov has reCAPTCHA, but the KSDADS (Kansas Department for Aging and Disability Services) glsuite portal has no CAPTCHA. It covers "Adult Care Home Administrators" (Kansas equivalent of NHA).

### Search flow

```python
page.goto(KS_URL, timeout=30000)
page.wait_for_load_state("networkidle", timeout=15000)
page.fill("#waLastName", last_name)
if first_name:
    page.fill("#waFirstName", first_name)
page.click("#btnSubmit")
page.wait_for_load_state("networkidle", timeout=15000)
```

### Results format
Results table: Details (link) | First Name | Middle Name | Last Name | License Number | License Type

Filter for "Adult Care Home Administrator License" (exclude "Temporary" variants).

### Detail page for expiration/status
Click "Details" link to get the full record. The page has a two-column layout where labels and values are in SEPARATE sections with a gap.

**Critical parsing pitfall:** Labels (Expiration Date:, Status:) appear on lines 7-16. Values appear on lines 19-28. They are NOT adjacent. Parse by:
1. Find "Disciplinary Action:" label to mark end of label section
2. Search for MM/DD/YYYY dates after that point — the SECOND date is the expiration (first is issue date)
3. Search for status words (active/inactive/expired) after that point

```python
lines = [l.strip() for l in text.split("\n") if l.strip()]
label_end = 0
for i, line in enumerate(lines):
    if "Disciplinary Action" in line:
        label_end = i
        break

dates_found = []
for i in range(label_end, len(lines)):
    line = lines[i]
    if len(line) == 10 and line.count("/") == 2:
        try:
            datetime.strptime(line, "%m/%d/%Y")
            dates_found.append(line)
        except ValueError:
            pass
    if line.lower() in ("active", "inactive", "expired", "revoked", "suspended"):
        status = line

# Expiration is the second date (after issue date)
if len(dates_found) >= 2:
    expiration = dates_found[1]
```

## Nebraska PDF Roster Scraper Pattern (FULLY FUNCTIONAL)

**Site:** https://dhhs.ne.gov/licensure/Documents/LTCRoster.pdf
**Verified:** Kristie Kallemeyn #324003 (MONROE HEALTHCARE), Alice Smith #034001 (VSL ALLIANCE)

Nebraska's License Lookup requires reCAPTCHA, but the state publishes a free monthly PDF roster of all Long Term Care facilities with administrator names and license numbers.

### How it works:
1. Download the PDF from the DHHS URL
2. Parse with pdfplumber
3. Search for admin name (case-insensitive)
4. Look backward in the text for license number (6-digit) and facility name

```python
import pdfplumber, urllib.request, tempfile, os, re

tmp_path = os.path.join(tempfile.gettempdir(), "nebraska_roster.pdf")
urllib.request.urlretrieve("https://dhhs.ne.gov/licensure/Documents/LTCRoster.pdf", tmp_path)

with pdfplumber.open(tmp_path) as pdf:
    text = ""
    for page in pdf.pages:
        text += (page.extract_text() or "") + "\n"
os.unlink(tmp_path)

# Search for "Kristie Kallemeyn, Administrator" in text
# Look backward for license number (6-digit on FAX line)
# Look for facility name before "Total Licensed"
```

**Pitfall:** The license number appears on a line with "FAX:" — extract the 6-digit number from that line. The facility name appears on a line with "Total Licensed" — extract the text before that phrase.

**Expiration rule:** Nebraska LTC licenses expire March 31st each year (stated in the PDF header). Calculate expiration rather than scraping:
```python
today = datetime.now()
if today.month < 3 or (today.month == 3 and today.day <= 31):
    expiration = f"{today.year}-03-31"
else:
    expiration = f"{today.year + 1}-03-31"
```

**Note:** Requires `pip install pdfplumber`. The roster is updated on or about the 15th of each month.

## Utah Paid Data Download (Alternative to CAPTCHA-blocked lookup)

**URL:** https://secure.utah.gov/datarequest/professionals/index.html
**Cost:** $0.01/record, minimum $5.00 for first 200 records

Utah DOPL License Lookup requires reCAPTCHA, but the state offers a paid data download service. You can order a full download filtered by "Health Facility Administrator" profession. This provides Name, License Type, License Status, and (with DOPL approval) Address, Phone, Email.

**Use case:** For monthly monitoring of 32 Utah facilities, the cost would be ~$0.32/month after the initial $5 setup. Worth it if Utah coverage is required.

## Iowa Amanda Portal Pattern (NEEDS REFINEMENT)

**Site:** https://amanda-portal.idph.state.ia.us/ibpl/portal/#/dashboards/index

The DIAL nursing-homes page only has informational links. The actual NHA search is on the Amanda Portal. Click "Find a Licensee" (no login required), then fill First Name, Last Name, and click Search. The portal has Board and License Type dropdowns but they may need to be set for NHA-specific results.

## Idaho edopl Portal Pattern (NEEDS REFINEMENT)
## Iowa DIAL Records Pattern (BLOCKED — NO NHA-SPECIFIC SEARCH)

**Site:** https://dial.iowa.gov/i-need/records
**Status:** BLOCKED — The DIAL page only has informational links. The Amanda Portal (`amanda-portal.idph.state.ia.us`) requires JavaScript verification that's not easily automated. No reliable NHA-only search found.

Kansas prolicenseverify.ks.gov has reCAPTCHA, but the KSDADS glsuite portal has no CAPTCHA and covers "Adult Care Home Administrators" (Kansas equivalent of NHA). Use this instead.

## Kansas prolicenseverify Pattern (SUPERSEDED — USE KSDADS)

**Old site:** https://prolicenseverify.ks.gov/
**Status:** BLOCKED — reCAPTCHA on page load. The KSDADS glsuite portal (see above) is the working alternative.

## Colorado DORA Scraper Pattern (SUPERSEDED — USE CIM API)

**Old site:** https://dpo.colorado.gov/COHPC (redirects to HPPP)
**Status:** The DORA license lookup at `apps.colorado.gov/dora/licensing/Lookup/LicenseLookup.aspx` has CAPTCHA. However, Colorado publishes all license data via the CIM open data API (see "Colorado CIM Open Data API Pattern" above). Use the API instead.

## Adding New State Scrapers (Procedure)

1. Find the state licensing board's public search URL via web search.
2. Determine search fields available: name-only is preferred; facility-only is LIMITED.
3. If name-based: write a Playwright script that fills the form and parses results.
4. **Test the scraper individually with a real admin name from the Excel before committing.**
5. **If the test passes, commit the scraper, then move to the next state. Do not batch-write stubs and test later.**
6. Add the scraper to `states/<state>.py`, import it in `verify_licenses.py`, and register it in `STATE_SCRAPERS` and `config.json["states"]`.

**Workflow rule: verify one state at a time.** Build → test with real data → commit → next state. This prevents carrying forward broken selectors across many files at once.

## Idaho edopl Portal Pattern (FULLY FUNCTIONAL)

**Site:** https://edopl.idaho.gov/OnlineServices/?link=PubSearch
**Verified:** Calene Cole Active #NHA-1492, expires 10-Feb-2028

The Name field uses the ID `Dd-11`. The Board and License Type fields are custom React comboboxes that are difficult to automate — but searching by Name alone works without selecting a board.

```python
page.locator('#Dd-11').fill(admin_name.strip())
page.locator('#Dd-11').press("Enter")
page.wait_for_load_state("networkidle", timeout=15000)
```

Results are tab-separated. The line containing the matched name also contains Status and Expiration. Look backward 1-2 lines for the license number (format `[A-Z]{3}-\d+`, e.g. `NHA-1492`).

**Parser logic:**
- Find the line containing the admin name
- Look backward 1-2 lines for license number pattern `^[A-Z]{3}-\d+$`
- Look at the current line's tab-separated fields: Status is typically field index 4, Expiration is index 5
- Expiration format: `10-Feb-2028` (DD-Mmm-YYYY)

## Tennessee Licensure Reports Portal (BLOCKED — AJAX FORM)

**Portal:** https://internet.health.tn.gov/LicensureReports/
**Board value:** 25 (Nursing Home Administrators)
**Profession value:** 2514 (Nursing Home Administrator)
**State value:** 1 (Tennessee)

The portal has a form that generates reports for all NHA licenses in Tennessee. The portal has NO CAPTCHA — it's a free, public portal. However, form submission via Playwright doesn't produce results because the form uses jQuery AJAX for dynamic dropdown loading and form submission with CSRF tokens.

**Why it fails:**
- Board dropdown loads dynamically via AJAX call (`FetchProfessionsByBoard`)
- Profession dropdown depends on Board selection (another AJAX call)
- Form submission uses jQuery's `unbind('submit').submit()` pattern
- CSRF token (`__RequestVerificationToken`) changes per session
- Report generation may be async (polling for file)

**Workaround:** Keep as BLOCKED for now. Only 11 TN facilities. If needed in the future, investigate the AJAX endpoints directly or use `semi_auto.py`.

## Kansas prolicenseverify Pattern (SUPERSEDED — USE KSDADS)

**Old site:** https://prolicenseverify.ks.gov/
**Status:** BLOCKED — reCAPTCHA on page load. Use the KSDADS glsuite portal instead (see "Kansas KSDADS glsuite Portal Pattern" above).

## Colorado DORA Pattern (BLOCKED — CAPTCHA)

**Site:** https://dpo.colorado.gov/COHPC
**Status:** BLOCKED — site shows "Let's confirm you are human" CAPTCHA before any search. No workaround found. The old DORA URL (dora.colorado.gov/check-a-license) doesn't return NHA data.

## Semi-Automated Browser (`semi_auto.py`)

For states blocked by CAPTCHA/reCAPTCHA/CloudFront/hCaptcha/JS verification. Opens a real Chrome window with a persistent profile. You solve ONE CAPTCHA per state per session, then the script auto-searches all admin names.

**Implemented states (8):** Alaska, Colorado, Iowa, Kansas, South Carolina, Tennessee, Utah, Washington

**Usage:**
```bash
python semi_auto.py              # Interactive — prompts for state
python semi_auto.py UTAH         # CLI arg — skips prompt, opens Chrome directly
```

**CLI argument support:** `semi_auto.py` accepts the state name as a command-line argument (`sys.argv[1]`), skipping the interactive `input()` prompt. This is useful for non-interactive terminals.

**Chrome profile locking:** `launch_persistent_context` locks the Chrome profile directory. If Chrome was previously running (even from a killed process), the next launch fails with "Opening in existing browser session." Fix: `taskkill //F //IM chrome.exe` before running, and remove `SingletonLock`/`SingletonSocket`/`SingletonCookie` files from the profile directory.

**Single-field portals:** When `selector_last == selector_first` (e.g., Utah uses `#fullName` for both), the script fills the full name into the single field instead of trying to fill two separate fields.

**Key selectors:**
- **South Carolina:** `#ctl00_ContentPlaceHolder1_UserInputGen_txt_lastName`, `#ctl00_ContentPlaceHolder1_UserInputGen_txt_firstName`, `#ctl00_ContentPlaceHolder1_btn_find`
- **Tennessee:** Dynamic ID inputs matched by label text. Submit: `button:has-text("Search")`
- **Utah:** `#lastName`, `#firstName`, `input[type='submit'][value='Search']`
- **Washington:** `#lastName`, `#firstName`, `button:has-text('Search')`
- **Kansas:** `#lastName`, `#firstName`, `button:has-text('Search')`
- **Alaska:** `select[name='Program']` (pre-submit hook selects "Nursing Home Administrators"), `input[name='OwnerLastName']`, `input[name='OwnerFirstName']`, `input[value='Search']`
- **Colorado:** `#lastName`, `#firstName`, `input[value='Submit']`
- **Iowa:** `input[name='lastName']`, `input[name='firstName']`, `button[type='submit']`

**Pre-submit hooks:** Alaska needs to select "Nursing Home Administrators" from a Program dropdown before searching. `semi_auto.py` supports `pre_submit` hooks in the state config for this.

## Master Verifier (`verify_all.py` + `run_nightly.py`)

Reads Excel, runs all state verifiers, writes color-coded Excel report.

```bash
python run_nightly.py
```

Output: `D:\license-verification\results\verification_YYYY-MM-DD.xlsx`

### Result Classification
- **PASS:** status is ACTIVE/FOUND + license is active
- **FAIL:** status is NOT FOUND/INACTIVE/EXPIRED/REVOKED/SUSPENDED
- **NEEDS MANUAL REVIEW:** BLOCKED, NEEDS_MANUAL, or ERROR

### Expiration Alerts
Any license expiring within 60 days (or already expired) gets an alert in the "Expiration Alert" column: `EXPIRES IN X DAYS` or `EXPIRED`.

### Error Handling
- Empty admin names in Excel → skipped (logged in summary)
- State not in `STATE_VERIFIERS` → logged in "states with issues" section
- Scraper exception → recorded as ERROR with traceback in note

## CAPTCHA/Blocked State Workarounds

For states blocked by CAPTCHA, reCAPTCHA, 403, or SSL errors, consider these alternatives:

### 1. Semi-Automated Browser (`scripts/semi_auto.py`) — Recommended for 5 states
Open a real Chrome window (non-headless, persistent profile), user solves ONE CAPTCHA, then the script auto-searches all admin names for that state. Only 1 CAPTCHA per state per month. Implemented states: SC, TN, UT, WA, KS.

Key selectors discovered:
- **South Carolina:** `#ctl00_ContentPlaceHolder1_UserInputGen_txt_lastName`, `#ctl00_ContentPlaceHolder1_UserInputGen_txt_firstName`, `#ctl00_ContentPlaceHolder1_btn_find`
- **Tennessee:** Dynamic ID inputs matched by label text (Last Name/First Name labels for `-33701226759` and `177334431563`). Submit button: `button:has-text("Search")`.
- **Utah:** `#fullName` (single field — not separate first/last), `input[type='submit'][value='Search']`. When `selector_last == selector_first`, the script fills the full name into the single field instead of trying to fill two fields.
- **Washington:** `#lastName`, `#firstName`, `button:has-text('Search')`.
- **Kansas:** `#lastName`, `#firstName`, `button:has-text('Search')`.

### 2. Public Records Requests
File formal public records requests with each state board for a list of all active NHA licensees. Most states provide CSV/Excel for free or $5-25. Takes 1-2 weeks but gives complete, reusable dataset.

### 3. Board Direct Contact
Call each state's NHA board, explain compliance verification needs. Many boards will mail/email current rosters or set up bulk verification.

### 4. CMS Provider Data (FREE, ALL STATES)
Free federal dataset at data.cms.gov of all Medicare-certified nursing homes. Covers all 15,000+ facilities nationwide. Updated monthly. Shows facility data (CCN, ownership, ratings, staffing) but may not include individual NHA names. Useful for cross-referencing facility certification status.

### 5. Stealth Plugins Don't Bypass reCAPTCHA v3
playwright-stealth and similar anti-detection libraries hide automation signals (webdriver flag, navigator properties) but do NOT bypass reCAPTCHA v3. reCAPTCHA v3 scores based on IP reputation + cookie history + behavioral patterns — a datacenter IP with no cookie history will still get flagged even with perfect browser fingerprint stealth. Residential proxies + session persistence are the only programmatic workaround without a solving service.

### 6. Persistent Context Session Storage
Saving cookies/storage state between runs does NOT bypass reCAPTCHA v3. The token is bound to the session/IP combination and expires quickly. We tested loading a saved Chrome profile into Playwright — the site still shows reCAPTCHA because reCAPTCHA v3 re-evaluates on every load.

### 7. Paid Data Downloads
Some states offer paid CSV/Excel downloads:
- Utah: $0.01/record, minimum $5 (https://secure.utah.gov/datarequest/professionals/index.html)
- Nebraska: Free PDF roster (already implemented)

## On-Demand Facility Addition (`add_facility.py`)

Interactive script — no coding needed. Prompts for facility name, state, and administrator name. Adds the facility to the master Excel and runs verification automatically.

```bash
python add_facility.py
```

Flow:
1. Prompts for: Facility name, State (abbreviation or full name), Administrator name
2. Validates state is recognized
3. Adds a new row to the master Excel (ENSG Facilities Only 6.1.26.xlsx)
4. Runs the appropriate state verifier
5. Displays result with expiration alerts
6. Saves individual result to `results/on_demand_YYYY-MM-DD_HHMMSS.xlsx`

States shown as "working" vs "blocked" before the user enters the state, so they know what to expect.

## Roster Reconciliation (`reconcile.py`)

Compare any facility roster (xlsx/csv) against the master Excel. Detects mismatches and runs license verification on flagged rows.

```bash
python reconcile.py
```

Prompts for the comparison file path. Auto-detects columns by header name (Location, Facility, Director, Admin, State). Falls back to position-based detection (same layout as master).

### Issues detected:

| Type | Severity | Meaning |
|------|----------|---------|
| ADMIN MISSING IN MASTER | HIGH | Facility exists but no admin listed |
| ADMIN MISMATCH | HIGH | Same facility, different admin between files |
| ADMIN FACILITY MISMATCH | HIGH | Same admin at different facilities |
| ADMIN MISSING IN FILE | MEDIUM | Admin in master but blank in uploaded file |
| STATE MISMATCH | MEDIUM | Same facility, different state |
| NEW FACILITY | INFO | In uploaded file but not in master |
| MISSING FROM FILE | WARNING | In master but not in uploaded file |

For HIGH/MEDIUM issues, the script offers to run license verification automatically on the flagged admins. Saves a multi-sheet Excel report to `results/reconcile_YYYY-MM-DD_HHMMSS.xlsx`.

## Pitfalls

0. **CMS state name matching — full names vs abbreviations.** Excel often stores state as full names ("Arizona", "California") but CMS data uses abbreviations ("AZ", "CA"). The `match_facility()` function must try BOTH. When state input is full name, also try the abbreviation from `STATE_MAP`. When abbreviated, also try full name. Without this, 0% of CMS matches will succeed. (Fixed 2026-06-24 in `cms_data.py`.)
0b. **Wisconsin "Granted" date ≠ Expiration date.** The WI DSPS portal shows a "Granted" date in the results, NOT an expiration date. The original scraper incorrectly used this as the expiration, showing licenses as "expired from 2019" when they were actually active. WI does not expose expiration in the search results. Set `expiration = ""` and `days_until_expiry = None` for WI. (Fixed 2026-06-24.)
0c. **Texas `_try_texas_search` needs explicit `page=None`.** The helper function must accept `page` as a parameter. Call with `page=None` from `verify_texas()` so it can create its own browser when no shared page is provided. Without this, `UnboundLocalError` crashes all TX verifications. (Fixed 2026-06-24.)
1. **Shadow DOM select piercing.** Playwright's `page.locator("select").all()` pierces shadow DOM and returns native `<select>` elements inside Lightning/LWC components. This is the most reliable way to interact with Salesforce Lightning forms. Do NOT try to click `lightning-combobox` elements directly — they fail with "Could not compute box model" errors.
2. **LWC race conditions.** Lightning Web Components re-render the DOM after selection changes. Always re-query `selects = page.locator("select").all()` after selecting Program Type, and add `page.wait_for_timeout(500)` between selections.
3. **LWC Submit button.** Standard `page.locator('button:has-text("Submit")').click()` does NOT trigger form submission on LWC forms. Use `page.get_by_text("Submit", exact=True).first.click(force=True)` which pierces shadow DOM and dispatches the click correctly.
4. **Retry on intermittent failures.** LWC forms sometimes fail to render fully before interaction. Add retry logic (2-3 attempts with 1s sleep) for any scraper that uses Lightning components.
5. **CDPH expiration requires extra click.** Results page shows Active/Inactive only; no date.
6. **Salesforce Lightning inputs** — standard Playwright `.fill()` does NOT work on `<lightning-input>`. Use `.click()` + `keyboard.type()`. However, for Texas TULIP, the native `<select>` and `<input type="text">` elements ARE accessible via standard locators.
7. **Excel file locking.** Use `data_only=True`, handle lock gracefully.
8. **Headless detection.** Add realistic user agent + random delays.
9. **Rate limiting.** Add 0.5-1s delay between requests.
10. **Name mismatches.** Normalize to uppercase, use rapidfuzz token_sort_ratio. Handle "First Last", "Last, First", and "First Last / Second Name" formats.
11. **Multiple admins per facility.** Split on `/` and check each separately.
12. **Config key drift.** If `config.json` uses `excel_sheet`, code must reference `config["excel_sheet"]`, not `config["sheet_name"]`. Same for `report_folder` vs `report_output`.
13. **Expiration date formats vary.** CA uses MM/DD/YYYY; TX uses YYYY-MM-DD; OR uses M/D/YYYY; AK uses 10-Feb-2028. Parse with a format fallback loop.
14. **Generic form selectors fail on custom UIs.** Do not build a "one form handler fits all" abstraction. Each state scraper must handle its own specific form elements (ASP.NET WebForms, Salesforce Lightning, React components, etc.). Test each scraper individually with a real admin name before integrating.
15. **ASP.NET WebForms sites** use `ctl00$ContentPlaceHolder1$btnSearch` style button names. Inspect the actual form before hardcoding selectors.
16. **AZ Care Check searches facilities, NOT individuals.** The site at `azcarecheck.azdhs.gov` is for facility lookup, not NHA verification. The correct Arizona NHA source is the NCIA Board at `aznciab.portalus.thentiacloud.net`.
17. **CAPTCHA / reCAPTCHA blocks automation but check for alternatives first.** Detect early (first request returns CAPTCHA page or reCAPTCHA badge appears in DOM). Before marking SEMI-AUTOMATED, check for: free PDF rosters (NE has one), paid data downloads (UT offers $0.01/record), public records requests, or CMS Provider Data.
18. **Language selection overlays.** Colorado DORA loads a "Select Language" dropdown before the search form is usable. Detect by checking for `select` with text "Select Language" or similar; select the first option or skip if no English option. Language selection prevents search form interaction.
19. **Each state has its own NHA verification URL.** Do NOT use the generic DORA/DOPL/KSBN main pages. Search for the specific NHA board URL (e.g., NCIA Board for Arizona, OHLO for Oregon, DSPS for Wisconsin, prolicenseverify.ks.gov for Kansas, edopl.idaho.gov for Idaho).
20. **Excel column mapping.** The ENSG Excel has: Col 0=LOCATION, Col 5=EXECUTIVE DIRECTOR, Col 8=STATE. Use `row[8]` for state and `row[5]` for admin name. The file path is `C:/Users/kevin/Desktop/ENSG Facilities Only 6.1.26.xlsx`.
21. ** Wisconsin DSPS result format uses `\r\n\t\r\n` separators.** Each field is on its own line with tabs between. Standard `split('\t')` won't work — use regex pattern matching instead.
22. ** Oregon OHLO results use standard tab separation** but the header row must be skipped (check for "Licensee Name" in first column). Expiration format is `M/D/YYYY` (no leading zeros).
23. **South Carolina reCAPTCHA hides the Find button.** The SC LLR LTC form at `LTC.aspx?div=35` has a Find button with `visibility: hidden` until reCAPTCHA is solved. The reCAPTCHA element is present in the DOM (`g-recaptcha-response` textarea). No stealth plugin bypasses this — it's server-side scoring.
24. **playwright-stealth does NOT bypass reCAPTCHA v3.** Stealth plugins hide automation signals but reCAPTCHA v3 scores on IP reputation + cookie history + behavior. Only residential proxies + session persistence work programmatically.
25. **Sites that load after `--ignore-certificate-errors` may still have no usable functionality.** Nevada's site (`beltca.nevada.gov`) loads after SSL error is ignored, but the homepage contains only links — no public license lookup form exists.
26. **Dynamic ID inputs require label-based selection.** Tennessee (`verify.tn.gov`) uses random IDs for inputs (`-33701226759`, `177334431563`). Match inputs by their associated `<label for="...">` text, not by ID.
27. **Colorado old URL (dora.colorado.gov) doesn't return NHA data.** The real NHA site is `dpo.colorado.gov/COHPC` which uses CloudFront and blocks automated requests. Mark as SEMI-AUTOMATED.
28. **Idaho DOPL edopl portal** uses `#Dd-11` for the Name field. Custom React comboboxes for Board/License Type are hard to automate, but Name-only search works without board selection.
29. **Kansas prolicenseverify has reCAPTCHA on page load.** The Profession dropdown has "Adult Care Home Administrator" and the form accepts firstName/lastName, but reCAPTCHA blocks submission. KSBN is for nursing only. Mark as SEMI-AUTOMATED.
30. **Iowa Amanda Portal requires JavaScript verification.** The DIAL records page only has informational links. Mark as SEMI-AUTOMATED and use `semi_auto.py`.
31. **Alaska CBPL Professional Search uses DataDome CAPTCHA.** The URL `commerce.alaska.gov/cbp/main/Search/Professional` has DataDome anti-bot protection (returns 403 with `captcha-delivery.com`). The form field is `OwnerEntityName` (single field, not separate last/first). The form loads dynamically — `select` and `input` elements are NOT visible to Playwright until JavaScript executes. Even with stealth settings, DataDome blocks headless Chromium. Mark as BLOCKED.
32. **Saved Chrome profiles/ contexts don't bypass reCAPTCHA v3.** The token is session-bound and re-evaluates on every load. Loading a saved state still shows the CAPTCHA. Use semi-auto only.
34. **Empty admin names in Excel should be handled gracefully.** `verify_all.py` skips facilities with no admin and logs them in the summary.
35. **Check open data portals before marking a state as BLOCKED.** Many states publish license data via Socrata/CKAN open data APIs (e.g., Colorado CIM at `data.colorado.gov`). Search for `site:data.colorado.gov <state> license` or `<state> open data professional license`. These APIs are free, no CAPTCHA, and often include expiration dates. Colorado's CIM API (`7s5z-vewr.json`) made the scraper fully functional without Playwright.
36. **Alaska CBPL form field is `OwnerEntityName` (single field).** The old scraper used `OwnerLastName`/`OwnerFirstName` which don't exist. The form has a single "Owner Last or Entity Name" field.
37. **Nebraska LTC licenses expire March 31st each year.** This is stated in the PDF header. Calculate the expiration date rather than trying to scrape it — it's the same for all licensees.
38. **Socrata `in()` clause doesn't work.** When querying Socrata APIs (Colorado CIM, Washington Open Data), the `in()` function fails with 400 errors. Use `OR` instead: `licensetype='NHA' OR licensetype='MSNHA'`.
39. **ASP.NET two-column label/value layouts.** Some ASP.NET portals (Kansas KSDADS) display labels and values in separate sections with a gap. Labels appear on lines 7-16, values on lines 19-28. They are NOT adjacent. Parse by finding the label section end, then searching for values (dates, status words) after that point.
40. **Kansas KSDADS license type is "Adult Care Home Administrator"** — not "Nursing Home Administrator". Filter results by this type and exclude "Temporary" variants.
41. **Washington Socrata credential type is "Nursing Home Administrator License"** — search with `upper(credentialtype) like '%NURSING HOME%'` for partial match.
42. **Tennessee Licensure Reports portal has complex AJAX form submission.** The form at `internet.health.tn.gov/LicensureReports/` accepts Board=25 (Nursing Home Administrators), Profession=2514, State=1 (Tennessee), but form submission via Playwright doesn't produce results — likely requires specific AJAX handling or token. Keep as BLOCKED for now; only 11 TN facilities.
42b. **Tennessee verify.tn.gov redirects to Commerce & Insurance portal.** `verify.tn.gov` now redirects to `search.cloud.commerce.tn.gov` — a Next.js app for Commerce & Insurance licenses (Accountancy, Contractors, etc.). It does NOT have Nursing Home Administrator data. NHA licenses are managed by the Department of Health, not Commerce & Insurance. The Health portal (`internet.health.tn.gov/Licensure/`) still has CAPTCHA. TN remains BLOCKED.
43. **Timestamped output filenames prevent PermissionError.** If the verification Excel is open in Excel when the next run finishes, `wb.save()` fails with `PermissionError: [Errno 13]`. Use `verification_YYYY-MM-DD_HHMMSS.xlsx` instead of `verification_YYYY-MM-DD.xlsx`.
44. **openpyxl chart imports must be inside the function.** `from openpyxl.chart import BarChart, PieChart, Reference` should be inside `write_results_excel()` to avoid import errors if openpyxl version doesn't support charts. The `DataPoint` import from `openpyxl.chart.series` is also needed for pie chart coloring.
45. **Texas `_try_texas_search` requires explicit `page=None` parameter.** The helper function must accept `page` as a parameter — do NOT rely on closure. Call with `page=None` from `verify_texas()` so it can create its own browser when no shared page is provided.
46. **User preference: auto-open reports after generation.** Use `os.startfile(str(path))` (Windows) to open the Excel file immediately after saving. The user expects the report to appear on screen, not just be saved to disk.
47. **`fails` is already an int, not a list.** In `write_results_excel`, `fails = sum(1 for r in results if r["overall"] == "FAIL")` returns an int. Do NOT call `len(fails)` — it's `TypeError: object of type 'int' has no len()`. Use `fails` directly in f-strings.
48. **Semi-auto must navigate back to search page before each search.** After clicking submit, the page changes to results — the search form no longer exists. The next `page.fill()` times out waiting for `#fullName` (or whatever the field selector is). Fix: before each search (except the first), `page.goto(config["url"])` back to the search page and wait for `networkidle`. Without this, every search after the first one times out with `Timeout 30000ms exceeded. waiting for locator("#fullName")`. (Fixed 2026-06-24 in semi_auto.py.)
49. **Utah reCAPTCHA may not trigger on first searches.** The Utah portal has reCAPTCHA but single searches often work without solving it. The CAPTCHA challenge may only appear after multiple rapid searches. If the CAPTCHA does appear, the user must solve it manually in the Chrome window before pressing ENTER in the terminal.

## CMS Staffing/Penalty Data Integration (for Executive Defense)

When the accusation is "unlicensed administrators + low staffing", the Excel must prove both compliance AND actual staffing levels. The `cms_data.py` module pulls from CMS Provider Data (free, no auth):

**Data sources:**
- Provider Info: `data.cms.gov/provider-data/dataset/4pq5-n9py` — 14,651 facilities, includes star ratings, staffing hours, turnover, penalties
- Penalties: `data.cms.gov/provider-data/dataset/g6vv-u9sr` — 16,572 penalty records with dates, types, amounts

**Columns added to verification Excel:**

| Column | Source | What it proves |
|--------|--------|----------------|
| CMS Overall Rating | Provider Info | 1-5 star overall quality |
| CMS Staffing Rating | Provider Info | 1-5 star staffing-specific |
| CMS Health Rating | Provider Info | 1-5 star inspection score |
| RN Hours/Resident/Day | Provider Info | Actual RN staffing level |
| Total Nursing Hours/Resident/Day | Provider Info | Total nurse staffing |
| Staff/RN/Admin Turnover | Provider Info | Staffing stability |
| Total Penalties | Provider Info | # of CMS penalties |
| Total Fines $ | Provider Info | Dollar amount of fines |
| Payment Denials | Provider Info | CMS payment denials |
| Complaint Deficiencies | Provider Info | # deficiencies from complaints |
| Abuse Flag | Provider Info | CMS abuse investigation flag |
| Penalty Details | Penalties | Specific penalties last 3 years |

**Matching:** Fuzzy match by facility name + state. Normalizes names (removes LLC/Inc, punctuation, extra spaces). Try exact match first, then substring containment.

**Caching:** Downloads CSV files to `cache/` directory, refreshes weekly. One `init_cms_cache()` call at startup loads all data into memory for fast lookups.

**Key pattern:** Match facility by name + state against CMS data, not by CCN. CMS uses different facility names than the Excel sometimes. Fuzzy matching with `setintersection` on normalized words works well.

**Implementation:** `cms_data.py` module with:
- `init_cms_cache()` — call once at startup, downloads CSVs to `cache/`, refreshes weekly
- `get_facility_cms(facility_name, state)` — returns dict with all CMS fields
- `match_facility(name, state, data)` — normalizes names (strips LLC/Inc/punctuation), tries exact match then substring containment with word overlap scoring. MUST handle both full state names ("Arizona") and abbreviations ("AZ") — see pitfall #0.
- Integrated into `verify_all.py` via `**get_facility_cms()` spread into each result row

## OVERLAPPING SKILLS

This skill (`license-verification`) supersedes `nha-license-verification` (regulatory-automation category). The older skill covers the same NHA workflow but is less comprehensive — it lacks CMS data integration, charts, add_facility.py, reconcile.py, and the detailed state-specific patterns. If the curator consolidates, absorb `nha-license-verification` into this skill and delete the old one.

## Streamlit Frontend (BUILT)

**File:** `app.py` — single Python file, runs at `http://localhost:8501`

```bash
cd D:/license-verification
streamlit run app.py
```

**4 pages (tabs in main content — no sidebar):**
1. **📊 Run Verification** — one-click full verification with live progress bar, auto-opens report
2. **➕ Add Facility** — form fields for facility name, state (dropdown), admin name; verifies license and adds to master Excel
3. **🔄 Reconcile Rosters** — file upload (xlsx/csv), compares against master, shows flagged issues by severity
4. **📁 View Reports** — lists all reports in `results/`, open/download buttons

**Key details:**
- Uses `os.startfile()` to auto-open reports after generation
- State dropdown includes all 17 states with working/blocked indicators
- Reconcile page shows issues grouped by type with severity icons (🔴 HIGH, 🟡 MEDIUM, 🟠 WARNING, 🔵 INFO)
- Reports page shows file size, modification date, and download buttons
- Install: `pip install streamlit` (one dependency)

## References

Open only what you need:

- `references/cms-data-sources.md` — CMS Provider Data datasets, CSV download URLs, key columns, matching strategy, caching (concise quick-reference)
- `references/executive-defense-data.md` — CMS Provider Data datasets, state open data APIs, recommended columns for executive defense against staffing/licensing accusations
- `references/executive-data-sources.md` — CMS Provider Data datasets, state open data APIs, and recommended columns for executive dashboards
- `references/excel-charts-pattern.md` — openpyxl chart patterns (pie, bar, horizontal bar) with code snippets

- `references/cdph-nha-scraper.md` — California scraper details (detail page pattern, JS extraction, name matching)
- `references/texas-tulip-scraper.md` — Texas scraper details
- `references/project-scaffold.md` — Project structure and setup
- `references/verification-log-2026-06-22.md` — Session test results per state
- `references/verification-log-2026-06-23.md` — 2026-06-23 full state run with real Excel names, semi-auto expansion, master verifier
- `references/captcha-blocks-and-lightning-fixes.md` — CAPTCHA/reCAPTCHA blockers, language overlays, Lightning combobox fixes, Arizona filter limitation
- `references/semi-automated-captcha-bypass.md` — Semi-automated browser approach for CAPTCHA-blocked states, state configs, usage guide
- `references/semi_auto_selectors.md` — Verified selectors for AK, CO, IA, KS, SC, TN, UT, WA
- `references/expiration-days-calculation.md` — Universal days_until_expiry calculation pattern

## Scripts

- `scripts/verify_one_state.py` — Run a single state scraper against one admin name for fast validation.
- `scripts/semi_auto.py` — Semi-automated browser for CAPTCHA-blocked states (AK, CO, IA, KS, SC, TN, UT, WA). Opens a real Chrome window, waits for the user to solve ONE CAPTCHA, then auto-searches all admin names for that state. Saves results to `results/`.
- `scripts/verify_all.py` — Master verifier: reads Excel, runs all state scrapers, writes PASS/FAIL/NEEDS MANUAL REVIEW Excel with expiration alerts and summary.
- `scripts/run_nightly.py` — Nightly wrapper around `verify_all.py` with timestamps and error handling.
