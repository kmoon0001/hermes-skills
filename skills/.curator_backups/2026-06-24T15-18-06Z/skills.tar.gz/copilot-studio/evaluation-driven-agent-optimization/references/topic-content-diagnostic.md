# Topic Content Diagnostic Pattern

When eval scores drop, dump ALL topic content via Dataverse API and check for issues.

## Quick Diagnostic Script

```javascript
// Run via Playwright connected to Dataverse org page
const filter = `_parentbotid_value eq '${BOT_ID}' and componenttype eq 9`;
const url = `${ORG}/api/data/v9.2/botcomponents?$select=name,content,data,statecode&$filter=${encodeURIComponent(filter)}&$orderby=name&$top=100`;
const resp = await fetch(url, { credentials: 'include', headers: { 'Accept': 'application/json' } });
const data = await resp.json();

for (const t of data.value) {
  const c = t.content || '';
  const flags = [];
  if (t.statecode !== 0) flags.push('INACTIVE');
  if (!c.includes('AdaptiveDialog')) flags.push('NO-AdaptiveDialog');
  if (c.includes('kind: Question')) flags.push('Question-node');
  if (c.includes('buttons:')) flags.push('Buttons');
  if (!c.includes('EndDialog') && c.includes('AdaptiveDialog')) flags.push('NoEndDialog');
  if (c.includes('SearchAndSummarizeContent')) flags.push('SearchSummarize');
  if (c.length < 200 && c.length > 0) flags.push('STUB');
  console.log(`${t.name} (${c.length}c) [${flags.join(' | ') || 'OK'}]`);
}
```

## Issue Categories

| Category | Signal | Impact | Fix |
|----------|--------|--------|-----|
| **Question node** | `kind: Question` in content | Agent asks question instead of answering → SR eval fails | Replace with `SearchAndSummarizeContent` + `EndDialog` |
| **Interactive menu** | `buttons:` or `AdaptiveCard` | Agent returns card/menu instead of text → eval fails | Give text answer first, offer menu as follow-up |
| **Inactive topic** | `statecode !== 0` | Topic doesn't fire → routing falls through | PATCH `statecode: 0` via Dataverse API |
| **Stub topic** | content < 200 chars | Returns unhelpful response | Delete or flesh out with real content |
| **No EndDialog** | Missing `kind: EndDialog` | Topic doesn't end properly, may block conversation | Add EndDialog as last action |
| **System error** | Broken action references | Agent hits error | Fix action references or delete topic |

## Correct Topic Pattern (Escalate QM Concern example)

```yaml
kind: AdaptiveDialog
beginDialog:
  kind: OnRecognizedIntent
  id: main
  intent:
    triggerQueries:
      - escalating a QM concern
      - escalate qm concern
      - escalate a quality measure concern

  actions:
    - kind: SendActivity
      id: escalation_answer
      activity: |
        [Direct text answer here]

    - kind: EndDialog
      id: end_escalation
```

## Broken Topic Pattern (DoR Summary example)

```yaml
kind: AdaptiveDialog
beginDialog:
  kind: OnRecognizedIntent
  id: main
  intent: {}
  actions:
    - kind: Question                    # ← BREAKS SR EVAL
      id: question_eM11Kq
      prompt: Which facility should this DoR summary cover?

    - kind: AdaptiveCardPrompt          # ← BREAKS SR EVAL
      id: adaptiveCardPrompt_summaryAudience
      card: |-
        [AdaptiveCard JSON with buttons]

    - kind: Question                    # ← BREAKS SR EVAL
      id: question_wLeVr8
      prompt: Which focus should lead the summary?
```

## Fix: Replace Question nodes with SearchAndSummarizeContent

```yaml
  actions:
    - kind: SearchAndSummarizeContent
      id: dor_summary_answer
      userInput: =System.Activity.Text
      additionalInstructions: |-
        [Instructions for generating the answer]
      allowLatencyMessage: false
      applyModelKnowledgeSetting: true
      responseCaptureType: FullResponse

    - kind: EndDialog
      id: end_dor_summary
```
