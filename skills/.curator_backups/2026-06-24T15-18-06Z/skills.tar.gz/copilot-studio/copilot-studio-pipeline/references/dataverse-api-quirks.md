# Dataverse API Quirks — botcomponent Table

Session-derived knowledge from 2026-06-22. Source: live API probing against `org3353a370.crm.dynamics.com` (Default) and `orgbd048f00.crm.dynamics.com` (Dev).

## `content` vs `data` Fields

Both fields are Memo type (MaxLength: 1048576) and MS Learn lists both as IsValidForUpdate: True. Reality differs:

| Field | Patchable via API? | Syncs on publish? | Purpose |
|-------|-------------------|-------------------|---------|
| `data` | YES (204 on PATCH) | N/A (source) | Authoring YAML — the source of truth you edit |
| `content` | NO (400: "Unexpected character encountered while parsing value: k") | NO | Compiled/runtime YAML — what the agent actually uses |

### The `content` rejection

When PATCHing `content` with YAML text:
```json
{ "content": "kind: AdaptiveDialog\nbeginDialog:\n..." }
```
The API returns:
```json
{
  "error": {
    "code": "0x80040265",
    "message": "Unexpected character encountered while parsing value: k. Path '', line 0, position 0."
  }
}
```

The `k` is the first character of `kind:` — the server-side plugin is trying to parse the YAML as JSON. This happens regardless of content. The field is effectively read-only via API.

### Workaround

To update `content`, edit the topic in the Copilot Studio UI and save. There is no API path.

## Auth for Dataverse API

### `az login` doesn't work for Dataverse

`az account get-access-token --resource https://<org>.crm.dynamics.com` returns a token with `aud: https://<org>.crm.dynamics.com` and `scp: user_impersonation`, but the Dataverse API rejects it with 401 + `insufficient_claims`. The Azure CLI's app registration (`04b07795-8ddb-461a-bbee-02f9e1bf7b46`) doesn't include the Dynamics 365 resource in its required resource list.

### What works

1. **`InteractiveBrowserCredential`** — Opens browser popup, gets CRM-specific token. Token expires quickly; no persistent cache between Node.js processes. Use for one-off API calls.
   ```js
   const cred = new InteractiveBrowserCredential({
     tenantId: '<tenant>',
     clientId: '04b07795-8ddb-461a-bbee-02f9e1bf7b46'
   });
   const t = await cred.getToken(['https://<org>.crm.dynamics.com/user_impersonation']);
   ```

2. **`pac` CLI** — Has its own persistent token store. Works for `pac copilot publish` and `pac copilot list`. Token stored in `tokencache_msalv3.dat` (DPAPI-encrypted, not readable by Node.js).

3. **`pac auth create --deviceCode`** — Device code flow, persistent. But may be blocked by admin policy depending on tenant.

### Batch operations

Since `InteractiveBrowserCredential` opens a browser each time, **get the token ONCE and reuse it across all API calls in a single script.** Don't call `getToken()` in a loop.

## `\r` Characters in API Responses

The Dataverse API returns `content` and `data` fields with `\r` (CR, 0x0D) characters embedded in YAML block scalars. Example:

```
content: "kind: AdaptiveDialog\r\nbeginDialog:\r\n  kind: OnRecognizedIntent\r\n..."
```

The `\r` characters are literal content within the YAML string. When written to files and parsed by `js-yaml`, they break block scalar parsing.

**Fix:** Strip `\r` before YAML processing:
```js
const clean = apiResponse.data.replace(/\r/g, '');
```

## System Topics — Protected

These topics are managed by the platform. Modifying their `data` field breaks `pac copilot publish`:

- Multiple Topics Matched
- End of Conversation
- Goodbye
- On Error
- Reset Conversation
- Conversational boosting
- Sign in

Identify them by name or by `beginDialog.kind: OnSystemRedirect` / `OnSelectIntent` in their YAML.

## PATCH Success Pattern

For updating `data` field:
```js
const body = JSON.stringify({ data: fixedYAML });
const r = await fetch(orgUrl + '/api/data/v9.2/botcomponents(' + topicId + ')', {
  method: 'PATCH',
  headers: {
    'Authorization': 'Bearer ' + token,
    'Content-Type': 'application/json; charset=utf-8'
  },
  body
});
// Expect 204 on success
```

For updating `name` or other simple fields:
```js
const body = JSON.stringify({ name: 'New Name' });
// Same pattern, expect 204
```
