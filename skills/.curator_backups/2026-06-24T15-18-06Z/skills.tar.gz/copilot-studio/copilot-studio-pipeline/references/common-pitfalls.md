# Common Pitfalls

Each pitfall maps to a known Copilot Studio failure mode. Cross-reference with `taxonomy-rules.md` for the full rule and `topic_lint.cjs` for automated detection.

## Structural

- `botcomponent` table `componenttype` = 9 (Topic V2). Older payloads used 0.
- `schemaname` field is REQUIRED on create. Pattern varies per agent: check the agent-specific skill.
- `parentbotid` uses OData-bound syntax: `'parentbotid@odata.bind': '/bots(BOT_ID)'`.
- Empty `beginDialog.actions` triggers R3 → publish crashes.
- Orphan Question nodes (no `property` and no `actions`) trigger R4 → SR collapses.
- Trigger overlap > 60% Jaccard across topics → topic routing drift, eval variance jumps.
- Every `InvokeConnectedAgentTaskAction` must have correct `botSchemaName` — verify against actual bot's `schemaname` field before publishing. Wrong schema → "Error" in eval (validated: TDA had PT/OT routing to SLP).
- Never mix "NOT JSON" and "Return exactly one valid JSON" in same `additionalInstructions` — causes model confusion.

## Topic Configuration

- `clearTopicQueue: false` on EndDialog triggers R9 → topic stacking (validated: PT conv 55→40%).
- `allowLatencyMessage: true` triggers R10 → misleads AI grader, "irrelevant" failures.
- `SearchSpecificFiles` or `fileSearchDataSource` triggers R11 → restricts search, groundedness failures.
- `knowledgeSources: kind: SearchAllKnowledgeSources` triggers R12 → invalid field, runtime errors.
- `applyModelKnowledgeSetting: false` triggers R13 → knowledge gaps, score collapse.

## Eval

- **Eval endpoint 404 (PUBLIC PREVIEW, regional rollout).** Even with valid bearer token, `api.powerplatform.com/copilotstudio/.../makerevaluation/...` returns 404 on some tenants. Treat as endpoint-not-yet-available, NOT auth failure. eval_bot.cjs tags such rows `source=unavailable`.

## GPT Instruction Corruption

- **Oversized instructions** cause response truncation in eval. Healthy ranges: PT/OT 3,000-5,500 | SLP 1,800-3,000 | TDA 4,000-7,000 | QM Coach 2,000-6,000. Query `botcomponents` where `componenttype eq 15` to check.
- **Ghost components** — empty 0-char GPT components sitting next to the real one. Delete them.
- **Duplicate section headers** — "RESPONSE LENGTH" appearing >1x means instructions are duplicated. Run anti-corruption checklist.
- **Verbose knowledge source lists** in GPT instructions waste instruction budget. The model already has access to configured knowledge sources — don't list them in instructions.
