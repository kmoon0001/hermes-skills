---
name: copilot-studio-pipeline
description: "Build, lint, deploy, and evaluate any Copilot Studio agent using D:/my agents copilot studio/pipeline/ scripts. Agent-agnostic: load alongside copilot-studio-<agent-name> for bot-specific IDs and rules."
version: 3.2.0
author: Copilot Studio Pipeline
license: MIT
platforms: [windows, linux, macos]
metadata:
  hermes:
    tags: [copilot-studio, dataverse, publish, auth, oauth, pac-cli, anti-corruption]
    homepage: https://learn.microsoft.com/microsoft-copilot-studio/
---

# Copilot Studio Pipeline — Universal Working Rules

**Rule-authoring procedure:** prefer decision-procedure framing over NEVER/ALWAYS rules. Reserve NEVER for hard engineering limits (broken OAuth). Reserve ALWAYS for code-enforced invariants (lint runs automatically). See `references/` for detailed rules per concern.

## Decision Procedure

1. **Say no to bad requests.** If a request is unsafe, against best practices, overcomplicates things, or contradicts existing work, decline with reasoning. Don't implement just because the user asked — protect the code. (User-explicit instruction, 2026-06-22.)
2. **Auth:** route through `auth_helper.cjs`. Chain: `az login` → AzureCliCredential → MSAL cache. On failure: `InteractiveBrowserCredential` (opens browser popup). On decline: ask framed as request, offer "skip this run". Skip app registration client secrets unless tenant requires it.
   - **PITFALL: `az login` tokens don't include Dynamics 365 claims.** The Azure CLI token works for ARM but returns 401 on Dataverse. Use `InteractiveBrowserCredential` with `clientId: '04b07795-8ddb-461a-bbee-02f9e1bf7b46'` and scope `https://<org>.crm.dynamics.com/user_impersonation`. This opens a browser popup each time — there's no persistent token cache between Node.js processes. For batch operations, get the token ONCE and reuse it across all API calls in a single script.
   - **PITFALL: `pac` CLI has persistent auth that works.** `pac auth select` + `pac copilot publish` use their own token store. Use `pac` for publish operations; use `InteractiveBrowserCredential` only for Dataverse API PATCH calls.
3. **Lint is a gate:** run `topic_lint.cjs` BEFORE writing topics to Dataverse. Block on R1-R4 errors; R5-R13 are warnings. See `references/taxonomy-rules.md` for rule details.
4. **Eval is append-only:** add rows to `eval_history.jsonl`, never rewrite.
5. **Don't overwrite non-empty topic content blindly.** GET first. If content is non-empty and you have a stub, stop and ask.
6. **Be autonomous.** Do obviously correct actions. Reserve questions for genuine ambiguity.
7. **Deliver files, not chat-pasted code.** No `MEDIA:` tags in CLI.

## Workflow Defaults

Topic YAML edits → topic_lint.cjs → test_topics.cjs → write `data` field to Dataverse via API → pac copilot publish → eval_bot capture.

- Source of truth = local YAML file per agent. Never edit topics only in Dataverse.
- MS Learn = source-of-truth for API schemas. Pull docs before writing against unknown endpoints.
- Don't hand-roll a YAML parser.
- **`data` field** = authoring YAML, patchable via Dataverse API PATCH.
- **`content` field** = compiled/runtime YAML, only patchable via Copilot Studio UI. Publishing does NOT sync `data` → `content`.

## Pipeline Folder Layout

```
D:/my agents copilot studio/pipeline/
├── auth_helper.cjs         # DefaultAzureCredential chain + InteractiveBrowserCredential fallback
├── topic_lint.cjs          # R1-R7, R9-R13 lint over topic YAMLs (R8 removed — HITL is a design choice, not a lint error)
├── test_topics.cjs         # Automated test suite (yaml, structure, lint, knowledge, triggers)
├── publish_pipeline.cjs    # Auth → Lint → Test → Empty-check → pac publish → Eval-capture
├── eval_bot.cjs            # Tries PP REST eval API; falls back to "unavailable" row; gates
├── routing_matrix.json     # Per-topic intent / triggers / expected_response_shape
├── eval_history.jsonl      # Append-only run history (git-track it)
├── agents/                 # Per-agent config files (BOT_ID, ENV_ID, ORG_URL, topic path)
│   └── <agent-name>.json
└── references/             # Per-concern rule files (see below)
    ├── anti-corruption-checklist.md  # Pre-patch detection, write pattern, post-patch verify
    ├── taxonomy-rules.md             # Copilot Studio taxonomy rules + lint rule mapping
    ├── hitl-patterns.md             # HITL confirmation patterns (MS Learn best practice)
    ├── common-pitfalls.md           # Known failure modes + R1-R13 mapping
    ├── api-endpoints-verified.md    # Endpoint status catalog
    └── preferred-auth.md            # Auth decision tree
```

## Reference Files (load when needed)

| File | When to load |
|------|-------------|
| `references/therapy-ai-agents-master-reference.md` | **START HERE** — full journey, remediation log, all rules, FAQ, agent-specific details |
| `references/anti-corruption-checklist.md` | Before ANY patch to botcomponent data field |
| `references/taxonomy-rules.md` | When authoring or reviewing topic YAML |
| `references/hitl-patterns.md` | When building patient-facing confirmation flows |
| `references/common-pitfalls.md` | When debugging publish failures or eval regressions |
| `references/content-vs-data-fields.md` | Why `content` PATCH fails (400) and only `data` is writable via API |
| `references/api-endpoints-verified.md` | Before writing code against a new API endpoint |
| `references/dataverse-api-quirks.md` | Before patching botcomponent fields via Dataverse API — content vs data, auth, \r issues |
| `references/preferred-auth.md` | When auth chain fails and you need the fallback procedure |

## How to Research (MS Learn MCP pattern)

1. `mcp_microsoft_learn_microsoft_docs_search` with the most specific query.
2. Read the canonical doc. Note: a single doc can hide multiple endpoints.
3. For API surface, hit `mcp_microsoft_learn_microsoft_docs_fetch` against the `learn.microsoft.com/en-us/rest/api/...` reference.
4. Find a *related* called-out endpoint — cross-check before assuming.
5. Confirm with a live probe via `auth_helper.getBearerToken(scope)` + `fetch()`.

## Automated Testing

```bash
node test_topics.cjs                                  # test all topics
node test_topics.cjs --agent qm_coach_v2              # test specific agent
```

Also runs automatically as step 3/6 in `publish_pipeline.cjs`. Exit 0 = pass, exit 1 = must fix before publish. System topics (OnUnknownIntent) and aggregate files (consolidated/fine_tuned) are skipped automatically.

## Debugging

All scripts use Node.js `console.log/error/warn`. Pipe to log file: `node publish_pipeline.cjs qm_coach_v2 2>&1 | tee pipeline.log`. When things break: check `probe()` for auth, `topic_lint.cjs` for YAML errors, `eval_history.jsonl` for last successful run.

## How to Extend

Before adding any new feature, fallback, or abstraction, run this check:
1. Does the existing auth chain / lint / test already handle this case?
2. Will this add code that needs maintenance but rarely gets used?
3. Is there a simpler path (e.g. "don't do that" instead of "add a fallback for when it fails")?
## How to Extend

- Auth: `require('./auth_helper.cjs').getBearerToken(scope)`. Never re-implement.
- Lint rule: add R14+ to `topic_lint.cjs` with MS Learn reference at top.
- Test: add `test*` function in `test_topics.cjs`, call from `main()`.
- Pipeline stage: drop `.cjs` in pipeline folder, add `stepN+1()` to `publish_pipeline.cjs`.
- New agent: create `agents/<agent-name>.json` with bot_id, env_id, org_url, topic_path.

## Dataverse API: content vs data Fields (Jun 22, 2026)

**`content` field is NOT writable via PATCH** — despite MS Learn listing it as `IsValidForUpdate: True`. PATCHing `content` returns 400: "Unexpected character encountered while parsing value: k". The platform has a server-side plugin that rejects direct writes. Only `data` (OBI format) is writable.

**`pac copilot publish` does NOT sync `content` from `data`** — after publishing, `content` remains stale if it was previously different from `data`. The two fields stay out of sync.

**Implication**: To update the live agent's behavior, you must update `content` through the Copilot Studio UI (code editor), NOT via the Dataverse API. The API can only update `data`, `name`, `statecode`, and `description`.

**Workaround for topic fixes**: If the `data` field already has the correct YAML (no Question nodes, uses Activity.Text), the fix is done — but `content` must be updated via the UI for the live agent to use it. Guide the user to paste YAML into the code editor.

## Session Pitfalls (Lessons Learned)

### Test before restructure
We restructured SKILL.md into reference files BEFORE running the test suite on the live agent. This was backwards — we built rules around assumptions, not data. **Always run test_topics.cjs on the agent first, see what fails, fix the agent, THEN restructure docs.**

### Exclude aggregate files from linting and testing
Files matching `consolidated|fine_tuned|all_topics|backup|archive` are `pac copilot pull` export artifacts — source control snapshots with empty sub-entries. They trigger false failures. Both `topic_lint.cjs` and `test_topics.cjs` now filter them out.

### Skip system topics (OnUnknownIntent)
Topics with `beginDialog.kind: OnUnknownIntent` are system topics (Conversational Boosting, Fallback, etc.). They have no trigger phrases by design. Both `topic_lint.cjs` and `test_topics.cjs` skip them.

### R8 (HITL) was too broad
R8 fired on ANY topic with SearchAndSummarizeContent + EndDialog but no AdaptiveCard. This caught informational topics (DoR Summary, Resident Outlier) that search knowledge and display results — they don't take actions. Per MS Learn, Adaptive Card confirmation is for actions (write to EHR, send to patient), not for displaying information. Removed R8 from both linter and test suite.

### InteractiveBrowserCredential opens browser every time
`InteractiveBrowserCredential` from `@azure/identity` opens a browser popup for EVERY `getToken()` call if the cached token is expired. The token expires in ~1 hour. Each new Node.js process needs a fresh browser interaction. User frustration: "why does it keep asking login".

**Fix**: Get the token ONCE at the start of the script and reuse it for all API calls. Do NOT call `getToken()` in a loop or per-request. Pass the token string to all functions.

**Better alternative**: Use `pac` CLI for publish operations (it has persistent auth). Use `InteractiveBrowserCredential` only for Dataverse API calls that `pac` can't do.

### GPT instruction corruption detection
Query `botcomponents` where `componenttype eq 15` for the bot using `_parentbotid_value` (not `botid`). Check for:
- Size above 6000 chars (QM Coach V2 was 7768 — above ceiling)
- Duplicate section headers ("RESPONSE LENGTH" appears >1x)
- Ghost components (0-char empty entries — delete them)
- Mid-word splices, BOM characters

### GPT instruction remediation workflow
When eval scores are low, follow this diagnosis path:
1. Query GPT components (`componenttype eq 15`) — check size and duplication
2. If >6000 chars: compress. Remove inline knowledge source list (model already has access via knowledge config). Consolidate overlapping sections.
3. Check topic `additionalInstructions` for overlap with GPT-level instructions. Each topic should have ≤4 focused bullets (Kiro guardrail). Detailed format guidance belongs at topic level; behavioral guidance belongs at GPT level.
4. Delete ghost components (0-char entries).
5. PATCH via Dataverse API, publish, re-test.

### Dataverse API auth (Jun 22, 2026)
- `az login` tokens DON'T work for Dataverse — returns 401 "insufficient_claims" even with correct resource audience. The `az` token is for Azure Resource Manager, not Dynamics 365.
- `InteractiveBrowserCredential` from `@azure/identity` works but opens a browser popup each time and tokens expire fast (~1 hour). No persistent cache between Node.js processes.
- `pac` CLI has persistent auth and works for `pac copilot publish`, but there's no way to extract the token for use in custom scripts.
- **Workaround for scripts**: Use `InteractiveBrowserCredential` with `tokenCachePersistenceOptions: { name: 'session_name', enableUnprotectedStorage: true }` to cache tokens within a single process. All API calls must happen in the same Node.js process — token can't be reused across processes.
- **Best path for topic updates**: Edit topics in Copilot Studio UI (code editor) rather than via API. The API can PATCH `data` but NOT `content`, and publishing doesn't sync them.

### content vs data field divergence (Jun 22, 2026)
- `data` = source YAML (authoring format). PATCHing works via API.
- `content` = compiled YAML (runtime format). PATCHing fails with 400 even for identical content.
- Publishing does NOT sync `content` from `data`. They can diverge.
- If `content` has stale patterns (e.g., Question nodes) but `data` is correct, the live agent may still exhibit the old behavior.
- **The only way to update `content` is through the Copilot Studio UI code editor.**
- Pattern: topics with correct `data` but stale `content` need manual UI fix + publish.

### System topics are off-limits (Jun 22, 2026)
- DO NOT modify system topics (Multiple Topics Matched, End of Conversation, Goodbye, Conversational boosting, etc.) via Dataverse API.
- Modifying them breaks `pac copilot publish` with a generic "Failed" error.
- If accidentally modified, user must reset them in Copilot Studio UI (topic menu → Reset to default).
- System topics have `beginDialog.kind: OnSystemRedirect` or `OnSelectIntent` — detect and skip these in batch operations.

### Routing matrix must use YAML filenames
The routing_matrix.json originally used display names ("Coaching Corner") but YAML files use snake_case ("coaching_corner"). Rebuilt to use actual YAML filenames as identifiers, pulled trigger phrases directly from YAML.

### Dataverse `content` field is NOT patchable via API
**CRITICAL:** Despite MS Learn listing `content` as IsValidForUpdate: True, the Dataverse API rejects PATCH requests on the `content` field with "Unexpected character encountered while parsing value: k". The platform has a server-side plugin that processes `content` differently from `data`. **Only `data` is patchable via API.** The `content` field can only be updated through the Copilot Studio UI. See `references/dataverse-api-quirks.md` for full details.

### `data` does NOT sync to `content` on publish
Publishing via `pac copilot publish` succeeds but does NOT regenerate `content` from `data`. The two fields can diverge: `data` (authoring YAML, writable via API) and `content` (compiled/runtime YAML, only writable via UI). If `data` is correct but `content` is stale, the live agent uses the stale `content`. **To sync, edit the topic in Copilot Studio UI and save.**

### `\r` characters from Dataverse API break YAML parsing
The Dataverse API returns `content` and `data` fields with `\r` (carriage return) line separators embedded in YAML block scalars. When written to files, these `\r` characters break `js-yaml` parsing. **Always strip `\r` from API responses before YAML processing:** `content.replace(/\r/g, '')`.

### System topics are protected — do not modify
Topics named "Multiple Topics Matched", "End of Conversation", "Goodbye", "On Error", "Reset Conversation", "Conversational boosting", "Sign in" are system topics. Modifying their `data` field (e.g., removing Question nodes) breaks `pac copilot publish`. **These topics are managed by the platform — leave them alone.**

### Question-node topics and Single Response eval
Topics with `kind: Question` nodes that ask "please paste the document" before answering will fail Single Response eval — the eval expects a direct answer, not a question. Fix: remove the Question node, set `userInput: =System.Activity.Text`, connect trigger directly to `SearchAndSummarizeContent`. This fix must be done in the Copilot Studio UI (see `content` field pitfall above).

## Process Rules

- **Finish one agent before starting the next.** User has an explicit ordering. Do not jump between agents mid-task. Complete all fixes for one agent (topic fixes → instruction fixes → publish → eval) before moving to the next. User called this out when I started working on SLP instead of QM V2.
- **Test before restructure.** Always run `test_topics.cjs` on the actual agent BEFORE building new rules or restructuring docs. Validate with real data first, then organize. Don't build infrastructure around assumptions.
- **Skip aggregate files in tests.** `test_topics.cjs` skips files matching `consolidated|fine_tuned|all_topics|backup|archive` — these are `pac copilot pull` export snapshots, not active topic definitions. Same filter as `topic_lint.cjs` for R5 overlap.
- **Skip system topics in tests.** Topics with `beginDialog.kind: OnUnknownIntent` are system topics (Conversational Boosting, Fallback, etc.) — they don't have custom triggers and aren't expected to pass custom topic rules.
- New reference file: add to `references/`, add one-line pointer in the Reference Files table above.
