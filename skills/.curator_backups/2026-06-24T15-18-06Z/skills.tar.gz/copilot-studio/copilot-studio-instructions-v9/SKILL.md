---
name: copilot-studio-instructions-v9
description: "Working v9 instructions template for therapy audit agents - conditional RESPONSE FORMAT, conversation continuity, natural citations."
version: 1.0.0
author: Hermes Agent
tags: [copilot-studio, instructions, template]
---

# Copilot Studio Agent Instructions Template (v9)

The v9 pattern works for all therapy audit agents (OT, PT, SLP). Key lesson: conditional RESPONSE FORMAT must NOT break single-response grading.

## Critical Design Rules

### Agent Description Must Match Instruction Output Format
The agent description field (on the Overview page, under Details) is read by the model as system-level context. If the description says "Returns deterministic JSON with confidence scores and SHAP-style feature attribution" but the instructions say "Use RESPONSE FORMAT: 1. Classification, 2. Compliance Findings...", the model follows the DESCRIPTION over the instructions.

**This caused PT SR to drop from 96% to 82%.**

**Correct description for audit agents:**
```
Returns compliance findings with risk levels, scores, and recommendations. Part of the Therapy Documentation Audit multi-agent system. HIPAA-compliant: references record_id pointers only. AI-generated output requires human verification.
```

**WRONG description (causes JSON output):**
```
Returns deterministic JSON with confidence scores and SHAP-style feature attribution.
```

**Rule:** Audit agent descriptions must say "Returns compliance findings" (natural language), NEVER "Returns JSON" or "Returns deterministic output".

### RESPONSE FORMAT Must Be Unconditional for SR Tests
The SR test set asks questions like "Can you audit my OT evaluation for Medicare compliance?" without providing document text. If instructions say "Use for full document audits only", the model skips the format for these questions and gets penalized.

**Working pattern** (validated at 97-99% SR):
```
RESPONSE FORMAT — Use for ALL document-related questions:
1. Classification
2. Compliance Findings [HIGH/MODERATE/LOW RISK]
3. Score X/100
4. Missing Elements
5. Recommendations (Top 3)
6. Advisory
```

### Conversation Follow-up Must Adapt Format
For conversation eval, the first turn uses full RESPONSE FORMAT. Subsequent turns must use focused answers without repeating the full format.

**Working pattern** (validated at 90% Conv for OT):
```
- For single-response questions: always use RESPONSE FORMAT.
- For conversation follow-ups: provide focused answers referencing prior context.
- For general clinical questions not about any document: give a natural answer.
```

### Citation Instructions
```
- Cite knowledge sources by natural source name. Examples: "Per CMS Chapter 15...", "Per AOTA/APTA/ASHA..."
- Do not output cite:1, Citation-1, [1]: cite:1, or metadata tags.
```

### No Refusal Rule
```
- NEVER refuse to help or ask the user to rephrase.
- NEVER say "please provide your content" — use the document type to generate a preliminary audit.
- If record text unavailable, provide best-effort compliance checklist and state what must be verified.
```

## Current Agent Scores (June 18 2026, 3-run baselines per Microsoft Learn)

| Agent | SR (3-run avg) | Conv (3-run avg) | SR Variance | Conv Variance | Status |
|-------|---------------|-------------------|-------------|---------------|--------|
| OT | 98.3% ✅ | 98.3% ✅ | 4% PASS | 5% PASS | STABLE — do not touch |
| PT | 88.0% ⚠️ | 88.3% ⚠️ | 12% INVESTIGATE | 5% PASS | SR grader unreliable; Conv blocked by eval case mismatch |
| SLP | 92.7% ⚠️ | 80.0% ❌ | 4% PASS | 10% BORDERLINE | SR stable; Conv blocked by eval case mismatch (98% of cases expect ask-first) |
| TDA | 88.0% ⚠️ | 90.0% ⚠️ | 15% INVESTIGATE | 10% BORDERLINE | Both borderline; routing tests, no instruction conflict |

Note: All scores show ±10-15% variance per run due to GPT-5 Chat non-determinism + LLM grader variance. See `evaluation-driven-agent-optimization/references/drift-quantified-analysis.md` for full statistics from 100 runs per agent.

**PRIMARY BLOCKER for PT/SLP Conv: Evaluation case mismatch.** 94% of PT and 98% of SLP conversation test cases expect the agent to ask for record_id first, but instructions say "answer directly." The agent fails for following its own instructions. Fix: update evaluation cases to match answer-first behavior, or switch to General quality grading. See `evaluation-driven-agent-optimization/references/eval-case-instruction-mismatch-detection.md`.

## Key Lesson: Topic YAML > Agent Instructions for Conv

The agent-level instructions matter for SR scoring, but **topic-level additionalInstructions** are the primary driver of Conversation eval failures. When Conv is low but SR is high, the fix is almost always in the topic YAML (800-char limits, missing citations), NOT in the agent instructions.

**Critical**: Fix ALL audit topics at once, not just the failing one. Fixing 1 of 4 SLP topics caused the score to swing 85% → 95% → 85% (non-deterministic hit on unfixed topics). Extract the template, check every topic, fix all in one pass.

**CB topics matter too**: The Conversational Boosting (system) topic is the fallback for ALL unmatched queries. If it has an 800-char limit, SR drops while Conv stays high. TDA SR dropped from 99% to 92-94% because of this.

## Instruction Budget Consolidation (Microsoft Learn, June 2026)

When instructions exceed ~50 lines, the model follows them inconsistently. Consolidation produced 16-23% size reduction:

| Agent | Old | New | Reduction |
|-------|-----|-----|-----------|
| PT | 5096 chars (61 lines) | 3949 chars (46 lines) | 23% |
| SLP | 4504 chars (60 lines) | 3618 chars (46 lines) | 20% |
| TDA | 1888 chars (29 lines) | 1587 chars (25 lines) | 16% |

**Technique:**
1. CONSOLIDATE: merge overlapping rules (citation rules appeared 5x → 1x)
2. PRIORITIZE: critical rules first (models attend to beginning/end)
3. SIMPLIFY: remove redundant XAI section (rules already in BEHAVIOR)
4. EXTERNALIZE: move clinical checklists into knowledge sources

**Preserved:** conditional format (PT), unconditional (SLP), soft language, clinical content, safety disclaimers.

**Consolidated instruction files:** `D:\my agents copilot studio\pt_instructions_consolidated.txt`, `slp_instructions_consolidated.txt`, `tda_instructions_consolidated.txt`

## TDA Routing Agent Instructions (v10 — June 2026)

TDA is NOT an audit agent — it's an orchestration router. Its instructions must:

1. **Name connected child agents explicitly**: PT_Specialist, OT_Specialist, SLP_Specialist. Copilot Studio uses these exact names to route. "Route to the PT specialist" without the connected agent name may fail.

2. **Include Medicare Part A/B routing context**:
   - Part A: SNF stays, PDPM, MDS, Section GG, Part A eval/recert
   - Part B: Outpatient, Plan of Care 485, CPT billing codes
   - TDA infers Medicare part from document type and passes to specialist

3. **Keep instructions SHORT** — TDA was most stable at 28 lines (27% SR range). Adding verbose routing logic increases variance.

**CRITICAL**: TDA's CB (Conversational Boosting) topic should KEEP the 800-char limit. Short focused routing responses score better than verbose ones. Audit agents (OT/PT/SLP) should REMOVE the limit.

## Current Recommended Instruction Files (June 18 2026)

These consolidated files are the HYBRID FORMULA — OT behavioral patterns + discipline content. Use these as the canonical source for manual paste:

| Agent | File | Chars | Notes |
|-------|------|-------|-------|
| PT | `D:\my agents copilot studio\pt_instructions_consolidated.txt` | 3,957 | Conditional RESPONSE FORMAT, PT-specific caregiver/Section GG content |
| SLP | `D:\my agents copilot studio\slp_instructions_consolidated.txt` | 3,626 | Conditional RESPONSE FORMAT, SLP-specific dysphagia/cognitive/AAC content |
| TDA | `D:\my agents copilot studio\tda_instructions_consolidated.txt` | 2,589 | Routing agent — short, names connected agents explicitly |
| OT | `D:\my agents copilot studio\ot_instructions_v9_final.txt` | ~3,500 | DO NOT CHANGE — OT is stable at 99%/100% |

**Injection method for instructions**: Use Playwright `fill()` on the contenteditable div (proven reliable, auto-saves). See `copilot-studio-instructions-editor` skill pitfall 0b.1 for the exact pattern. Manual paste from Notepad is always the fallback.

## Known Issues

- **TDA CB topic fix still NOT injected** — `tda_fix_cb.yaml` exists but Monaco injection corrupts YAML. Needs manual paste into Conversational Boosting system topic.
- **SLP Conv 80%** — Multiple Conv Guards creating routing conflicts. Guard topic count inversely predicts stability (0 guards = OT 99%, 15+ guards = PT/SLP drift).
- **PT/SLP Conv blocked by eval case mismatch** — 94% of PT and 98% of SLP conversation test cases expect ask-first behavior, but instructions say answer-first. Fix: update eval cases or switch grading method.
- **OT-style simplification caused massive regression** (June 18) — Copying OT's short format to PT/SLP/TDA without discipline content caused SLP 90%→75%, PT erratic swings. The HYBRID formula (OT patterns + discipline content) is the safe path.
- **Instruction changes have diminishing returns past ~90% Conv.** Topic YAML is the primary lever for Conv improvements.
- **SLP has 5+ audit topics** (Daily, Evaluation, Discharge, Progress Note, Recertification, Dysphagia, Caregiver). Progress Note and Recertification are NOT visible on Overview page — must use Topics tab.
- **Agent description affects model behavior.** If description says "Returns JSON" but instructions say "Use RESPONSE FORMAT", model follows description. Check description field for conflicts. PT SR dropped 96%→82% from this conflict.

**See `references/ms-learn-eval-framework.md` for Microsoft Learn evaluation triage framework, thresholds, and non-determinism rules.**
